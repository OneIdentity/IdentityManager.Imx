(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('imx-qbm-dbts')) :
    typeof define === 'function' && define.amd ? define(['exports', 'imx-qbm-dbts'], factory) :
    (global = global || self, factory(global['imx-api'] = {}, global.imxQbmDbts));
}(this, (function (exports, imxQbmDbts) { 'use strict';

    var __extends = (undefined && undefined.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    };
    var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    };
    (function (OutstandingAction) {
        OutstandingAction[OutstandingAction["Delete"] = 0] = "Delete";
        OutstandingAction[OutstandingAction["DeleteState"] = 1] = "DeleteState";
        OutstandingAction[OutstandingAction["Publish"] = 2] = "Publish";
    })(exports.OutstandingAction || (exports.OutstandingAction = {}));
    var TypedClient = /** @class */ (function () {
        function TypedClient(client, translationProvider) {
            this.OpsupportNamespaces = new OpsupportNamespacesWrapper(client, translationProvider);
            this.OpsupportOutstandingTables = new OpsupportOutstandingTablesWrapper(client, translationProvider);
            this.OpsupportSyncDatastore = new OpsupportSyncDatastoreWrapper(client, translationProvider);
            this.OpsupportSyncJournal = new OpsupportSyncJournalWrapper(client, translationProvider);
            this.OpsupportSyncJournalfailure = new OpsupportSyncJournalfailureWrapper(client, translationProvider);
            this.OpsupportSyncJournalmessage = new OpsupportSyncJournalmessageWrapper(client, translationProvider);
            this.OpsupportSyncJournalobject = new OpsupportSyncJournalobjectWrapper(client, translationProvider);
            this.OpsupportSyncShell = new OpsupportSyncShellWrapper(client, translationProvider);
        }
        return TypedClient;
    }());
    var OpsupportNamespaces = /** @class */ (function (_super) {
        __extends(OpsupportNamespaces, _super);
        function OpsupportNamespaces() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.Ident_DPRNameSpace = _this.GetEntityValue('Ident_DPRNameSpace');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        OpsupportNamespaces.GetEntitySchema = function () {
            var columns = {
                'Ident_DPRNameSpace': {
                    ColumnName: 'Ident_DPRNameSpace',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'DPRNameSpace', Columns: columns };
        };
        return OpsupportNamespaces;
    }(imxQbmDbts.TypedEntity));
    var OpsupportOutstandingTables = /** @class */ (function (_super) {
        __extends(OpsupportOutstandingTables, _super);
        function OpsupportOutstandingTables() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.TableName = _this.GetEntityValue('TableName');
            _this.CountOutstanding = _this.GetEntityValue('CountOutstanding');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        OpsupportOutstandingTables.GetEntitySchema = function () {
            var columns = {
                'TableName': {
                    ColumnName: 'TableName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'CountOutstanding': {
                    ColumnName: 'CountOutstanding',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'DialogTable', Columns: columns };
        };
        return OpsupportOutstandingTables;
    }(imxQbmDbts.TypedEntity));
    var OpsupportSyncDatastore = /** @class */ (function (_super) {
        __extends(OpsupportSyncDatastore, _super);
        function OpsupportSyncDatastore() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.OwnerObject = _this.GetEntityValue('OwnerObject');
            _this.Name = _this.GetEntityValue('Name');
            _this.Data = _this.GetEntityValue('Data');
            _this.DisplayName = _this.GetEntityValue('DisplayName');
            _this.ShellDisplay = _this.GetEntityValue('ShellDisplay');
            _this.SystemDisplay = _this.GetEntityValue('SystemDisplay');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        OpsupportSyncDatastore.GetEntitySchema = function () {
            var columns = {
                'OwnerObject': {
                    ColumnName: 'OwnerObject',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'Name': {
                    ColumnName: 'Name',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Data': {
                    ColumnName: 'Data',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'DisplayName': {
                    ColumnName: 'DisplayName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ShellDisplay': {
                    ColumnName: 'ShellDisplay',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'SystemDisplay': {
                    ColumnName: 'SystemDisplay',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: '', Columns: columns };
        };
        return OpsupportSyncDatastore;
    }(imxQbmDbts.TypedEntity));
    var OpsupportSyncJournal = /** @class */ (function (_super) {
        __extends(OpsupportSyncJournal, _super);
        function OpsupportSyncJournal() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.CreationTime = _this.GetEntityValue('CreationTime');
            _this.UID_DPRProjectionConfig = _this.GetEntityValue('UID_DPRProjectionConfig');
            _this.ProjectionConfigDisplay = _this.GetEntityValue('ProjectionConfigDisplay');
            _this.ProjectionState = _this.GetEntityValue('ProjectionState');
            _this.ProjectionStartInfoDisplay = _this.GetEntityValue('ProjectionStartInfoDisplay');
            _this.UID_DPRJournal = _this.GetEntityValue('UID_DPRJournal');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        OpsupportSyncJournal.GetEntitySchema = function () {
            var columns = {
                'CreationTime': {
                    ColumnName: 'CreationTime',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'UID_DPRProjectionConfig': {
                    ColumnName: 'UID_DPRProjectionConfig',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ProjectionConfigDisplay': {
                    ColumnName: 'ProjectionConfigDisplay',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ProjectionState': {
                    ColumnName: 'ProjectionState',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ProjectionStartInfoDisplay': {
                    ColumnName: 'ProjectionStartInfoDisplay',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_DPRJournal': {
                    ColumnName: 'UID_DPRJournal',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'DPRJournal', Columns: columns };
        };
        return OpsupportSyncJournal;
    }(imxQbmDbts.TypedEntity));
    var OpsupportSyncJournalfailure = /** @class */ (function (_super) {
        __extends(OpsupportSyncJournalfailure, _super);
        function OpsupportSyncJournalfailure() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.ObjectDisplay = _this.GetEntityValue('ObjectDisplay');
            _this.ObjectState = _this.GetEntityValue('ObjectState');
            _this.Reason = _this.GetEntityValue('Reason');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        OpsupportSyncJournalfailure.GetEntitySchema = function () {
            var columns = {
                'ObjectDisplay': {
                    ColumnName: 'ObjectDisplay',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ObjectState': {
                    ColumnName: 'ObjectState',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Reason': {
                    ColumnName: 'Reason',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'DPRJournalFailure', Columns: columns };
        };
        return OpsupportSyncJournalfailure;
    }(imxQbmDbts.TypedEntity));
    var OpsupportSyncJournalmessage = /** @class */ (function (_super) {
        __extends(OpsupportSyncJournalmessage, _super);
        function OpsupportSyncJournalmessage() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.MessageString = _this.GetEntityValue('MessageString');
            _this.MessageContext = _this.GetEntityValue('MessageContext');
            _this.MessageSource = _this.GetEntityValue('MessageSource');
            _this.MessageType = _this.GetEntityValue('MessageType');
            _this.SequenceNumber = _this.GetEntityValue('SequenceNumber');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        OpsupportSyncJournalmessage.GetEntitySchema = function () {
            var columns = {
                'MessageString': {
                    ColumnName: 'MessageString',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'MessageContext': {
                    ColumnName: 'MessageContext',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'MessageSource': {
                    ColumnName: 'MessageSource',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'MessageType': {
                    ColumnName: 'MessageType',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'SequenceNumber': {
                    ColumnName: 'SequenceNumber',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'DPRJournalMessage', Columns: columns };
        };
        return OpsupportSyncJournalmessage;
    }(imxQbmDbts.TypedEntity));
    var OpsupportSyncJournalobject = /** @class */ (function (_super) {
        __extends(OpsupportSyncJournalobject, _super);
        function OpsupportSyncJournalobject() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.SchemaTypeName = _this.GetEntityValue('SchemaTypeName');
            _this.Method = _this.GetEntityValue('Method');
            _this.ObjectDisplay = _this.GetEntityValue('ObjectDisplay');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        OpsupportSyncJournalobject.GetEntitySchema = function () {
            var columns = {
                'SchemaTypeName': {
                    ColumnName: 'SchemaTypeName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Method': {
                    ColumnName: 'Method',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ObjectDisplay': {
                    ColumnName: 'ObjectDisplay',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'DPRJournalObject', Columns: columns };
        };
        return OpsupportSyncJournalobject;
    }(imxQbmDbts.TypedEntity));
    var OpsupportSyncShell = /** @class */ (function (_super) {
        __extends(OpsupportSyncShell, _super);
        function OpsupportSyncShell() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_DPRShell = _this.GetEntityValue('UID_DPRShell');
            _this.DisplayName = _this.GetEntityValue('DisplayName');
            _this.Description = _this.GetEntityValue('Description');
            _this.NextSyncDate = _this.GetEntityValue('NextSyncDate');
            _this.CountJournalFailure = _this.GetEntityValue('CountJournalFailure');
            _this.LastSyncCountObjects = _this.GetEntityValue('LastSyncCountObjects');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        OpsupportSyncShell.GetEntitySchema = function () {
            var columns = {
                'UID_DPRShell': {
                    ColumnName: 'UID_DPRShell',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'DisplayName': {
                    ColumnName: 'DisplayName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Description': {
                    ColumnName: 'Description',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'NextSyncDate': {
                    ColumnName: 'NextSyncDate',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'CountJournalFailure': {
                    ColumnName: 'CountJournalFailure',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'LastSyncCountObjects': {
                    ColumnName: 'LastSyncCountObjects',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'DPRShell', Columns: columns };
        };
        return OpsupportSyncShell;
    }(imxQbmDbts.TypedEntity));
    var OpsupportNamespacesWrapper = /** @class */ (function () {
        function OpsupportNamespacesWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportNamespacesWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/namespaces');
        };
        OpsupportNamespacesWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/namespaces');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportNamespaces, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportNamespacesWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_namespaces_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportNamespacesWrapper;
    }());
    var OpsupportOutstandingTablesWrapper = /** @class */ (function () {
        function OpsupportOutstandingTablesWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportOutstandingTablesWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/outstanding/tables');
        };
        OpsupportOutstandingTablesWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/outstanding/tables');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportOutstandingTables, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportOutstandingTablesWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_outstanding_tables_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportOutstandingTablesWrapper;
    }());
    var OpsupportSyncDatastoreWrapper = /** @class */ (function () {
        function OpsupportSyncDatastoreWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportSyncDatastoreWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/sync/datastore');
        };
        OpsupportSyncDatastoreWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/sync/datastore');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportSyncDatastore, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportSyncDatastoreWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_sync_datastore_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportSyncDatastoreWrapper;
    }());
    var OpsupportSyncJournalWrapper = /** @class */ (function () {
        function OpsupportSyncJournalWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportSyncJournalWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/sync/journal');
        };
        OpsupportSyncJournalWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/sync/journal');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportSyncJournal, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportSyncJournalWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_sync_journal_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportSyncJournalWrapper;
    }());
    var OpsupportSyncJournalfailureWrapper = /** @class */ (function () {
        function OpsupportSyncJournalfailureWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportSyncJournalfailureWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/sync/journalfailure');
        };
        OpsupportSyncJournalfailureWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/sync/journalfailure');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportSyncJournalfailure, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportSyncJournalfailureWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_sync_journalfailure_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportSyncJournalfailureWrapper;
    }());
    var OpsupportSyncJournalmessageWrapper = /** @class */ (function () {
        function OpsupportSyncJournalmessageWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportSyncJournalmessageWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/sync/journalmessage');
        };
        OpsupportSyncJournalmessageWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/sync/journalmessage');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportSyncJournalmessage, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportSyncJournalmessageWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_sync_journalmessage_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportSyncJournalmessageWrapper;
    }());
    var OpsupportSyncJournalobjectWrapper = /** @class */ (function () {
        function OpsupportSyncJournalobjectWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportSyncJournalobjectWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/sync/journalobject');
        };
        OpsupportSyncJournalobjectWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/sync/journalobject');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportSyncJournalobject, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportSyncJournalobjectWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_sync_journalobject_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportSyncJournalobjectWrapper;
    }());
    var OpsupportSyncShellWrapper = /** @class */ (function () {
        function OpsupportSyncShellWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportSyncShellWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/sync/shell');
        };
        OpsupportSyncShellWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/sync/shell');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportSyncShell, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportSyncShellWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_sync_shell_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportSyncShellWrapper;
    }());
    /** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
    var ApiClientMethodFactory = /** @class */ (function () {
        function ApiClientMethodFactory() {
        }
        ApiClientMethodFactory.prototype.opsupport_namespaces_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/opsupport/namespaces',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_outstanding_dependencies_post = function (action, inputParameterName) {
            return {
                path: '/opsupport/outstanding/dependencies/{action}',
                parameters: [
                    {
                        name: 'action',
                        value: action,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_outstanding_journal_get = function (uid_journal) {
            return {
                path: '/opsupport/outstanding/journal/{uid_journal}',
                parameters: [
                    {
                        name: 'uid_journal',
                        value: uid_journal,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_outstanding_namespace_get = function (namespace) {
            return {
                path: '/opsupport/outstanding/namespace/{namespace}',
                parameters: [
                    {
                        name: 'namespace',
                        value: namespace,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_outstanding_process_post = function (action, bulk, inputParameterName) {
            return {
                path: '/opsupport/outstanding/process/{action}',
                parameters: [
                    {
                        name: 'action',
                        value: action,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'bulk',
                        value: bulk,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_outstanding_table_get = function (tablename, namespace) {
            return {
                path: '/opsupport/outstanding/table/{tablename}',
                parameters: [
                    {
                        name: 'tablename',
                        value: tablename,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'namespace',
                        value: namespace,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_outstanding_tables_get = function (namespace, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/opsupport/outstanding/tables',
                parameters: [
                    {
                        name: 'namespace',
                        value: namespace,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_sync_datastore_get = function (ElementObjectKey) {
            return {
                path: '/opsupport/sync/datastore',
                parameters: [
                    {
                        name: 'ElementObjectKey',
                        value: ElementObjectKey,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_sync_journal_get = function (shell, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/opsupport/sync/journal',
                parameters: [
                    {
                        name: 'shell',
                        value: shell,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_sync_journalfailure_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/opsupport/sync/journalfailure',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_sync_journalmessage_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/opsupport/sync/journalmessage',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_sync_journalobject_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/opsupport/sync/journalobject',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_sync_journalobject_group_get = function (by, def, filter, StartIndex, PageSize, withcount) {
            return {
                path: '/opsupport/sync/journalobject/group',
                parameters: [
                    {
                        name: 'by',
                        value: by,
                        in: 'query'
                    },
                    {
                        name: 'def',
                        value: def,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'withcount',
                        value: withcount,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_sync_shell_get = function (withfrozenjobs, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/opsupport/sync/shell',
                parameters: [
                    {
                        name: 'withfrozenjobs',
                        value: withfrozenjobs,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_sync_summary_get = function (journal) {
            return {
                path: '/opsupport/sync/summary',
                parameters: [
                    {
                        name: 'journal',
                        value: journal,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'blob'
            };
        };
        return ApiClientMethodFactory;
    }());
    /** @deprecated Use the V2Client class for a stable method interface. */
    var Client = /** @class */ (function () {
        function Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        /** Returns all namespaces */
        Client.prototype.opsupport_namespaces_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_namespaces_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns dependencies for the supplied object keys. */
        Client.prototype.opsupport_outstanding_dependencies_post = function (action, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_outstanding_dependencies_post(action, inputParameterName), requestOptions);
        };
        /** Returns all outstanding objects for a specific journal entry. */
        Client.prototype.opsupport_outstanding_journal_get = function (uid_journal, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_outstanding_journal_get(uid_journal), requestOptions);
        };
        /** Returns all outstanding objects in the namespace. */
        Client.prototype.opsupport_outstanding_namespace_get = function (namespace, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_outstanding_namespace_get(namespace), requestOptions);
        };
        /** Applies the specified action to the supplied object keys. */
        Client.prototype.opsupport_outstanding_process_post = function (action, bulk, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_outstanding_process_post(action, bulk, inputParameterName), requestOptions);
        };
        /** Returns all outstanding objects in a specific table. */
        Client.prototype.opsupport_outstanding_table_get = function (tablename, namespace, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_outstanding_table_get(tablename, namespace), requestOptions);
        };
        /** Returns all tables relevant to management of outstanding objects */
        Client.prototype.opsupport_outstanding_tables_get = function (namespace, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_outstanding_tables_get(namespace, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.opsupport_sync_datastore_get = function (ElementObjectKey, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_sync_datastore_get(ElementObjectKey), requestOptions);
        };
        Client.prototype.opsupport_sync_journal_get = function (shell, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_sync_journal_get(shell, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.opsupport_sync_journalfailure_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_sync_journalfailure_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.opsupport_sync_journalmessage_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_sync_journalmessage_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.opsupport_sync_journalobject_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_sync_journalobject_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.opsupport_sync_journalobject_group_get = function (by, def, filter, StartIndex, PageSize, withcount, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_sync_journalobject_group_get(by, def, filter, StartIndex, PageSize, withcount), requestOptions);
        };
        Client.prototype.opsupport_sync_shell_get = function (withfrozenjobs, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_sync_shell_get(withfrozenjobs, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.opsupport_sync_summary_get = function (journal, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_sync_summary_get(journal), requestOptions);
        };
        return Client;
    }());
    var V2ApiClientMethodFactory = /** @class */ (function () {
        function V2ApiClientMethodFactory() {
        }
        V2ApiClientMethodFactory.prototype.opsupport_namespaces_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/namespaces',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_outstanding_dependencies_post = function (action, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/outstanding/dependencies/{action}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'action',
                        value: action,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_outstanding_journal_get = function (uid_journal, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/outstanding/journal/{uid_journal}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid_journal',
                        value: uid_journal,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_outstanding_namespace_get = function (namespace, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/outstanding/namespace/{namespace}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'namespace',
                        value: namespace,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_outstanding_process_post = function (action, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/outstanding/process/{action}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'action',
                        value: action,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_outstanding_table_get = function (tablename, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/outstanding/table/{tablename}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'tablename',
                        value: tablename,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_outstanding_tables_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/outstanding/tables',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_sync_datastore_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/sync/datastore',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_sync_journal_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/sync/journal',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_sync_journalfailure_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/sync/journalfailure',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_sync_journalmessage_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/sync/journalmessage',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_sync_journalobject_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/sync/journalobject',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_sync_journalobject_group_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/sync/journalobject/group',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_sync_shell_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/sync/shell',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_sync_summary_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/sync/summary',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'blob'
            };
        };
        return V2ApiClientMethodFactory;
    }());
    var V2Client = /** @class */ (function () {
        function V2Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new V2ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(V2Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        V2Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        V2Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        V2Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        /** Returns all namespaces */
        V2Client.prototype.opsupport_namespaces_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_namespaces_get(options), requestOptions);
        };
        /** Returns dependencies for the supplied object keys. */
        V2Client.prototype.opsupport_outstanding_dependencies_post = function (action, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_outstanding_dependencies_post(action, inputParameterName, options), requestOptions);
        };
        /** Returns all outstanding objects for a specific journal entry. */
        V2Client.prototype.opsupport_outstanding_journal_get = function (uid_journal, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_outstanding_journal_get(uid_journal, options), requestOptions);
        };
        /** Returns all outstanding objects in the namespace. */
        V2Client.prototype.opsupport_outstanding_namespace_get = function (namespace, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_outstanding_namespace_get(namespace, options), requestOptions);
        };
        /** Applies the specified action to the supplied object keys. */
        V2Client.prototype.opsupport_outstanding_process_post = function (action, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_outstanding_process_post(action, inputParameterName, options), requestOptions);
        };
        /** Returns all outstanding objects in a specific table. */
        V2Client.prototype.opsupport_outstanding_table_get = function (tablename, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_outstanding_table_get(tablename, options), requestOptions);
        };
        /** Returns all tables relevant to management of outstanding objects */
        V2Client.prototype.opsupport_outstanding_tables_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_outstanding_tables_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_sync_datastore_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_sync_datastore_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_sync_journal_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_sync_journal_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_sync_journalfailure_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_sync_journalfailure_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_sync_journalmessage_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_sync_journalmessage_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_sync_journalobject_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_sync_journalobject_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_sync_journalobject_group_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_sync_journalobject_group_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_sync_shell_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_sync_shell_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_sync_summary_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_sync_summary_get(options), requestOptions);
        };
        return V2Client;
    }());

    exports.ApiClientMethodFactory = ApiClientMethodFactory;
    exports.Client = Client;
    exports.OpsupportNamespaces = OpsupportNamespaces;
    exports.OpsupportNamespacesWrapper = OpsupportNamespacesWrapper;
    exports.OpsupportOutstandingTables = OpsupportOutstandingTables;
    exports.OpsupportOutstandingTablesWrapper = OpsupportOutstandingTablesWrapper;
    exports.OpsupportSyncDatastore = OpsupportSyncDatastore;
    exports.OpsupportSyncDatastoreWrapper = OpsupportSyncDatastoreWrapper;
    exports.OpsupportSyncJournal = OpsupportSyncJournal;
    exports.OpsupportSyncJournalWrapper = OpsupportSyncJournalWrapper;
    exports.OpsupportSyncJournalfailure = OpsupportSyncJournalfailure;
    exports.OpsupportSyncJournalfailureWrapper = OpsupportSyncJournalfailureWrapper;
    exports.OpsupportSyncJournalmessage = OpsupportSyncJournalmessage;
    exports.OpsupportSyncJournalmessageWrapper = OpsupportSyncJournalmessageWrapper;
    exports.OpsupportSyncJournalobject = OpsupportSyncJournalobject;
    exports.OpsupportSyncJournalobjectWrapper = OpsupportSyncJournalobjectWrapper;
    exports.OpsupportSyncShell = OpsupportSyncShell;
    exports.OpsupportSyncShellWrapper = OpsupportSyncShellWrapper;
    exports.TypedClient = TypedClient;
    exports.V2ApiClientMethodFactory = V2ApiClientMethodFactory;
    exports.V2Client = V2Client;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
