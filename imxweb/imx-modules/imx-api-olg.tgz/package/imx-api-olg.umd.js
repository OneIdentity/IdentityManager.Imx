(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('imx-qbm-dbts')) :
    typeof define === 'function' && define.amd ? define(['exports', 'imx-qbm-dbts'], factory) :
    (global = global || self, factory(global['imx-api'] = {}, global.imxQbmDbts));
}(this, (function (exports, imxQbmDbts) { 'use strict';

    var __extends = (undefined && undefined.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    };
    var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    };
    (function (VerifyPollingResult) {
        VerifyPollingResult[VerifyPollingResult["Expired"] = 0] = "Expired";
        VerifyPollingResult[VerifyPollingResult["Accepted"] = 1] = "Accepted";
        VerifyPollingResult[VerifyPollingResult["Rejected"] = 2] = "Rejected";
    })(exports.VerifyPollingResult || (exports.VerifyPollingResult = {}));
    var TypedClient = /** @class */ (function () {
        function TypedClient(client, translationProvider) {
            this.PortalOlgapplicationMemberships = new PortalOlgapplicationMembershipsWrapper(client, translationProvider);
            this.PortalOlgroleMemberships = new PortalOlgroleMembershipsWrapper(client, translationProvider);
        }
        return TypedClient;
    }());
    var PortalOlgapplicationMemberships = /** @class */ (function (_super) {
        __extends(PortalOlgapplicationMemberships, _super);
        function PortalOlgapplicationMemberships() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.ObjectKeyAssignment = _this.GetEntityValue('ObjectKeyAssignment');
            _this.XOrigin = _this.GetEntityValue('XOrigin');
            _this.IsPending = _this.GetEntityValue('IsPending');
            _this.IsPrimary = _this.GetEntityValue('IsPrimary');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.OrderState = _this.GetEntityValue('OrderState');
            _this.ValidUntil = _this.GetEntityValue('ValidUntil');
            _this.UID_UNSAccount = _this.GetEntityValue('UID_UNSAccount');
            _this.UID_UNSGroupChild = _this.GetEntityValue('UID_UNSGroupChild');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        PortalOlgapplicationMemberships.GetEntitySchema = function () {
            var columns = {
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ObjectKeyAssignment': {
                    ColumnName: 'ObjectKeyAssignment',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XOrigin': {
                    ColumnName: 'XOrigin',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'IsPending': {
                    ColumnName: 'IsPending',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsPrimary': {
                    ColumnName: 'IsPrimary',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'OrderState': {
                    ColumnName: 'OrderState',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ValidUntil': {
                    ColumnName: 'ValidUntil',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'UID_UNSAccount': {
                    ColumnName: 'UID_UNSAccount',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSGroupChild': {
                    ColumnName: 'UID_UNSGroupChild',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: '', Columns: columns };
        };
        return PortalOlgapplicationMemberships;
    }(imxQbmDbts.TypedEntity));
    var PortalOlgroleMemberships = /** @class */ (function (_super) {
        __extends(PortalOlgroleMemberships, _super);
        function PortalOlgroleMemberships() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.ObjectKeyAssignment = _this.GetEntityValue('ObjectKeyAssignment');
            _this.XOrigin = _this.GetEntityValue('XOrigin');
            _this.IsPending = _this.GetEntityValue('IsPending');
            _this.IsPrimary = _this.GetEntityValue('IsPrimary');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.OrderState = _this.GetEntityValue('OrderState');
            _this.ValidUntil = _this.GetEntityValue('ValidUntil');
            _this.UID_UNSAccount = _this.GetEntityValue('UID_UNSAccount');
            _this.UID_UNSGroupChild = _this.GetEntityValue('UID_UNSGroupChild');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        PortalOlgroleMemberships.GetEntitySchema = function () {
            var columns = {
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ObjectKeyAssignment': {
                    ColumnName: 'ObjectKeyAssignment',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XOrigin': {
                    ColumnName: 'XOrigin',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'IsPending': {
                    ColumnName: 'IsPending',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsPrimary': {
                    ColumnName: 'IsPrimary',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'OrderState': {
                    ColumnName: 'OrderState',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ValidUntil': {
                    ColumnName: 'ValidUntil',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'UID_UNSAccount': {
                    ColumnName: 'UID_UNSAccount',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSGroupChild': {
                    ColumnName: 'UID_UNSGroupChild',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: '', Columns: columns };
        };
        return PortalOlgroleMemberships;
    }(imxQbmDbts.TypedEntity));
    var PortalOlgapplicationMembershipsWrapper = /** @class */ (function () {
        function PortalOlgapplicationMembershipsWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalOlgapplicationMembershipsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/OLGApplication/{uid}/memberships');
        };
        PortalOlgapplicationMembershipsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/OLGApplication/{uid}/memberships');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalOlgapplicationMemberships, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalOlgapplicationMembershipsWrapper.prototype.Get = function (uid, requestOpts) {
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_OLGApplication_memberships_get(uid, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalOlgapplicationMembershipsWrapper;
    }());
    var PortalOlgroleMembershipsWrapper = /** @class */ (function () {
        function PortalOlgroleMembershipsWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalOlgroleMembershipsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/OLGRole/{uid}/memberships');
        };
        PortalOlgroleMembershipsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/OLGRole/{uid}/memberships');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalOlgroleMemberships, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalOlgroleMembershipsWrapper.prototype.Get = function (uid, requestOpts) {
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_OLGRole_memberships_get(uid, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalOlgroleMembershipsWrapper;
    }());
    /** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
    var ApiClientMethodFactory = /** @class */ (function () {
        function ApiClientMethodFactory() {
        }
        ApiClientMethodFactory.prototype.portal_OLGApplication_memberships_get = function (uid) {
            return {
                path: '/portal/OLGApplication/{uid}/memberships',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_OLGApplication_memberships_delete = function (uid, uidaccount) {
            return {
                path: '/portal/OLGApplication/{uid}/memberships/{uidaccount}',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_OLGRole_memberships_get = function (uid) {
            return {
                path: '/portal/OLGRole/{uid}/memberships',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_OLGRole_memberships_delete = function (uid, uidaccount) {
            return {
                path: '/portal/OLGRole/{uid}/memberships/{uidaccount}',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_onelogin_mfa_activate_post = function (workflowActionId, deviceid) {
            return {
                path: '/portal/onelogin/mfa/{workflowActionId}/activate/{deviceid}',
                parameters: [
                    {
                        name: 'workflowActionId',
                        value: workflowActionId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'deviceid',
                        value: deviceid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_onelogin_mfa_poll_get = function (workflowActionId, verificationid, deviceid) {
            return {
                path: '/portal/onelogin/mfa/{workflowActionId}/poll/{verificationid}',
                parameters: [
                    {
                        name: 'workflowActionId',
                        value: workflowActionId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'verificationid',
                        value: verificationid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'deviceid',
                        value: deviceid,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_onelogin_mfa_verifyotpwithverificationid_post = function (workflowActionId, verificationid, deviceid, inputParameterName) {
            return {
                path: '/portal/onelogin/mfa/{workflowActionId}/verifyotp/{verificationid}',
                parameters: [
                    {
                        name: 'workflowActionId',
                        value: workflowActionId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'verificationid',
                        value: verificationid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'deviceid',
                        value: deviceid,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_onelogin_mfa_factors_get = function () {
            return {
                path: '/portal/onelogin/mfa/factors',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/OLGApplication/UID_OLGApplication/candidates',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/OLGApplication/UID_OLGApplication/candidates/datamodel',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/OLGApplication/UID_OLGApplication/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/OLGRole/UID_OLGRole/candidates',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/OLGRole/UID_OLGRole/candidates/datamodel',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/OLGRole/UID_OLGRole/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        return ApiClientMethodFactory;
    }());
    /** @deprecated Use the V2Client class for a stable method interface. */
    var Client = /** @class */ (function () {
        function Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        Client.prototype.portal_OLGApplication_memberships_get = function (uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_OLGApplication_memberships_get(uid), requestOptions);
        };
        /** Deletes an account membership. */
        Client.prototype.portal_OLGApplication_memberships_delete = function (uid, uidaccount, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_OLGApplication_memberships_delete(uid, uidaccount), requestOptions);
        };
        Client.prototype.portal_OLGRole_memberships_get = function (uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_OLGRole_memberships_get(uid), requestOptions);
        };
        /** Deletes an account membership. */
        Client.prototype.portal_OLGRole_memberships_delete = function (uid, uidaccount, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_OLGRole_memberships_delete(uid, uidaccount), requestOptions);
        };
        /** Activates the given factor. */
        Client.prototype.portal_onelogin_mfa_activate_post = function (workflowActionId, deviceid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_onelogin_mfa_activate_post(workflowActionId, deviceid), requestOptions);
        };
        /** Waits for a confirmation of the factor. */
        Client.prototype.portal_onelogin_mfa_poll_get = function (workflowActionId, verificationid, deviceid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_onelogin_mfa_poll_get(workflowActionId, verificationid, deviceid), requestOptions);
        };
        /** Verifies the supplied one-time password. */
        Client.prototype.portal_onelogin_mfa_verifyotpwithverificationid_post = function (workflowActionId, verificationid, deviceid, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_onelogin_mfa_verifyotpwithverificationid_post(workflowActionId, verificationid, deviceid, inputParameterName), requestOptions);
        };
        /** Returns the enrolled factors for the user. */
        Client.prototype.portal_onelogin_mfa_factors_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_onelogin_mfa_factors_get(), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_OLGApplication. */
        Client.prototype.portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/OLGApplication/UID_OLGApplication/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_datamodel_get = function (UID_ITShopOrg, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_datamodel_get(UID_ITShopOrg, filter), requestOptions);
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/OLGApplication/UID_OLGApplication/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_OLGRole. */
        Client.prototype.portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/OLGRole/UID_OLGRole/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_datamodel_get = function (UID_ITShopOrg, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_datamodel_get(UID_ITShopOrg, filter), requestOptions);
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/OLGRole/UID_OLGRole/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName), requestOptions);
        };
        return Client;
    }());
    var V2ApiClientMethodFactory = /** @class */ (function () {
        function V2ApiClientMethodFactory() {
        }
        V2ApiClientMethodFactory.prototype.portal_OLGApplication_memberships_get = function (uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/OLGApplication/{uid}/memberships',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_OLGApplication_memberships_delete = function (uid, uidaccount, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/OLGApplication/{uid}/memberships/{uidaccount}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_OLGRole_memberships_get = function (uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/OLGRole/{uid}/memberships',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_OLGRole_memberships_delete = function (uid, uidaccount, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/OLGRole/{uid}/memberships/{uidaccount}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_onelogin_mfa_activate_post = function (workflowActionId, deviceid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/onelogin/mfa/{workflowActionId}/activate/{deviceid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'workflowActionId',
                        value: workflowActionId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'deviceid',
                        value: deviceid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_onelogin_mfa_poll_get = function (workflowActionId, verificationid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/onelogin/mfa/{workflowActionId}/poll/{verificationid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'workflowActionId',
                        value: workflowActionId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'verificationid',
                        value: verificationid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_onelogin_mfa_verifyotpwithverificationid_post = function (workflowActionId, verificationid, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/onelogin/mfa/{workflowActionId}/verifyotp/{verificationid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'workflowActionId',
                        value: workflowActionId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'verificationid',
                        value: verificationid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_onelogin_mfa_factors_get = function (options, requestOptions) {
            return {
                path: '/portal/onelogin/mfa/factors',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_get = function (UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/OLGApplication/UID_OLGApplication/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_datamodel_get = function (UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/OLGApplication/UID_OLGApplication/candidates/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_filtertree_post = function (UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/OLGApplication/UID_OLGApplication/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_get = function (UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/OLGRole/UID_OLGRole/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_datamodel_get = function (UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/OLGRole/UID_OLGRole/candidates/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_filtertree_post = function (UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/OLGRole/UID_OLGRole/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        return V2ApiClientMethodFactory;
    }());
    var V2Client = /** @class */ (function () {
        function V2Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new V2ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(V2Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        V2Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        V2Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        V2Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        V2Client.prototype.portal_OLGApplication_memberships_get = function (uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_OLGApplication_memberships_get(uid, options), requestOptions);
        };
        /** Deletes an account membership. */
        V2Client.prototype.portal_OLGApplication_memberships_delete = function (uid, uidaccount, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_OLGApplication_memberships_delete(uid, uidaccount, options), requestOptions);
        };
        V2Client.prototype.portal_OLGRole_memberships_get = function (uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_OLGRole_memberships_get(uid, options), requestOptions);
        };
        /** Deletes an account membership. */
        V2Client.prototype.portal_OLGRole_memberships_delete = function (uid, uidaccount, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_OLGRole_memberships_delete(uid, uidaccount, options), requestOptions);
        };
        /** Activates the given factor. */
        V2Client.prototype.portal_onelogin_mfa_activate_post = function (workflowActionId, deviceid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_onelogin_mfa_activate_post(workflowActionId, deviceid, options), requestOptions);
        };
        /** Waits for a confirmation of the factor. */
        V2Client.prototype.portal_onelogin_mfa_poll_get = function (workflowActionId, verificationid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_onelogin_mfa_poll_get(workflowActionId, verificationid, options), requestOptions);
        };
        /** Verifies the supplied one-time password. */
        V2Client.prototype.portal_onelogin_mfa_verifyotpwithverificationid_post = function (workflowActionId, verificationid, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_onelogin_mfa_verifyotpwithverificationid_post(workflowActionId, verificationid, inputParameterName, options), requestOptions);
        };
        /** Returns the enrolled factors for the user. */
        V2Client.prototype.portal_onelogin_mfa_factors_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_onelogin_mfa_factors_get(options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_OLGApplication. */
        V2Client.prototype.portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_get = function (UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_get(UID_ITShopOrg, options), requestOptions);
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/OLGApplication/UID_OLGApplication/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_datamodel_get = function (UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_datamodel_get(UID_ITShopOrg, options), requestOptions);
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/OLGApplication/UID_OLGApplication/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_filtertree_post = function (UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_OLGRole. */
        V2Client.prototype.portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_get = function (UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_get(UID_ITShopOrg, options), requestOptions);
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/OLGRole/UID_OLGRole/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_datamodel_get = function (UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_datamodel_get(UID_ITShopOrg, options), requestOptions);
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/OLGRole/UID_OLGRole/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_filtertree_post = function (UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
        };
        return V2Client;
    }());

    exports.ApiClientMethodFactory = ApiClientMethodFactory;
    exports.Client = Client;
    exports.PortalOlgapplicationMemberships = PortalOlgapplicationMemberships;
    exports.PortalOlgapplicationMembershipsWrapper = PortalOlgapplicationMembershipsWrapper;
    exports.PortalOlgroleMemberships = PortalOlgroleMemberships;
    exports.PortalOlgroleMembershipsWrapper = PortalOlgroleMembershipsWrapper;
    exports.TypedClient = TypedClient;
    exports.V2ApiClientMethodFactory = V2ApiClientMethodFactory;
    exports.V2Client = V2Client;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
