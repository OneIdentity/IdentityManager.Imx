import { ApiClient, DataModel, EntityCollectionData, EntitySchema, EntityWriteDataSingle, FilterData, FilterTreeData, FkProviderItem, IReadValue, MethodDescriptor, StaticSchema, TypedEntity } from 'imx-qbm-dbts';
export interface ActivateFactorData {
    auth_factor_name?: string;
    type_display_name?: string;
    user_display_name?: string;
    id?: string;
    user_id?: string;
    expires_at: Date;
    device_id?: string;
}
export interface AuthFactor {
    Display?: string;
    Name?: string;
    Id?: string;
    FactorId?: string;
}
export interface AuthFactors {
    Factors?: AuthFactor[];
    DefaultId?: string;
}
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export declare enum VerifyPollingResult {
    Expired = 0,
    Accepted = 1,
    Rejected = 2
}
export declare class TypedClient {
    readonly PortalOlgapplicationMemberships: PortalOlgapplicationMembershipsWrapper;
    readonly PortalOlgroleMemberships: PortalOlgroleMembershipsWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalOlgapplicationMemberships extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly IsPending: IReadValue<boolean>;
    readonly IsPrimary: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'ObjectKeyAssignment' | 'XOrigin' | 'IsPending' | 'IsPrimary' | 'XMarkedForDeletion' | 'XDateInserted' | 'OrderState' | 'ValidUntil' | 'UID_UNSAccount' | 'UID_UNSGroupChild'>;
}
export declare class PortalOlgroleMemberships extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly IsPending: IReadValue<boolean>;
    readonly IsPrimary: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'ObjectKeyAssignment' | 'XOrigin' | 'IsPending' | 'IsPrimary' | 'XMarkedForDeletion' | 'XDateInserted' | 'OrderState' | 'ValidUntil' | 'UID_UNSAccount' | 'UID_UNSGroupChild'>;
}
export declare class PortalOlgapplicationMembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalOlgapplicationMemberships, unknown>>;
}
export declare class PortalOlgroleMembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalOlgroleMemberships, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    portal_OLGApplication_memberships_get(uid: string): MethodDescriptor<EntityCollectionData>;
    portal_OLGApplication_memberships_delete(uid: string, uidaccount: string): MethodDescriptor<void>;
    portal_OLGRole_memberships_get(uid: string): MethodDescriptor<EntityCollectionData>;
    portal_OLGRole_memberships_delete(uid: string, uidaccount: string): MethodDescriptor<void>;
    portal_onelogin_mfa_activate_post(workflowActionId: string, deviceid: string): MethodDescriptor<ActivateFactorData>;
    portal_onelogin_mfa_poll_get(workflowActionId: string, verificationid: string, deviceid: string): MethodDescriptor<VerifyPollingResult>;
    portal_onelogin_mfa_verifyotpwithverificationid_post(workflowActionId: string, verificationid: string, deviceid: string, inputParameterName: string): MethodDescriptor<boolean>;
    portal_onelogin_mfa_factors_get(): MethodDescriptor<AuthFactors>;
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_OLGApplication_memberships_get(uid: string): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_OLGApplication_memberships_delete(uid: string, uidaccount: string): Promise<void>;
    portal_OLGRole_memberships_get(uid: string): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_OLGRole_memberships_delete(uid: string, uidaccount: string): Promise<void>;
    /** Activates the given factor. */
    portal_onelogin_mfa_activate_post(workflowActionId: string, deviceid: string): Promise<ActivateFactorData>;
    /** Waits for a confirmation of the factor. */
    portal_onelogin_mfa_poll_get(workflowActionId: string, verificationid: string, deviceid: string): Promise<VerifyPollingResult>;
    /** Verifies the supplied one-time password. */
    portal_onelogin_mfa_verifyotpwithverificationid_post(workflowActionId: string, verificationid: string, deviceid: string, inputParameterName: string): Promise<boolean>;
    /** Returns the enrolled factors for the user. */
    portal_onelogin_mfa_factors_get(): Promise<AuthFactors>;
    /** Returns a list of objects that can be assigned to the property UID_OLGApplication. */
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/OLGApplication/UID_OLGApplication/candidates endpoint. */
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/OLGApplication/UID_OLGApplication/candidates endpoint. */
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OLGRole. */
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/OLGRole/UID_OLGRole/candidates endpoint. */
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/OLGRole/UID_OLGRole/candidates endpoint. */
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
}
export declare class V2ApiClientMethodFactory {
    portal_OLGApplication_memberships_get(uid: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_OLGApplication_memberships_delete(uid: string, uidaccount: string, options?: {}): MethodDescriptor<void>;
    portal_OLGRole_memberships_get(uid: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_OLGRole_memberships_delete(uid: string, uidaccount: string, options?: {}): MethodDescriptor<void>;
    portal_onelogin_mfa_activate_post(workflowActionId: string, deviceid: string, options?: {}): MethodDescriptor<ActivateFactorData>;
    portal_onelogin_mfa_poll_get(workflowActionId: string, verificationid: string, options?: {
        deviceid?: string;
    }): MethodDescriptor<VerifyPollingResult>;
    portal_onelogin_mfa_verifyotpwithverificationid_post(workflowActionId: string, verificationid: string, inputParameterName: string, options?: {
        deviceid?: string;
    }): MethodDescriptor<boolean>;
    portal_onelogin_mfa_factors_get(options?: {}): MethodDescriptor<AuthFactors>;
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_OLGApplication_memberships_get(uid: string, options?: {}): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_OLGApplication_memberships_delete(uid: string, uidaccount: string, options?: {}): Promise<void>;
    portal_OLGRole_memberships_get(uid: string, options?: {}): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_OLGRole_memberships_delete(uid: string, uidaccount: string, options?: {}): Promise<void>;
    /** Activates the given factor. */
    portal_onelogin_mfa_activate_post(workflowActionId: string, deviceid: string, options?: {}): Promise<ActivateFactorData>;
    /** Waits for a confirmation of the factor. */
    portal_onelogin_mfa_poll_get(workflowActionId: string, verificationid: string, options?: {
        deviceid?: string;
    }): Promise<VerifyPollingResult>;
    /** Verifies the supplied one-time password. */
    portal_onelogin_mfa_verifyotpwithverificationid_post(workflowActionId: string, verificationid: string, inputParameterName: string, options?: {
        deviceid?: string;
    }): Promise<boolean>;
    /** Returns the enrolled factors for the user. */
    portal_onelogin_mfa_factors_get(options?: {}): Promise<AuthFactors>;
    /** Returns a list of objects that can be assigned to the property UID_OLGApplication. */
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/OLGApplication/UID_OLGApplication/candidates endpoint. */
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/OLGApplication/UID_OLGApplication/candidates endpoint. */
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OLGRole. */
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/OLGRole/UID_OLGRole/candidates endpoint. */
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/OLGRole/UID_OLGRole/candidates endpoint. */
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
}
