(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('imx-qbm-dbts')) :
    typeof define === 'function' && define.amd ? define(['exports', 'imx-qbm-dbts'], factory) :
    (global = global || self, factory(global['imx-api'] = {}, global.imxQbmDbts));
}(this, (function (exports, imxQbmDbts) { 'use strict';

    var __extends = (undefined && undefined.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    };
    var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    };
    var TypedClient = /** @class */ (function () {
        function TypedClient(client, translationProvider) {
            this.PortalAdminRoleEset = new PortalAdminRoleEsetWrapper(client, translationProvider);
            this.PortalAdminRoleEsetInteractive = new PortalAdminRoleEsetInteractiveWrapper(client, translationProvider);
            this.PortalPersonRolemembershipsEset = new PortalPersonRolemembershipsEsetWrapper(client, translationProvider);
            this.PortalRespEset = new PortalRespEsetWrapper(client, translationProvider);
            this.PortalRespEsetInteractive = new PortalRespEsetInteractiveWrapper(client, translationProvider);
            this.PortalRolesConfigEntitlementsEset = new PortalRolesConfigEntitlementsEsetWrapper(client, translationProvider);
            this.PortalRolesConfigMembershipEset = new PortalRolesConfigMembershipEsetWrapper(client, translationProvider);
            this.PortalShopConfigEntitlementsEset = new PortalShopConfigEntitlementsEsetWrapper(client, translationProvider);
        }
        return TypedClient;
    }());
    var PortalAdminRoleEset = /** @class */ (function (_super) {
        __extends(PortalAdminRoleEset, _super);
        function PortalAdminRoleEset() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_AccProduct = _this.GetEntityValue('UID_AccProduct');
            _this.RiskIndexCalculated = _this.GetEntityValue('RiskIndexCalculated');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        PortalAdminRoleEset.GetEntitySchema = function () {
            var columns = {
                'UID_AccProduct': {
                    ColumnName: 'UID_AccProduct',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'RiskIndexCalculated': {
                    ColumnName: 'RiskIndexCalculated',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'ESet', Columns: columns };
        };
        return PortalAdminRoleEset;
    }(imxQbmDbts.TypedEntity));
    var PortalAdminRoleEsetInteractive = /** @class */ (function (_super) {
        __extends(PortalAdminRoleEsetInteractive, _super);
        function PortalAdminRoleEsetInteractive() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_AccProduct = _this.GetEntityValue('UID_AccProduct');
            _this.RiskIndexCalculated = _this.GetEntityValue('RiskIndexCalculated');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        PortalAdminRoleEsetInteractive.GetEntitySchema = function () {
            var columns = {
                'UID_AccProduct': {
                    ColumnName: 'UID_AccProduct',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'RiskIndexCalculated': {
                    ColumnName: 'RiskIndexCalculated',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'ESet', Columns: columns };
        };
        return PortalAdminRoleEsetInteractive;
    }(imxQbmDbts.TypedEntity));
    var PortalPersonRolemembershipsEset = /** @class */ (function (_super) {
        __extends(PortalPersonRolemembershipsEset, _super);
        function PortalPersonRolemembershipsEset() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.XOrigin = _this.GetEntityValue('XOrigin');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.UID_ESet = _this.GetEntityValue('UID_ESet');
            _this.RoleFullPath = _this.GetEntityValue('RoleFullPath');
            _this.UID_PersonWantsOrg = _this.GetEntityValue('UID_PersonWantsOrg');
            _this.OrderState = _this.GetEntityValue('OrderState');
            _this.IsRequestCancellable = _this.GetEntityValue('IsRequestCancellable');
            _this.ValidUntil = _this.GetEntityValue('ValidUntil');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        PortalPersonRolemembershipsEset.GetEntitySchema = function () {
            var columns = {
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XOrigin': {
                    ColumnName: 'XOrigin',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'UID_ESet': {
                    ColumnName: 'UID_ESet',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'RoleFullPath': {
                    ColumnName: 'RoleFullPath',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_PersonWantsOrg': {
                    ColumnName: 'UID_PersonWantsOrg',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'OrderState': {
                    ColumnName: 'OrderState',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'IsRequestCancellable': {
                    ColumnName: 'IsRequestCancellable',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'ValidUntil': {
                    ColumnName: 'ValidUntil',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'PersonHasESet', Columns: columns };
        };
        return PortalPersonRolemembershipsEset;
    }(imxQbmDbts.TypedEntity));
    var PortalRespEset = /** @class */ (function (_super) {
        __extends(PortalRespEset, _super);
        function PortalRespEset() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        PortalRespEset.GetEntitySchema = function () {
            var columns = {
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'ESet', Columns: columns };
        };
        return PortalRespEset;
    }(imxQbmDbts.TypedEntity));
    var PortalRespEsetInteractive = /** @class */ (function (_super) {
        __extends(PortalRespEsetInteractive, _super);
        function PortalRespEsetInteractive() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        PortalRespEsetInteractive.GetEntitySchema = function () {
            var columns = {
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'ESet', Columns: columns };
        };
        return PortalRespEsetInteractive;
    }(imxQbmDbts.TypedEntity));
    var PortalRolesConfigEntitlementsEset = /** @class */ (function (_super) {
        __extends(PortalRolesConfigEntitlementsEset, _super);
        function PortalRolesConfigEntitlementsEset() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_ESet = _this.GetEntityValue('UID_ESet');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.XOrigin = _this.GetEntityValue('XOrigin');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            _this.Entitlement = _this.GetEntityValue('Entitlement');
            _this.UID_PersonWantsOrg = _this.GetEntityValue('UID_PersonWantsOrg');
            _this.OrderState = _this.GetEntityValue('OrderState');
            _this.IsRequestCancellable = _this.GetEntityValue('IsRequestCancellable');
            _this.ValidUntil = _this.GetEntityValue('ValidUntil');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        PortalRolesConfigEntitlementsEset.GetEntitySchema = function () {
            var columns = {
                'UID_ESet': {
                    ColumnName: 'UID_ESet',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XOrigin': {
                    ColumnName: 'XOrigin',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'Entitlement': {
                    ColumnName: 'Entitlement',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'UID_PersonWantsOrg': {
                    ColumnName: 'UID_PersonWantsOrg',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'OrderState': {
                    ColumnName: 'OrderState',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'IsRequestCancellable': {
                    ColumnName: 'IsRequestCancellable',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'ValidUntil': {
                    ColumnName: 'ValidUntil',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'ESetHasEntitlement', Columns: columns };
        };
        return PortalRolesConfigEntitlementsEset;
    }(imxQbmDbts.TypedEntity));
    var PortalRolesConfigMembershipEset = /** @class */ (function (_super) {
        __extends(PortalRolesConfigMembershipEset, _super);
        function PortalRolesConfigMembershipEset() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_ESet = _this.GetEntityValue('UID_ESet');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.XOrigin = _this.GetEntityValue('XOrigin');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.XIsInEffect = _this.GetEntityValue('XIsInEffect');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.UID_PersonWantsOrg = _this.GetEntityValue('UID_PersonWantsOrg');
            _this.OrderState = _this.GetEntityValue('OrderState');
            _this.IsRequestCancellable = _this.GetEntityValue('IsRequestCancellable');
            _this.ValidUntil = _this.GetEntityValue('ValidUntil');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        PortalRolesConfigMembershipEset.GetEntitySchema = function () {
            var columns = {
                'UID_ESet': {
                    ColumnName: 'UID_ESet',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XOrigin': {
                    ColumnName: 'XOrigin',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'XIsInEffect': {
                    ColumnName: 'XIsInEffect',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'UID_PersonWantsOrg': {
                    ColumnName: 'UID_PersonWantsOrg',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'OrderState': {
                    ColumnName: 'OrderState',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'IsRequestCancellable': {
                    ColumnName: 'IsRequestCancellable',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'ValidUntil': {
                    ColumnName: 'ValidUntil',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'PersonHasESet', Columns: columns };
        };
        return PortalRolesConfigMembershipEset;
    }(imxQbmDbts.TypedEntity));
    var PortalShopConfigEntitlementsEset = /** @class */ (function (_super) {
        __extends(PortalShopConfigEntitlementsEset, _super);
        function PortalShopConfigEntitlementsEset() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_ITShopOrg = _this.GetEntityValue('UID_ITShopOrg');
            _this.UID_ESet = _this.GetEntityValue('UID_ESet');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        PortalShopConfigEntitlementsEset.GetEntitySchema = function () {
            var columns = {
                'UID_ITShopOrg': {
                    ColumnName: 'UID_ITShopOrg',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_ESet': {
                    ColumnName: 'UID_ESet',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'ITShopOrgHasESet', Columns: columns };
        };
        return PortalShopConfigEntitlementsEset;
    }(imxQbmDbts.TypedEntity));
    var PortalAdminRoleEsetWrapper = /** @class */ (function () {
        function PortalAdminRoleEsetWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_admin_role_eset_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalAdminRoleEsetWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/admin/role/eset');
        };
        PortalAdminRoleEsetWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/admin/role/eset');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalAdminRoleEset, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAdminRoleEsetWrapper.prototype.Get = function (parametersOptional) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_admin_role_eset_get(parametersOptional)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalAdminRoleEsetWrapper.prototype.Put = function (inputParameterName) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_admin_role_eset_put(inputParameterName.EntityWriteData)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAdminRoleEsetWrapper;
    }());
    var PortalAdminRoleEsetInteractiveWrapper = /** @class */ (function () {
        function PortalAdminRoleEsetInteractiveWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_admin_role_eset_interactive_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalAdminRoleEsetInteractiveWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/admin/role/eset/interactive');
        };
        PortalAdminRoleEsetInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/admin/role/eset/interactive');
                this.builder = new imxQbmDbts.InteractiveTypedEntityBuilder(PortalAdminRoleEsetInteractive, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAdminRoleEsetInteractiveWrapper.prototype.Put = function (inputParameterName) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_admin_role_eset_interactive_put(inputParameterName.InteractiveEntityWriteData)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalAdminRoleEsetInteractiveWrapper.prototype.Get_byid = function (UID_ESet) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_admin_role_eset_interactive_byid_get(UID_ESet)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAdminRoleEsetInteractiveWrapper;
    }());
    var PortalPersonRolemembershipsEsetWrapper = /** @class */ (function () {
        function PortalPersonRolemembershipsEsetWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalPersonRolemembershipsEsetWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/person/{UID_Person}/rolememberships/ESet');
        };
        PortalPersonRolemembershipsEsetWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/person/{UID_Person}/rolememberships/ESet');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalPersonRolemembershipsEset, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalPersonRolemembershipsEsetWrapper.prototype.Get = function (UID_Person, parametersOptional) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_person_rolememberships_ESet_get(UID_Person, parametersOptional)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalPersonRolemembershipsEsetWrapper;
    }());
    var PortalRespEsetWrapper = /** @class */ (function () {
        function PortalRespEsetWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalRespEsetWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/resp/eset');
        };
        PortalRespEsetWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/resp/eset');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalRespEset, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalRespEsetWrapper.prototype.Get = function (parametersOptional) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_resp_eset_get(parametersOptional)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalRespEsetWrapper;
    }());
    var PortalRespEsetInteractiveWrapper = /** @class */ (function () {
        function PortalRespEsetInteractiveWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_resp_eset_interactive_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalRespEsetInteractiveWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/resp/eset/interactive');
        };
        PortalRespEsetInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/resp/eset/interactive');
                this.builder = new imxQbmDbts.InteractiveTypedEntityBuilder(PortalRespEsetInteractive, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalRespEsetInteractiveWrapper.prototype.Put = function (inputParameterName) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_resp_eset_interactive_put(inputParameterName.InteractiveEntityWriteData)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalRespEsetInteractiveWrapper.prototype.Get_byid = function (UID_ESet) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_resp_eset_interactive_byid_get(UID_ESet)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalRespEsetInteractiveWrapper;
    }());
    var PortalRolesConfigEntitlementsEsetWrapper = /** @class */ (function () {
        function PortalRolesConfigEntitlementsEsetWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                {
                    return _this.client.portal_roles_config_entitlements_ESet_post(entity.GetColumn('UID_ESet').GetValue(), writeData);
                }
            };
            this.deleteMethod = function (entity) {
                return _this.client.portal_roles_config_entitlements_ESet_delete(entity.GetColumn('UID_ESet').GetValue(), entity.GetColumn('UID_ESetHasEntitlement').GetValue());
            };
        }
        PortalRolesConfigEntitlementsEsetWrapper.prototype.createEntity = function (initialData) {
            this.buildBuilderIfNeeded();
            return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, imxQbmDbts.EntityState.Created);
        };
        /** Returns the runtime schema for this method. */
        PortalRolesConfigEntitlementsEsetWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/roles/config/entitlements/ESet/{UID_ESet}');
        };
        PortalRolesConfigEntitlementsEsetWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/roles/config/entitlements/ESet/{UID_ESet}');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalRolesConfigEntitlementsEset, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalRolesConfigEntitlementsEsetWrapper.prototype.Get = function (UID_ESet, parametersOptional) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_roles_config_entitlements_ESet_get(UID_ESet, parametersOptional)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalRolesConfigEntitlementsEsetWrapper.prototype.Post = function (UID_ESet, inputParameterName) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_roles_config_entitlements_ESet_post(UID_ESet, inputParameterName.EntityWriteData)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalRolesConfigEntitlementsEsetWrapper.prototype.Delete = function (UID_ESet, UID_ESetHasEntitlement) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_roles_config_entitlements_ESet_delete(UID_ESet, UID_ESetHasEntitlement)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalRolesConfigEntitlementsEsetWrapper;
    }());
    var PortalRolesConfigMembershipEsetWrapper = /** @class */ (function () {
        function PortalRolesConfigMembershipEsetWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                {
                    return _this.client.portal_roles_config_membership_ESet_post(entity.GetColumn('UID_ESet').GetValue(), writeData);
                }
            };
            this.deleteMethod = function (entity) {
                return _this.client.portal_roles_config_membership_ESet_delete(entity.GetColumn('UID_ESet').GetValue(), entity.GetColumn('UID_Person').GetValue());
            };
        }
        PortalRolesConfigMembershipEsetWrapper.prototype.createEntity = function (initialData) {
            this.buildBuilderIfNeeded();
            return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, imxQbmDbts.EntityState.Created);
        };
        /** Returns the runtime schema for this method. */
        PortalRolesConfigMembershipEsetWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/roles/config/membership/ESet/{UID_ESet}');
        };
        PortalRolesConfigMembershipEsetWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/roles/config/membership/ESet/{UID_ESet}');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalRolesConfigMembershipEset, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalRolesConfigMembershipEsetWrapper.prototype.Get = function (UID_ESet, parametersOptional) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_roles_config_membership_ESet_get(UID_ESet, parametersOptional)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalRolesConfigMembershipEsetWrapper.prototype.Post = function (UID_ESet, inputParameterName) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_roles_config_membership_ESet_post(UID_ESet, inputParameterName.EntityWriteData)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalRolesConfigMembershipEsetWrapper.prototype.Delete = function (UID_ESet, UID_Person) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_roles_config_membership_ESet_delete(UID_ESet, UID_Person)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalRolesConfigMembershipEsetWrapper;
    }());
    var PortalShopConfigEntitlementsEsetWrapper = /** @class */ (function () {
        function PortalShopConfigEntitlementsEsetWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                {
                    return _this.client.portal_shop_config_entitlements_ESet_post(entity.GetColumn('UID_ITShopOrg').GetValue(), writeData);
                }
            };
            this.deleteMethod = function (entity) {
                return _this.client.portal_shop_config_entitlements_ESet_delete(entity.GetColumn('UID_ITShopOrg').GetValue(), entity.GetColumn('UID_ESet').GetValue());
            };
        }
        PortalShopConfigEntitlementsEsetWrapper.prototype.createEntity = function (initialData) {
            this.buildBuilderIfNeeded();
            return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, imxQbmDbts.EntityState.Created);
        };
        /** Returns the runtime schema for this method. */
        PortalShopConfigEntitlementsEsetWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/shop/config/entitlements/{UID_ITShopOrg}/ESet');
        };
        PortalShopConfigEntitlementsEsetWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/shop/config/entitlements/{UID_ITShopOrg}/ESet');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalShopConfigEntitlementsEset, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalShopConfigEntitlementsEsetWrapper.prototype.Get = function (UID_ITShopOrg, parametersOptional) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_ESet_get(UID_ITShopOrg, parametersOptional)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalShopConfigEntitlementsEsetWrapper.prototype.Post = function (UID_ITShopOrg, inputParameterName) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_ESet_post(UID_ITShopOrg, inputParameterName.EntityWriteData)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalShopConfigEntitlementsEsetWrapper.prototype.Delete = function (UID_ITShopOrg, UID_ESet) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_ESet_delete(UID_ITShopOrg, UID_ESet)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalShopConfigEntitlementsEsetWrapper;
    }());
    /** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
    var ApiClientMethodFactory = /** @class */ (function () {
        function ApiClientMethodFactory() {
        }
        ApiClientMethodFactory.prototype.portal_admin_role_eset_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, risk, esettype) {
            return {
                path: '/portal/admin/role/eset',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'risk',
                        value: risk,
                        in: 'query'
                    },
                    {
                        name: 'esettype',
                        value: esettype,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_admin_role_eset_put = function (inputParameterName) {
            return {
                path: '/portal/admin/role/eset',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_admin_role_eset_bulk_put = function (inputParameterName) {
            return {
                path: '/portal/admin/role/eset/bulk',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_admin_role_eset_datamodel_get = function (filter) {
            return {
                path: '/portal/admin/role/eset/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_admin_role_eset_interactive_put = function (inputParameterName) {
            return {
                path: '/portal/admin/role/eset/interactive',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_admin_role_eset_interactive_byid_get = function (UID_ESet) {
            return {
                path: '/portal/admin/role/eset/interactive/{UID_ESet}',
                parameters: [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_person_rolememberships_ESet_get = function (UID_Person, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/person/{UID_Person}/rolememberships/ESet',
                parameters: [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_resp_eset_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, esettype) {
            return {
                path: '/portal/resp/eset',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'esettype',
                        value: esettype,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_resp_eset_datamodel_get = function (filter) {
            return {
                path: '/portal/resp/eset/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_resp_eset_interactive_put = function (inputParameterName) {
            return {
                path: '/portal/resp/eset/interactive',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_resp_eset_interactive_byid_get = function (UID_ESet) {
            return {
                path: '/portal/resp/eset/interactive/{UID_ESet}',
                parameters: [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_roles_config_classes_ESet_get = function () {
            return {
                path: '/portal/roles/config/classes/ESet',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_get = function (UID_ESet, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}',
                parameters: [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_post = function (UID_ESet, inputParameterName) {
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}',
                parameters: [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_delete = function (UID_ESet, UID_ESetHasEntitlement) {
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}/{UID_ESetHasEntitlement}',
                parameters: [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_ESetHasEntitlement',
                        value: UID_ESetHasEntitlement,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_get = function (UID_ESet, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}/Entitlement/ESet/candidates',
                parameters: [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_filtertree_post = function (UID_ESet, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}/Entitlement/ESet/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERAssign_candidates_get = function (UID_ESet, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERAssign/candidates',
                parameters: [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERAssign_candidates_filtertree_post = function (UID_ESet, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERAssign/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_get = function (UID_ESet, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERResource/candidates',
                parameters: [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_filtertree_post = function (UID_ESet, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERResource/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERReuse_candidates_get = function (UID_ESet, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERReuse/candidates',
                parameters: [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERReuse_candidates_filtertree_post = function (UID_ESet, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERReuse/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERReuseUS_candidates_get = function (UID_ESet, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERReuseUS/candidates',
                parameters: [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERReuseUS_candidates_filtertree_post = function (UID_ESet, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERReuseUS/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_roles_config_membership_ESet_get = function (UID_ESet, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/roles/config/membership/ESet/{UID_ESet}',
                parameters: [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_roles_config_membership_ESet_post = function (UID_ESet, inputParameterName) {
            return {
                path: '/portal/roles/config/membership/ESet/{UID_ESet}',
                parameters: [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_roles_config_membership_ESet_delete = function (UID_ESet, UID_Person) {
            return {
                path: '/portal/roles/config/membership/ESet/{UID_ESet}/{UID_Person}',
                parameters: [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_roles_config_membership_ESet_UID_Person_candidates_get = function (UID_ESet, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/roles/config/membership/ESet/{UID_ESet}/UID_Person/candidates',
                parameters: [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'xorigin',
                        value: xorigin,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_roles_config_membership_ESet_UID_Person_candidates_filtertree_post = function (UID_ESet, xorigin, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/roles/config/membership/ESet/{UID_ESet}/UID_Person/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'xorigin',
                        value: xorigin,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_ESet_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/ESet',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_ESet_post = function (UID_ITShopOrg, inputParameterName) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/ESet',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_ESet_delete = function (UID_ITShopOrg, UID_ESet) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/ESet/{UID_ESet}',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_ESet_UID_ESet_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/ESet/UID_ESet/candidates',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_ESet_UID_ESet_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/ESet/UID_ESet/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        return ApiClientMethodFactory;
    }());
    /** @deprecated Use the V2Client class for a stable method interface. */
    var Client = /** @class */ (function () {
        function Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        Client.prototype.portal_admin_role_eset_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, risk, esettype) {
            return this.apiClient.processRequest(this.methodFactory.portal_admin_role_eset_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, risk, esettype));
        };
        Client.prototype.portal_admin_role_eset_put = function (inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_admin_role_eset_put(inputParameterName));
        };
        Client.prototype.portal_admin_role_eset_bulk_put = function (inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_admin_role_eset_bulk_put(inputParameterName));
        };
        /** Returns data model information about query options for the admin/role/eset endpoint. */
        Client.prototype.portal_admin_role_eset_datamodel_get = function (filter) {
            return this.apiClient.processRequest(this.methodFactory.portal_admin_role_eset_datamodel_get(filter));
        };
        Client.prototype.portal_admin_role_eset_interactive_put = function (inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_admin_role_eset_interactive_put(inputParameterName));
        };
        Client.prototype.portal_admin_role_eset_interactive_byid_get = function (UID_ESet) {
            return this.apiClient.processRequest(this.methodFactory.portal_admin_role_eset_interactive_byid_get(UID_ESet));
        };
        Client.prototype.portal_person_rolememberships_ESet_get = function (UID_Person, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_person_rolememberships_ESet_get(UID_Person, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        Client.prototype.portal_resp_eset_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, esettype) {
            return this.apiClient.processRequest(this.methodFactory.portal_resp_eset_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, esettype));
        };
        /** Returns data model information about query options for the resp/eset endpoint. */
        Client.prototype.portal_resp_eset_datamodel_get = function (filter) {
            return this.apiClient.processRequest(this.methodFactory.portal_resp_eset_datamodel_get(filter));
        };
        Client.prototype.portal_resp_eset_interactive_put = function (inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_resp_eset_interactive_put(inputParameterName));
        };
        Client.prototype.portal_resp_eset_interactive_byid_get = function (UID_ESet) {
            return this.apiClient.processRequest(this.methodFactory.portal_resp_eset_interactive_byid_get(UID_ESet));
        };
        Client.prototype.portal_roles_config_classes_ESet_get = function () {
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_classes_ESet_get());
        };
        Client.prototype.portal_roles_config_entitlements_ESet_get = function (UID_ESet, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_get(UID_ESet, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        Client.prototype.portal_roles_config_entitlements_ESet_post = function (UID_ESet, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_post(UID_ESet, inputParameterName));
        };
        Client.prototype.portal_roles_config_entitlements_ESet_delete = function (UID_ESet, UID_ESetHasEntitlement) {
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_delete(UID_ESet, UID_ESetHasEntitlement));
        };
        /** Returns a list of objects that can be assigned to the property Entitlement. */
        Client.prototype.portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_get = function (UID_ESet, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_get(UID_ESet, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/ESet/candidates endpoint. */
        Client.prototype.portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_filtertree_post = function (UID_ESet, filter, parentkey, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_filtertree_post(UID_ESet, filter, parentkey, inputParameterName));
        };
        /** Returns a list of objects that can be assigned to the property Entitlement. */
        Client.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERAssign_candidates_get = function (UID_ESet, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_Entitlement_QERAssign_candidates_get(UID_ESet, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERAssign/candidates endpoint. */
        Client.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERAssign_candidates_filtertree_post = function (UID_ESet, filter, parentkey, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_Entitlement_QERAssign_candidates_filtertree_post(UID_ESet, filter, parentkey, inputParameterName));
        };
        /** Returns a list of objects that can be assigned to the property Entitlement. */
        Client.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_get = function (UID_ESet, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_get(UID_ESet, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERResource/candidates endpoint. */
        Client.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_filtertree_post = function (UID_ESet, filter, parentkey, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_filtertree_post(UID_ESet, filter, parentkey, inputParameterName));
        };
        /** Returns a list of objects that can be assigned to the property Entitlement. */
        Client.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERReuse_candidates_get = function (UID_ESet, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_Entitlement_QERReuse_candidates_get(UID_ESet, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERReuse/candidates endpoint. */
        Client.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERReuse_candidates_filtertree_post = function (UID_ESet, filter, parentkey, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_Entitlement_QERReuse_candidates_filtertree_post(UID_ESet, filter, parentkey, inputParameterName));
        };
        /** Returns a list of objects that can be assigned to the property Entitlement. */
        Client.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERReuseUS_candidates_get = function (UID_ESet, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_Entitlement_QERReuseUS_candidates_get(UID_ESet, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERReuseUS/candidates endpoint. */
        Client.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERReuseUS_candidates_filtertree_post = function (UID_ESet, filter, parentkey, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_Entitlement_QERReuseUS_candidates_filtertree_post(UID_ESet, filter, parentkey, inputParameterName));
        };
        Client.prototype.portal_roles_config_membership_ESet_get = function (UID_ESet, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_membership_ESet_get(UID_ESet, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        Client.prototype.portal_roles_config_membership_ESet_post = function (UID_ESet, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_membership_ESet_post(UID_ESet, inputParameterName));
        };
        Client.prototype.portal_roles_config_membership_ESet_delete = function (UID_ESet, UID_Person) {
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_membership_ESet_delete(UID_ESet, UID_Person));
        };
        /** Returns a list of objects that can be assigned to the property UID_Person. */
        Client.prototype.portal_roles_config_membership_ESet_UID_Person_candidates_get = function (UID_ESet, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_membership_ESet_UID_Person_candidates_get(UID_ESet, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        /** Returns filter tree information for the roles/config/membership/ESet/{UID_ESet}/UID_Person/candidates endpoint. */
        Client.prototype.portal_roles_config_membership_ESet_UID_Person_candidates_filtertree_post = function (UID_ESet, xorigin, filter, parentkey, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_membership_ESet_UID_Person_candidates_filtertree_post(UID_ESet, xorigin, filter, parentkey, inputParameterName));
        };
        Client.prototype.portal_shop_config_entitlements_ESet_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_ESet_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        Client.prototype.portal_shop_config_entitlements_ESet_post = function (UID_ITShopOrg, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_ESet_post(UID_ITShopOrg, inputParameterName));
        };
        Client.prototype.portal_shop_config_entitlements_ESet_delete = function (UID_ITShopOrg, UID_ESet) {
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_ESet_delete(UID_ITShopOrg, UID_ESet));
        };
        /** Returns a list of objects that can be assigned to the property UID_ESet. */
        Client.prototype.portal_shop_config_entitlements_ESet_UID_ESet_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_ESet_UID_ESet_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/ESet/UID_ESet/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_ESet_UID_ESet_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_ESet_UID_ESet_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName));
        };
        return Client;
    }());
    var V2ApiClientMethodFactory = /** @class */ (function () {
        function V2ApiClientMethodFactory() {
        }
        V2ApiClientMethodFactory.prototype.portal_admin_role_eset_get = function (options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/admin/role/eset',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_admin_role_eset_put = function (inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/admin/role/eset',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_admin_role_eset_bulk_put = function (inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/admin/role/eset/bulk',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_admin_role_eset_datamodel_get = function (options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/admin/role/eset/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_admin_role_eset_interactive_put = function (inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/admin/role/eset/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_admin_role_eset_interactive_byid_get = function (UID_ESet, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/admin/role/eset/interactive/{UID_ESet}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_person_rolememberships_ESet_get = function (UID_Person, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/person/{UID_Person}/rolememberships/ESet',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_resp_eset_get = function (options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/resp/eset',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_resp_eset_datamodel_get = function (options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/resp/eset/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_resp_eset_interactive_put = function (inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/resp/eset/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_resp_eset_interactive_byid_get = function (UID_ESet, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/resp/eset/interactive/{UID_ESet}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_roles_config_classes_ESet_get = function (options) {
            return {
                path: '/portal/roles/config/classes/ESet',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_get = function (UID_ESet, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_post = function (UID_ESet, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_delete = function (UID_ESet, UID_ESetHasEntitlement, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}/{UID_ESetHasEntitlement}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_ESetHasEntitlement',
                        value: UID_ESetHasEntitlement,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_get = function (UID_ESet, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}/Entitlement/ESet/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_filtertree_post = function (UID_ESet, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}/Entitlement/ESet/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERAssign_candidates_get = function (UID_ESet, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERAssign/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERAssign_candidates_filtertree_post = function (UID_ESet, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERAssign/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_get = function (UID_ESet, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERResource/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_filtertree_post = function (UID_ESet, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERResource/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERReuse_candidates_get = function (UID_ESet, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERReuse/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERReuse_candidates_filtertree_post = function (UID_ESet, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERReuse/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERReuseUS_candidates_get = function (UID_ESet, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERReuseUS/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERReuseUS_candidates_filtertree_post = function (UID_ESet, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERReuseUS/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_roles_config_membership_ESet_get = function (UID_ESet, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/roles/config/membership/ESet/{UID_ESet}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_roles_config_membership_ESet_post = function (UID_ESet, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/roles/config/membership/ESet/{UID_ESet}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_roles_config_membership_ESet_delete = function (UID_ESet, UID_Person, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/roles/config/membership/ESet/{UID_ESet}/{UID_Person}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_roles_config_membership_ESet_UID_Person_candidates_get = function (UID_ESet, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/roles/config/membership/ESet/{UID_ESet}/UID_Person/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_roles_config_membership_ESet_UID_Person_candidates_filtertree_post = function (UID_ESet, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/roles/config/membership/ESet/{UID_ESet}/UID_Person/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_ESet_get = function (UID_ITShopOrg, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/ESet',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_ESet_post = function (UID_ITShopOrg, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/ESet',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_ESet_delete = function (UID_ITShopOrg, UID_ESet, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/ESet/{UID_ESet}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_ESet',
                        value: UID_ESet,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_ESet_UID_ESet_candidates_get = function (UID_ITShopOrg, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/ESet/UID_ESet/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_ESet_UID_ESet_candidates_filtertree_post = function (UID_ITShopOrg, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/ESet/UID_ESet/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        return V2ApiClientMethodFactory;
    }());
    var V2Client = /** @class */ (function () {
        function V2Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new V2ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(V2Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        V2Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        V2Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        V2Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        V2Client.prototype.portal_admin_role_eset_get = function (options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_admin_role_eset_get(options));
        };
        V2Client.prototype.portal_admin_role_eset_put = function (inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_admin_role_eset_put(inputParameterName, options));
        };
        V2Client.prototype.portal_admin_role_eset_bulk_put = function (inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_admin_role_eset_bulk_put(inputParameterName, options));
        };
        /** Returns data model information about query options for the admin/role/eset endpoint. */
        V2Client.prototype.portal_admin_role_eset_datamodel_get = function (options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_admin_role_eset_datamodel_get(options));
        };
        V2Client.prototype.portal_admin_role_eset_interactive_put = function (inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_admin_role_eset_interactive_put(inputParameterName, options));
        };
        V2Client.prototype.portal_admin_role_eset_interactive_byid_get = function (UID_ESet, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_admin_role_eset_interactive_byid_get(UID_ESet, options));
        };
        V2Client.prototype.portal_person_rolememberships_ESet_get = function (UID_Person, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_rolememberships_ESet_get(UID_Person, options));
        };
        V2Client.prototype.portal_resp_eset_get = function (options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_eset_get(options));
        };
        /** Returns data model information about query options for the resp/eset endpoint. */
        V2Client.prototype.portal_resp_eset_datamodel_get = function (options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_eset_datamodel_get(options));
        };
        V2Client.prototype.portal_resp_eset_interactive_put = function (inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_eset_interactive_put(inputParameterName, options));
        };
        V2Client.prototype.portal_resp_eset_interactive_byid_get = function (UID_ESet, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_eset_interactive_byid_get(UID_ESet, options));
        };
        V2Client.prototype.portal_roles_config_classes_ESet_get = function (options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_classes_ESet_get(options));
        };
        V2Client.prototype.portal_roles_config_entitlements_ESet_get = function (UID_ESet, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_get(UID_ESet, options));
        };
        V2Client.prototype.portal_roles_config_entitlements_ESet_post = function (UID_ESet, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_post(UID_ESet, inputParameterName, options));
        };
        V2Client.prototype.portal_roles_config_entitlements_ESet_delete = function (UID_ESet, UID_ESetHasEntitlement, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_delete(UID_ESet, UID_ESetHasEntitlement, options));
        };
        /** Returns a list of objects that can be assigned to the property Entitlement. */
        V2Client.prototype.portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_get = function (UID_ESet, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_get(UID_ESet, options));
        };
        /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/ESet/candidates endpoint. */
        V2Client.prototype.portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_filtertree_post = function (UID_ESet, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_filtertree_post(UID_ESet, inputParameterName, options));
        };
        /** Returns a list of objects that can be assigned to the property Entitlement. */
        V2Client.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERAssign_candidates_get = function (UID_ESet, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_Entitlement_QERAssign_candidates_get(UID_ESet, options));
        };
        /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERAssign/candidates endpoint. */
        V2Client.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERAssign_candidates_filtertree_post = function (UID_ESet, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_Entitlement_QERAssign_candidates_filtertree_post(UID_ESet, inputParameterName, options));
        };
        /** Returns a list of objects that can be assigned to the property Entitlement. */
        V2Client.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_get = function (UID_ESet, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_get(UID_ESet, options));
        };
        /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERResource/candidates endpoint. */
        V2Client.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_filtertree_post = function (UID_ESet, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_filtertree_post(UID_ESet, inputParameterName, options));
        };
        /** Returns a list of objects that can be assigned to the property Entitlement. */
        V2Client.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERReuse_candidates_get = function (UID_ESet, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_Entitlement_QERReuse_candidates_get(UID_ESet, options));
        };
        /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERReuse/candidates endpoint. */
        V2Client.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERReuse_candidates_filtertree_post = function (UID_ESet, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_Entitlement_QERReuse_candidates_filtertree_post(UID_ESet, inputParameterName, options));
        };
        /** Returns a list of objects that can be assigned to the property Entitlement. */
        V2Client.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERReuseUS_candidates_get = function (UID_ESet, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_Entitlement_QERReuseUS_candidates_get(UID_ESet, options));
        };
        /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERReuseUS/candidates endpoint. */
        V2Client.prototype.portal_roles_config_entitlements_ESet_Entitlement_QERReuseUS_candidates_filtertree_post = function (UID_ESet, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_entitlements_ESet_Entitlement_QERReuseUS_candidates_filtertree_post(UID_ESet, inputParameterName, options));
        };
        V2Client.prototype.portal_roles_config_membership_ESet_get = function (UID_ESet, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_membership_ESet_get(UID_ESet, options));
        };
        V2Client.prototype.portal_roles_config_membership_ESet_post = function (UID_ESet, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_membership_ESet_post(UID_ESet, inputParameterName, options));
        };
        V2Client.prototype.portal_roles_config_membership_ESet_delete = function (UID_ESet, UID_Person, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_membership_ESet_delete(UID_ESet, UID_Person, options));
        };
        /** Returns a list of objects that can be assigned to the property UID_Person. */
        V2Client.prototype.portal_roles_config_membership_ESet_UID_Person_candidates_get = function (UID_ESet, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_membership_ESet_UID_Person_candidates_get(UID_ESet, options));
        };
        /** Returns filter tree information for the roles/config/membership/ESet/{UID_ESet}/UID_Person/candidates endpoint. */
        V2Client.prototype.portal_roles_config_membership_ESet_UID_Person_candidates_filtertree_post = function (UID_ESet, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_membership_ESet_UID_Person_candidates_filtertree_post(UID_ESet, inputParameterName, options));
        };
        V2Client.prototype.portal_shop_config_entitlements_ESet_get = function (UID_ITShopOrg, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_ESet_get(UID_ITShopOrg, options));
        };
        V2Client.prototype.portal_shop_config_entitlements_ESet_post = function (UID_ITShopOrg, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_ESet_post(UID_ITShopOrg, inputParameterName, options));
        };
        V2Client.prototype.portal_shop_config_entitlements_ESet_delete = function (UID_ITShopOrg, UID_ESet, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_ESet_delete(UID_ITShopOrg, UID_ESet, options));
        };
        /** Returns a list of objects that can be assigned to the property UID_ESet. */
        V2Client.prototype.portal_shop_config_entitlements_ESet_UID_ESet_candidates_get = function (UID_ITShopOrg, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_ESet_UID_ESet_candidates_get(UID_ITShopOrg, options));
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/ESet/UID_ESet/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_ESet_UID_ESet_candidates_filtertree_post = function (UID_ITShopOrg, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_ESet_UID_ESet_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options));
        };
        return V2Client;
    }());

    exports.ApiClientMethodFactory = ApiClientMethodFactory;
    exports.Client = Client;
    exports.PortalAdminRoleEset = PortalAdminRoleEset;
    exports.PortalAdminRoleEsetInteractive = PortalAdminRoleEsetInteractive;
    exports.PortalAdminRoleEsetInteractiveWrapper = PortalAdminRoleEsetInteractiveWrapper;
    exports.PortalAdminRoleEsetWrapper = PortalAdminRoleEsetWrapper;
    exports.PortalPersonRolemembershipsEset = PortalPersonRolemembershipsEset;
    exports.PortalPersonRolemembershipsEsetWrapper = PortalPersonRolemembershipsEsetWrapper;
    exports.PortalRespEset = PortalRespEset;
    exports.PortalRespEsetInteractive = PortalRespEsetInteractive;
    exports.PortalRespEsetInteractiveWrapper = PortalRespEsetInteractiveWrapper;
    exports.PortalRespEsetWrapper = PortalRespEsetWrapper;
    exports.PortalRolesConfigEntitlementsEset = PortalRolesConfigEntitlementsEset;
    exports.PortalRolesConfigEntitlementsEsetWrapper = PortalRolesConfigEntitlementsEsetWrapper;
    exports.PortalRolesConfigMembershipEset = PortalRolesConfigMembershipEset;
    exports.PortalRolesConfigMembershipEsetWrapper = PortalRolesConfigMembershipEsetWrapper;
    exports.PortalShopConfigEntitlementsEset = PortalShopConfigEntitlementsEset;
    exports.PortalShopConfigEntitlementsEsetWrapper = PortalShopConfigEntitlementsEsetWrapper;
    exports.TypedClient = TypedClient;
    exports.V2ApiClientMethodFactory = V2ApiClientMethodFactory;
    exports.V2Client = V2Client;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
