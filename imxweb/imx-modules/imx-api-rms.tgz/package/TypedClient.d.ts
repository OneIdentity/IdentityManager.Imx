import { ApiClient, ApiRequestOptions, DataModel, EntityCollectionData, EntityData, EntitySchema, EntityWriteData, EntityWriteDataColumn, EntityWriteDataSingle, FilterData, FilterTreeData, FkProviderItem, InteractiveEntityData, InteractiveEntityWriteData, IReadValue, IWriteValue, MethodDescriptor, StaticSchema, TypedEntity } from 'imx-qbm-dbts';
export interface EntityWriteDataBulk {
    Keys?: string[][];
    Data?: EntityWriteDataColumn[];
}
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface RoleAssignmentData {
    TableName?: string;
    TableDisplay?: string;
    UnionTableName?: string;
    UnionTableDisplay?: string;
    AssignTable?: string;
    RoleTable?: string;
    RoleFk?: string;
    EntitlementPk?: string;
    EntitlementFk?: string;
}
export declare class TypedClient {
    readonly PortalAdminRoleEset: PortalAdminRoleEsetWrapper;
    readonly PortalAdminRoleEsetInteractive: PortalAdminRoleEsetInteractiveWrapper;
    readonly PortalPersonRolemembershipsEset: PortalPersonRolemembershipsEsetWrapper;
    readonly PortalRespEset: PortalRespEsetWrapper;
    readonly PortalRespEsetInteractive: PortalRespEsetInteractiveWrapper;
    readonly PortalRolesConfigEntitlementsEset: PortalRolesConfigEntitlementsEsetWrapper;
    readonly PortalRolesConfigMembershipEset: PortalRolesConfigMembershipEsetWrapper;
    readonly PortalShopConfigEntitlementsEset: PortalShopConfigEntitlementsEsetWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalAdminRoleEset extends TypedEntity {
    readonly UID_AccProduct: IReadValue<string>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly XObjectKey: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_AccProduct' | 'RiskIndexCalculated' | 'XObjectKey'>;
}
export declare class PortalAdminRoleEsetInteractive extends TypedEntity {
    readonly UID_AccProduct: IReadValue<string>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly XObjectKey: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_AccProduct' | 'RiskIndexCalculated' | 'XObjectKey'>;
}
export declare class PortalPersonRolemembershipsEset extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly UID_ESet: IReadValue<string>;
    readonly RoleFullPath: IReadValue<string>;
    readonly UID_PersonWantsOrg: IReadValue<string>;
    readonly OrderState: IReadValue<string>;
    readonly IsRequestCancellable: IReadValue<boolean>;
    readonly ValidUntil: IReadValue<Date>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'XObjectKey' | 'XOrigin' | 'XDateInserted' | 'UID_ESet' | 'RoleFullPath' | 'UID_PersonWantsOrg' | 'OrderState' | 'IsRequestCancellable' | 'ValidUntil'>;
}
export declare class PortalRespEset extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey'>;
}
export declare class PortalRespEsetInteractive extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey'>;
}
export declare class PortalRolesConfigEntitlementsEset extends TypedEntity {
    readonly UID_ESet: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly Entitlement: IWriteValue<string>;
    readonly UID_PersonWantsOrg: IReadValue<string>;
    readonly OrderState: IReadValue<string>;
    readonly IsRequestCancellable: IReadValue<boolean>;
    readonly ValidUntil: IReadValue<Date>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_ESet' | 'XObjectKey' | 'XOrigin' | 'XDateInserted' | 'XMarkedForDeletion' | 'Entitlement' | 'UID_PersonWantsOrg' | 'OrderState' | 'IsRequestCancellable' | 'ValidUntil'>;
}
export declare class PortalRolesConfigMembershipEset extends TypedEntity {
    readonly UID_ESet: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XIsInEffect: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly UID_Person: IWriteValue<string>;
    readonly UID_PersonWantsOrg: IReadValue<string>;
    readonly OrderState: IReadValue<string>;
    readonly IsRequestCancellable: IReadValue<boolean>;
    readonly ValidUntil: IReadValue<Date>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_ESet' | 'XObjectKey' | 'XOrigin' | 'XDateInserted' | 'XIsInEffect' | 'XMarkedForDeletion' | 'UID_Person' | 'UID_PersonWantsOrg' | 'OrderState' | 'IsRequestCancellable' | 'ValidUntil'>;
}
export declare class PortalShopConfigEntitlementsEset extends TypedEntity {
    readonly UID_ITShopOrg: IReadValue<string>;
    readonly UID_ESet: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_ITShopOrg' | 'UID_ESet'>;
}
export declare class PortalAdminRoleEsetWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        risk?: string;
        esettype?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleEset, unknown>>;
    Put(inputParameterName: PortalAdminRoleEset, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleEset, unknown>>;
}
export declare class PortalAdminRoleEsetInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalAdminRoleEsetInteractive, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleEsetInteractive, unknown>>;
    Get_byid(UID_ESet: string, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleEsetInteractive, unknown>>;
}
export declare class PortalPersonRolemembershipsEsetWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_Person: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonRolemembershipsEset, unknown>>;
}
export declare class PortalRespEsetWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        esettype?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespEset, unknown>>;
}
export declare class PortalRespEsetInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalRespEsetInteractive, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespEsetInteractive, unknown>>;
    Get_byid(UID_ESet: string, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespEsetInteractive, unknown>>;
}
export declare class PortalRolesConfigEntitlementsEsetWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalRolesConfigEntitlementsEset;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ESet: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRolesConfigEntitlementsEset, unknown>>;
    Post(UID_ESet: string, inputParameterName: PortalRolesConfigEntitlementsEset, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRolesConfigEntitlementsEset, unknown>>;
    Delete(UID_ESet: string, UID_ESetHasEntitlement: string, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRolesConfigEntitlementsEset, unknown>>;
}
export declare class PortalRolesConfigMembershipEsetWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalRolesConfigMembershipEset;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ESet: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRolesConfigMembershipEset, unknown>>;
    Post(UID_ESet: string, inputParameterName: PortalRolesConfigMembershipEset, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRolesConfigMembershipEset, unknown>>;
    Delete(UID_ESet: string, UID_Person: string, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRolesConfigMembershipEset, unknown>>;
}
export declare class PortalShopConfigEntitlementsEsetWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalShopConfigEntitlementsEset;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ITShopOrg: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsEset, unknown>>;
    Post(UID_ITShopOrg: string, inputParameterName: PortalShopConfigEntitlementsEset, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsEset, unknown>>;
    Delete(UID_ITShopOrg: string, UID_ESet: string, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsEset, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    portal_admin_role_eset_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, risk: string, esettype: string): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_eset_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_eset_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_admin_role_eset_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_admin_role_eset_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_eset_interactive_byid_get(UID_ESet: string): MethodDescriptor<InteractiveEntityData>;
    portal_person_rolememberships_ESet_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_resp_eset_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, esettype: string): MethodDescriptor<EntityCollectionData>;
    portal_resp_eset_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_resp_eset_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_resp_eset_interactive_byid_get(UID_ESet: string): MethodDescriptor<InteractiveEntityData>;
    portal_roles_config_classes_ESet_get(): MethodDescriptor<RoleAssignmentData[]>;
    portal_roles_config_entitlements_ESet_get(UID_ESet: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_post(UID_ESet: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_delete(UID_ESet: string, UID_ESetHasEntitlement: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_get(UID_ESet: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_filtertree_post(UID_ESet: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_roles_config_entitlements_ESet_Entitlement_QERAssign_candidates_get(UID_ESet: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_Entitlement_QERAssign_candidates_filtertree_post(UID_ESet: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_get(UID_ESet: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_filtertree_post(UID_ESet: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_roles_config_entitlements_ESet_Entitlement_QERReuse_candidates_get(UID_ESet: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_Entitlement_QERReuse_candidates_filtertree_post(UID_ESet: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_roles_config_entitlements_ESet_Entitlement_QERReuseUS_candidates_get(UID_ESet: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_Entitlement_QERReuseUS_candidates_filtertree_post(UID_ESet: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_roles_config_membership_ESet_get(UID_ESet: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ESet_post(UID_ESet: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ESet_delete(UID_ESet: string, UID_Person: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ESet_UID_Person_candidates_get(UID_ESet: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ESet_UID_Person_candidates_filtertree_post(UID_ESet: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_ESet_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_delete(UID_ITShopOrg: string, UID_ESet: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_UID_ESet_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_UID_ESet_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_admin_role_eset_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, risk: string, esettype: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_admin_role_eset_put(inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_admin_role_eset_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the admin/role/eset endpoint. */
    portal_admin_role_eset_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_admin_role_eset_interactive_put(inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_admin_role_eset_interactive_byid_get(UID_ESet: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_person_rolememberships_ESet_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_resp_eset_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, esettype: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/eset endpoint. */
    portal_resp_eset_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_resp_eset_interactive_put(inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_eset_interactive_byid_get(UID_ESet: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_roles_config_classes_ESet_get(requestOptions?: ApiRequestOptions): Promise<RoleAssignmentData[]>;
    portal_roles_config_entitlements_ESet_get(UID_ESet: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_post(UID_ESet: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_delete(UID_ESet: string, UID_ESetHasEntitlement: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property Entitlement. */
    portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_get(UID_ESet: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/ESet/candidates endpoint. */
    portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_filtertree_post(UID_ESet: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property Entitlement. */
    portal_roles_config_entitlements_ESet_Entitlement_QERAssign_candidates_get(UID_ESet: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERAssign/candidates endpoint. */
    portal_roles_config_entitlements_ESet_Entitlement_QERAssign_candidates_filtertree_post(UID_ESet: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property Entitlement. */
    portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_get(UID_ESet: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERResource/candidates endpoint. */
    portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_filtertree_post(UID_ESet: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property Entitlement. */
    portal_roles_config_entitlements_ESet_Entitlement_QERReuse_candidates_get(UID_ESet: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERReuse/candidates endpoint. */
    portal_roles_config_entitlements_ESet_Entitlement_QERReuse_candidates_filtertree_post(UID_ESet: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property Entitlement. */
    portal_roles_config_entitlements_ESet_Entitlement_QERReuseUS_candidates_get(UID_ESet: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERReuseUS/candidates endpoint. */
    portal_roles_config_entitlements_ESet_Entitlement_QERReuseUS_candidates_filtertree_post(UID_ESet: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_roles_config_membership_ESet_get(UID_ESet: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_config_membership_ESet_post(UID_ESet: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_config_membership_ESet_delete(UID_ESet: string, UID_Person: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    portal_roles_config_membership_ESet_UID_Person_candidates_get(UID_ESet: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the roles/config/membership/ESet/{UID_ESet}/UID_Person/candidates endpoint. */
    portal_roles_config_membership_ESet_UID_Person_candidates_filtertree_post(UID_ESet: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_shop_config_entitlements_ESet_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_delete(UID_ITShopOrg: string, UID_ESet: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_ESet. */
    portal_shop_config_entitlements_ESet_UID_ESet_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/ESet/UID_ESet/candidates endpoint. */
    portal_shop_config_entitlements_ESet_UID_ESet_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
}
export declare class V2ApiClientMethodFactory {
    portal_admin_role_eset_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        risk?: string;
        esettype?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_eset_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_eset_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_admin_role_eset_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_admin_role_eset_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_eset_interactive_byid_get(UID_ESet: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_person_rolememberships_ESet_get(UID_Person: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_resp_eset_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        esettype?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_resp_eset_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_resp_eset_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_resp_eset_interactive_byid_get(UID_ESet: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_roles_config_classes_ESet_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<RoleAssignmentData[]>;
    portal_roles_config_entitlements_ESet_get(UID_ESet: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_post(UID_ESet: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_delete(UID_ESet: string, UID_ESetHasEntitlement: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_get(UID_ESet: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_filtertree_post(UID_ESet: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_roles_config_entitlements_ESet_Entitlement_QERAssign_candidates_get(UID_ESet: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_Entitlement_QERAssign_candidates_filtertree_post(UID_ESet: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_get(UID_ESet: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_filtertree_post(UID_ESet: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_roles_config_entitlements_ESet_Entitlement_QERReuse_candidates_get(UID_ESet: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_Entitlement_QERReuse_candidates_filtertree_post(UID_ESet: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_roles_config_entitlements_ESet_Entitlement_QERReuseUS_candidates_get(UID_ESet: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_Entitlement_QERReuseUS_candidates_filtertree_post(UID_ESet: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_roles_config_membership_ESet_get(UID_ESet: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ESet_post(UID_ESet: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ESet_delete(UID_ESet: string, UID_Person: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ESet_UID_Person_candidates_get(UID_ESet: string, options?: {
        xorigin?: number;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ESet_UID_Person_candidates_filtertree_post(UID_ESet: string, inputParameterName: EntityWriteDataSingle, options?: {
        xorigin?: number;
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_ESet_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_delete(UID_ITShopOrg: string, UID_ESet: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_UID_ESet_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_UID_ESet_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_admin_role_eset_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        risk?: string;
        esettype?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_admin_role_eset_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_admin_role_eset_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the admin/role/eset endpoint. */
    portal_admin_role_eset_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_admin_role_eset_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_admin_role_eset_interactive_byid_get(UID_ESet: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_person_rolememberships_ESet_get(UID_Person: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_resp_eset_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        esettype?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/eset endpoint. */
    portal_resp_eset_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_resp_eset_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_eset_interactive_byid_get(UID_ESet: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_roles_config_classes_ESet_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<RoleAssignmentData[]>;
    portal_roles_config_entitlements_ESet_get(UID_ESet: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_post(UID_ESet: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_config_entitlements_ESet_delete(UID_ESet: string, UID_ESetHasEntitlement: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property Entitlement. */
    portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_get(UID_ESet: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/ESet/candidates endpoint. */
    portal_roles_config_entitlements_ESet_Entitlement_ESet_candidates_filtertree_post(UID_ESet: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property Entitlement. */
    portal_roles_config_entitlements_ESet_Entitlement_QERAssign_candidates_get(UID_ESet: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERAssign/candidates endpoint. */
    portal_roles_config_entitlements_ESet_Entitlement_QERAssign_candidates_filtertree_post(UID_ESet: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property Entitlement. */
    portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_get(UID_ESet: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERResource/candidates endpoint. */
    portal_roles_config_entitlements_ESet_Entitlement_QERResource_candidates_filtertree_post(UID_ESet: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property Entitlement. */
    portal_roles_config_entitlements_ESet_Entitlement_QERReuse_candidates_get(UID_ESet: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERReuse/candidates endpoint. */
    portal_roles_config_entitlements_ESet_Entitlement_QERReuse_candidates_filtertree_post(UID_ESet: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property Entitlement. */
    portal_roles_config_entitlements_ESet_Entitlement_QERReuseUS_candidates_get(UID_ESet: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the roles/config/entitlements/ESet/{UID_ESet}/Entitlement/QERReuseUS/candidates endpoint. */
    portal_roles_config_entitlements_ESet_Entitlement_QERReuseUS_candidates_filtertree_post(UID_ESet: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_roles_config_membership_ESet_get(UID_ESet: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_config_membership_ESet_post(UID_ESet: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_config_membership_ESet_delete(UID_ESet: string, UID_Person: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    portal_roles_config_membership_ESet_UID_Person_candidates_get(UID_ESet: string, options?: {
        xorigin?: number;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the roles/config/membership/ESet/{UID_ESet}/UID_Person/candidates endpoint. */
    portal_roles_config_membership_ESet_UID_Person_candidates_filtertree_post(UID_ESet: string, inputParameterName: EntityWriteDataSingle, options?: {
        xorigin?: number;
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_shop_config_entitlements_ESet_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_ESet_delete(UID_ITShopOrg: string, UID_ESet: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_ESet. */
    portal_shop_config_entitlements_ESet_UID_ESet_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/ESet/UID_ESet/candidates endpoint. */
    portal_shop_config_entitlements_ESet_UID_ESet_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
}
