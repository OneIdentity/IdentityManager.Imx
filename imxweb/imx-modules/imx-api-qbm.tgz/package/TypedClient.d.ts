import { ApiClient, DataModel, EntityCollectionData, EntityColumnData, EntityData, EntitySchema, FilterData, FkCandidateRouteDto, FkProviderItem, HistoryData, IReadValue, MetaColumnData, MethodDescriptor, MethodSchemaDto, StaticSchema, TypedEntity } from 'imx-qbm-dbts';
export interface ApplicationAuthConfig {
    SsoAuthentifiers?: string[];
    ManualAuthentifiers?: string[];
    AdditionalAuthProps?: string;
    AuthenticationType?: AuthType;
    AllowPersistentAuth?: boolean;
    Product?: string;
    SecondaryAuth?: ISecondaryAuthProvider;
}
/** Represents application-specific configuration of method sets. */
export interface ApplicationMethodConfig {
    ApiProjects?: {
        [key: string]: ApplicationAuthConfig;
    };
    /** Gets or sets a flag indicating if all projects should be loaded, even the ones
not explicitly listed. */
    AllProjects: boolean;
}
export interface AuthConfig {
    Name?: string;
    Display?: string;
    ExternalLogoutUrl?: string;
    AuthProps?: AuthPropData[];
}
export interface AuthPropData {
    Name?: string;
    Display?: string;
    Type: AuthPropType;
    IsMandatory: boolean;
}
/** Authentication property types */
export declare enum AuthPropType {
    Info = 0,
    Edit = 1,
    Password = 2,
    Hidden = 3,
    Checkbox = 4,
    OAuth2Code = 5,
    NewPassword = 6
}
/** Represents the authentication status of a session. */
export interface AuthStatus {
    /** Returns the primary (database) authentication status. */
    PrimaryAuth?: PrimaryAuthStatus;
    /** Returns the authentication status for the second factor. */
    SecondaryAuth?: SecondaryAuthStatus;
    /** Returns the expiration date for the current authentication. */
    AuthValidUntil?: Date;
    /** Returns a URL to use for logging out from an external authentication provider. */
    ExternalLogoutUrl?: string;
    /** Returns the currently active culture for interface strings. */
    Culture?: string;
    /** Returns the currently active culture for value formatting. */
    CultureFormat?: string;
}
export declare enum AuthType {
    Default = 0,
    AllManualModules = 1,
    FixedCredentials = 2
}
export interface CacheData {
    IsDisabled: boolean;
    ObjectCount: number;
}
export interface CandidateData {
    ParameterName?: string;
    Candidates?: FkCandidateRouteDto;
}
export interface ConfigData {
    MethodConfig?: {
        [key: string]: ISessionAuthDbConfig;
    };
    ApplicationConfig?: ApplicationMethodConfig;
}
export interface ConfigNodeData {
    Key?: string;
    Name?: string;
    CanAddSetting?: boolean;
    Description?: string;
    Children?: ConfigNodeData[];
    Settings?: ConfigSettingData[];
}
export interface ConfigSettingData {
    Key?: string;
    Name?: string;
    Description?: string;
    HasCustomGlobalValue?: boolean;
    HasCustomLocalValue?: boolean;
    Value?: any;
    OriginalValue?: any;
    Type: ConfigSettingType;
}
export declare enum ConfigSettingType {
    None = 0,
    Sql = 1,
    Int = 2,
    PositiveInt = 3,
    Double = 4,
    RiskIndex = 5,
    PositiveDouble = 6,
    LimitedValues = 7
}
export interface ConfigSettingValidValue {
    Display?: string;
    Value?: string;
}
export interface EventStreamConfig {
    /** Specify how often to update the JobQueue chart. */
    RefreshIntervalSeconds: number;
    /** Specify how long data is kept in the history. */
    HistorySeconds: number;
}
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface HistoryComparisonData {
    CurrentValueDisplay?: string;
    HasChanged: boolean;
    ChangeType?: string;
    HistoryValueDisplay?: string;
    Property?: string;
    TableName?: string;
    Id?: string;
}
export interface ImxConfig {
    CompanyLogoUrl?: string;
    ProductName?: string;
    ProductVersion?: string;
}
export interface ISecondaryAuthProvider {
    Key: string;
    Display: any;
}
export interface ISessionAuthDbConfig {
    SsoAuthentifiers: any;
    ManualAuthentifiers: any;
    AdditionalAuthProps: any;
    AuthenticationType: any;
    Product: string;
    ExcludedAuthentifiers: any;
    SecondaryAuth: any;
    AllowUsersWithoutSecondFactor: boolean;
    AllowPersistentAuth: boolean;
    AuthProviders: any;
}
export interface LoadedPlugin {
    Plugin?: string;
    /**            If defined, the plugin failed while loading with the given exception.
            */
    Exception?: ExceptionData[];
}
export interface LogFileInfo {
    Path?: string;
    LastModified: Date;
}
export interface MetaTableData {
    Columns?: {
        [key: string]: MetaColumnData;
    };
    Display?: string;
    DisplaySingular?: string;
    ImageId?: string;
    Tablename?: string;
    IsDeactivated: boolean;
    IsMAllTable: boolean;
    IsMNTable: boolean;
    PrimaryKeyColumns?: string[];
    Uid?: string;
}
export interface MethodSetInfo {
    AppId?: string;
}
export interface NodeAppInfo {
    Name?: string;
    Description?: string;
    DisplayName?: string;
    PlugIns?: PlugInLib[];
}
export interface OfF__AnonymousType1OfInt32AndInt32 {
    Errors: number;
    Warnings: number;
}
export interface OfF__AnonymousType2OfBooleanAndBooleanAndBooleanAndBoolean {
    IsDbSchedulerDisabled: boolean;
    IsJobServiceDisabled: boolean;
    IsCompilationRequired: boolean;
    IsInMaintenanceMode: boolean;
}
export interface PackageInfo {
    Name?: string;
    RelativePath?: string;
    Fingerprint?: string;
    LastChangeDate: Date;
    IsCustom: boolean;
}
export interface PerfDataPoints extends ValueType {
    RuntimeMs?: number[];
}
export interface PingResult {
    /** Returns a flag indicating if the API could not be correctly initialized. */
    NoDbConnection: boolean;
    HasPluginErrors: boolean;
    IsWaitingToStartUpdate: boolean;
    PluginsWithErrors?: string[];
}
export interface PlugInLib {
    Container?: string;
    Name?: string;
}
export interface PrimaryAuthStatus {
    /** Returns the display name of the authenticated user. */
    Display?: string;
    /** Returns the unique identifier of the associated identity, if any. */
    Uid?: string;
    IsAuthenticated: boolean;
    /** Returns the time of the authentication. */
    AuthTime: Date;
}
export interface ProjectConfig {
    CandidateConfig?: {
        [key: string]: CandidateData[];
    };
    /** Enter the instrumentation key required to log metrics to App Insights. */
    AppInsightsKey?: string;
    /** Specify whether the web application sends browser notifications (for example, for pending requests or pending attestations). Users can still deactivate browser notifications. */
    VI_Common_EnableNotifications: boolean;
    /** Specify whether images are resized automatically when uploaded to the server. */
    EnableImageResizing: boolean;
    /** Enter the site key (public key) for reCAPTCHA integration. */
    RecaptchaPublicKey?: string;
    DefaultPageSize: number;
    /** Specify how many of the previous days to take into account by default when generating reports. */
    DefaultHistoryLengthDays: number;
}
export interface QueueEntriesData {
    DbQueue?: EntityData[];
    JobQueue?: EntityData[];
    Unsupported: boolean;
}
export interface ReactivateJobInput {
    UidJobs?: string[];
    Mode: ReactivateJobMode;
}
export declare enum ReactivateJobMode {
    Reactivate = 0,
    ContinueSuccess = 1,
    ContinueError = 2
}
export interface SearchResultObject {
    Key?: string;
    Display?: string;
}
export interface SecondaryAuthStatus {
    /** Returns a flag indicating if the second authentication factor has succeeded. */
    IsAuthenticated: boolean;
    ErrorMessage?: string;
    /** Returns a flag indicating whether two-factor authentication is enabled.
If this value is false, two-factor authentication is not required. */
    IsEnabled: boolean;
    /** Returns the name of the two-factor authentication provider. */
    Name?: string;
}
export interface ServerConfig {
    ServerName?: string;
    Version?: string;
    Time: Date;
    User?: string;
    Revision?: string;
}
export interface SessionResponse {
    Status?: AuthStatus;
    Config?: AuthConfig[];
}
/** Represents for a single hyperview shape. */
export interface ShapeData {
    /** Returns a flag indicating whether the shape should show that the object is in a deleted state. */
    IsDeleted: boolean;
    /** Returns the title caption of the shape. */
    Caption?: string;
    /** Returns an optional, secondary header text. */
    HeaderText?: string;
    Identifier?: string;
    /** Returns the object key of the associated object. */
    ObjectKey?: string;
    /** Returns the shape color to use, in ARGB hex format. */
    ElementColor?: string;
    Description?: string;
    TableName?: string;
    DbWhereClause?: string;
    /** Returns a list of elements to be displayed inside this shape. */
    Elements?: ShapeListEntry[];
    /** Returns a flag indicating whether the list of element is truncated because
the maximum number of elements was reached. */
    IsLimitReached?: boolean;
    /** Returns the layout type to use for this shape. */
    LayoutType?: string;
    ImageUid?: string;
    DbTableName?: string;
    /** Returns a list of properties to be displayed inside this shape. */
    Properties?: ShapeProperty[];
}
export interface ShapeListEntry {
    /** Returns the object key of the associated object. This property may be null. */
    ObjectKey?: string;
    DisplayValue?: string;
}
export interface ShapeProperty {
    Property?: string;
    DbColumnName?: string;
    EndsSection?: boolean;
    Value?: EntityColumnData;
}
export interface SoftwareStatus {
    CanStartUpdater: boolean;
    Status: UpdaterState;
}
export interface SystemInfo {
    /** Returns the list of active preprocessor definitions. */
    PreProps?: string[];
    UpdatePhase: number;
    SoftwareStatus: UpdaterState;
    DbDisplay?: string;
    ServerVersion?: string;
    ProductionLevel: number;
    ProductionLevelAddOn?: string;
    LastMigrationDate: Date;
    CustomerName?: string;
    IsDbSchedulerDisabled: boolean;
    IsJobServiceDisabled: boolean;
}
/** Represents the software update state. */
export declare enum UpdaterState {
    UpdatesAvailable = 0,
    NoUpdatesAvailable = 1,
    AlreadyRunning = 2,
    Disabled = 3
}
export interface UserGroupInfo {
    Uid?: string;
    Name?: string;
}
export interface ValueType {
}
export interface VerbPermissionInfo {
    Allowed: boolean;
}
export declare class TypedClient {
    readonly ImxMultilanguageUicultures: ImxMultilanguageUiculturesWrapper;
    readonly ImxSysteminfoThirdparty: ImxSysteminfoThirdpartyWrapper;
    readonly OpsupportJobservers: OpsupportJobserversWrapper;
    readonly OpsupportJournal: OpsupportJournalWrapper;
    readonly OpsupportQueueDbqueue: OpsupportQueueDbqueueWrapper;
    readonly OpsupportQueueFrozenjobs: OpsupportQueueFrozenjobsWrapper;
    readonly OpsupportQueueFrozenjobsbyqueue: OpsupportQueueFrozenjobsbyqueueWrapper;
    readonly OpsupportQueueJobaffects: OpsupportQueueJobaffectsWrapper;
    readonly OpsupportQueueJobchains: OpsupportQueueJobchainsWrapper;
    readonly OpsupportQueueJobperformance: OpsupportQueueJobperformanceWrapper;
    readonly OpsupportQueueJobs: OpsupportQueueJobsWrapper;
    readonly OpsupportQueueOverview: OpsupportQueueOverviewWrapper;
    readonly OpsupportQueueTree: OpsupportQueueTreeWrapper;
    readonly OpsupportSearchIndexedtables: OpsupportSearchIndexedtablesWrapper;
    readonly OpsupportSystemoverview: OpsupportSystemoverviewWrapper;
    readonly OpsupportWebapplications: OpsupportWebapplicationsWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class ImxMultilanguageUicultures extends TypedEntity {
    readonly Ident_DialogCulture: IReadValue<string>;
    readonly NativeName: IReadValue<string>;
    readonly Iso2Name: IReadValue<string>;
    readonly Iso3Name: IReadValue<string>;
    readonly DisplayName: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Ident_DialogCulture' | 'NativeName' | 'Iso2Name' | 'Iso3Name' | 'DisplayName'>;
}
export declare class ImxSysteminfoThirdparty extends TypedEntity {
    readonly ComponentName: IReadValue<string>;
    readonly CopyRight: IReadValue<string>;
    readonly EmailOrURl: IReadValue<string>;
    readonly LicenceName: IReadValue<string>;
    readonly LicenceText: IReadValue<string>;
    readonly UID_QBMV3rdPartyLicence: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'ComponentName' | 'CopyRight' | 'EmailOrURl' | 'LicenceName' | 'LicenceText' | 'UID_QBMV3rdPartyLicence'>;
}
export declare class OpsupportJobservers extends TypedEntity {
    readonly Ident_Server: IReadValue<string>;
    readonly IsInSoftwareUpdate: IReadValue<boolean>;
    readonly IsJobServiceDisabled: IReadValue<boolean>;
    readonly IsNoAutoupdate: IReadValue<boolean>;
    readonly QueueName: IReadValue<string>;
    readonly IPV6: IReadValue<string>;
    readonly IPV4: IReadValue<string>;
    readonly FQDN: IReadValue<string>;
    readonly PhysicalServerName: IReadValue<string>;
    readonly LastJobFetchTime: IReadValue<Date>;
    readonly ServerTags: IReadValue<string>;
    readonly ServerWebUrl: IReadValue<string>;
    readonly Connection: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Ident_Server' | 'IsInSoftwareUpdate' | 'IsJobServiceDisabled' | 'IsNoAutoupdate' | 'QueueName' | 'IPV6' | 'IPV4' | 'FQDN' | 'PhysicalServerName' | 'LastJobFetchTime' | 'ServerTags' | 'ServerWebUrl' | 'Connection'>;
}
export declare class OpsupportJournal extends TypedEntity {
    readonly MessageString: IReadValue<string>;
    readonly MessageType: IReadValue<string>;
    readonly MessageDate: IReadValue<Date>;
    readonly ApplicationName: IReadValue<string>;
    readonly LogonUser: IReadValue<string>;
    readonly HostName: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'MessageString' | 'MessageType' | 'MessageDate' | 'ApplicationName' | 'LogonUser' | 'HostName'>;
}
export declare class OpsupportQueueDbqueue extends TypedEntity {
    readonly UID_Task: IReadValue<string>;
    readonly CountProcessing: IReadValue<number>;
    readonly CountWaiting: IReadValue<number>;
    readonly SortOrder: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_Task' | 'CountProcessing' | 'CountWaiting' | 'SortOrder'>;
}
export declare class OpsupportQueueFrozenjobs extends TypedEntity {
    readonly BasisObjectKey: IReadValue<string>;
    readonly ComponentAssembly: IReadValue<string>;
    readonly ComponentClass: IReadValue<string>;
    readonly DeferOnError: IReadValue<boolean>;
    readonly ErrorMessages: IReadValue<string>;
    readonly ErrorNotify: IReadValue<boolean>;
    readonly ExecutionType: IReadValue<string>;
    readonly GenProcID: IReadValue<string>;
    readonly IgnoreErrors: IReadValue<boolean>;
    readonly IsForHistory: IReadValue<boolean>;
    readonly IsNoDBQueueDefer: IReadValue<boolean>;
    readonly IsRootJob: IReadValue<boolean>;
    readonly IsSplitOnly: IReadValue<boolean>;
    readonly IsToFreezeOnError: IReadValue<boolean>;
    readonly JobChainName: IReadValue<string>;
    readonly LimitationCount: IReadValue<number>;
    readonly LimitationWarning: IReadValue<number>;
    readonly LogMode: IReadValue<string>;
    readonly MaxInstance: IReadValue<number>;
    readonly MinutesToDefer: IReadValue<number>;
    readonly NotifyAddress: IReadValue<string>;
    readonly NotifyAddressSuccess: IReadValue<string>;
    readonly NotifyBody: IReadValue<string>;
    readonly NotifyBodySuccess: IReadValue<string>;
    readonly NotifySender: IReadValue<string>;
    readonly NotifySenderSuccess: IReadValue<string>;
    readonly NotifySubject: IReadValue<string>;
    readonly NotifySubjectSuccess: IReadValue<string>;
    readonly ParamIN: IReadValue<string>;
    readonly Priority: IReadValue<number>;
    readonly ProcessTracking: IReadValue<boolean>;
    readonly Queue: IReadValue<string>;
    readonly Ready2EXE: IReadValue<string>;
    readonly Retries: IReadValue<number>;
    readonly StartAt: IReadValue<Date>;
    readonly SuccessNotify: IReadValue<boolean>;
    readonly TaskName: IReadValue<string>;
    readonly UID_Job: IReadValue<string>;
    readonly UID_JobError: IReadValue<string>;
    readonly UID_JobOrigin: IReadValue<string>;
    readonly UID_JobSameServer: IReadValue<string>;
    readonly UID_JobSuccess: IReadValue<string>;
    readonly UID_Tree: IReadValue<string>;
    readonly WasError: IReadValue<boolean>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XDateUpdated: IReadValue<Date>;
    readonly XTouched: IReadValue<string>;
    readonly XUserInserted: IReadValue<string>;
    readonly XUserUpdated: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'BasisObjectKey' | 'ComponentAssembly' | 'ComponentClass' | 'DeferOnError' | 'ErrorMessages' | 'ErrorNotify' | 'ExecutionType' | 'GenProcID' | 'IgnoreErrors' | 'IsForHistory' | 'IsNoDBQueueDefer' | 'IsRootJob' | 'IsSplitOnly' | 'IsToFreezeOnError' | 'JobChainName' | 'LimitationCount' | 'LimitationWarning' | 'LogMode' | 'MaxInstance' | 'MinutesToDefer' | 'NotifyAddress' | 'NotifyAddressSuccess' | 'NotifyBody' | 'NotifyBodySuccess' | 'NotifySender' | 'NotifySenderSuccess' | 'NotifySubject' | 'NotifySubjectSuccess' | 'ParamIN' | 'Priority' | 'ProcessTracking' | 'Queue' | 'Ready2EXE' | 'Retries' | 'StartAt' | 'SuccessNotify' | 'TaskName' | 'UID_Job' | 'UID_JobError' | 'UID_JobOrigin' | 'UID_JobSameServer' | 'UID_JobSuccess' | 'UID_Tree' | 'WasError' | 'XDateInserted' | 'XDateUpdated' | 'XTouched' | 'XUserInserted' | 'XUserUpdated'>;
}
export declare class OpsupportQueueFrozenjobsbyqueue extends TypedEntity {
    readonly QueueName: IReadValue<string>;
    readonly Count: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'QueueName' | 'Count'>;
}
export declare class OpsupportQueueJobaffects extends TypedEntity {
    readonly ObjectKeyAffected: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'ObjectKeyAffected'>;
}
export declare class OpsupportQueueJobchains extends TypedEntity {
    readonly JobChainName: IReadValue<string>;
    readonly Count: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'JobChainName' | 'Count'>;
}
export declare class OpsupportQueueJobperformance extends TypedEntity {
    readonly Queue: IReadValue<string>;
    readonly ComponentClass: IReadValue<string>;
    readonly TaskName: IReadValue<string>;
    readonly CountPerMinute: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Queue' | 'ComponentClass' | 'TaskName' | 'CountPerMinute'>;
}
export declare class OpsupportQueueJobs extends TypedEntity {
    readonly JobChainName: IReadValue<string>;
    readonly UID_JobOrigin: IReadValue<string>;
    readonly Ready2EXE: IReadValue<string>;
    readonly TaskName: IReadValue<string>;
    readonly UID_Tree: IReadValue<string>;
    readonly UID_Job: IReadValue<string>;
    readonly Queue: IReadValue<string>;
    readonly Retries: IReadValue<number>;
    readonly IsRootJob: IReadValue<boolean>;
    readonly UID_JobSuccess: IReadValue<string>;
    readonly UID_JobError: IReadValue<string>;
    readonly XDateInserted: IReadValue<Date>;
    readonly JobChainDescription: IReadValue<string>;
    readonly JobName: IReadValue<string>;
    readonly CombinedStatus: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'JobChainName' | 'UID_JobOrigin' | 'Ready2EXE' | 'TaskName' | 'UID_Tree' | 'UID_Job' | 'Queue' | 'Retries' | 'IsRootJob' | 'UID_JobSuccess' | 'UID_JobError' | 'XDateInserted' | 'JobChainDescription' | 'JobName' | 'CombinedStatus'>;
}
export declare class OpsupportQueueOverview extends TypedEntity {
    readonly CountDelete: IReadValue<number>;
    readonly CountFalse: IReadValue<number>;
    readonly CountFinished: IReadValue<number>;
    readonly CountFrozen: IReadValue<number>;
    readonly CountHistory: IReadValue<number>;
    readonly CountLoaded: IReadValue<number>;
    readonly CountMissing: IReadValue<number>;
    readonly CountOverlimt: IReadValue<number>;
    readonly CountProcessing: IReadValue<number>;
    readonly CountTrue: IReadValue<number>;
    readonly IsInitQueueRunning: IReadValue<boolean>;
    readonly IsInvalid: IReadValue<boolean>;
    readonly QueueName: IReadValue<string>;
    readonly UID_QBMJobqueueOverview: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'CountDelete' | 'CountFalse' | 'CountFinished' | 'CountFrozen' | 'CountHistory' | 'CountLoaded' | 'CountMissing' | 'CountOverlimt' | 'CountProcessing' | 'CountTrue' | 'IsInitQueueRunning' | 'IsInvalid' | 'QueueName' | 'UID_QBMJobqueueOverview' | 'XObjectKey'>;
}
export declare class OpsupportQueueTree extends TypedEntity {
    readonly UID_Job: IReadValue<string>;
    readonly BasisObjectKey: IReadValue<string>;
    readonly DeferOnError: IReadValue<boolean>;
    readonly ErrorMessages: IReadValue<string>;
    readonly GenProcID: IReadValue<string>;
    readonly IsRootJob: IReadValue<boolean>;
    readonly JobChainName: IReadValue<string>;
    readonly LimitationCount: IReadValue<number>;
    readonly Retries: IReadValue<number>;
    readonly Queue: IReadValue<string>;
    readonly Ready2EXE: IReadValue<string>;
    readonly TaskName: IReadValue<string>;
    readonly UID_JobError: IReadValue<string>;
    readonly UID_JobOrigin: IReadValue<string>;
    readonly UID_JobSameServer: IReadValue<string>;
    readonly UID_JobSuccess: IReadValue<string>;
    readonly UID_Tree: IReadValue<string>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XDateUpdated: IReadValue<Date>;
    readonly XUserInserted: IReadValue<string>;
    readonly XUserUpdated: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_Job' | 'BasisObjectKey' | 'DeferOnError' | 'ErrorMessages' | 'GenProcID' | 'IsRootJob' | 'JobChainName' | 'LimitationCount' | 'Retries' | 'Queue' | 'Ready2EXE' | 'TaskName' | 'UID_JobError' | 'UID_JobOrigin' | 'UID_JobSameServer' | 'UID_JobSuccess' | 'UID_Tree' | 'XDateInserted' | 'XDateUpdated' | 'XUserInserted' | 'XUserUpdated'>;
}
export declare class OpsupportSearchIndexedtables extends TypedEntity {
    readonly TableName: IReadValue<string>;
    readonly DisplayName: IReadValue<string>;
    readonly DisplayNameSingular: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'TableName' | 'DisplayName' | 'DisplayNameSingular'>;
}
export declare class OpsupportSystemoverview extends TypedEntity {
    readonly Category: IReadValue<string>;
    readonly Element: IReadValue<string>;
    readonly QualityOfValue: IReadValue<number>;
    readonly RecommendedValue: IReadValue<string>;
    readonly SortOrder: IReadValue<number>;
    readonly SubElement: IReadValue<string>;
    readonly UID_QBMVSystemOverview: IReadValue<string>;
    readonly Value: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Category' | 'Element' | 'QualityOfValue' | 'RecommendedValue' | 'SortOrder' | 'SubElement' | 'UID_QBMVSystemOverview' | 'Value'>;
}
export declare class OpsupportWebapplications extends TypedEntity {
    readonly BaseURL: IReadValue<string>;
    readonly AutoUpdateLevel: IReadValue<number>;
    readonly UID_DialogProduct: IReadValue<string>;
    readonly IsDebug: IReadValue<boolean>;
    readonly IsPrivate: IReadValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'BaseURL' | 'AutoUpdateLevel' | 'UID_DialogProduct' | 'IsDebug' | 'IsPrivate'>;
}
export declare class ImxMultilanguageUiculturesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<ImxMultilanguageUicultures, unknown>>;
}
export declare class ImxSysteminfoThirdpartyWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<ImxSysteminfoThirdparty, unknown>>;
}
export declare class OpsupportJobserversWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        withconnection?: boolean;
        nofetchjob?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportJobservers, unknown>>;
}
export declare class OpsupportJournalWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        messagetype?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportJournal, unknown>>;
}
export declare class OpsupportQueueDbqueueWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportQueueDbqueue, unknown>>;
}
export declare class OpsupportQueueFrozenjobsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        queue?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportQueueFrozenjobs, unknown>>;
}
export declare class OpsupportQueueFrozenjobsbyqueueWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportQueueFrozenjobsbyqueue, unknown>>;
}
export declare class OpsupportQueueJobaffectsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidjob: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportQueueJobaffects, unknown>>;
}
export declare class OpsupportQueueJobchainsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportQueueJobchains, unknown>>;
}
export declare class OpsupportQueueJobperformanceWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        queue?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportQueueJobperformance, unknown>>;
}
export declare class OpsupportQueueJobsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        state?: string;
        queue?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportQueueJobs, unknown>>;
}
export declare class OpsupportQueueOverviewWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportQueueOverview, unknown>>;
}
export declare class OpsupportQueueTreeWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        uidtree?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportQueueTree, unknown>>;
}
export declare class OpsupportSearchIndexedtablesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportSearchIndexedtables, unknown>>;
}
export declare class OpsupportSystemoverviewWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportSystemoverview, unknown>>;
}
export declare class OpsupportWebapplicationsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportWebapplications, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    admin_apiconfig_get(appId: string): MethodDescriptor<ConfigNodeData[]>;
    admin_apiconfig_post(appId: string, global: boolean, inputParameterName: {
        [key: string]: any;
    }): MethodDescriptor<{
        [key: string]: any;
    }>;
    admin_apiconfigsingle_get(appId: string, path: string): MethodDescriptor<any>;
    admin_apiconfigsingle_post(appId: string, path: string): MethodDescriptor<void>;
    admin_apiconfig_convert_post(appId: string): MethodDescriptor<void>;
    admin_apiconfig_revert_post(appId: string, global: boolean): MethodDescriptor<void>;
    admin_apiconfig_values_get(appId: string, path: string): MethodDescriptor<ConfigSettingValidValue[]>;
    admin_cache_get(appId: string): MethodDescriptor<{
        [key: string]: CacheData;
    }>;
    admin_cache_post(appId: string, flush: boolean, disable: boolean): MethodDescriptor<{
        [key: string]: CacheData;
    }>;
    admin_cachebyid_get(appId: string, cacheid: string): MethodDescriptor<CacheData>;
    admin_cachebyid_post(appId: string, cacheid: string, flush: boolean, disable: boolean): MethodDescriptor<CacheData>;
    admin_config_get(): MethodDescriptor<ConfigData>;
    admin_config_post(inputParameterName: ApplicationMethodConfig): MethodDescriptor<ApplicationMethodConfig>;
    admin_packages_get(): MethodDescriptor<PackageInfo[]>;
    admin_performance_get(): MethodDescriptor<{
        [key: string]: PerfDataPoints;
    }>;
    admin_projects_get(): MethodDescriptor<MethodSetInfo[]>;
    admin_status_get(): MethodDescriptor<string>;
    admin_systeminfo_log_get(dir: string, file: string): MethodDescriptor<void>;
    admin_systeminfo_logs_get(): MethodDescriptor<LogFileInfo[]>;
    admin_systeminfo_plugins_get(): MethodDescriptor<LoadedPlugin[]>;
    admin_systeminfo_software_status_get(): MethodDescriptor<SoftwareStatus>;
    admin_systeminfo_software_update_post(): MethodDescriptor<void>;
    imx_activeverbs_get(appId: string): MethodDescriptor<{
        [key: string]: {
            [key: string]: VerbPermissionInfo;
        };
    }>;
    imx_applications_get(): MethodDescriptor<NodeAppInfo[]>;
    imx_config_get(): MethodDescriptor<ImxConfig>;
    imx_entityschema_get(): MethodDescriptor<{
        [key: string]: MethodSchemaDto;
    }>;
    imx_login_post(appId: string, noxsrf: boolean, inputParameterName: {
        [key: string]: string;
    }): MethodDescriptor<SessionResponse>;
    imx_logout_post(appId: string): MethodDescriptor<SessionResponse>;
    imx_metadata_table_get(tableName: string, cultureName: string): MethodDescriptor<MetaTableData>;
    imx_modelcss_get(): MethodDescriptor<void>;
    imx_modelimage_get(key: string, size: string): MethodDescriptor<void>;
    imx_multilanguage_getcaptions_get(cultureName: string): MethodDescriptor<{
        [key: string]: string;
    }>;
    imx_multilanguage_translations_get(cultureName: string, appId: string): MethodDescriptor<{
        [key: string]: {
            [key: string]: string;
        };
    }>;
    imx_multilanguage_uicultures_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    imx_oauth_get(authentifier: string, appId: string, redirecturi: string): MethodDescriptor<string>;
    imx_ping_get(): MethodDescriptor<PingResult>;
    imx_sessions_get(appId: string): MethodDescriptor<SessionResponse>;
    imx_system_get(): MethodDescriptor<SystemInfo>;
    imx_systeminfo_thirdparty_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    opsupport_assignment_get(tableName: string, uid: string): MethodDescriptor<EntityData[]>;
    opsupport_config_get(): MethodDescriptor<ProjectConfig>;
    opsupport_dbobject_get(tableName: string, uid: string): MethodDescriptor<EntityData>;
    opsupport_history_get(table: string, uid: string): MethodDescriptor<HistoryData[]>;
    opsupport_history_comparison_get(table: string, uid: string, CompareDate: Date): MethodDescriptor<HistoryComparisonData[]>;
    opsupport_hyperview_get(table: string, uid: string): MethodDescriptor<ShapeData[]>;
    opsupport_jobserver_get(server: string): MethodDescriptor<ServerConfig>;
    opsupport_jobservers_get(withconnection: boolean, nofetchjob: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    opsupport_journal_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, messagetype: string): MethodDescriptor<EntityCollectionData>;
    opsupport_journal_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    opsupport_journal_stat_get(): MethodDescriptor<any>;
    opsupport_queue_dbqueue_get(): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_frozenjobs_get(queue: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_frozenjobsbyqueue_get(): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_jobaffects_get(uidjob: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_jobchains_get(): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_jobperformance_get(queue: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_jobperformancequeues_get(): MethodDescriptor<string[]>;
    opsupport_queue_jobs_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, state: string, queue: string): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_jobs_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    opsupport_queue_object_get(table: string, uid: string): MethodDescriptor<QueueEntriesData>;
    opsupport_queue_overview_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_overview_stream_get(): MethodDescriptor<void>;
    opsupport_queue_reactivatejob_post(inputParameterName: ReactivateJobInput): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_tree_get(uidtree: string): MethodDescriptor<EntityCollectionData>;
    opsupport_search_get(term: string, tables: string): MethodDescriptor<SearchResultObject[]>;
    opsupport_search_indexedtables_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    opsupport_streamconfig_get(): MethodDescriptor<EventStreamConfig>;
    opsupport_systemoverview_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    opsupport_systemstatus_get(): MethodDescriptor<any>;
    opsupport_systemstatus_post(IsDbSchedulerDisabled: boolean, IsJobServiceDisabled: boolean, inputParameterName: any): MethodDescriptor<any>;
    opsupport_usergroups_get(): MethodDescriptor<UserGroupInfo[]>;
    opsupport_webapplications_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    /** Returns the currently active configuration for the specified project. */
    admin_apiconfig_get(appId: string): Promise<ConfigNodeData[]>;
    /** Updates the configuration with the supplied values. */
    admin_apiconfig_post(appId: string, global: boolean, inputParameterName: {
        [key: string]: any;
    }): Promise<{
        [key: string]: any;
    }>;
    /** Returns the currently active configuration value for the specified path. */
    admin_apiconfigsingle_get(appId: string, path: string): Promise<any>;
    /** Adds a new configuration key on the specified path. */
    admin_apiconfigsingle_post(appId: string, path: string): Promise<void>;
    admin_apiconfig_convert_post(appId: string): Promise<void>;
    /** Reverts all global or local customizations */
    admin_apiconfig_revert_post(appId: string, global: boolean): Promise<void>;
    /** Returns valid values for the configuration setting identified by specified path. */
    admin_apiconfig_values_get(appId: string, path: string): Promise<ConfigSettingValidValue[]>;
    /** Returns cache data for the specified project. */
    admin_cache_get(appId: string): Promise<{
        [key: string]: CacheData;
    }>;
    /** Returns cache data for the specified project. */
    admin_cache_post(appId: string, flush: boolean, disable: boolean): Promise<{
        [key: string]: CacheData;
    }>;
    /** Manages the specified cache for the specified project. */
    admin_cachebyid_get(appId: string, cacheid: string): Promise<CacheData>;
    /** Manages the specified cache for the specified project. */
    admin_cachebyid_post(appId: string, cacheid: string, flush: boolean, disable: boolean): Promise<CacheData>;
    admin_config_get(): Promise<ConfigData>;
    admin_config_post(inputParameterName: ApplicationMethodConfig): Promise<ApplicationMethodConfig>;
    admin_packages_get(): Promise<PackageInfo[]>;
    /** Returns the most recently recorded performance data. */
    admin_performance_get(): Promise<{
        [key: string]: PerfDataPoints;
    }>;
    admin_projects_get(): Promise<MethodSetInfo[]>;
    admin_status_get(): Promise<string>;
    admin_systeminfo_log_get(dir: string, file: string): Promise<void>;
    admin_systeminfo_logs_get(): Promise<LogFileInfo[]>;
    admin_systeminfo_plugins_get(): Promise<LoadedPlugin[]>;
    admin_systeminfo_software_status_get(): Promise<SoftwareStatus>;
    /** Starts the software update process */
    admin_systeminfo_software_update_post(): Promise<void>;
    /** Returns the set of currently active endpoints, and a flag indicating whether an endpoint is active for the current user. */
    imx_activeverbs_get(appId: string): Promise<{
        [key: string]: {
            [key: string]: VerbPermissionInfo;
        };
    }>;
    imx_applications_get(): Promise<NodeAppInfo[]>;
    imx_config_get(): Promise<ImxConfig>;
    imx_entityschema_get(): Promise<{
        [key: string]: MethodSchemaDto;
    }>;
    imx_login_post(appId: string, noxsrf: boolean, inputParameterName: {
        [key: string]: string;
    }): Promise<SessionResponse>;
    imx_logout_post(appId: string): Promise<SessionResponse>;
    /** Returns metadata for a specific database table. */
    imx_metadata_table_get(tableName: string, cultureName: string): Promise<MetaTableData>;
    /** Returns the model-generated stylesheet. */
    imx_modelcss_get(): Promise<void>;
    /** Returns an image stored from data model. */
    imx_modelimage_get(key: string, size: string): Promise<void>;
    /** Returns web UI translations for a specific culture. */
    imx_multilanguage_getcaptions_get(cultureName: string): Promise<{
        [key: string]: string;
    }>;
    /** Returns translations for the data model for an API project. */
    imx_multilanguage_translations_get(cultureName: string, appId: string): Promise<{
        [key: string]: {
            [key: string]: string;
        };
    }>;
    /** Returns all cultures that are available to frontends. */
    imx_multilanguage_uicultures_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    imx_oauth_get(authentifier: string, appId: string, redirecturi: string): Promise<string>;
    /** Returns an object indicating whether this API server was able to start up and establish a database connection. */
    imx_ping_get(): Promise<PingResult>;
    imx_sessions_get(appId: string): Promise<SessionResponse>;
    imx_system_get(): Promise<SystemInfo>;
    /** Returns a list of all third party components. */
    imx_systeminfo_thirdparty_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns the objects that are part of assignment, specified by the assignment's 'table name and the uid. */
    opsupport_assignment_get(tableName: string, uid: string): Promise<EntityData[]>;
    opsupport_config_get(): Promise<ProjectConfig>;
    /** Returns basic information about an object specified by the table name and the uid. */
    opsupport_dbobject_get(tableName: string, uid: string): Promise<EntityData>;
    opsupport_history_get(table: string, uid: string): Promise<HistoryData[]>;
    opsupport_history_comparison_get(table: string, uid: string, CompareDate: Date): Promise<HistoryComparisonData[]>;
    opsupport_hyperview_get(table: string, uid: string): Promise<ShapeData[]>;
    opsupport_jobserver_get(server: string): Promise<ServerConfig>;
    opsupport_jobservers_get(withconnection: boolean, nofetchjob: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): Promise<EntityCollectionData>;
    /** Returns entries in the journal, returning the newest entries first. */
    opsupport_journal_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, messagetype: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the journal endpoint. */
    opsupport_journal_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    opsupport_journal_stat_get(): Promise<any>;
    opsupport_queue_dbqueue_get(): Promise<EntityCollectionData>;
    opsupport_queue_frozenjobs_get(queue: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    opsupport_queue_frozenjobsbyqueue_get(): Promise<EntityCollectionData>;
    opsupport_queue_jobaffects_get(uidjob: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    opsupport_queue_jobchains_get(): Promise<EntityCollectionData>;
    opsupport_queue_jobperformance_get(queue: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    opsupport_queue_jobperformancequeues_get(): Promise<string[]>;
    opsupport_queue_jobs_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, state: string, queue: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the queue/jobs endpoint. */
    opsupport_queue_jobs_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    opsupport_queue_object_get(table: string, uid: string): Promise<QueueEntriesData>;
    opsupport_queue_overview_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    opsupport_queue_overview_stream_get(): Promise<void>;
    opsupport_queue_reactivatejob_post(inputParameterName: ReactivateJobInput): Promise<EntityCollectionData>;
    opsupport_queue_tree_get(uidtree: string): Promise<EntityCollectionData>;
    opsupport_search_get(term: string, tables: string): Promise<SearchResultObject[]>;
    /** Returns the list of tables that are included in the search index. */
    opsupport_search_indexedtables_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    opsupport_streamconfig_get(): Promise<EventStreamConfig>;
    opsupport_systemoverview_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    opsupport_systemstatus_get(): Promise<any>;
    opsupport_systemstatus_post(IsDbSchedulerDisabled: boolean, IsJobServiceDisabled: boolean, inputParameterName: any): Promise<any>;
    /** Returns the list of permissions groups that the current user is assigned to. */
    opsupport_usergroups_get(): Promise<UserGroupInfo[]>;
    opsupport_webapplications_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
}
export declare class V2ApiClientMethodFactory {
    admin_apiconfig_get(appId: string, options?: {}): MethodDescriptor<ConfigNodeData[]>;
    admin_apiconfig_post(appId: string, inputParameterName: {
        [key: string]: any;
    }, options?: {
        global?: boolean;
    }): MethodDescriptor<{
        [key: string]: any;
    }>;
    admin_apiconfigsingle_get(appId: string, path: string, options?: {}): MethodDescriptor<any>;
    admin_apiconfigsingle_post(appId: string, path: string, options?: {}): MethodDescriptor<void>;
    admin_apiconfig_convert_post(appId: string, options?: {}): MethodDescriptor<void>;
    admin_apiconfig_revert_post(appId: string, options?: {
        global?: boolean;
    }): MethodDescriptor<void>;
    admin_apiconfig_values_get(appId: string, path: string, options?: {}): MethodDescriptor<ConfigSettingValidValue[]>;
    admin_cache_get(appId: string, options?: {}): MethodDescriptor<{
        [key: string]: CacheData;
    }>;
    admin_cache_post(appId: string, options?: {
        flush?: boolean;
        disable?: boolean;
    }): MethodDescriptor<{
        [key: string]: CacheData;
    }>;
    admin_cachebyid_get(appId: string, cacheid: string, options?: {}): MethodDescriptor<CacheData>;
    admin_cachebyid_post(appId: string, cacheid: string, options?: {
        flush?: boolean;
        disable?: boolean;
    }): MethodDescriptor<CacheData>;
    admin_config_get(options?: {}): MethodDescriptor<ConfigData>;
    admin_config_post(inputParameterName: ApplicationMethodConfig, options?: {}): MethodDescriptor<ApplicationMethodConfig>;
    admin_packages_get(options?: {}): MethodDescriptor<PackageInfo[]>;
    admin_performance_get(options?: {}): MethodDescriptor<{
        [key: string]: PerfDataPoints;
    }>;
    admin_projects_get(options?: {}): MethodDescriptor<MethodSetInfo[]>;
    admin_status_get(options?: {}): MethodDescriptor<string>;
    admin_systeminfo_log_get(dir: string, file: string, options?: {}): MethodDescriptor<void>;
    admin_systeminfo_logs_get(options?: {}): MethodDescriptor<LogFileInfo[]>;
    admin_systeminfo_plugins_get(options?: {}): MethodDescriptor<LoadedPlugin[]>;
    admin_systeminfo_software_status_get(options?: {}): MethodDescriptor<SoftwareStatus>;
    admin_systeminfo_software_update_post(options?: {}): MethodDescriptor<void>;
    imx_activeverbs_get(appId: string, options?: {}): MethodDescriptor<{
        [key: string]: {
            [key: string]: VerbPermissionInfo;
        };
    }>;
    imx_applications_get(options?: {}): MethodDescriptor<NodeAppInfo[]>;
    imx_config_get(options?: {}): MethodDescriptor<ImxConfig>;
    imx_entityschema_get(options?: {}): MethodDescriptor<{
        [key: string]: MethodSchemaDto;
    }>;
    imx_login_post(appId: string, inputParameterName: {
        [key: string]: string;
    }, options?: {
        noxsrf?: boolean;
    }): MethodDescriptor<SessionResponse>;
    imx_logout_post(appId: string, options?: {}): MethodDescriptor<SessionResponse>;
    imx_metadata_table_get(tableName: string, options?: {
        cultureName?: string;
    }): MethodDescriptor<MetaTableData>;
    imx_modelcss_get(options?: {}): MethodDescriptor<void>;
    imx_modelimage_get(key: string, size: string, options?: {}): MethodDescriptor<void>;
    imx_multilanguage_getcaptions_get(options?: {
        cultureName?: string;
    }): MethodDescriptor<{
        [key: string]: string;
    }>;
    imx_multilanguage_translations_get(appId: string, options?: {
        cultureName?: string;
    }): MethodDescriptor<{
        [key: string]: {
            [key: string]: string;
        };
    }>;
    imx_multilanguage_uicultures_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    imx_oauth_get(authentifier: string, appId: string, options?: {
        redirecturi?: string;
    }): MethodDescriptor<string>;
    imx_ping_get(options?: {}): MethodDescriptor<PingResult>;
    imx_sessions_get(appId: string, options?: {}): MethodDescriptor<SessionResponse>;
    imx_system_get(options?: {}): MethodDescriptor<SystemInfo>;
    imx_systeminfo_thirdparty_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    opsupport_assignment_get(tableName: string, uid: string, options?: {}): MethodDescriptor<EntityData[]>;
    opsupport_config_get(options?: {}): MethodDescriptor<ProjectConfig>;
    opsupport_dbobject_get(tableName: string, uid: string, options?: {}): MethodDescriptor<EntityData>;
    opsupport_history_get(table: string, uid: string, options?: {}): MethodDescriptor<HistoryData[]>;
    opsupport_history_comparison_get(table: string, uid: string, options?: {
        CompareDate?: Date;
    }): MethodDescriptor<HistoryComparisonData[]>;
    opsupport_hyperview_get(table: string, uid: string, options?: {}): MethodDescriptor<ShapeData[]>;
    opsupport_jobserver_get(server: string, options?: {}): MethodDescriptor<ServerConfig>;
    opsupport_jobservers_get(options?: {
        withconnection?: boolean;
        nofetchjob?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    opsupport_journal_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        messagetype?: string;
    }): MethodDescriptor<EntityCollectionData>;
    opsupport_journal_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    opsupport_journal_stat_get(options?: {}): MethodDescriptor<any>;
    opsupport_queue_dbqueue_get(options?: {}): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_frozenjobs_get(options?: {
        queue?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_frozenjobsbyqueue_get(options?: {}): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_jobaffects_get(uidjob: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_jobchains_get(options?: {}): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_jobperformance_get(options?: {
        queue?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_jobperformancequeues_get(options?: {}): MethodDescriptor<string[]>;
    opsupport_queue_jobs_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        state?: string;
        queue?: string;
    }): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_jobs_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    opsupport_queue_object_get(table: string, uid: string, options?: {}): MethodDescriptor<QueueEntriesData>;
    opsupport_queue_overview_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_overview_stream_get(options?: {}): MethodDescriptor<void>;
    opsupport_queue_reactivatejob_post(inputParameterName: ReactivateJobInput, options?: {}): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_tree_get(options?: {
        uidtree?: string;
    }): MethodDescriptor<EntityCollectionData>;
    opsupport_search_get(options?: {
        term?: string;
        tables?: string;
    }): MethodDescriptor<SearchResultObject[]>;
    opsupport_search_indexedtables_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    opsupport_streamconfig_get(options?: {}): MethodDescriptor<EventStreamConfig>;
    opsupport_systemoverview_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    opsupport_systemstatus_get(options?: {}): MethodDescriptor<any>;
    opsupport_systemstatus_post(inputParameterName: any, options?: {
        IsDbSchedulerDisabled?: boolean;
        IsJobServiceDisabled?: boolean;
    }): MethodDescriptor<any>;
    opsupport_usergroups_get(options?: {}): MethodDescriptor<UserGroupInfo[]>;
    opsupport_webapplications_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    /** Returns the currently active configuration for the specified project. */
    admin_apiconfig_get(appId: string, options?: {}): Promise<ConfigNodeData[]>;
    /** Updates the configuration with the supplied values. */
    admin_apiconfig_post(appId: string, inputParameterName: {
        [key: string]: any;
    }, options?: {
        global?: boolean;
    }): Promise<{
        [key: string]: any;
    }>;
    /** Returns the currently active configuration value for the specified path. */
    admin_apiconfigsingle_get(appId: string, path: string, options?: {}): Promise<any>;
    /** Adds a new configuration key on the specified path. */
    admin_apiconfigsingle_post(appId: string, path: string, options?: {}): Promise<void>;
    admin_apiconfig_convert_post(appId: string, options?: {}): Promise<void>;
    /** Reverts all global or local customizations */
    admin_apiconfig_revert_post(appId: string, options?: {
        global?: boolean;
    }): Promise<void>;
    /** Returns valid values for the configuration setting identified by specified path. */
    admin_apiconfig_values_get(appId: string, path: string, options?: {}): Promise<ConfigSettingValidValue[]>;
    /** Returns cache data for the specified project. */
    admin_cache_get(appId: string, options?: {}): Promise<{
        [key: string]: CacheData;
    }>;
    /** Returns cache data for the specified project. */
    admin_cache_post(appId: string, options?: {
        flush?: boolean;
        disable?: boolean;
    }): Promise<{
        [key: string]: CacheData;
    }>;
    /** Manages the specified cache for the specified project. */
    admin_cachebyid_get(appId: string, cacheid: string, options?: {}): Promise<CacheData>;
    /** Manages the specified cache for the specified project. */
    admin_cachebyid_post(appId: string, cacheid: string, options?: {
        flush?: boolean;
        disable?: boolean;
    }): Promise<CacheData>;
    admin_config_get(options?: {}): Promise<ConfigData>;
    admin_config_post(inputParameterName: ApplicationMethodConfig, options?: {}): Promise<ApplicationMethodConfig>;
    admin_packages_get(options?: {}): Promise<PackageInfo[]>;
    /** Returns the most recently recorded performance data. */
    admin_performance_get(options?: {}): Promise<{
        [key: string]: PerfDataPoints;
    }>;
    admin_projects_get(options?: {}): Promise<MethodSetInfo[]>;
    admin_status_get(options?: {}): Promise<string>;
    admin_systeminfo_log_get(dir: string, file: string, options?: {}): Promise<void>;
    admin_systeminfo_logs_get(options?: {}): Promise<LogFileInfo[]>;
    admin_systeminfo_plugins_get(options?: {}): Promise<LoadedPlugin[]>;
    admin_systeminfo_software_status_get(options?: {}): Promise<SoftwareStatus>;
    /** Starts the software update process */
    admin_systeminfo_software_update_post(options?: {}): Promise<void>;
    /** Returns the set of currently active endpoints, and a flag indicating whether an endpoint is active for the current user. */
    imx_activeverbs_get(appId: string, options?: {}): Promise<{
        [key: string]: {
            [key: string]: VerbPermissionInfo;
        };
    }>;
    imx_applications_get(options?: {}): Promise<NodeAppInfo[]>;
    imx_config_get(options?: {}): Promise<ImxConfig>;
    imx_entityschema_get(options?: {}): Promise<{
        [key: string]: MethodSchemaDto;
    }>;
    imx_login_post(appId: string, inputParameterName: {
        [key: string]: string;
    }, options?: {
        noxsrf?: boolean;
    }): Promise<SessionResponse>;
    imx_logout_post(appId: string, options?: {}): Promise<SessionResponse>;
    /** Returns metadata for a specific database table. */
    imx_metadata_table_get(tableName: string, options?: {
        cultureName?: string;
    }): Promise<MetaTableData>;
    /** Returns the model-generated stylesheet. */
    imx_modelcss_get(options?: {}): Promise<void>;
    /** Returns an image stored from data model. */
    imx_modelimage_get(key: string, size: string, options?: {}): Promise<void>;
    /** Returns web UI translations for a specific culture. */
    imx_multilanguage_getcaptions_get(options?: {
        cultureName?: string;
    }): Promise<{
        [key: string]: string;
    }>;
    /** Returns translations for the data model for an API project. */
    imx_multilanguage_translations_get(appId: string, options?: {
        cultureName?: string;
    }): Promise<{
        [key: string]: {
            [key: string]: string;
        };
    }>;
    /** Returns all cultures that are available to frontends. */
    imx_multilanguage_uicultures_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    imx_oauth_get(authentifier: string, appId: string, options?: {
        redirecturi?: string;
    }): Promise<string>;
    /** Returns an object indicating whether this API server was able to start up and establish a database connection. */
    imx_ping_get(options?: {}): Promise<PingResult>;
    imx_sessions_get(appId: string, options?: {}): Promise<SessionResponse>;
    imx_system_get(options?: {}): Promise<SystemInfo>;
    /** Returns a list of all third party components. */
    imx_systeminfo_thirdparty_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns the objects that are part of assignment, specified by the assignment's 'table name and the uid. */
    opsupport_assignment_get(tableName: string, uid: string, options?: {}): Promise<EntityData[]>;
    opsupport_config_get(options?: {}): Promise<ProjectConfig>;
    /** Returns basic information about an object specified by the table name and the uid. */
    opsupport_dbobject_get(tableName: string, uid: string, options?: {}): Promise<EntityData>;
    opsupport_history_get(table: string, uid: string, options?: {}): Promise<HistoryData[]>;
    opsupport_history_comparison_get(table: string, uid: string, options?: {
        CompareDate?: Date;
    }): Promise<HistoryComparisonData[]>;
    opsupport_hyperview_get(table: string, uid: string, options?: {}): Promise<ShapeData[]>;
    opsupport_jobserver_get(server: string, options?: {}): Promise<ServerConfig>;
    opsupport_jobservers_get(options?: {
        withconnection?: boolean;
        nofetchjob?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    /** Returns entries in the journal, returning the newest entries first. */
    opsupport_journal_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        messagetype?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the journal endpoint. */
    opsupport_journal_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    opsupport_journal_stat_get(options?: {}): Promise<any>;
    opsupport_queue_dbqueue_get(options?: {}): Promise<EntityCollectionData>;
    opsupport_queue_frozenjobs_get(options?: {
        queue?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    opsupport_queue_frozenjobsbyqueue_get(options?: {}): Promise<EntityCollectionData>;
    opsupport_queue_jobaffects_get(uidjob: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    opsupport_queue_jobchains_get(options?: {}): Promise<EntityCollectionData>;
    opsupport_queue_jobperformance_get(options?: {
        queue?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    opsupport_queue_jobperformancequeues_get(options?: {}): Promise<string[]>;
    opsupport_queue_jobs_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        state?: string;
        queue?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the queue/jobs endpoint. */
    opsupport_queue_jobs_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    opsupport_queue_object_get(table: string, uid: string, options?: {}): Promise<QueueEntriesData>;
    opsupport_queue_overview_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    opsupport_queue_overview_stream_get(options?: {}): Promise<void>;
    opsupport_queue_reactivatejob_post(inputParameterName: ReactivateJobInput, options?: {}): Promise<EntityCollectionData>;
    opsupport_queue_tree_get(options?: {
        uidtree?: string;
    }): Promise<EntityCollectionData>;
    opsupport_search_get(options?: {
        term?: string;
        tables?: string;
    }): Promise<SearchResultObject[]>;
    /** Returns the list of tables that are included in the search index. */
    opsupport_search_indexedtables_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    opsupport_streamconfig_get(options?: {}): Promise<EventStreamConfig>;
    opsupport_systemoverview_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    opsupport_systemstatus_get(options?: {}): Promise<any>;
    opsupport_systemstatus_post(inputParameterName: any, options?: {
        IsDbSchedulerDisabled?: boolean;
        IsJobServiceDisabled?: boolean;
    }): Promise<any>;
    /** Returns the list of permissions groups that the current user is assigned to. */
    opsupport_usergroups_get(options?: {}): Promise<UserGroupInfo[]>;
    opsupport_webapplications_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
}
