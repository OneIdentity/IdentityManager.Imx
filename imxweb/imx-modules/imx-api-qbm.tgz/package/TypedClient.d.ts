import { ApiClient, ApiRequestOptions, DataModel, EntityCollectionData, EntityColumnData, EntityData, EntitySchema, FilterData, FkCandidateRouteDto, FkProviderItem, HistoryData, IReadValue, MetaColumnData, MethodDescriptor, MethodSchemaDto, StaticSchema, TypedEntity } from 'imx-qbm-dbts';
export interface ApplicationAuthConfig {
    SsoAuthentifiers?: string[];
    ManualAuthentifiers?: string[];
    AdditionalAuthProps?: string;
    AuthenticationType?: AuthType;
    AllowPersistentAuth?: boolean;
    Product?: string;
    SecondaryAuth?: ISecondaryAuthProvider;
}
/** Represents application-specific configuration of method sets. */
export interface ApplicationMethodConfig {
    ApiProjects?: {
        [key: string]: ApplicationAuthConfig;
    };
    /** Gets or sets a flag indicating if all projects should be loaded, even the ones
not explicitly listed. */
    AllProjects: boolean;
}
export interface AuthConfig {
    Name?: string;
    Display?: string;
    ExternalLogoutUrl?: string;
    AuthProps?: AuthPropData[];
}
export interface AuthPropData {
    Name?: string;
    Display?: string;
    Type: AuthPropType;
    IsMandatory: boolean;
}
/** Authentication property types */
export declare enum AuthPropType {
    Info = 0,
    Edit = 1,
    Password = 2,
    Hidden = 3,
    Checkbox = 4,
    OAuth2Code = 5,
    NewPassword = 6
}
/** Represents the authentication status of a session. */
export interface AuthStatus {
    /** Returns the primary (database) authentication status. */
    PrimaryAuth?: PrimaryAuthStatus;
    /** Returns the authentication status for the second factor. */
    SecondaryAuth?: SecondaryAuthStatus;
    /** Returns the expiration date for the current authentication. */
    AuthValidUntil?: Date;
    /** Returns a URL to use for logging out from an external authentication provider. */
    ExternalLogoutUrl?: string;
    /** Returns the currently active culture for interface strings. */
    Culture?: string;
    /** Returns the currently active culture for value formatting. */
    CultureFormat?: string;
}
export declare enum AuthType {
    Default = 0,
    AllManualModules = 1,
    FixedCredentials = 2
}
export interface CacheData {
    IsDisabled: boolean;
    ObjectCount: number;
}
export interface CandidateData {
    ParameterName?: string;
    Candidates?: FkCandidateRouteDto;
}
export interface ConfigData {
    MethodConfig?: {
        [key: string]: ISessionAuthDbConfig;
    };
    ApplicationConfig?: ApplicationMethodConfig;
}
export interface ConfigNodeData {
    Key?: string;
    Name?: string;
    CanAddSetting?: boolean;
    Description?: string;
    Children?: ConfigNodeData[];
    Settings?: ConfigSettingData[];
}
export interface ConfigSettingData {
    Key?: string;
    Name?: string;
    Description?: string;
    HasCustomGlobalValue?: boolean;
    HasCustomLocalValue?: boolean;
    Value?: any;
    OriginalValue?: any;
    Type: ConfigSettingType;
}
export declare enum ConfigSettingType {
    None = 0,
    Sql = 1,
    Int = 2,
    PositiveInt = 3,
    Double = 4,
    RiskIndex = 5,
    PositiveDouble = 6,
    LimitedValues = 7
}
export interface ConfigSettingValidValue {
    Display?: string;
    Value?: string;
}
export interface EventStreamConfig {
    /** Specify how often to update the JobQueue chart. */
    RefreshIntervalSeconds: number;
    /** Specify how long data is kept in the history. */
    HistorySeconds: number;
}
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface HistoryComparisonData {
    CurrentValueDisplay?: string;
    HasChanged: boolean;
    ChangeType?: string;
    HistoryValueDisplay?: string;
    Property?: string;
    TableName?: string;
    Id?: string;
}
export interface ImxConfig {
    CompanyLogoUrl?: string;
    ProductName?: string;
    ProductVersion?: string;
}
export interface ISecondaryAuthProvider {
    Key: string;
    Display: any;
}
export interface ISessionAuthDbConfig {
    SsoAuthentifiers: any;
    ManualAuthentifiers: any;
    AdditionalAuthProps: any;
    AuthenticationType: any;
    Product: string;
    ExcludedAuthentifiers: any;
    SecondaryAuth: any;
    AllowUsersWithoutSecondFactor: boolean;
    AllowPersistentAuth: boolean;
    AuthProviders: any;
}
export interface LoadedPlugin {
    Plugin?: string;
    /**            If defined, the plugin failed while loading with the given exception.
            */
    Exception?: ExceptionData[];
}
export interface LogFileInfo {
    Path?: string;
    LastModified: Date;
}
export interface MetaTableData {
    Columns?: {
        [key: string]: MetaColumnData;
    };
    Display?: string;
    DisplaySingular?: string;
    ImageId?: string;
    Tablename?: string;
    IsDeactivated: boolean;
    IsMAllTable: boolean;
    IsMNTable: boolean;
    PrimaryKeyColumns?: string[];
    Uid?: string;
}
export interface MethodSetInfo {
    AppId?: string;
}
export interface NodeAppInfo {
    Name?: string;
    Description?: string;
    DisplayName?: string;
    PlugIns?: PlugInLib[];
}
export interface OfF__AnonymousType1OfInt32AndInt32 {
    Errors: number;
    Warnings: number;
}
export interface OfF__AnonymousType2OfBooleanAndBooleanAndBooleanAndBoolean {
    IsDbSchedulerDisabled: boolean;
    IsJobServiceDisabled: boolean;
    IsCompilationRequired: boolean;
    IsInMaintenanceMode: boolean;
}
export interface PackageInfo {
    Name?: string;
    RelativePath?: string;
    Fingerprint?: string;
    LastChangeDate: Date;
    IsCustom: boolean;
}
export interface PerfDataPoints extends ValueType {
    RuntimeMs?: number[];
}
export interface PingResult {
    /** Returns a flag indicating if the API could not be correctly initialized. */
    NoDbConnection: boolean;
    HasPluginErrors: boolean;
    IsWaitingToStartUpdate: boolean;
    PluginsWithErrors?: string[];
}
export interface PlugInLib {
    Container?: string;
    Name?: string;
}
export interface PrimaryAuthStatus {
    /** Returns the display name of the authenticated user. */
    Display?: string;
    /** Returns the unique identifier of the associated identity, if any. */
    Uid?: string;
    IsAuthenticated: boolean;
    /** Returns the time of the authentication. */
    AuthTime: Date;
}
export interface ProjectConfig {
    CandidateConfig?: {
        [key: string]: CandidateData[];
    };
    /** Enter the instrumentation key required to log metrics to App Insights. */
    AppInsightsKey?: string;
    /** Specify whether the web application sends browser notifications (for example, for pending requests or pending attestations). Users can still deactivate browser notifications. */
    VI_Common_EnableNotifications: boolean;
    /** Specify whether images are resized automatically when uploaded to the server. */
    EnableImageResizing: boolean;
    /** Enter the site key (public key) for reCAPTCHA integration. */
    RecaptchaPublicKey?: string;
    DefaultPageSize: number;
    /** Specify how many of the previous days to take into account by default when generating reports. */
    DefaultHistoryLengthDays: number;
}
export interface QueueEntriesData {
    DbQueue?: EntityData[];
    JobQueue?: EntityData[];
    Unsupported: boolean;
}
export interface ReactivateJobInput {
    /** UIDs of any process step in the process. The API will find the process step to reactivate. */
    UidJobs?: string[];
    Mode: ReactivateJobMode;
}
export declare enum ReactivateJobMode {
    Reactivate = 0,
    ContinueSuccess = 1,
    ContinueError = 2
}
export interface SearchResultObject {
    Key?: string;
    Display?: string;
}
export interface SecondaryAuthStatus {
    /** Returns a flag indicating if the second authentication factor has succeeded. */
    IsAuthenticated: boolean;
    ErrorMessage?: string;
    /** Returns a flag indicating whether two-factor authentication is enabled.
If this value is false, two-factor authentication is not required. */
    IsEnabled: boolean;
    /** Returns the name of the two-factor authentication provider. */
    Name?: string;
}
export interface ServerConfig {
    ServerName?: string;
    Version?: string;
    Time: Date;
    User?: string;
    Revision?: string;
}
export interface SessionResponse {
    Status?: AuthStatus;
    Config?: AuthConfig[];
}
/** Represents for a single hyperview shape. */
export interface ShapeData {
    /** Returns a flag indicating whether the shape should show that the object is in a deleted state. */
    IsDeleted: boolean;
    /** Returns the title caption of the shape. */
    Caption?: string;
    /** Returns an optional, secondary header text. */
    HeaderText?: string;
    Identifier?: string;
    /** Returns the object key of the associated object. */
    ObjectKey?: string;
    /** Returns the shape color to use, in ARGB hex format. */
    ElementColor?: string;
    Description?: string;
    TableName?: string;
    DbWhereClause?: string;
    /** Returns a list of elements to be displayed inside this shape. */
    Elements?: ShapeListEntry[];
    /** Returns a flag indicating whether the list of element is truncated because
the maximum number of elements was reached. */
    IsLimitReached?: boolean;
    /** Returns the layout type to use for this shape. */
    LayoutType?: string;
    ImageUid?: string;
    DbTableName?: string;
    /** Returns a list of properties to be displayed inside this shape. */
    Properties?: ShapeProperty[];
}
export interface ShapeListEntry {
    /** Returns the object key of the associated object. This property may be null. */
    ObjectKey?: string;
    DisplayValue?: string;
}
export interface ShapeProperty {
    Property?: string;
    DbColumnName?: string;
    EndsSection?: boolean;
    Value?: EntityColumnData;
}
export interface SoftwareStatus {
    CanStartUpdater: boolean;
    Status: UpdaterState;
}
export interface SystemInfo {
    /** Returns the list of active preprocessor definitions. */
    PreProps?: string[];
    UpdatePhase: number;
    SoftwareStatus: UpdaterState;
    DbDisplay?: string;
    ServerVersion?: string;
    ProductionLevel: number;
    ProductionLevelAddOn?: string;
    LastMigrationDate: Date;
    CustomerName?: string;
    IsDbSchedulerDisabled: boolean;
    IsJobServiceDisabled: boolean;
}
/** Represents the software update state. */
export declare enum UpdaterState {
    UpdatesAvailable = 0,
    NoUpdatesAvailable = 1,
    AlreadyRunning = 2,
    Disabled = 3
}
export interface UserGroupInfo {
    Uid?: string;
    Name?: string;
}
export interface ValueType {
}
export interface VerbPermissionInfo {
    Allowed: boolean;
}
export declare class TypedClient {
    readonly ImxMultilanguageUicultures: ImxMultilanguageUiculturesWrapper;
    readonly ImxSysteminfoThirdparty: ImxSysteminfoThirdpartyWrapper;
    readonly OpsupportJobservers: OpsupportJobserversWrapper;
    readonly OpsupportJournal: OpsupportJournalWrapper;
    readonly OpsupportQueueDbqueue: OpsupportQueueDbqueueWrapper;
    readonly OpsupportQueueFrozenjobs: OpsupportQueueFrozenjobsWrapper;
    readonly OpsupportQueueFrozenjobsbyqueue: OpsupportQueueFrozenjobsbyqueueWrapper;
    readonly OpsupportQueueJobaffects: OpsupportQueueJobaffectsWrapper;
    readonly OpsupportQueueJobchains: OpsupportQueueJobchainsWrapper;
    readonly OpsupportQueueJobperformance: OpsupportQueueJobperformanceWrapper;
    readonly OpsupportQueueJobs: OpsupportQueueJobsWrapper;
    readonly OpsupportQueueOverview: OpsupportQueueOverviewWrapper;
    readonly OpsupportQueueTree: OpsupportQueueTreeWrapper;
    readonly OpsupportSearchIndexedtables: OpsupportSearchIndexedtablesWrapper;
    readonly OpsupportSystemoverview: OpsupportSystemoverviewWrapper;
    readonly OpsupportWebapplications: OpsupportWebapplicationsWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class ImxMultilanguageUicultures extends TypedEntity {
    readonly Ident_DialogCulture: IReadValue<string>;
    readonly NativeName: IReadValue<string>;
    readonly Iso2Name: IReadValue<string>;
    readonly Iso3Name: IReadValue<string>;
    readonly DisplayName: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Ident_DialogCulture' | 'NativeName' | 'Iso2Name' | 'Iso3Name' | 'DisplayName'>;
}
export declare class ImxSysteminfoThirdparty extends TypedEntity {
    readonly ComponentName: IReadValue<string>;
    readonly CopyRight: IReadValue<string>;
    readonly EmailOrURl: IReadValue<string>;
    readonly LicenceName: IReadValue<string>;
    readonly LicenceText: IReadValue<string>;
    readonly UID_QBMV3rdPartyLicence: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'ComponentName' | 'CopyRight' | 'EmailOrURl' | 'LicenceName' | 'LicenceText' | 'UID_QBMV3rdPartyLicence'>;
}
export declare class OpsupportJobservers extends TypedEntity {
    readonly Ident_Server: IReadValue<string>;
    readonly IsInSoftwareUpdate: IReadValue<boolean>;
    readonly IsJobServiceDisabled: IReadValue<boolean>;
    readonly IsNoAutoupdate: IReadValue<boolean>;
    readonly QueueName: IReadValue<string>;
    readonly IPV6: IReadValue<string>;
    readonly IPV4: IReadValue<string>;
    readonly FQDN: IReadValue<string>;
    readonly PhysicalServerName: IReadValue<string>;
    readonly LastJobFetchTime: IReadValue<Date>;
    readonly ServerTags: IReadValue<string>;
    readonly ServerWebUrl: IReadValue<string>;
    readonly Connection: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Ident_Server' | 'IsInSoftwareUpdate' | 'IsJobServiceDisabled' | 'IsNoAutoupdate' | 'QueueName' | 'IPV6' | 'IPV4' | 'FQDN' | 'PhysicalServerName' | 'LastJobFetchTime' | 'ServerTags' | 'ServerWebUrl' | 'Connection'>;
}
export declare class OpsupportJournal extends TypedEntity {
    readonly MessageString: IReadValue<string>;
    readonly MessageType: IReadValue<string>;
    readonly MessageDate: IReadValue<Date>;
    readonly ApplicationName: IReadValue<string>;
    readonly LogonUser: IReadValue<string>;
    readonly HostName: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'MessageString' | 'MessageType' | 'MessageDate' | 'ApplicationName' | 'LogonUser' | 'HostName'>;
}
export declare class OpsupportQueueDbqueue extends TypedEntity {
    readonly UID_Task: IReadValue<string>;
    readonly CountProcessing: IReadValue<number>;
    readonly CountWaiting: IReadValue<number>;
    readonly SortOrder: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_Task' | 'CountProcessing' | 'CountWaiting' | 'SortOrder'>;
}
export declare class OpsupportQueueFrozenjobs extends TypedEntity {
    readonly BasisObjectKey: IReadValue<string>;
    readonly ComponentAssembly: IReadValue<string>;
    readonly ComponentClass: IReadValue<string>;
    readonly DeferOnError: IReadValue<boolean>;
    readonly ErrorMessages: IReadValue<string>;
    readonly ErrorNotify: IReadValue<boolean>;
    readonly ExecutionType: IReadValue<string>;
    readonly GenProcID: IReadValue<string>;
    readonly IgnoreErrors: IReadValue<boolean>;
    readonly IsForHistory: IReadValue<boolean>;
    readonly IsNoDBQueueDefer: IReadValue<boolean>;
    readonly IsRootJob: IReadValue<boolean>;
    readonly IsSplitOnly: IReadValue<boolean>;
    readonly IsToFreezeOnError: IReadValue<boolean>;
    readonly JobChainName: IReadValue<string>;
    readonly LimitationCount: IReadValue<number>;
    readonly LimitationWarning: IReadValue<number>;
    readonly LogMode: IReadValue<string>;
    readonly MaxInstance: IReadValue<number>;
    readonly MinutesToDefer: IReadValue<number>;
    readonly NotifyAddress: IReadValue<string>;
    readonly NotifyAddressSuccess: IReadValue<string>;
    readonly NotifyBody: IReadValue<string>;
    readonly NotifyBodySuccess: IReadValue<string>;
    readonly NotifySender: IReadValue<string>;
    readonly NotifySenderSuccess: IReadValue<string>;
    readonly NotifySubject: IReadValue<string>;
    readonly NotifySubjectSuccess: IReadValue<string>;
    readonly ParamIN: IReadValue<string>;
    readonly Priority: IReadValue<number>;
    readonly ProcessTracking: IReadValue<boolean>;
    readonly Queue: IReadValue<string>;
    readonly Ready2EXE: IReadValue<string>;
    readonly Retries: IReadValue<number>;
    readonly StartAt: IReadValue<Date>;
    readonly SuccessNotify: IReadValue<boolean>;
    readonly TaskName: IReadValue<string>;
    readonly UID_Job: IReadValue<string>;
    readonly UID_JobError: IReadValue<string>;
    readonly UID_JobOrigin: IReadValue<string>;
    readonly UID_JobSameServer: IReadValue<string>;
    readonly UID_JobSuccess: IReadValue<string>;
    readonly UID_Tree: IReadValue<string>;
    readonly WasError: IReadValue<boolean>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XDateUpdated: IReadValue<Date>;
    readonly XTouched: IReadValue<string>;
    readonly XUserInserted: IReadValue<string>;
    readonly XUserUpdated: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'BasisObjectKey' | 'ComponentAssembly' | 'ComponentClass' | 'DeferOnError' | 'ErrorMessages' | 'ErrorNotify' | 'ExecutionType' | 'GenProcID' | 'IgnoreErrors' | 'IsForHistory' | 'IsNoDBQueueDefer' | 'IsRootJob' | 'IsSplitOnly' | 'IsToFreezeOnError' | 'JobChainName' | 'LimitationCount' | 'LimitationWarning' | 'LogMode' | 'MaxInstance' | 'MinutesToDefer' | 'NotifyAddress' | 'NotifyAddressSuccess' | 'NotifyBody' | 'NotifyBodySuccess' | 'NotifySender' | 'NotifySenderSuccess' | 'NotifySubject' | 'NotifySubjectSuccess' | 'ParamIN' | 'Priority' | 'ProcessTracking' | 'Queue' | 'Ready2EXE' | 'Retries' | 'StartAt' | 'SuccessNotify' | 'TaskName' | 'UID_Job' | 'UID_JobError' | 'UID_JobOrigin' | 'UID_JobSameServer' | 'UID_JobSuccess' | 'UID_Tree' | 'WasError' | 'XDateInserted' | 'XDateUpdated' | 'XTouched' | 'XUserInserted' | 'XUserUpdated'>;
}
export declare class OpsupportQueueFrozenjobsbyqueue extends TypedEntity {
    readonly QueueName: IReadValue<string>;
    readonly Count: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'QueueName' | 'Count'>;
}
export declare class OpsupportQueueJobaffects extends TypedEntity {
    readonly ObjectKeyAffected: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'ObjectKeyAffected'>;
}
export declare class OpsupportQueueJobchains extends TypedEntity {
    readonly JobChainName: IReadValue<string>;
    readonly Count: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'JobChainName' | 'Count'>;
}
export declare class OpsupportQueueJobperformance extends TypedEntity {
    readonly Queue: IReadValue<string>;
    readonly ComponentClass: IReadValue<string>;
    readonly TaskName: IReadValue<string>;
    readonly CountPerMinute: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Queue' | 'ComponentClass' | 'TaskName' | 'CountPerMinute'>;
}
export declare class OpsupportQueueJobs extends TypedEntity {
    readonly JobChainName: IReadValue<string>;
    readonly UID_JobOrigin: IReadValue<string>;
    readonly Ready2EXE: IReadValue<string>;
    readonly TaskName: IReadValue<string>;
    readonly UID_Tree: IReadValue<string>;
    readonly UID_Job: IReadValue<string>;
    readonly Queue: IReadValue<string>;
    readonly Retries: IReadValue<number>;
    readonly IsRootJob: IReadValue<boolean>;
    readonly UID_JobSuccess: IReadValue<string>;
    readonly UID_JobError: IReadValue<string>;
    readonly XDateInserted: IReadValue<Date>;
    readonly JobChainDescription: IReadValue<string>;
    readonly JobName: IReadValue<string>;
    readonly CombinedStatus: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'JobChainName' | 'UID_JobOrigin' | 'Ready2EXE' | 'TaskName' | 'UID_Tree' | 'UID_Job' | 'Queue' | 'Retries' | 'IsRootJob' | 'UID_JobSuccess' | 'UID_JobError' | 'XDateInserted' | 'JobChainDescription' | 'JobName' | 'CombinedStatus'>;
}
export declare class OpsupportQueueOverview extends TypedEntity {
    readonly CountDelete: IReadValue<number>;
    readonly CountFalse: IReadValue<number>;
    readonly CountFinished: IReadValue<number>;
    readonly CountFrozen: IReadValue<number>;
    readonly CountHistory: IReadValue<number>;
    readonly CountLoaded: IReadValue<number>;
    readonly CountMissing: IReadValue<number>;
    readonly CountOverlimt: IReadValue<number>;
    readonly CountProcessing: IReadValue<number>;
    readonly CountTrue: IReadValue<number>;
    readonly IsInitQueueRunning: IReadValue<boolean>;
    readonly IsInvalid: IReadValue<boolean>;
    readonly QueueName: IReadValue<string>;
    readonly UID_QBMJobqueueOverview: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'CountDelete' | 'CountFalse' | 'CountFinished' | 'CountFrozen' | 'CountHistory' | 'CountLoaded' | 'CountMissing' | 'CountOverlimt' | 'CountProcessing' | 'CountTrue' | 'IsInitQueueRunning' | 'IsInvalid' | 'QueueName' | 'UID_QBMJobqueueOverview' | 'XObjectKey'>;
}
export declare class OpsupportQueueTree extends TypedEntity {
    readonly UID_Job: IReadValue<string>;
    readonly BasisObjectKey: IReadValue<string>;
    readonly DeferOnError: IReadValue<boolean>;
    readonly ErrorMessages: IReadValue<string>;
    readonly GenProcID: IReadValue<string>;
    readonly IsRootJob: IReadValue<boolean>;
    readonly JobChainName: IReadValue<string>;
    readonly LimitationCount: IReadValue<number>;
    readonly Retries: IReadValue<number>;
    readonly Queue: IReadValue<string>;
    readonly Ready2EXE: IReadValue<string>;
    readonly TaskName: IReadValue<string>;
    readonly UID_JobError: IReadValue<string>;
    readonly UID_JobOrigin: IReadValue<string>;
    readonly UID_JobSameServer: IReadValue<string>;
    readonly UID_JobSuccess: IReadValue<string>;
    readonly UID_Tree: IReadValue<string>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XDateUpdated: IReadValue<Date>;
    readonly XUserInserted: IReadValue<string>;
    readonly XUserUpdated: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_Job' | 'BasisObjectKey' | 'DeferOnError' | 'ErrorMessages' | 'GenProcID' | 'IsRootJob' | 'JobChainName' | 'LimitationCount' | 'Retries' | 'Queue' | 'Ready2EXE' | 'TaskName' | 'UID_JobError' | 'UID_JobOrigin' | 'UID_JobSameServer' | 'UID_JobSuccess' | 'UID_Tree' | 'XDateInserted' | 'XDateUpdated' | 'XUserInserted' | 'XUserUpdated'>;
}
export declare class OpsupportSearchIndexedtables extends TypedEntity {
    readonly TableName: IReadValue<string>;
    readonly DisplayName: IReadValue<string>;
    readonly DisplayNameSingular: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'TableName' | 'DisplayName' | 'DisplayNameSingular'>;
}
export declare class OpsupportSystemoverview extends TypedEntity {
    readonly Category: IReadValue<string>;
    readonly Element: IReadValue<string>;
    readonly QualityOfValue: IReadValue<number>;
    readonly RecommendedValue: IReadValue<string>;
    readonly SortOrder: IReadValue<number>;
    readonly SubElement: IReadValue<string>;
    readonly UID_QBMVSystemOverview: IReadValue<string>;
    readonly Value: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Category' | 'Element' | 'QualityOfValue' | 'RecommendedValue' | 'SortOrder' | 'SubElement' | 'UID_QBMVSystemOverview' | 'Value'>;
}
export declare class OpsupportWebapplications extends TypedEntity {
    readonly BaseURL: IReadValue<string>;
    readonly AutoUpdateLevel: IReadValue<number>;
    readonly UID_DialogProduct: IReadValue<string>;
    readonly IsDebug: IReadValue<boolean>;
    readonly IsPrivate: IReadValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'BaseURL' | 'AutoUpdateLevel' | 'UID_DialogProduct' | 'IsDebug' | 'IsPrivate'>;
}
export declare class ImxMultilanguageUiculturesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<ImxMultilanguageUicultures, unknown>>;
}
export declare class ImxSysteminfoThirdpartyWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<ImxSysteminfoThirdparty, unknown>>;
}
export declare class OpsupportJobserversWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        withconnection?: boolean;
        nofetchjob?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportJobservers, unknown>>;
}
export declare class OpsupportJournalWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        messagetype?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportJournal, unknown>>;
}
export declare class OpsupportQueueDbqueueWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportQueueDbqueue, unknown>>;
}
export declare class OpsupportQueueFrozenjobsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        queue?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportQueueFrozenjobs, unknown>>;
}
export declare class OpsupportQueueFrozenjobsbyqueueWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportQueueFrozenjobsbyqueue, unknown>>;
}
export declare class OpsupportQueueJobaffectsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidjob: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportQueueJobaffects, unknown>>;
}
export declare class OpsupportQueueJobchainsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportQueueJobchains, unknown>>;
}
export declare class OpsupportQueueJobperformanceWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        queue?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportQueueJobperformance, unknown>>;
}
export declare class OpsupportQueueJobsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        state?: string;
        queue?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportQueueJobs, unknown>>;
}
export declare class OpsupportQueueOverviewWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportQueueOverview, unknown>>;
}
export declare class OpsupportQueueTreeWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        uidtree?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportQueueTree, unknown>>;
}
export declare class OpsupportSearchIndexedtablesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportSearchIndexedtables, unknown>>;
}
export declare class OpsupportSystemoverviewWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportSystemoverview, unknown>>;
}
export declare class OpsupportWebapplicationsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportWebapplications, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    admin_apiconfig_get(appId: string): MethodDescriptor<ConfigNodeData[]>;
    admin_apiconfig_post(appId: string, global: boolean, inputParameterName: {
        [key: string]: any;
    }): MethodDescriptor<{
        [key: string]: any;
    }>;
    admin_apiconfigsingle_get(appId: string, path: string): MethodDescriptor<any>;
    admin_apiconfigsingle_post(appId: string, path: string): MethodDescriptor<void>;
    admin_apiconfig_convert_post(appId: string): MethodDescriptor<void>;
    admin_apiconfig_revert_post(appId: string, global: boolean): MethodDescriptor<void>;
    admin_apiconfig_values_get(appId: string, path: string): MethodDescriptor<ConfigSettingValidValue[]>;
    admin_cache_get(appId: string): MethodDescriptor<{
        [key: string]: CacheData;
    }>;
    admin_cache_post(appId: string, flush: boolean, disable: boolean): MethodDescriptor<{
        [key: string]: CacheData;
    }>;
    admin_cachebyid_get(appId: string, cacheid: string): MethodDescriptor<CacheData>;
    admin_cachebyid_post(appId: string, cacheid: string, flush: boolean, disable: boolean): MethodDescriptor<CacheData>;
    admin_config_get(): MethodDescriptor<ConfigData>;
    admin_config_post(inputParameterName: ApplicationMethodConfig): MethodDescriptor<ApplicationMethodConfig>;
    admin_packages_get(): MethodDescriptor<PackageInfo[]>;
    admin_performance_get(): MethodDescriptor<{
        [key: string]: PerfDataPoints;
    }>;
    admin_projects_get(): MethodDescriptor<MethodSetInfo[]>;
    admin_status_get(): MethodDescriptor<string>;
    admin_systeminfo_log_get(dir: string, file: string): MethodDescriptor<void>;
    admin_systeminfo_logs_get(): MethodDescriptor<LogFileInfo[]>;
    admin_systeminfo_plugins_get(): MethodDescriptor<LoadedPlugin[]>;
    admin_systeminfo_software_status_get(): MethodDescriptor<SoftwareStatus>;
    admin_systeminfo_software_update_post(): MethodDescriptor<void>;
    imx_activeverbs_get(appId: string): MethodDescriptor<{
        [key: string]: {
            [key: string]: VerbPermissionInfo;
        };
    }>;
    imx_applications_get(): MethodDescriptor<NodeAppInfo[]>;
    imx_config_get(): MethodDescriptor<ImxConfig>;
    imx_entityschema_get(): MethodDescriptor<{
        [key: string]: MethodSchemaDto;
    }>;
    imx_login_post(appId: string, noxsrf: boolean, inputParameterName: {
        [key: string]: string;
    }): MethodDescriptor<SessionResponse>;
    imx_logout_post(appId: string): MethodDescriptor<SessionResponse>;
    imx_metadata_table_get(tableName: string, cultureName: string): MethodDescriptor<MetaTableData>;
    imx_modelcss_get(): MethodDescriptor<void>;
    imx_modelimage_get(key: string, size: string): MethodDescriptor<void>;
    imx_multilanguage_getcaptions_get(cultureName: string): MethodDescriptor<{
        [key: string]: string;
    }>;
    imx_multilanguage_translations_get(cultureName: string, appId: string): MethodDescriptor<{
        [key: string]: {
            [key: string]: string;
        };
    }>;
    imx_multilanguage_uicultures_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    imx_oauth_get(authentifier: string, appId: string, redirecturi: string): MethodDescriptor<string>;
    imx_ping_get(): MethodDescriptor<PingResult>;
    imx_sessions_get(appId: string): MethodDescriptor<SessionResponse>;
    imx_system_get(): MethodDescriptor<SystemInfo>;
    imx_systeminfo_thirdparty_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    opsupport_assignment_get(tableName: string, uid: string): MethodDescriptor<EntityData[]>;
    opsupport_config_get(): MethodDescriptor<ProjectConfig>;
    opsupport_dbobject_get(tableName: string, uid: string): MethodDescriptor<EntityData>;
    opsupport_history_get(table: string, uid: string): MethodDescriptor<HistoryData[]>;
    opsupport_history_comparison_get(table: string, uid: string, CompareDate: Date): MethodDescriptor<HistoryComparisonData[]>;
    opsupport_hyperview_get(table: string, uid: string): MethodDescriptor<ShapeData[]>;
    opsupport_jobserver_get(server: string): MethodDescriptor<ServerConfig>;
    opsupport_jobservers_get(withconnection: boolean, nofetchjob: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    opsupport_journal_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, messagetype: string): MethodDescriptor<EntityCollectionData>;
    opsupport_journal_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    opsupport_journal_stat_get(): MethodDescriptor<any>;
    opsupport_queue_dbqueue_get(): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_frozenjobs_get(queue: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_frozenjobsbyqueue_get(): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_jobaffects_get(uidjob: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_jobchains_get(): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_jobperformance_get(queue: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_jobperformancequeues_get(): MethodDescriptor<string[]>;
    opsupport_queue_jobs_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, state: string, queue: string): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_jobs_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    opsupport_queue_object_get(table: string, uid: string): MethodDescriptor<QueueEntriesData>;
    opsupport_queue_overview_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_overview_stream_get(): MethodDescriptor<void>;
    opsupport_queue_reactivatejob_post(inputParameterName: ReactivateJobInput): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_tree_get(uidtree: string): MethodDescriptor<EntityCollectionData>;
    opsupport_search_get(term: string, tables: string): MethodDescriptor<SearchResultObject[]>;
    opsupport_search_indexedtables_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    opsupport_streamconfig_get(): MethodDescriptor<EventStreamConfig>;
    opsupport_systemoverview_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    opsupport_systemstatus_get(): MethodDescriptor<any>;
    opsupport_systemstatus_post(IsDbSchedulerDisabled: boolean, IsJobServiceDisabled: boolean, inputParameterName: any): MethodDescriptor<any>;
    opsupport_usergroups_get(): MethodDescriptor<UserGroupInfo[]>;
    opsupport_webapplications_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    scim_v2_get(filter: string): MethodDescriptor<any>;
    scim_v2__search_get(count: string, startIndex: string, attributes: string, filter: string): MethodDescriptor<any>;
    scim_v2__search_post(): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_AccProduct_get(count: string, startIndex: string, attributes: string, filter: string): MethodDescriptor<any>;
    scim_v2_AccProduct_post(): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_AccProductby_id_get(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_AccProductby_id_delete(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<void>;
    scim_v2_AccProductby_id_put(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_AccProductby_id_patch(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Bulk_get(count: string, startIndex: string, attributes: string, filter: string): MethodDescriptor<any>;
    scim_v2_Bulk_post(): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Department_get(count: string, startIndex: string, attributes: string, filter: string): MethodDescriptor<any>;
    scim_v2_Department_post(): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Departmentby_id_get(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Departmentby_id_delete(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<void>;
    scim_v2_Departmentby_id_put(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Departmentby_id_patch(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Locality_get(count: string, startIndex: string, attributes: string, filter: string): MethodDescriptor<any>;
    scim_v2_Locality_post(): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Localityby_id_get(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Localityby_id_delete(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<void>;
    scim_v2_Localityby_id_put(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Localityby_id_patch(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Me_get(count: string, startIndex: string, attributes: string, filter: string): MethodDescriptor<any>;
    scim_v2_Me_post(): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Person_get(count: string, startIndex: string, attributes: string, filter: string): MethodDescriptor<any>;
    scim_v2_Person_post(): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Personby_id_get(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Personby_id_delete(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<void>;
    scim_v2_Personby_id_put(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Personby_id_patch(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Profitcenter_get(count: string, startIndex: string, attributes: string, filter: string): MethodDescriptor<any>;
    scim_v2_Profitcenter_post(): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Profitcenterby_id_get(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Profitcenterby_id_delete(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<void>;
    scim_v2_Profitcenterby_id_put(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Profitcenterby_id_patch(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_ResourceTypes_get(): MethodDescriptor<any>;
    scim_v2_Schemas_get(): MethodDescriptor<any>;
    scim_v2_ServiceProviderConfig_get(): MethodDescriptor<any>;
    scim_v2_UnsAccount_get(count: string, startIndex: string, attributes: string, filter: string): MethodDescriptor<any>;
    scim_v2_UnsAccount_post(): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountby_id_get(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountby_id_delete(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<void>;
    scim_v2_UnsAccountby_id_put(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountby_id_patch(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountB_get(count: string, startIndex: string, attributes: string, filter: string): MethodDescriptor<any>;
    scim_v2_UnsAccountB_post(): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountBby_id_get(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountBby_id_delete(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<void>;
    scim_v2_UnsAccountBby_id_put(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountBby_id_patch(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsContainerB_get(count: string, startIndex: string, attributes: string, filter: string): MethodDescriptor<any>;
    scim_v2_UnsContainerB_post(): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsContainerBby_id_get(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsContainerBby_id_delete(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<void>;
    scim_v2_UnsContainerBby_id_put(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsContainerBby_id_patch(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroup_get(count: string, startIndex: string, attributes: string, filter: string): MethodDescriptor<any>;
    scim_v2_UnsGroup_post(): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupby_id_get(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupby_id_delete(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<void>;
    scim_v2_UnsGroupby_id_put(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupby_id_patch(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB_get(count: string, startIndex: string, attributes: string, filter: string): MethodDescriptor<any>;
    scim_v2_UnsGroupB_post(): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupBby_id_get(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupBby_id_delete(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<void>;
    scim_v2_UnsGroupBby_id_put(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupBby_id_patch(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB1_get(count: string, startIndex: string, attributes: string, filter: string): MethodDescriptor<any>;
    scim_v2_UnsGroupB1_post(): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB1by_id_get(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB1by_id_delete(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<void>;
    scim_v2_UnsGroupB1by_id_put(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB1by_id_patch(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB2_get(count: string, startIndex: string, attributes: string, filter: string): MethodDescriptor<any>;
    scim_v2_UnsGroupB2_post(): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB2by_id_get(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB2by_id_delete(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<void>;
    scim_v2_UnsGroupB2by_id_put(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB2by_id_patch(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB3_get(count: string, startIndex: string, attributes: string, filter: string): MethodDescriptor<any>;
    scim_v2_UnsGroupB3_post(): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB3by_id_get(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB3by_id_delete(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<void>;
    scim_v2_UnsGroupB3by_id_put(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB3by_id_patch(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsRootB_get(count: string, startIndex: string, attributes: string, filter: string): MethodDescriptor<any>;
    scim_v2_UnsRootB_post(): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsRootBby_id_get(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsRootBby_id_delete(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<void>;
    scim_v2_UnsRootBby_id_put(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsRootBby_id_patch(attributes: string, excludedAttributes: string, uid: string): MethodDescriptor<{
        [key: string]: any;
    }>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    /** Returns the currently active configuration for the specified project. */
    admin_apiconfig_get(appId: string, requestOptions?: ApiRequestOptions): Promise<ConfigNodeData[]>;
    /** Updates the configuration with the supplied values. */
    admin_apiconfig_post(appId: string, global: boolean, inputParameterName: {
        [key: string]: any;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    /** Returns the currently active configuration value for the specified path. */
    admin_apiconfigsingle_get(appId: string, path: string, requestOptions?: ApiRequestOptions): Promise<any>;
    /** Adds a new configuration key on the specified path. */
    admin_apiconfigsingle_post(appId: string, path: string, requestOptions?: ApiRequestOptions): Promise<void>;
    admin_apiconfig_convert_post(appId: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Reverts all global or local customizations */
    admin_apiconfig_revert_post(appId: string, global: boolean, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns valid values for the configuration setting identified by specified path. */
    admin_apiconfig_values_get(appId: string, path: string, requestOptions?: ApiRequestOptions): Promise<ConfigSettingValidValue[]>;
    /** Returns cache data for the specified project. */
    admin_cache_get(appId: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: CacheData;
    }>;
    /** Returns cache data for the specified project. */
    admin_cache_post(appId: string, flush: boolean, disable: boolean, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: CacheData;
    }>;
    /** Manages the specified cache for the specified project. */
    admin_cachebyid_get(appId: string, cacheid: string, requestOptions?: ApiRequestOptions): Promise<CacheData>;
    /** Manages the specified cache for the specified project. */
    admin_cachebyid_post(appId: string, cacheid: string, flush: boolean, disable: boolean, requestOptions?: ApiRequestOptions): Promise<CacheData>;
    admin_config_get(requestOptions?: ApiRequestOptions): Promise<ConfigData>;
    admin_config_post(inputParameterName: ApplicationMethodConfig, requestOptions?: ApiRequestOptions): Promise<ApplicationMethodConfig>;
    admin_packages_get(requestOptions?: ApiRequestOptions): Promise<PackageInfo[]>;
    /** Returns the most recently recorded performance data. */
    admin_performance_get(requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: PerfDataPoints;
    }>;
    admin_projects_get(requestOptions?: ApiRequestOptions): Promise<MethodSetInfo[]>;
    admin_status_get(requestOptions?: ApiRequestOptions): Promise<string>;
    admin_systeminfo_log_get(dir: string, file: string, requestOptions?: ApiRequestOptions): Promise<void>;
    admin_systeminfo_logs_get(requestOptions?: ApiRequestOptions): Promise<LogFileInfo[]>;
    admin_systeminfo_plugins_get(requestOptions?: ApiRequestOptions): Promise<LoadedPlugin[]>;
    admin_systeminfo_software_status_get(requestOptions?: ApiRequestOptions): Promise<SoftwareStatus>;
    /** Starts the software update process */
    admin_systeminfo_software_update_post(requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns the set of currently active endpoints, and a flag indicating whether an endpoint is active for the current user. */
    imx_activeverbs_get(appId: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: {
            [key: string]: VerbPermissionInfo;
        };
    }>;
    imx_applications_get(requestOptions?: ApiRequestOptions): Promise<NodeAppInfo[]>;
    imx_config_get(requestOptions?: ApiRequestOptions): Promise<ImxConfig>;
    imx_entityschema_get(requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: MethodSchemaDto;
    }>;
    imx_login_post(appId: string, noxsrf: boolean, inputParameterName: {
        [key: string]: string;
    }, requestOptions?: ApiRequestOptions): Promise<SessionResponse>;
    imx_logout_post(appId: string, requestOptions?: ApiRequestOptions): Promise<SessionResponse>;
    /** Returns metadata for a specific database table. */
    imx_metadata_table_get(tableName: string, cultureName: string, requestOptions?: ApiRequestOptions): Promise<MetaTableData>;
    /** Returns the model-generated stylesheet. */
    imx_modelcss_get(requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns an image stored from data model. */
    imx_modelimage_get(key: string, size: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns web UI translations for a specific culture. */
    imx_multilanguage_getcaptions_get(cultureName: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: string;
    }>;
    /** Returns translations for the data model for an API project. */
    imx_multilanguage_translations_get(cultureName: string, appId: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: {
            [key: string]: string;
        };
    }>;
    /** Returns all cultures that are available to frontends. */
    imx_multilanguage_uicultures_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    imx_oauth_get(authentifier: string, appId: string, redirecturi: string, requestOptions?: ApiRequestOptions): Promise<string>;
    /** Returns an object indicating whether this API server was able to start up and establish a database connection. */
    imx_ping_get(requestOptions?: ApiRequestOptions): Promise<PingResult>;
    imx_sessions_get(appId: string, requestOptions?: ApiRequestOptions): Promise<SessionResponse>;
    imx_system_get(requestOptions?: ApiRequestOptions): Promise<SystemInfo>;
    /** Returns a list of all third party components. */
    imx_systeminfo_thirdparty_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns the objects that are part of assignment, specified by the assignment's 'table name and the uid. */
    opsupport_assignment_get(tableName: string, uid: string, requestOptions?: ApiRequestOptions): Promise<EntityData[]>;
    opsupport_config_get(requestOptions?: ApiRequestOptions): Promise<ProjectConfig>;
    /** Returns basic information about an object specified by the table name and the uid. */
    opsupport_dbobject_get(tableName: string, uid: string, requestOptions?: ApiRequestOptions): Promise<EntityData>;
    opsupport_history_get(table: string, uid: string, requestOptions?: ApiRequestOptions): Promise<HistoryData[]>;
    opsupport_history_comparison_get(table: string, uid: string, CompareDate: Date, requestOptions?: ApiRequestOptions): Promise<HistoryComparisonData[]>;
    opsupport_hyperview_get(table: string, uid: string, requestOptions?: ApiRequestOptions): Promise<ShapeData[]>;
    opsupport_jobserver_get(server: string, requestOptions?: ApiRequestOptions): Promise<ServerConfig>;
    opsupport_jobservers_get(withconnection: boolean, nofetchjob: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns entries in the journal, returning the newest entries first. */
    opsupport_journal_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, messagetype: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the journal endpoint. */
    opsupport_journal_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    opsupport_journal_stat_get(requestOptions?: ApiRequestOptions): Promise<any>;
    opsupport_queue_dbqueue_get(requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_queue_frozenjobs_get(queue: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_queue_frozenjobsbyqueue_get(requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_queue_jobaffects_get(uidjob: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_queue_jobchains_get(requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_queue_jobperformance_get(queue: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_queue_jobperformancequeues_get(requestOptions?: ApiRequestOptions): Promise<string[]>;
    opsupport_queue_jobs_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, state: string, queue: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the queue/jobs endpoint. */
    opsupport_queue_jobs_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    opsupport_queue_object_get(table: string, uid: string, requestOptions?: ApiRequestOptions): Promise<QueueEntriesData>;
    opsupport_queue_overview_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_queue_overview_stream_get(requestOptions?: ApiRequestOptions): Promise<void>;
    /** Reactivates a process where one of the process steps is in the FROZEN or OVERLIMIT state. */
    opsupport_queue_reactivatejob_post(inputParameterName: ReactivateJobInput, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_queue_tree_get(uidtree: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_search_get(term: string, tables: string, requestOptions?: ApiRequestOptions): Promise<SearchResultObject[]>;
    /** Returns the list of tables that are included in the search index. */
    opsupport_search_indexedtables_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_streamconfig_get(requestOptions?: ApiRequestOptions): Promise<EventStreamConfig>;
    opsupport_systemoverview_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_systemstatus_get(requestOptions?: ApiRequestOptions): Promise<any>;
    opsupport_systemstatus_post(IsDbSchedulerDisabled: boolean, IsJobServiceDisabled: boolean, inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<any>;
    /** Returns the list of permissions groups that the current user is assigned to. */
    opsupport_usergroups_get(requestOptions?: ApiRequestOptions): Promise<UserGroupInfo[]>;
    opsupport_webapplications_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    scim_v2_get(filter: string, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2__search_get(count: string, startIndex: string, attributes: string, filter: string, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2__search_post(requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_AccProduct_get(count: string, startIndex: string, attributes: string, filter: string, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_AccProduct_post(requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_AccProductby_id_get(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_AccProductby_id_delete(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_AccProductby_id_put(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_AccProductby_id_patch(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Bulk_get(count: string, startIndex: string, attributes: string, filter: string, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_Bulk_post(requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Department_get(count: string, startIndex: string, attributes: string, filter: string, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_Department_post(requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Departmentby_id_get(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Departmentby_id_delete(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_Departmentby_id_put(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Departmentby_id_patch(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Locality_get(count: string, startIndex: string, attributes: string, filter: string, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_Locality_post(requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Localityby_id_get(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Localityby_id_delete(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_Localityby_id_put(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Localityby_id_patch(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Me_get(count: string, startIndex: string, attributes: string, filter: string, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_Me_post(requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Person_get(count: string, startIndex: string, attributes: string, filter: string, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_Person_post(requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Personby_id_get(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Personby_id_delete(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_Personby_id_put(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Personby_id_patch(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Profitcenter_get(count: string, startIndex: string, attributes: string, filter: string, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_Profitcenter_post(requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Profitcenterby_id_get(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Profitcenterby_id_delete(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_Profitcenterby_id_put(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Profitcenterby_id_patch(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_ResourceTypes_get(requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_Schemas_get(requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_ServiceProviderConfig_get(requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_UnsAccount_get(count: string, startIndex: string, attributes: string, filter: string, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_UnsAccount_post(requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountby_id_get(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountby_id_delete(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_UnsAccountby_id_put(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountby_id_patch(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountB_get(count: string, startIndex: string, attributes: string, filter: string, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_UnsAccountB_post(requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountBby_id_get(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountBby_id_delete(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_UnsAccountBby_id_put(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountBby_id_patch(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsContainerB_get(count: string, startIndex: string, attributes: string, filter: string, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_UnsContainerB_post(requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsContainerBby_id_get(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsContainerBby_id_delete(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_UnsContainerBby_id_put(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsContainerBby_id_patch(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroup_get(count: string, startIndex: string, attributes: string, filter: string, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_UnsGroup_post(requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupby_id_get(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupby_id_delete(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_UnsGroupby_id_put(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupby_id_patch(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB_get(count: string, startIndex: string, attributes: string, filter: string, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_UnsGroupB_post(requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupBby_id_get(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupBby_id_delete(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_UnsGroupBby_id_put(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupBby_id_patch(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB1_get(count: string, startIndex: string, attributes: string, filter: string, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_UnsGroupB1_post(requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB1by_id_get(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB1by_id_delete(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_UnsGroupB1by_id_put(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB1by_id_patch(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB2_get(count: string, startIndex: string, attributes: string, filter: string, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_UnsGroupB2_post(requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB2by_id_get(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB2by_id_delete(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_UnsGroupB2by_id_put(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB2by_id_patch(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB3_get(count: string, startIndex: string, attributes: string, filter: string, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_UnsGroupB3_post(requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB3by_id_get(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB3by_id_delete(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_UnsGroupB3by_id_put(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB3by_id_patch(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsRootB_get(count: string, startIndex: string, attributes: string, filter: string, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_UnsRootB_post(requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsRootBby_id_get(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsRootBby_id_delete(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_UnsRootBby_id_put(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsRootBby_id_patch(attributes: string, excludedAttributes: string, uid: string, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
}
export declare class V2ApiClientMethodFactory {
    admin_apiconfig_get(appId: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ConfigNodeData[]>;
    admin_apiconfig_post(appId: string, inputParameterName: {
        [key: string]: any;
    }, options?: {
        global?: boolean;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    admin_apiconfigsingle_get(appId: string, path: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    admin_apiconfigsingle_post(appId: string, path: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    admin_apiconfig_convert_post(appId: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    admin_apiconfig_revert_post(appId: string, options?: {
        global?: boolean;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    admin_apiconfig_values_get(appId: string, path: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ConfigSettingValidValue[]>;
    admin_cache_get(appId: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: CacheData;
    }>;
    admin_cache_post(appId: string, options?: {
        flush?: boolean;
        disable?: boolean;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: CacheData;
    }>;
    admin_cachebyid_get(appId: string, cacheid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<CacheData>;
    admin_cachebyid_post(appId: string, cacheid: string, options?: {
        flush?: boolean;
        disable?: boolean;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<CacheData>;
    admin_config_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ConfigData>;
    admin_config_post(inputParameterName: ApplicationMethodConfig, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ApplicationMethodConfig>;
    admin_packages_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<PackageInfo[]>;
    admin_performance_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: PerfDataPoints;
    }>;
    admin_projects_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<MethodSetInfo[]>;
    admin_status_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<string>;
    admin_systeminfo_log_get(dir: string, file: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    admin_systeminfo_logs_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<LogFileInfo[]>;
    admin_systeminfo_plugins_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<LoadedPlugin[]>;
    admin_systeminfo_software_status_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<SoftwareStatus>;
    admin_systeminfo_software_update_post(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    imx_activeverbs_get(appId: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: {
            [key: string]: VerbPermissionInfo;
        };
    }>;
    imx_applications_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<NodeAppInfo[]>;
    imx_config_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ImxConfig>;
    imx_entityschema_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: MethodSchemaDto;
    }>;
    imx_login_post(appId: string, inputParameterName: {
        [key: string]: string;
    }, options?: {
        noxsrf?: boolean;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<SessionResponse>;
    imx_logout_post(appId: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<SessionResponse>;
    imx_metadata_table_get(tableName: string, options?: {
        cultureName?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<MetaTableData>;
    imx_modelcss_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    imx_modelimage_get(key: string, size: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    imx_multilanguage_getcaptions_get(options?: {
        cultureName?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: string;
    }>;
    imx_multilanguage_translations_get(appId: string, options?: {
        cultureName?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: {
            [key: string]: string;
        };
    }>;
    imx_multilanguage_uicultures_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    imx_oauth_get(authentifier: string, appId: string, options?: {
        redirecturi?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<string>;
    imx_ping_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<PingResult>;
    imx_sessions_get(appId: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<SessionResponse>;
    imx_system_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<SystemInfo>;
    imx_systeminfo_thirdparty_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_assignment_get(tableName: string, uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityData[]>;
    opsupport_config_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ProjectConfig>;
    opsupport_dbobject_get(tableName: string, uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityData>;
    opsupport_history_get(table: string, uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<HistoryData[]>;
    opsupport_history_comparison_get(table: string, uid: string, options?: {
        CompareDate?: Date;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<HistoryComparisonData[]>;
    opsupport_hyperview_get(table: string, uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ShapeData[]>;
    opsupport_jobserver_get(server: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ServerConfig>;
    opsupport_jobservers_get(options?: {
        withconnection?: boolean;
        nofetchjob?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_journal_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        messagetype?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_journal_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    opsupport_journal_stat_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    opsupport_queue_dbqueue_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_frozenjobs_get(options?: {
        queue?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_frozenjobsbyqueue_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_jobaffects_get(uidjob: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_jobchains_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_jobperformance_get(options?: {
        queue?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_jobperformancequeues_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<string[]>;
    opsupport_queue_jobs_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        state?: string;
        queue?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_jobs_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    opsupport_queue_object_get(table: string, uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<QueueEntriesData>;
    opsupport_queue_overview_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_overview_stream_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    opsupport_queue_reactivatejob_post(inputParameterName: ReactivateJobInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_queue_tree_get(options?: {
        uidtree?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_search_get(options?: {
        term?: string;
        tables?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<SearchResultObject[]>;
    opsupport_search_indexedtables_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_streamconfig_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EventStreamConfig>;
    opsupport_systemoverview_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    opsupport_systemstatus_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    opsupport_systemstatus_post(inputParameterName: any, options?: {
        IsDbSchedulerDisabled?: boolean;
        IsJobServiceDisabled?: boolean;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    opsupport_usergroups_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<UserGroupInfo[]>;
    opsupport_webapplications_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    scim_v2_get(filter: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    scim_v2__search_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    scim_v2__search_post(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_AccProduct_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    scim_v2_AccProduct_post(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_AccProductby_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_AccProductby_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    scim_v2_AccProductby_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_AccProductby_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Bulk_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    scim_v2_Bulk_post(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Department_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    scim_v2_Department_post(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Departmentby_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Departmentby_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    scim_v2_Departmentby_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Departmentby_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Locality_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    scim_v2_Locality_post(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Localityby_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Localityby_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    scim_v2_Localityby_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Localityby_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Me_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    scim_v2_Me_post(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Person_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    scim_v2_Person_post(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Personby_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Personby_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    scim_v2_Personby_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Personby_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Profitcenter_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    scim_v2_Profitcenter_post(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Profitcenterby_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Profitcenterby_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    scim_v2_Profitcenterby_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_Profitcenterby_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_ResourceTypes_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    scim_v2_Schemas_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    scim_v2_ServiceProviderConfig_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    scim_v2_UnsAccount_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    scim_v2_UnsAccount_post(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountby_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountby_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    scim_v2_UnsAccountby_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountby_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountB_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    scim_v2_UnsAccountB_post(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountBby_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountBby_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    scim_v2_UnsAccountBby_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountBby_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsContainerB_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    scim_v2_UnsContainerB_post(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsContainerBby_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsContainerBby_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    scim_v2_UnsContainerBby_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsContainerBby_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroup_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    scim_v2_UnsGroup_post(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupby_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupby_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    scim_v2_UnsGroupby_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupby_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    scim_v2_UnsGroupB_post(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupBby_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupBby_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    scim_v2_UnsGroupBby_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupBby_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB1_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    scim_v2_UnsGroupB1_post(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB1by_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB1by_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    scim_v2_UnsGroupB1by_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB1by_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB2_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    scim_v2_UnsGroupB2_post(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB2by_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB2by_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    scim_v2_UnsGroupB2by_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB2by_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB3_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    scim_v2_UnsGroupB3_post(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB3by_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB3by_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    scim_v2_UnsGroupB3by_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB3by_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsRootB_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    scim_v2_UnsRootB_post(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsRootBby_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsRootBby_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    scim_v2_UnsRootBby_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
    scim_v2_UnsRootBby_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<{
        [key: string]: any;
    }>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    /** Returns the currently active configuration for the specified project. */
    admin_apiconfig_get(appId: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ConfigNodeData[]>;
    /** Updates the configuration with the supplied values. */
    admin_apiconfig_post(appId: string, inputParameterName: {
        [key: string]: any;
    }, options?: {
        global?: boolean;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    /** Returns the currently active configuration value for the specified path. */
    admin_apiconfigsingle_get(appId: string, path: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    /** Adds a new configuration key on the specified path. */
    admin_apiconfigsingle_post(appId: string, path: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    admin_apiconfig_convert_post(appId: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Reverts all global or local customizations */
    admin_apiconfig_revert_post(appId: string, options?: {
        global?: boolean;
    }, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns valid values for the configuration setting identified by specified path. */
    admin_apiconfig_values_get(appId: string, path: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ConfigSettingValidValue[]>;
    /** Returns cache data for the specified project. */
    admin_cache_get(appId: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: CacheData;
    }>;
    /** Returns cache data for the specified project. */
    admin_cache_post(appId: string, options?: {
        flush?: boolean;
        disable?: boolean;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: CacheData;
    }>;
    /** Manages the specified cache for the specified project. */
    admin_cachebyid_get(appId: string, cacheid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<CacheData>;
    /** Manages the specified cache for the specified project. */
    admin_cachebyid_post(appId: string, cacheid: string, options?: {
        flush?: boolean;
        disable?: boolean;
    }, requestOptions?: ApiRequestOptions): Promise<CacheData>;
    admin_config_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<ConfigData>;
    admin_config_post(inputParameterName: ApplicationMethodConfig, options?: {}, requestOptions?: ApiRequestOptions): Promise<ApplicationMethodConfig>;
    admin_packages_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<PackageInfo[]>;
    /** Returns the most recently recorded performance data. */
    admin_performance_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: PerfDataPoints;
    }>;
    admin_projects_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<MethodSetInfo[]>;
    admin_status_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<string>;
    admin_systeminfo_log_get(dir: string, file: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    admin_systeminfo_logs_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<LogFileInfo[]>;
    admin_systeminfo_plugins_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<LoadedPlugin[]>;
    admin_systeminfo_software_status_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<SoftwareStatus>;
    /** Starts the software update process */
    admin_systeminfo_software_update_post(options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns the set of currently active endpoints, and a flag indicating whether an endpoint is active for the current user. */
    imx_activeverbs_get(appId: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: {
            [key: string]: VerbPermissionInfo;
        };
    }>;
    imx_applications_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<NodeAppInfo[]>;
    imx_config_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<ImxConfig>;
    imx_entityschema_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: MethodSchemaDto;
    }>;
    imx_login_post(appId: string, inputParameterName: {
        [key: string]: string;
    }, options?: {
        noxsrf?: boolean;
    }, requestOptions?: ApiRequestOptions): Promise<SessionResponse>;
    imx_logout_post(appId: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<SessionResponse>;
    /** Returns metadata for a specific database table. */
    imx_metadata_table_get(tableName: string, options?: {
        cultureName?: string;
    }, requestOptions?: ApiRequestOptions): Promise<MetaTableData>;
    /** Returns the model-generated stylesheet. */
    imx_modelcss_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns an image stored from data model. */
    imx_modelimage_get(key: string, size: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns web UI translations for a specific culture. */
    imx_multilanguage_getcaptions_get(options?: {
        cultureName?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: string;
    }>;
    /** Returns translations for the data model for an API project. */
    imx_multilanguage_translations_get(appId: string, options?: {
        cultureName?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: {
            [key: string]: string;
        };
    }>;
    /** Returns all cultures that are available to frontends. */
    imx_multilanguage_uicultures_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    imx_oauth_get(authentifier: string, appId: string, options?: {
        redirecturi?: string;
    }, requestOptions?: ApiRequestOptions): Promise<string>;
    /** Returns an object indicating whether this API server was able to start up and establish a database connection. */
    imx_ping_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<PingResult>;
    imx_sessions_get(appId: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<SessionResponse>;
    imx_system_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<SystemInfo>;
    /** Returns a list of all third party components. */
    imx_systeminfo_thirdparty_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns the objects that are part of assignment, specified by the assignment's 'table name and the uid. */
    opsupport_assignment_get(tableName: string, uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityData[]>;
    opsupport_config_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<ProjectConfig>;
    /** Returns basic information about an object specified by the table name and the uid. */
    opsupport_dbobject_get(tableName: string, uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityData>;
    opsupport_history_get(table: string, uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<HistoryData[]>;
    opsupport_history_comparison_get(table: string, uid: string, options?: {
        CompareDate?: Date;
    }, requestOptions?: ApiRequestOptions): Promise<HistoryComparisonData[]>;
    opsupport_hyperview_get(table: string, uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ShapeData[]>;
    opsupport_jobserver_get(server: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ServerConfig>;
    opsupport_jobservers_get(options?: {
        withconnection?: boolean;
        nofetchjob?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns entries in the journal, returning the newest entries first. */
    opsupport_journal_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        messagetype?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the journal endpoint. */
    opsupport_journal_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    opsupport_journal_stat_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    opsupport_queue_dbqueue_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_queue_frozenjobs_get(options?: {
        queue?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_queue_frozenjobsbyqueue_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_queue_jobaffects_get(uidjob: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_queue_jobchains_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_queue_jobperformance_get(options?: {
        queue?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_queue_jobperformancequeues_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<string[]>;
    opsupport_queue_jobs_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        state?: string;
        queue?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the queue/jobs endpoint. */
    opsupport_queue_jobs_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    opsupport_queue_object_get(table: string, uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<QueueEntriesData>;
    opsupport_queue_overview_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_queue_overview_stream_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Reactivates a process where one of the process steps is in the FROZEN or OVERLIMIT state. */
    opsupport_queue_reactivatejob_post(inputParameterName: ReactivateJobInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_queue_tree_get(options?: {
        uidtree?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_search_get(options?: {
        term?: string;
        tables?: string;
    }, requestOptions?: ApiRequestOptions): Promise<SearchResultObject[]>;
    /** Returns the list of tables that are included in the search index. */
    opsupport_search_indexedtables_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_streamconfig_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<EventStreamConfig>;
    opsupport_systemoverview_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    opsupport_systemstatus_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    opsupport_systemstatus_post(inputParameterName: any, options?: {
        IsDbSchedulerDisabled?: boolean;
        IsJobServiceDisabled?: boolean;
    }, requestOptions?: ApiRequestOptions): Promise<any>;
    /** Returns the list of permissions groups that the current user is assigned to. */
    opsupport_usergroups_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<UserGroupInfo[]>;
    opsupport_webapplications_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    scim_v2_get(filter: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2__search_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2__search_post(options?: {}, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_AccProduct_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_AccProduct_post(options?: {}, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_AccProductby_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_AccProductby_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_AccProductby_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_AccProductby_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Bulk_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_Bulk_post(options?: {}, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Department_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_Department_post(options?: {}, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Departmentby_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Departmentby_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_Departmentby_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Departmentby_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Locality_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_Locality_post(options?: {}, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Localityby_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Localityby_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_Localityby_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Localityby_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Me_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_Me_post(options?: {}, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Person_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_Person_post(options?: {}, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Personby_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Personby_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_Personby_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Personby_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Profitcenter_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_Profitcenter_post(options?: {}, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Profitcenterby_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Profitcenterby_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_Profitcenterby_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_Profitcenterby_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_ResourceTypes_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_Schemas_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_ServiceProviderConfig_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_UnsAccount_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_UnsAccount_post(options?: {}, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountby_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountby_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_UnsAccountby_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountby_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountB_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_UnsAccountB_post(options?: {}, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountBby_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountBby_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_UnsAccountBby_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsAccountBby_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsContainerB_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_UnsContainerB_post(options?: {}, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsContainerBby_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsContainerBby_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_UnsContainerBby_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsContainerBby_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroup_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_UnsGroup_post(options?: {}, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupby_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupby_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_UnsGroupby_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupby_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_UnsGroupB_post(options?: {}, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupBby_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupBby_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_UnsGroupBby_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupBby_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB1_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_UnsGroupB1_post(options?: {}, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB1by_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB1by_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_UnsGroupB1by_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB1by_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB2_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_UnsGroupB2_post(options?: {}, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB2by_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB2by_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_UnsGroupB2by_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB2by_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB3_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_UnsGroupB3_post(options?: {}, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB3by_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB3by_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_UnsGroupB3by_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsGroupB3by_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsRootB_get(count: string, startIndex: string, attributes: string, filter: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    scim_v2_UnsRootB_post(options?: {}, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsRootBby_id_get(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsRootBby_id_delete(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<void>;
    scim_v2_UnsRootBby_id_put(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
    scim_v2_UnsRootBby_id_patch(uid: string, options?: {
        attributes?: string;
        excludedAttributes?: string;
    }, requestOptions?: ApiRequestOptions): Promise<{
        [key: string]: any;
    }>;
}
