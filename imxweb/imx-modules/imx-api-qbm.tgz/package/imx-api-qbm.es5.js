import { ValType, DisplayColumns, TypedEntity, TypedEntityBuilder, TimeZoneInfo, DisplayPattern, FkCandidateBuilder, MethodDefinition } from 'imx-qbm-dbts';

var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
/** Authentication property types */
var AuthPropType;
(function (AuthPropType) {
    AuthPropType[AuthPropType["Info"] = 0] = "Info";
    AuthPropType[AuthPropType["Edit"] = 1] = "Edit";
    AuthPropType[AuthPropType["Password"] = 2] = "Password";
    AuthPropType[AuthPropType["Hidden"] = 3] = "Hidden";
    AuthPropType[AuthPropType["Checkbox"] = 4] = "Checkbox";
    AuthPropType[AuthPropType["OAuth2Code"] = 5] = "OAuth2Code";
    AuthPropType[AuthPropType["NewPassword"] = 6] = "NewPassword";
})(AuthPropType || (AuthPropType = {}));
var AuthType;
(function (AuthType) {
    AuthType[AuthType["Default"] = 0] = "Default";
    AuthType[AuthType["AllManualModules"] = 1] = "AllManualModules";
    AuthType[AuthType["FixedCredentials"] = 2] = "FixedCredentials";
})(AuthType || (AuthType = {}));
var ConfigSettingType;
(function (ConfigSettingType) {
    ConfigSettingType[ConfigSettingType["None"] = 0] = "None";
    ConfigSettingType[ConfigSettingType["Sql"] = 1] = "Sql";
    ConfigSettingType[ConfigSettingType["Int"] = 2] = "Int";
    ConfigSettingType[ConfigSettingType["PositiveInt"] = 3] = "PositiveInt";
    ConfigSettingType[ConfigSettingType["Double"] = 4] = "Double";
    ConfigSettingType[ConfigSettingType["RiskIndex"] = 5] = "RiskIndex";
    ConfigSettingType[ConfigSettingType["PositiveDouble"] = 6] = "PositiveDouble";
    ConfigSettingType[ConfigSettingType["LimitedValues"] = 7] = "LimitedValues";
})(ConfigSettingType || (ConfigSettingType = {}));
var ReactivateJobMode;
(function (ReactivateJobMode) {
    ReactivateJobMode[ReactivateJobMode["Reactivate"] = 0] = "Reactivate";
    ReactivateJobMode[ReactivateJobMode["ContinueSuccess"] = 1] = "ContinueSuccess";
    ReactivateJobMode[ReactivateJobMode["ContinueError"] = 2] = "ContinueError";
})(ReactivateJobMode || (ReactivateJobMode = {}));
/** Represents the software update state. */
var UpdaterState;
(function (UpdaterState) {
    UpdaterState[UpdaterState["UpdatesAvailable"] = 0] = "UpdatesAvailable";
    UpdaterState[UpdaterState["NoUpdatesAvailable"] = 1] = "NoUpdatesAvailable";
    UpdaterState[UpdaterState["AlreadyRunning"] = 2] = "AlreadyRunning";
    UpdaterState[UpdaterState["Disabled"] = 3] = "Disabled";
})(UpdaterState || (UpdaterState = {}));
var TypedClient = /** @class */ (function () {
    function TypedClient(client, translationProvider) {
        this.ImxMultilanguageUicultures = new ImxMultilanguageUiculturesWrapper(client, translationProvider);
        this.ImxSysteminfoThirdparty = new ImxSysteminfoThirdpartyWrapper(client, translationProvider);
        this.OpsupportJobservers = new OpsupportJobserversWrapper(client, translationProvider);
        this.OpsupportJournal = new OpsupportJournalWrapper(client, translationProvider);
        this.OpsupportQueueDbqueue = new OpsupportQueueDbqueueWrapper(client, translationProvider);
        this.OpsupportQueueFrozenjobs = new OpsupportQueueFrozenjobsWrapper(client, translationProvider);
        this.OpsupportQueueFrozenjobsbyqueue = new OpsupportQueueFrozenjobsbyqueueWrapper(client, translationProvider);
        this.OpsupportQueueJobaffects = new OpsupportQueueJobaffectsWrapper(client, translationProvider);
        this.OpsupportQueueJobchains = new OpsupportQueueJobchainsWrapper(client, translationProvider);
        this.OpsupportQueueJobperformance = new OpsupportQueueJobperformanceWrapper(client, translationProvider);
        this.OpsupportQueueJobs = new OpsupportQueueJobsWrapper(client, translationProvider);
        this.OpsupportQueueOverview = new OpsupportQueueOverviewWrapper(client, translationProvider);
        this.OpsupportQueueTree = new OpsupportQueueTreeWrapper(client, translationProvider);
        this.OpsupportSearchIndexedtables = new OpsupportSearchIndexedtablesWrapper(client, translationProvider);
        this.OpsupportSystemoverview = new OpsupportSystemoverviewWrapper(client, translationProvider);
        this.OpsupportWebapplications = new OpsupportWebapplicationsWrapper(client, translationProvider);
    }
    return TypedClient;
}());
var ImxMultilanguageUicultures = /** @class */ (function (_super) {
    __extends(ImxMultilanguageUicultures, _super);
    function ImxMultilanguageUicultures() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.Ident_DialogCulture = _this.GetEntityValue('Ident_DialogCulture');
        _this.NativeName = _this.GetEntityValue('NativeName');
        _this.Iso2Name = _this.GetEntityValue('Iso2Name');
        _this.Iso3Name = _this.GetEntityValue('Iso3Name');
        _this.DisplayName = _this.GetEntityValue('DisplayName');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    ImxMultilanguageUicultures.GetEntitySchema = function () {
        var columns = {
            'Ident_DialogCulture': {
                ColumnName: 'Ident_DialogCulture',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'NativeName': {
                ColumnName: 'NativeName',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Iso2Name': {
                ColumnName: 'Iso2Name',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Iso3Name': {
                ColumnName: 'Iso3Name',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'DisplayName': {
                ColumnName: 'DisplayName',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'QBMCulture', Columns: columns };
    };
    return ImxMultilanguageUicultures;
}(TypedEntity));
var ImxSysteminfoThirdparty = /** @class */ (function (_super) {
    __extends(ImxSysteminfoThirdparty, _super);
    function ImxSysteminfoThirdparty() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.ComponentName = _this.GetEntityValue('ComponentName');
        _this.CopyRight = _this.GetEntityValue('CopyRight');
        _this.EmailOrURl = _this.GetEntityValue('EmailOrURl');
        _this.LicenceName = _this.GetEntityValue('LicenceName');
        _this.LicenceText = _this.GetEntityValue('LicenceText');
        _this.UID_QBMV3rdPartyLicence = _this.GetEntityValue('UID_QBMV3rdPartyLicence');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    ImxSysteminfoThirdparty.GetEntitySchema = function () {
        var columns = {
            'ComponentName': {
                ColumnName: 'ComponentName',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'CopyRight': {
                ColumnName: 'CopyRight',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'EmailOrURl': {
                ColumnName: 'EmailOrURl',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'LicenceName': {
                ColumnName: 'LicenceName',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'LicenceText': {
                ColumnName: 'LicenceText',
                Type: ValType.Text,
                IsReadOnly: true,
            },
            'UID_QBMV3rdPartyLicence': {
                ColumnName: 'UID_QBMV3rdPartyLicence',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'QBMV3rdPartyLicence', Columns: columns };
    };
    return ImxSysteminfoThirdparty;
}(TypedEntity));
var OpsupportJobservers = /** @class */ (function (_super) {
    __extends(OpsupportJobservers, _super);
    function OpsupportJobservers() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.Ident_Server = _this.GetEntityValue('Ident_Server');
        _this.IsInSoftwareUpdate = _this.GetEntityValue('IsInSoftwareUpdate');
        _this.IsJobServiceDisabled = _this.GetEntityValue('IsJobServiceDisabled');
        _this.IsNoAutoupdate = _this.GetEntityValue('IsNoAutoupdate');
        _this.QueueName = _this.GetEntityValue('QueueName');
        _this.IPV6 = _this.GetEntityValue('IPV6');
        _this.IPV4 = _this.GetEntityValue('IPV4');
        _this.FQDN = _this.GetEntityValue('FQDN');
        _this.PhysicalServerName = _this.GetEntityValue('PhysicalServerName');
        _this.LastJobFetchTime = _this.GetEntityValue('LastJobFetchTime');
        _this.ServerTags = _this.GetEntityValue('ServerTags');
        _this.ServerWebUrl = _this.GetEntityValue('ServerWebUrl');
        _this.Connection = _this.GetEntityValue('Connection');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    OpsupportJobservers.GetEntitySchema = function () {
        var columns = {
            'Ident_Server': {
                ColumnName: 'Ident_Server',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'IsInSoftwareUpdate': {
                ColumnName: 'IsInSoftwareUpdate',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'IsJobServiceDisabled': {
                ColumnName: 'IsJobServiceDisabled',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'IsNoAutoupdate': {
                ColumnName: 'IsNoAutoupdate',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'QueueName': {
                ColumnName: 'QueueName',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'IPV6': {
                ColumnName: 'IPV6',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'IPV4': {
                ColumnName: 'IPV4',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'FQDN': {
                ColumnName: 'FQDN',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'PhysicalServerName': {
                ColumnName: 'PhysicalServerName',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'LastJobFetchTime': {
                ColumnName: 'LastJobFetchTime',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'ServerTags': {
                ColumnName: 'ServerTags',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'ServerWebUrl': {
                ColumnName: 'ServerWebUrl',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Connection': {
                ColumnName: 'Connection',
                Type: ValType.Long,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'QBMServer', Columns: columns };
    };
    return OpsupportJobservers;
}(TypedEntity));
var OpsupportJournal = /** @class */ (function (_super) {
    __extends(OpsupportJournal, _super);
    function OpsupportJournal() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.MessageString = _this.GetEntityValue('MessageString');
        _this.MessageType = _this.GetEntityValue('MessageType');
        _this.MessageDate = _this.GetEntityValue('MessageDate');
        _this.ApplicationName = _this.GetEntityValue('ApplicationName');
        _this.LogonUser = _this.GetEntityValue('LogonUser');
        _this.HostName = _this.GetEntityValue('HostName');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    OpsupportJournal.GetEntitySchema = function () {
        var columns = {
            'MessageString': {
                ColumnName: 'MessageString',
                Type: ValType.Text,
                IsReadOnly: true,
            },
            'MessageType': {
                ColumnName: 'MessageType',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'MessageDate': {
                ColumnName: 'MessageDate',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'ApplicationName': {
                ColumnName: 'ApplicationName',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'LogonUser': {
                ColumnName: 'LogonUser',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'HostName': {
                ColumnName: 'HostName',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'DialogJournal', Columns: columns };
    };
    return OpsupportJournal;
}(TypedEntity));
var OpsupportQueueDbqueue = /** @class */ (function (_super) {
    __extends(OpsupportQueueDbqueue, _super);
    function OpsupportQueueDbqueue() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_Task = _this.GetEntityValue('UID_Task');
        _this.CountProcessing = _this.GetEntityValue('CountProcessing');
        _this.CountWaiting = _this.GetEntityValue('CountWaiting');
        _this.SortOrder = _this.GetEntityValue('SortOrder');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    OpsupportQueueDbqueue.GetEntitySchema = function () {
        var columns = {
            'UID_Task': {
                ColumnName: 'UID_Task',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'CountProcessing': {
                ColumnName: 'CountProcessing',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'CountWaiting': {
                ColumnName: 'CountWaiting',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'SortOrder': {
                ColumnName: 'SortOrder',
                Type: ValType.Int,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: '', Columns: columns };
    };
    return OpsupportQueueDbqueue;
}(TypedEntity));
var OpsupportQueueFrozenjobs = /** @class */ (function (_super) {
    __extends(OpsupportQueueFrozenjobs, _super);
    function OpsupportQueueFrozenjobs() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.BasisObjectKey = _this.GetEntityValue('BasisObjectKey');
        _this.ComponentAssembly = _this.GetEntityValue('ComponentAssembly');
        _this.ComponentClass = _this.GetEntityValue('ComponentClass');
        _this.DeferOnError = _this.GetEntityValue('DeferOnError');
        _this.ErrorMessages = _this.GetEntityValue('ErrorMessages');
        _this.ErrorNotify = _this.GetEntityValue('ErrorNotify');
        _this.ExecutionType = _this.GetEntityValue('ExecutionType');
        _this.GenProcID = _this.GetEntityValue('GenProcID');
        _this.IgnoreErrors = _this.GetEntityValue('IgnoreErrors');
        _this.IsForHistory = _this.GetEntityValue('IsForHistory');
        _this.IsNoDBQueueDefer = _this.GetEntityValue('IsNoDBQueueDefer');
        _this.IsRootJob = _this.GetEntityValue('IsRootJob');
        _this.IsSplitOnly = _this.GetEntityValue('IsSplitOnly');
        _this.IsToFreezeOnError = _this.GetEntityValue('IsToFreezeOnError');
        _this.JobChainName = _this.GetEntityValue('JobChainName');
        _this.LimitationCount = _this.GetEntityValue('LimitationCount');
        _this.LimitationWarning = _this.GetEntityValue('LimitationWarning');
        _this.LogMode = _this.GetEntityValue('LogMode');
        _this.MaxInstance = _this.GetEntityValue('MaxInstance');
        _this.MinutesToDefer = _this.GetEntityValue('MinutesToDefer');
        _this.NotifyAddress = _this.GetEntityValue('NotifyAddress');
        _this.NotifyAddressSuccess = _this.GetEntityValue('NotifyAddressSuccess');
        _this.NotifyBody = _this.GetEntityValue('NotifyBody');
        _this.NotifyBodySuccess = _this.GetEntityValue('NotifyBodySuccess');
        _this.NotifySender = _this.GetEntityValue('NotifySender');
        _this.NotifySenderSuccess = _this.GetEntityValue('NotifySenderSuccess');
        _this.NotifySubject = _this.GetEntityValue('NotifySubject');
        _this.NotifySubjectSuccess = _this.GetEntityValue('NotifySubjectSuccess');
        _this.ParamIN = _this.GetEntityValue('ParamIN');
        _this.Priority = _this.GetEntityValue('Priority');
        _this.ProcessTracking = _this.GetEntityValue('ProcessTracking');
        _this.Queue = _this.GetEntityValue('Queue');
        _this.Ready2EXE = _this.GetEntityValue('Ready2EXE');
        _this.Retries = _this.GetEntityValue('Retries');
        _this.StartAt = _this.GetEntityValue('StartAt');
        _this.SuccessNotify = _this.GetEntityValue('SuccessNotify');
        _this.TaskName = _this.GetEntityValue('TaskName');
        _this.UID_Job = _this.GetEntityValue('UID_Job');
        _this.UID_JobError = _this.GetEntityValue('UID_JobError');
        _this.UID_JobOrigin = _this.GetEntityValue('UID_JobOrigin');
        _this.UID_JobSameServer = _this.GetEntityValue('UID_JobSameServer');
        _this.UID_JobSuccess = _this.GetEntityValue('UID_JobSuccess');
        _this.UID_Tree = _this.GetEntityValue('UID_Tree');
        _this.WasError = _this.GetEntityValue('WasError');
        _this.XDateInserted = _this.GetEntityValue('XDateInserted');
        _this.XDateUpdated = _this.GetEntityValue('XDateUpdated');
        _this.XTouched = _this.GetEntityValue('XTouched');
        _this.XUserInserted = _this.GetEntityValue('XUserInserted');
        _this.XUserUpdated = _this.GetEntityValue('XUserUpdated');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    OpsupportQueueFrozenjobs.GetEntitySchema = function () {
        var columns = {
            'BasisObjectKey': {
                ColumnName: 'BasisObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'ComponentAssembly': {
                ColumnName: 'ComponentAssembly',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'ComponentClass': {
                ColumnName: 'ComponentClass',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'DeferOnError': {
                ColumnName: 'DeferOnError',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'ErrorMessages': {
                ColumnName: 'ErrorMessages',
                Type: ValType.Text,
                IsReadOnly: true,
            },
            'ErrorNotify': {
                ColumnName: 'ErrorNotify',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'ExecutionType': {
                ColumnName: 'ExecutionType',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'GenProcID': {
                ColumnName: 'GenProcID',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'IgnoreErrors': {
                ColumnName: 'IgnoreErrors',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'IsForHistory': {
                ColumnName: 'IsForHistory',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'IsNoDBQueueDefer': {
                ColumnName: 'IsNoDBQueueDefer',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'IsRootJob': {
                ColumnName: 'IsRootJob',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'IsSplitOnly': {
                ColumnName: 'IsSplitOnly',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'IsToFreezeOnError': {
                ColumnName: 'IsToFreezeOnError',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'JobChainName': {
                ColumnName: 'JobChainName',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'LimitationCount': {
                ColumnName: 'LimitationCount',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'LimitationWarning': {
                ColumnName: 'LimitationWarning',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'LogMode': {
                ColumnName: 'LogMode',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'MaxInstance': {
                ColumnName: 'MaxInstance',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'MinutesToDefer': {
                ColumnName: 'MinutesToDefer',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'NotifyAddress': {
                ColumnName: 'NotifyAddress',
                Type: ValType.Text,
                IsReadOnly: true,
            },
            'NotifyAddressSuccess': {
                ColumnName: 'NotifyAddressSuccess',
                Type: ValType.Text,
                IsReadOnly: true,
            },
            'NotifyBody': {
                ColumnName: 'NotifyBody',
                Type: ValType.Text,
                IsReadOnly: true,
            },
            'NotifyBodySuccess': {
                ColumnName: 'NotifyBodySuccess',
                Type: ValType.Text,
                IsReadOnly: true,
            },
            'NotifySender': {
                ColumnName: 'NotifySender',
                Type: ValType.Text,
                IsReadOnly: true,
            },
            'NotifySenderSuccess': {
                ColumnName: 'NotifySenderSuccess',
                Type: ValType.Text,
                IsReadOnly: true,
            },
            'NotifySubject': {
                ColumnName: 'NotifySubject',
                Type: ValType.Text,
                IsReadOnly: true,
            },
            'NotifySubjectSuccess': {
                ColumnName: 'NotifySubjectSuccess',
                Type: ValType.Text,
                IsReadOnly: true,
            },
            'ParamIN': {
                ColumnName: 'ParamIN',
                Type: ValType.Text,
                IsReadOnly: true,
            },
            'Priority': {
                ColumnName: 'Priority',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'ProcessTracking': {
                ColumnName: 'ProcessTracking',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'Queue': {
                ColumnName: 'Queue',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Ready2EXE': {
                ColumnName: 'Ready2EXE',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Retries': {
                ColumnName: 'Retries',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'StartAt': {
                ColumnName: 'StartAt',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'SuccessNotify': {
                ColumnName: 'SuccessNotify',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'TaskName': {
                ColumnName: 'TaskName',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_Job': {
                ColumnName: 'UID_Job',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_JobError': {
                ColumnName: 'UID_JobError',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_JobOrigin': {
                ColumnName: 'UID_JobOrigin',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_JobSameServer': {
                ColumnName: 'UID_JobSameServer',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_JobSuccess': {
                ColumnName: 'UID_JobSuccess',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_Tree': {
                ColumnName: 'UID_Tree',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'WasError': {
                ColumnName: 'WasError',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'XDateInserted': {
                ColumnName: 'XDateInserted',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'XDateUpdated': {
                ColumnName: 'XDateUpdated',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'XTouched': {
                ColumnName: 'XTouched',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XUserInserted': {
                ColumnName: 'XUserInserted',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XUserUpdated': {
                ColumnName: 'XUserUpdated',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'JobQueue', Columns: columns };
    };
    return OpsupportQueueFrozenjobs;
}(TypedEntity));
var OpsupportQueueFrozenjobsbyqueue = /** @class */ (function (_super) {
    __extends(OpsupportQueueFrozenjobsbyqueue, _super);
    function OpsupportQueueFrozenjobsbyqueue() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.QueueName = _this.GetEntityValue('QueueName');
        _this.Count = _this.GetEntityValue('Count');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    OpsupportQueueFrozenjobsbyqueue.GetEntitySchema = function () {
        var columns = {
            'QueueName': {
                ColumnName: 'QueueName',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Count': {
                ColumnName: 'Count',
                Type: ValType.Int,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: '', Columns: columns };
    };
    return OpsupportQueueFrozenjobsbyqueue;
}(TypedEntity));
var OpsupportQueueJobaffects = /** @class */ (function (_super) {
    __extends(OpsupportQueueJobaffects, _super);
    function OpsupportQueueJobaffects() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.ObjectKeyAffected = _this.GetEntityValue('ObjectKeyAffected');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    OpsupportQueueJobaffects.GetEntitySchema = function () {
        var columns = {
            'ObjectKeyAffected': {
                ColumnName: 'ObjectKeyAffected',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'QBMElementAffectedByJob', Columns: columns };
    };
    return OpsupportQueueJobaffects;
}(TypedEntity));
var OpsupportQueueJobchains = /** @class */ (function (_super) {
    __extends(OpsupportQueueJobchains, _super);
    function OpsupportQueueJobchains() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.JobChainName = _this.GetEntityValue('JobChainName');
        _this.Count = _this.GetEntityValue('Count');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    OpsupportQueueJobchains.GetEntitySchema = function () {
        var columns = {
            'JobChainName': {
                ColumnName: 'JobChainName',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Count': {
                ColumnName: 'Count',
                Type: ValType.Int,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: '', Columns: columns };
    };
    return OpsupportQueueJobchains;
}(TypedEntity));
var OpsupportQueueJobperformance = /** @class */ (function (_super) {
    __extends(OpsupportQueueJobperformance, _super);
    function OpsupportQueueJobperformance() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.Queue = _this.GetEntityValue('Queue');
        _this.ComponentClass = _this.GetEntityValue('ComponentClass');
        _this.TaskName = _this.GetEntityValue('TaskName');
        _this.CountPerMinute = _this.GetEntityValue('CountPerMinute');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    OpsupportQueueJobperformance.GetEntitySchema = function () {
        var columns = {
            'Queue': {
                ColumnName: 'Queue',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'ComponentClass': {
                ColumnName: 'ComponentClass',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'TaskName': {
                ColumnName: 'TaskName',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'CountPerMinute': {
                ColumnName: 'CountPerMinute',
                Type: ValType.Int,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'JobPerformance', Columns: columns };
    };
    return OpsupportQueueJobperformance;
}(TypedEntity));
var OpsupportQueueJobs = /** @class */ (function (_super) {
    __extends(OpsupportQueueJobs, _super);
    function OpsupportQueueJobs() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.JobChainName = _this.GetEntityValue('JobChainName');
        _this.UID_JobOrigin = _this.GetEntityValue('UID_JobOrigin');
        _this.Ready2EXE = _this.GetEntityValue('Ready2EXE');
        _this.TaskName = _this.GetEntityValue('TaskName');
        _this.UID_Tree = _this.GetEntityValue('UID_Tree');
        _this.UID_Job = _this.GetEntityValue('UID_Job');
        _this.Queue = _this.GetEntityValue('Queue');
        _this.Retries = _this.GetEntityValue('Retries');
        _this.IsRootJob = _this.GetEntityValue('IsRootJob');
        _this.UID_JobSuccess = _this.GetEntityValue('UID_JobSuccess');
        _this.UID_JobError = _this.GetEntityValue('UID_JobError');
        _this.XDateInserted = _this.GetEntityValue('XDateInserted');
        _this.JobChainDescription = _this.GetEntityValue('JobChainDescription');
        _this.JobName = _this.GetEntityValue('JobName');
        _this.CombinedStatus = _this.GetEntityValue('CombinedStatus');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    OpsupportQueueJobs.GetEntitySchema = function () {
        var columns = {
            'JobChainName': {
                ColumnName: 'JobChainName',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_JobOrigin': {
                ColumnName: 'UID_JobOrigin',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Ready2EXE': {
                ColumnName: 'Ready2EXE',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'TaskName': {
                ColumnName: 'TaskName',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_Tree': {
                ColumnName: 'UID_Tree',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_Job': {
                ColumnName: 'UID_Job',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Queue': {
                ColumnName: 'Queue',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Retries': {
                ColumnName: 'Retries',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'IsRootJob': {
                ColumnName: 'IsRootJob',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'UID_JobSuccess': {
                ColumnName: 'UID_JobSuccess',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_JobError': {
                ColumnName: 'UID_JobError',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XDateInserted': {
                ColumnName: 'XDateInserted',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'JobChainDescription': {
                ColumnName: 'JobChainDescription',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'JobName': {
                ColumnName: 'JobName',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'CombinedStatus': {
                ColumnName: 'CombinedStatus',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'JobQueue', Columns: columns };
    };
    return OpsupportQueueJobs;
}(TypedEntity));
var OpsupportQueueOverview = /** @class */ (function (_super) {
    __extends(OpsupportQueueOverview, _super);
    function OpsupportQueueOverview() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.CountDelete = _this.GetEntityValue('CountDelete');
        _this.CountFalse = _this.GetEntityValue('CountFalse');
        _this.CountFinished = _this.GetEntityValue('CountFinished');
        _this.CountFrozen = _this.GetEntityValue('CountFrozen');
        _this.CountHistory = _this.GetEntityValue('CountHistory');
        _this.CountLoaded = _this.GetEntityValue('CountLoaded');
        _this.CountMissing = _this.GetEntityValue('CountMissing');
        _this.CountOverlimt = _this.GetEntityValue('CountOverlimt');
        _this.CountProcessing = _this.GetEntityValue('CountProcessing');
        _this.CountTrue = _this.GetEntityValue('CountTrue');
        _this.IsInitQueueRunning = _this.GetEntityValue('IsInitQueueRunning');
        _this.IsInvalid = _this.GetEntityValue('IsInvalid');
        _this.QueueName = _this.GetEntityValue('QueueName');
        _this.UID_QBMJobqueueOverview = _this.GetEntityValue('UID_QBMJobqueueOverview');
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    OpsupportQueueOverview.GetEntitySchema = function () {
        var columns = {
            'CountDelete': {
                ColumnName: 'CountDelete',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'CountFalse': {
                ColumnName: 'CountFalse',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'CountFinished': {
                ColumnName: 'CountFinished',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'CountFrozen': {
                ColumnName: 'CountFrozen',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'CountHistory': {
                ColumnName: 'CountHistory',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'CountLoaded': {
                ColumnName: 'CountLoaded',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'CountMissing': {
                ColumnName: 'CountMissing',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'CountOverlimt': {
                ColumnName: 'CountOverlimt',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'CountProcessing': {
                ColumnName: 'CountProcessing',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'CountTrue': {
                ColumnName: 'CountTrue',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'IsInitQueueRunning': {
                ColumnName: 'IsInitQueueRunning',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'IsInvalid': {
                ColumnName: 'IsInvalid',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'QueueName': {
                ColumnName: 'QueueName',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_QBMJobqueueOverview': {
                ColumnName: 'UID_QBMJobqueueOverview',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'QBMJobqueueOverview', Columns: columns };
    };
    return OpsupportQueueOverview;
}(TypedEntity));
var OpsupportQueueTree = /** @class */ (function (_super) {
    __extends(OpsupportQueueTree, _super);
    function OpsupportQueueTree() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_Job = _this.GetEntityValue('UID_Job');
        _this.BasisObjectKey = _this.GetEntityValue('BasisObjectKey');
        _this.DeferOnError = _this.GetEntityValue('DeferOnError');
        _this.ErrorMessages = _this.GetEntityValue('ErrorMessages');
        _this.GenProcID = _this.GetEntityValue('GenProcID');
        _this.IsRootJob = _this.GetEntityValue('IsRootJob');
        _this.JobChainName = _this.GetEntityValue('JobChainName');
        _this.LimitationCount = _this.GetEntityValue('LimitationCount');
        _this.Retries = _this.GetEntityValue('Retries');
        _this.Queue = _this.GetEntityValue('Queue');
        _this.Ready2EXE = _this.GetEntityValue('Ready2EXE');
        _this.TaskName = _this.GetEntityValue('TaskName');
        _this.UID_JobError = _this.GetEntityValue('UID_JobError');
        _this.UID_JobOrigin = _this.GetEntityValue('UID_JobOrigin');
        _this.UID_JobSameServer = _this.GetEntityValue('UID_JobSameServer');
        _this.UID_JobSuccess = _this.GetEntityValue('UID_JobSuccess');
        _this.UID_Tree = _this.GetEntityValue('UID_Tree');
        _this.XDateInserted = _this.GetEntityValue('XDateInserted');
        _this.XDateUpdated = _this.GetEntityValue('XDateUpdated');
        _this.XUserInserted = _this.GetEntityValue('XUserInserted');
        _this.XUserUpdated = _this.GetEntityValue('XUserUpdated');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    OpsupportQueueTree.GetEntitySchema = function () {
        var columns = {
            'UID_Job': {
                ColumnName: 'UID_Job',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'BasisObjectKey': {
                ColumnName: 'BasisObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'DeferOnError': {
                ColumnName: 'DeferOnError',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'ErrorMessages': {
                ColumnName: 'ErrorMessages',
                Type: ValType.Text,
                IsReadOnly: true,
            },
            'GenProcID': {
                ColumnName: 'GenProcID',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'IsRootJob': {
                ColumnName: 'IsRootJob',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'JobChainName': {
                ColumnName: 'JobChainName',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'LimitationCount': {
                ColumnName: 'LimitationCount',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'Retries': {
                ColumnName: 'Retries',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'Queue': {
                ColumnName: 'Queue',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Ready2EXE': {
                ColumnName: 'Ready2EXE',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'TaskName': {
                ColumnName: 'TaskName',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_JobError': {
                ColumnName: 'UID_JobError',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_JobOrigin': {
                ColumnName: 'UID_JobOrigin',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_JobSameServer': {
                ColumnName: 'UID_JobSameServer',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_JobSuccess': {
                ColumnName: 'UID_JobSuccess',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_Tree': {
                ColumnName: 'UID_Tree',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XDateInserted': {
                ColumnName: 'XDateInserted',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'XDateUpdated': {
                ColumnName: 'XDateUpdated',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'XUserInserted': {
                ColumnName: 'XUserInserted',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XUserUpdated': {
                ColumnName: 'XUserUpdated',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: '', Columns: columns };
    };
    return OpsupportQueueTree;
}(TypedEntity));
var OpsupportSearchIndexedtables = /** @class */ (function (_super) {
    __extends(OpsupportSearchIndexedtables, _super);
    function OpsupportSearchIndexedtables() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.TableName = _this.GetEntityValue('TableName');
        _this.DisplayName = _this.GetEntityValue('DisplayName');
        _this.DisplayNameSingular = _this.GetEntityValue('DisplayNameSingular');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    OpsupportSearchIndexedtables.GetEntitySchema = function () {
        var columns = {
            'TableName': {
                ColumnName: 'TableName',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'DisplayName': {
                ColumnName: 'DisplayName',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'DisplayNameSingular': {
                ColumnName: 'DisplayNameSingular',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'DialogTable', Columns: columns };
    };
    return OpsupportSearchIndexedtables;
}(TypedEntity));
var OpsupportSystemoverview = /** @class */ (function (_super) {
    __extends(OpsupportSystemoverview, _super);
    function OpsupportSystemoverview() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.Category = _this.GetEntityValue('Category');
        _this.Element = _this.GetEntityValue('Element');
        _this.QualityOfValue = _this.GetEntityValue('QualityOfValue');
        _this.RecommendedValue = _this.GetEntityValue('RecommendedValue');
        _this.SortOrder = _this.GetEntityValue('SortOrder');
        _this.SubElement = _this.GetEntityValue('SubElement');
        _this.UID_QBMVSystemOverview = _this.GetEntityValue('UID_QBMVSystemOverview');
        _this.Value = _this.GetEntityValue('Value');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    OpsupportSystemoverview.GetEntitySchema = function () {
        var columns = {
            'Category': {
                ColumnName: 'Category',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Element': {
                ColumnName: 'Element',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'QualityOfValue': {
                ColumnName: 'QualityOfValue',
                Type: ValType.Double,
                IsReadOnly: true,
            },
            'RecommendedValue': {
                ColumnName: 'RecommendedValue',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'SortOrder': {
                ColumnName: 'SortOrder',
                Type: ValType.Long,
                IsReadOnly: true,
            },
            'SubElement': {
                ColumnName: 'SubElement',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_QBMVSystemOverview': {
                ColumnName: 'UID_QBMVSystemOverview',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Value': {
                ColumnName: 'Value',
                Type: ValType.Text,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'QBMVSystemOverview', Columns: columns };
    };
    return OpsupportSystemoverview;
}(TypedEntity));
var OpsupportWebapplications = /** @class */ (function (_super) {
    __extends(OpsupportWebapplications, _super);
    function OpsupportWebapplications() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.BaseURL = _this.GetEntityValue('BaseURL');
        _this.AutoUpdateLevel = _this.GetEntityValue('AutoUpdateLevel');
        _this.UID_DialogProduct = _this.GetEntityValue('UID_DialogProduct');
        _this.IsDebug = _this.GetEntityValue('IsDebug');
        _this.IsPrivate = _this.GetEntityValue('IsPrivate');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    OpsupportWebapplications.GetEntitySchema = function () {
        var columns = {
            'BaseURL': {
                ColumnName: 'BaseURL',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'AutoUpdateLevel': {
                ColumnName: 'AutoUpdateLevel',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'UID_DialogProduct': {
                ColumnName: 'UID_DialogProduct',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'IsDebug': {
                ColumnName: 'IsDebug',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'IsPrivate': {
                ColumnName: 'IsPrivate',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'QBMWebApplication', Columns: columns };
    };
    return OpsupportWebapplications;
}(TypedEntity));
var ImxMultilanguageUiculturesWrapper = /** @class */ (function () {
    function ImxMultilanguageUiculturesWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    ImxMultilanguageUiculturesWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('imx/multilanguage/uicultures');
    };
    ImxMultilanguageUiculturesWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('imx/multilanguage/uicultures');
            this.builder = new TypedEntityBuilder(ImxMultilanguageUicultures, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    ImxMultilanguageUiculturesWrapper.prototype.Get = function (parametersOptional) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.imx_multilanguage_uicultures_get(parametersOptional)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return ImxMultilanguageUiculturesWrapper;
}());
var ImxSysteminfoThirdpartyWrapper = /** @class */ (function () {
    function ImxSysteminfoThirdpartyWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    ImxSysteminfoThirdpartyWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('imx/systeminfo/thirdparty');
    };
    ImxSysteminfoThirdpartyWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('imx/systeminfo/thirdparty');
            this.builder = new TypedEntityBuilder(ImxSysteminfoThirdparty, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    ImxSysteminfoThirdpartyWrapper.prototype.Get = function (parametersOptional) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.imx_systeminfo_thirdparty_get(parametersOptional)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return ImxSysteminfoThirdpartyWrapper;
}());
var OpsupportJobserversWrapper = /** @class */ (function () {
    function OpsupportJobserversWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    OpsupportJobserversWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('opsupport/jobservers');
    };
    OpsupportJobserversWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('opsupport/jobservers');
            this.builder = new TypedEntityBuilder(OpsupportJobservers, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    OpsupportJobserversWrapper.prototype.Get = function (parametersOptional) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.opsupport_jobservers_get(parametersOptional)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return OpsupportJobserversWrapper;
}());
var OpsupportJournalWrapper = /** @class */ (function () {
    function OpsupportJournalWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    OpsupportJournalWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('opsupport/journal');
    };
    OpsupportJournalWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('opsupport/journal');
            this.builder = new TypedEntityBuilder(OpsupportJournal, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    OpsupportJournalWrapper.prototype.Get = function (parametersOptional) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.opsupport_journal_get(parametersOptional)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return OpsupportJournalWrapper;
}());
var OpsupportQueueDbqueueWrapper = /** @class */ (function () {
    function OpsupportQueueDbqueueWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    OpsupportQueueDbqueueWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('opsupport/queue/dbqueue');
    };
    OpsupportQueueDbqueueWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('opsupport/queue/dbqueue');
            this.builder = new TypedEntityBuilder(OpsupportQueueDbqueue, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    OpsupportQueueDbqueueWrapper.prototype.Get = function () {
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.opsupport_queue_dbqueue_get()];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return OpsupportQueueDbqueueWrapper;
}());
var OpsupportQueueFrozenjobsWrapper = /** @class */ (function () {
    function OpsupportQueueFrozenjobsWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    OpsupportQueueFrozenjobsWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('opsupport/queue/frozenjobs');
    };
    OpsupportQueueFrozenjobsWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('opsupport/queue/frozenjobs');
            this.builder = new TypedEntityBuilder(OpsupportQueueFrozenjobs, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    OpsupportQueueFrozenjobsWrapper.prototype.Get = function (parametersOptional) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.opsupport_queue_frozenjobs_get(parametersOptional)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return OpsupportQueueFrozenjobsWrapper;
}());
var OpsupportQueueFrozenjobsbyqueueWrapper = /** @class */ (function () {
    function OpsupportQueueFrozenjobsbyqueueWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    OpsupportQueueFrozenjobsbyqueueWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('opsupport/queue/frozenjobsbyqueue');
    };
    OpsupportQueueFrozenjobsbyqueueWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('opsupport/queue/frozenjobsbyqueue');
            this.builder = new TypedEntityBuilder(OpsupportQueueFrozenjobsbyqueue, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    OpsupportQueueFrozenjobsbyqueueWrapper.prototype.Get = function () {
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.opsupport_queue_frozenjobsbyqueue_get()];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return OpsupportQueueFrozenjobsbyqueueWrapper;
}());
var OpsupportQueueJobaffectsWrapper = /** @class */ (function () {
    function OpsupportQueueJobaffectsWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    OpsupportQueueJobaffectsWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('opsupport/queue/jobaffects/{uidjob}');
    };
    OpsupportQueueJobaffectsWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('opsupport/queue/jobaffects/{uidjob}');
            this.builder = new TypedEntityBuilder(OpsupportQueueJobaffects, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    OpsupportQueueJobaffectsWrapper.prototype.Get = function (uidjob, parametersOptional) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.opsupport_queue_jobaffects_get(uidjob, parametersOptional)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return OpsupportQueueJobaffectsWrapper;
}());
var OpsupportQueueJobchainsWrapper = /** @class */ (function () {
    function OpsupportQueueJobchainsWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    OpsupportQueueJobchainsWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('opsupport/queue/jobchains');
    };
    OpsupportQueueJobchainsWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('opsupport/queue/jobchains');
            this.builder = new TypedEntityBuilder(OpsupportQueueJobchains, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    OpsupportQueueJobchainsWrapper.prototype.Get = function () {
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.opsupport_queue_jobchains_get()];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return OpsupportQueueJobchainsWrapper;
}());
var OpsupportQueueJobperformanceWrapper = /** @class */ (function () {
    function OpsupportQueueJobperformanceWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    OpsupportQueueJobperformanceWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('opsupport/queue/jobperformance');
    };
    OpsupportQueueJobperformanceWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('opsupport/queue/jobperformance');
            this.builder = new TypedEntityBuilder(OpsupportQueueJobperformance, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    OpsupportQueueJobperformanceWrapper.prototype.Get = function (parametersOptional) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.opsupport_queue_jobperformance_get(parametersOptional)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return OpsupportQueueJobperformanceWrapper;
}());
var OpsupportQueueJobsWrapper = /** @class */ (function () {
    function OpsupportQueueJobsWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    OpsupportQueueJobsWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('opsupport/queue/jobs');
    };
    OpsupportQueueJobsWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('opsupport/queue/jobs');
            this.builder = new TypedEntityBuilder(OpsupportQueueJobs, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    OpsupportQueueJobsWrapper.prototype.Get = function (parametersOptional) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.opsupport_queue_jobs_get(parametersOptional)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return OpsupportQueueJobsWrapper;
}());
var OpsupportQueueOverviewWrapper = /** @class */ (function () {
    function OpsupportQueueOverviewWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    OpsupportQueueOverviewWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('opsupport/queue/overview');
    };
    OpsupportQueueOverviewWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('opsupport/queue/overview');
            this.builder = new TypedEntityBuilder(OpsupportQueueOverview, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    OpsupportQueueOverviewWrapper.prototype.Get = function (parametersOptional) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.opsupport_queue_overview_get(parametersOptional)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return OpsupportQueueOverviewWrapper;
}());
var OpsupportQueueTreeWrapper = /** @class */ (function () {
    function OpsupportQueueTreeWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    OpsupportQueueTreeWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('opsupport/queue/tree');
    };
    OpsupportQueueTreeWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('opsupport/queue/tree');
            this.builder = new TypedEntityBuilder(OpsupportQueueTree, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    OpsupportQueueTreeWrapper.prototype.Get = function (parametersOptional) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.opsupport_queue_tree_get(parametersOptional)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return OpsupportQueueTreeWrapper;
}());
var OpsupportSearchIndexedtablesWrapper = /** @class */ (function () {
    function OpsupportSearchIndexedtablesWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    OpsupportSearchIndexedtablesWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('opsupport/search/indexedtables');
    };
    OpsupportSearchIndexedtablesWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('opsupport/search/indexedtables');
            this.builder = new TypedEntityBuilder(OpsupportSearchIndexedtables, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    OpsupportSearchIndexedtablesWrapper.prototype.Get = function (parametersOptional) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.opsupport_search_indexedtables_get(parametersOptional)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return OpsupportSearchIndexedtablesWrapper;
}());
var OpsupportSystemoverviewWrapper = /** @class */ (function () {
    function OpsupportSystemoverviewWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    OpsupportSystemoverviewWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('opsupport/systemoverview');
    };
    OpsupportSystemoverviewWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('opsupport/systemoverview');
            this.builder = new TypedEntityBuilder(OpsupportSystemoverview, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    OpsupportSystemoverviewWrapper.prototype.Get = function (parametersOptional) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.opsupport_systemoverview_get(parametersOptional)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return OpsupportSystemoverviewWrapper;
}());
var OpsupportWebapplicationsWrapper = /** @class */ (function () {
    function OpsupportWebapplicationsWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    OpsupportWebapplicationsWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('opsupport/webapplications');
    };
    OpsupportWebapplicationsWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('opsupport/webapplications');
            this.builder = new TypedEntityBuilder(OpsupportWebapplications, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    OpsupportWebapplicationsWrapper.prototype.Get = function (parametersOptional) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.opsupport_webapplications_get(parametersOptional)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return OpsupportWebapplicationsWrapper;
}());
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
var ApiClientMethodFactory = /** @class */ (function () {
    function ApiClientMethodFactory() {
    }
    ApiClientMethodFactory.prototype.admin_apiconfig_get = function (appId) {
        return {
            path: '/admin/apiconfig/{appId}',
            parameters: [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.admin_apiconfig_post = function (appId, global, inputParameterName) {
        return {
            path: '/admin/apiconfig/{appId}',
            parameters: [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'global',
                    value: global,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.admin_apiconfigsingle_get = function (appId, path) {
        return {
            path: '/admin/apiconfig/{appId}/{path}',
            parameters: [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'path',
                    value: path,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.admin_apiconfigsingle_post = function (appId, path) {
        return {
            path: '/admin/apiconfig/{appId}/{path}',
            parameters: [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'path',
                    value: path,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.admin_apiconfig_convert_post = function (appId) {
        return {
            path: '/admin/apiconfig/convert/{appId}',
            parameters: [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.admin_apiconfig_revert_post = function (appId, global) {
        return {
            path: '/admin/apiconfig/revert/{appId}',
            parameters: [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'global',
                    value: global,
                    in: 'query'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.admin_apiconfig_values_get = function (appId, path) {
        return {
            path: '/admin/apiconfig/values/{appId}/{path}',
            parameters: [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'path',
                    value: path,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.admin_cache_get = function (appId) {
        return {
            path: '/admin/cache/{appId}',
            parameters: [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.admin_cache_post = function (appId, flush, disable) {
        return {
            path: '/admin/cache/{appId}',
            parameters: [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'flush',
                    value: flush,
                    in: 'query'
                },
                {
                    name: 'disable',
                    value: disable,
                    in: 'query'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.admin_cachebyid_get = function (appId, cacheid) {
        return {
            path: '/admin/cache/{appId}/{cacheid}',
            parameters: [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'cacheid',
                    value: cacheid,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.admin_cachebyid_post = function (appId, cacheid, flush, disable) {
        return {
            path: '/admin/cache/{appId}/{cacheid}',
            parameters: [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'cacheid',
                    value: cacheid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'flush',
                    value: flush,
                    in: 'query'
                },
                {
                    name: 'disable',
                    value: disable,
                    in: 'query'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.admin_config_get = function () {
        return {
            path: '/admin/config',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.admin_config_post = function (inputParameterName) {
        return {
            path: '/admin/config',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.admin_packages_get = function () {
        return {
            path: '/admin/packages',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.admin_performance_get = function () {
        return {
            path: '/admin/performance',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.admin_projects_get = function () {
        return {
            path: '/admin/projects',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.admin_status_get = function () {
        return {
            path: '/admin/status',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.admin_systeminfo_log_get = function (dir, file) {
        return {
            path: '/admin/systeminfo/log/{dir}/{file}',
            parameters: [
                {
                    name: 'dir',
                    value: dir,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'file',
                    value: file,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.admin_systeminfo_logs_get = function () {
        return {
            path: '/admin/systeminfo/logs',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.admin_systeminfo_plugins_get = function () {
        return {
            path: '/admin/systeminfo/plugins',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.admin_systeminfo_software_status_get = function () {
        return {
            path: '/admin/systeminfo/software/status',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.admin_systeminfo_software_update_post = function () {
        return {
            path: '/admin/systeminfo/software/update',
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.imx_activeverbs_get = function (appId) {
        return {
            path: '/imx/activeverbs/{appId}',
            parameters: [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.imx_applications_get = function () {
        return {
            path: '/imx/applications',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.imx_config_get = function () {
        return {
            path: '/imx/config',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.imx_entityschema_get = function () {
        return {
            path: '/imx/entityschema',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.imx_login_post = function (appId, noxsrf, inputParameterName) {
        return {
            path: '/imx/login/{appId}',
            parameters: [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'noxsrf',
                    value: noxsrf,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.imx_logout_post = function (appId) {
        return {
            path: '/imx/logout/{appId}',
            parameters: [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.imx_metadata_table_get = function (tableName, cultureName) {
        return {
            path: '/imx/metadata/table/{tableName}',
            parameters: [
                {
                    name: 'tableName',
                    value: tableName,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'cultureName',
                    value: cultureName,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.imx_modelcss_get = function () {
        return {
            path: '/imx/modelcss',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.imx_modelimage_get = function (key, size) {
        return {
            path: '/imx/modelimage/{key}',
            parameters: [
                {
                    name: 'key',
                    value: key,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'size',
                    value: size,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.imx_multilanguage_getcaptions_get = function (cultureName) {
        return {
            path: '/imx/multilanguage/getcaptions',
            parameters: [
                {
                    name: 'cultureName',
                    value: cultureName,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.imx_multilanguage_translations_get = function (cultureName, appId) {
        return {
            path: '/imx/multilanguage/translations/{appId}',
            parameters: [
                {
                    name: 'cultureName',
                    value: cultureName,
                    in: 'query'
                },
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.imx_multilanguage_uicultures_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/imx/multilanguage/uicultures',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.imx_oauth_get = function (authentifier, appId, redirecturi) {
        return {
            path: '/imx/oauth/{appId}/{authentifier}',
            parameters: [
                {
                    name: 'authentifier',
                    value: authentifier,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'redirecturi',
                    value: redirecturi,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.imx_ping_get = function () {
        return {
            path: '/imx/ping',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.imx_sessions_get = function (appId) {
        return {
            path: '/imx/sessions/{appId}',
            parameters: [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.imx_system_get = function () {
        return {
            path: '/imx/system',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.imx_systeminfo_thirdparty_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/imx/systeminfo/thirdparty',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_assignment_get = function (tableName, uid) {
        return {
            path: '/opsupport/assignment/{tableName}/{uid}',
            parameters: [
                {
                    name: 'tableName',
                    value: tableName,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_config_get = function () {
        return {
            path: '/opsupport/config',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_dbobject_get = function (tableName, uid) {
        return {
            path: '/opsupport/dbobject/{tableName}/{uid}',
            parameters: [
                {
                    name: 'tableName',
                    value: tableName,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_history_get = function (table, uid) {
        return {
            path: '/opsupport/history/{table}/{uid}',
            parameters: [
                {
                    name: 'table',
                    value: table,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_history_comparison_get = function (table, uid, CompareDate) {
        return {
            path: '/opsupport/history/{table}/{uid}/comparison',
            parameters: [
                {
                    name: 'table',
                    value: table,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'CompareDate',
                    value: CompareDate,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_hyperview_get = function (table, uid) {
        return {
            path: '/opsupport/hyperview/{table}/{uid}',
            parameters: [
                {
                    name: 'table',
                    value: table,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_jobserver_get = function (server) {
        return {
            path: '/opsupport/jobserver/{server}',
            parameters: [
                {
                    name: 'server',
                    value: server,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_jobservers_get = function (withconnection, nofetchjob, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
        return {
            path: '/opsupport/jobservers',
            parameters: [
                {
                    name: 'withconnection',
                    value: withconnection,
                    in: 'query'
                },
                {
                    name: 'nofetchjob',
                    value: nofetchjob,
                    in: 'query'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_journal_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, messagetype) {
        return {
            path: '/opsupport/journal',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'messagetype',
                    value: messagetype,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_journal_datamodel_get = function (filter) {
        return {
            path: '/opsupport/journal/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_journal_stat_get = function () {
        return {
            path: '/opsupport/journal/stat',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_queue_dbqueue_get = function () {
        return {
            path: '/opsupport/queue/dbqueue',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_queue_frozenjobs_get = function (queue, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/opsupport/queue/frozenjobs',
            parameters: [
                {
                    name: 'queue',
                    value: queue,
                    in: 'query'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_queue_frozenjobsbyqueue_get = function () {
        return {
            path: '/opsupport/queue/frozenjobsbyqueue',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_queue_jobaffects_get = function (uidjob, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/opsupport/queue/jobaffects/{uidjob}',
            parameters: [
                {
                    name: 'uidjob',
                    value: uidjob,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_queue_jobchains_get = function () {
        return {
            path: '/opsupport/queue/jobchains',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_queue_jobperformance_get = function (queue, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/opsupport/queue/jobperformance',
            parameters: [
                {
                    name: 'queue',
                    value: queue,
                    in: 'query'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_queue_jobperformancequeues_get = function () {
        return {
            path: '/opsupport/queue/jobperformancequeues',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_queue_jobs_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, state, queue) {
        return {
            path: '/opsupport/queue/jobs',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'state',
                    value: state,
                    in: 'query'
                },
                {
                    name: 'queue',
                    value: queue,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_queue_jobs_datamodel_get = function (filter) {
        return {
            path: '/opsupport/queue/jobs/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_queue_object_get = function (table, uid) {
        return {
            path: '/opsupport/queue/object/{table}/{uid}',
            parameters: [
                {
                    name: 'table',
                    value: table,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_queue_overview_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/opsupport/queue/overview',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_queue_overview_stream_get = function () {
        return {
            path: '/opsupport/queue/overview/stream',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_queue_reactivatejob_post = function (inputParameterName) {
        return {
            path: '/opsupport/queue/reactivatejob',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_queue_tree_get = function (uidtree) {
        return {
            path: '/opsupport/queue/tree',
            parameters: [
                {
                    name: 'uidtree',
                    value: uidtree,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_search_get = function (term, tables) {
        return {
            path: '/opsupport/search',
            parameters: [
                {
                    name: 'term',
                    value: term,
                    in: 'query'
                },
                {
                    name: 'tables',
                    value: tables,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_search_indexedtables_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/opsupport/search/indexedtables',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_streamconfig_get = function () {
        return {
            path: '/opsupport/streamconfig',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_systemoverview_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/opsupport/systemoverview',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_systemstatus_get = function () {
        return {
            path: '/opsupport/systemstatus',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_systemstatus_post = function (IsDbSchedulerDisabled, IsJobServiceDisabled, inputParameterName) {
        return {
            path: '/opsupport/systemstatus',
            parameters: [
                {
                    name: 'IsDbSchedulerDisabled',
                    value: IsDbSchedulerDisabled,
                    in: 'query'
                },
                {
                    name: 'IsJobServiceDisabled',
                    value: IsJobServiceDisabled,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_usergroups_get = function () {
        return {
            path: '/opsupport/usergroups',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.opsupport_webapplications_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/opsupport/webapplications',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    return ApiClientMethodFactory;
}());
/** @deprecated Use the V2Client class for a stable method interface. */
var Client = /** @class */ (function () {
    function Client(apiClient, schemaProvider) {
        this.apiClient = apiClient;
        this.schemaProvider = schemaProvider;
        this.methodFactory = new ApiClientMethodFactory();
        if (!apiClient) {
            throw new Error("The value for the apiClient parameter is undefined.");
        }
    }
    Object.defineProperty(Client.prototype, "schemas", {
        get: function () {
            if (!this.schemaProvider) {
                throw new Error("The schema has not been loaded.");
            }
            return this.schemaProvider.schemas;
        },
        enumerable: false,
        configurable: true
    });
    Client.prototype.loadSchema = function (language) {
        return __awaiter(this, void 0, void 0, function () {
            var headers, dtos, schemas, key, dto, columns;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        headers = {};
                        if (language)
                            headers['Accept-Language'] = language;
                        return [4 /*yield*/, this.apiClient.processRequest({
                                path: '/imx/entityschema',
                                parameters: [],
                                method: 'GET',
                                headers: headers,
                                credentials: 'include',
                                observe: 'response',
                                responseType: 'json'
                            })];
                    case 1:
                        dtos = _a.sent();
                        schemas = {};
                        for (key in dtos) {
                            dto = dtos[key];
                            columns = dto.Properties;
                            columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
                            columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
                            schemas[key] = {
                                TypeName: dto.TypeName,
                                DisplayPattern: new DisplayPattern(dto.DisplayPattern),
                                Display: dto.Display,
                                DisplaySingular: dto.DisplaySingular,
                                FkCandidateRoutes: dto.FkCandidateRoutes,
                                Columns: columns
                            };
                        }
                        this.schemaProvider = { schemas: schemas };
                        return [2 /*return*/];
                }
            });
        });
    };
    Client.prototype.getFkProviderItems = function (methodKey) {
        var _a;
        return new FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
    };
    /** Returns the runtime schema for the named method. */
    Client.prototype.getSchema = function (methodKey) {
        var result = this.schemas[methodKey];
        if (!result)
            throw new Error('Unknown method: ' + methodKey);
        return result;
    };
    /** Returns the currently active configuration for the specified project. */
    Client.prototype.admin_apiconfig_get = function (appId) {
        return this.apiClient.processRequest(this.methodFactory.admin_apiconfig_get(appId));
    };
    /** Updates the configuration with the supplied values. */
    Client.prototype.admin_apiconfig_post = function (appId, global, inputParameterName) {
        return this.apiClient.processRequest(this.methodFactory.admin_apiconfig_post(appId, global, inputParameterName));
    };
    /** Returns the currently active configuration value for the specified path. */
    Client.prototype.admin_apiconfigsingle_get = function (appId, path) {
        return this.apiClient.processRequest(this.methodFactory.admin_apiconfigsingle_get(appId, path));
    };
    /** Adds a new configuration key on the specified path. */
    Client.prototype.admin_apiconfigsingle_post = function (appId, path) {
        return this.apiClient.processRequest(this.methodFactory.admin_apiconfigsingle_post(appId, path));
    };
    Client.prototype.admin_apiconfig_convert_post = function (appId) {
        return this.apiClient.processRequest(this.methodFactory.admin_apiconfig_convert_post(appId));
    };
    /** Reverts all global or local customizations */
    Client.prototype.admin_apiconfig_revert_post = function (appId, global) {
        return this.apiClient.processRequest(this.methodFactory.admin_apiconfig_revert_post(appId, global));
    };
    /** Returns valid values for the configuration setting identified by specified path. */
    Client.prototype.admin_apiconfig_values_get = function (appId, path) {
        return this.apiClient.processRequest(this.methodFactory.admin_apiconfig_values_get(appId, path));
    };
    /** Returns cache data for the specified project. */
    Client.prototype.admin_cache_get = function (appId) {
        return this.apiClient.processRequest(this.methodFactory.admin_cache_get(appId));
    };
    /** Returns cache data for the specified project. */
    Client.prototype.admin_cache_post = function (appId, flush, disable) {
        return this.apiClient.processRequest(this.methodFactory.admin_cache_post(appId, flush, disable));
    };
    /** Manages the specified cache for the specified project. */
    Client.prototype.admin_cachebyid_get = function (appId, cacheid) {
        return this.apiClient.processRequest(this.methodFactory.admin_cachebyid_get(appId, cacheid));
    };
    /** Manages the specified cache for the specified project. */
    Client.prototype.admin_cachebyid_post = function (appId, cacheid, flush, disable) {
        return this.apiClient.processRequest(this.methodFactory.admin_cachebyid_post(appId, cacheid, flush, disable));
    };
    Client.prototype.admin_config_get = function () {
        return this.apiClient.processRequest(this.methodFactory.admin_config_get());
    };
    Client.prototype.admin_config_post = function (inputParameterName) {
        return this.apiClient.processRequest(this.methodFactory.admin_config_post(inputParameterName));
    };
    Client.prototype.admin_packages_get = function () {
        return this.apiClient.processRequest(this.methodFactory.admin_packages_get());
    };
    /** Returns the most recently recorded performance data. */
    Client.prototype.admin_performance_get = function () {
        return this.apiClient.processRequest(this.methodFactory.admin_performance_get());
    };
    Client.prototype.admin_projects_get = function () {
        return this.apiClient.processRequest(this.methodFactory.admin_projects_get());
    };
    Client.prototype.admin_status_get = function () {
        return this.apiClient.processRequest(this.methodFactory.admin_status_get());
    };
    Client.prototype.admin_systeminfo_log_get = function (dir, file) {
        return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_log_get(dir, file));
    };
    Client.prototype.admin_systeminfo_logs_get = function () {
        return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_logs_get());
    };
    Client.prototype.admin_systeminfo_plugins_get = function () {
        return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_plugins_get());
    };
    Client.prototype.admin_systeminfo_software_status_get = function () {
        return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_software_status_get());
    };
    /** Starts the software update process */
    Client.prototype.admin_systeminfo_software_update_post = function () {
        return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_software_update_post());
    };
    /** Returns the set of currently active endpoints, and a flag indicating whether an endpoint is active for the current user. */
    Client.prototype.imx_activeverbs_get = function (appId) {
        return this.apiClient.processRequest(this.methodFactory.imx_activeverbs_get(appId));
    };
    Client.prototype.imx_applications_get = function () {
        return this.apiClient.processRequest(this.methodFactory.imx_applications_get());
    };
    Client.prototype.imx_config_get = function () {
        return this.apiClient.processRequest(this.methodFactory.imx_config_get());
    };
    Client.prototype.imx_entityschema_get = function () {
        return this.apiClient.processRequest(this.methodFactory.imx_entityschema_get());
    };
    Client.prototype.imx_login_post = function (appId, noxsrf, inputParameterName) {
        return this.apiClient.processRequest(this.methodFactory.imx_login_post(appId, noxsrf, inputParameterName));
    };
    Client.prototype.imx_logout_post = function (appId) {
        return this.apiClient.processRequest(this.methodFactory.imx_logout_post(appId));
    };
    /** Returns metadata for a specific database table. */
    Client.prototype.imx_metadata_table_get = function (tableName, cultureName) {
        return this.apiClient.processRequest(this.methodFactory.imx_metadata_table_get(tableName, cultureName));
    };
    /** Returns the model-generated stylesheet. */
    Client.prototype.imx_modelcss_get = function () {
        return this.apiClient.processRequest(this.methodFactory.imx_modelcss_get());
    };
    /** Returns an image stored from data model. */
    Client.prototype.imx_modelimage_get = function (key, size) {
        return this.apiClient.processRequest(this.methodFactory.imx_modelimage_get(key, size));
    };
    /** Returns web UI translations for a specific culture. */
    Client.prototype.imx_multilanguage_getcaptions_get = function (cultureName) {
        return this.apiClient.processRequest(this.methodFactory.imx_multilanguage_getcaptions_get(cultureName));
    };
    /** Returns translations for the data model for an API project. */
    Client.prototype.imx_multilanguage_translations_get = function (cultureName, appId) {
        return this.apiClient.processRequest(this.methodFactory.imx_multilanguage_translations_get(cultureName, appId));
    };
    /** Returns all cultures that are available to frontends. */
    Client.prototype.imx_multilanguage_uicultures_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return this.apiClient.processRequest(this.methodFactory.imx_multilanguage_uicultures_get(OrderBy, StartIndex, PageSize, filter, withProperties, search));
    };
    Client.prototype.imx_oauth_get = function (authentifier, appId, redirecturi) {
        return this.apiClient.processRequest(this.methodFactory.imx_oauth_get(authentifier, appId, redirecturi));
    };
    /** Returns an object indicating whether this API server was able to start up and establish a database connection. */
    Client.prototype.imx_ping_get = function () {
        return this.apiClient.processRequest(this.methodFactory.imx_ping_get());
    };
    Client.prototype.imx_sessions_get = function (appId) {
        return this.apiClient.processRequest(this.methodFactory.imx_sessions_get(appId));
    };
    Client.prototype.imx_system_get = function () {
        return this.apiClient.processRequest(this.methodFactory.imx_system_get());
    };
    /** Returns a list of all third party components. */
    Client.prototype.imx_systeminfo_thirdparty_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return this.apiClient.processRequest(this.methodFactory.imx_systeminfo_thirdparty_get(OrderBy, StartIndex, PageSize, filter, withProperties, search));
    };
    /** Returns the objects that are part of assignment, specified by the assignment's 'table name and the uid. */
    Client.prototype.opsupport_assignment_get = function (tableName, uid) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_assignment_get(tableName, uid));
    };
    Client.prototype.opsupport_config_get = function () {
        return this.apiClient.processRequest(this.methodFactory.opsupport_config_get());
    };
    /** Returns basic information about an object specified by the table name and the uid. */
    Client.prototype.opsupport_dbobject_get = function (tableName, uid) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_dbobject_get(tableName, uid));
    };
    Client.prototype.opsupport_history_get = function (table, uid) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_history_get(table, uid));
    };
    Client.prototype.opsupport_history_comparison_get = function (table, uid, CompareDate) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_history_comparison_get(table, uid, CompareDate));
    };
    Client.prototype.opsupport_hyperview_get = function (table, uid) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_hyperview_get(table, uid));
    };
    Client.prototype.opsupport_jobserver_get = function (server) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_jobserver_get(server));
    };
    Client.prototype.opsupport_jobservers_get = function (withconnection, nofetchjob, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_jobservers_get(withconnection, nofetchjob, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey));
    };
    /** Returns entries in the journal, returning the newest entries first. */
    Client.prototype.opsupport_journal_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, messagetype) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_journal_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, messagetype));
    };
    /** Returns data model information about query options for the journal endpoint. */
    Client.prototype.opsupport_journal_datamodel_get = function (filter) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_journal_datamodel_get(filter));
    };
    Client.prototype.opsupport_journal_stat_get = function () {
        return this.apiClient.processRequest(this.methodFactory.opsupport_journal_stat_get());
    };
    Client.prototype.opsupport_queue_dbqueue_get = function () {
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_dbqueue_get());
    };
    Client.prototype.opsupport_queue_frozenjobs_get = function (queue, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_frozenjobs_get(queue, OrderBy, StartIndex, PageSize, filter, withProperties, search));
    };
    Client.prototype.opsupport_queue_frozenjobsbyqueue_get = function () {
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_frozenjobsbyqueue_get());
    };
    Client.prototype.opsupport_queue_jobaffects_get = function (uidjob, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobaffects_get(uidjob, OrderBy, StartIndex, PageSize, filter, withProperties, search));
    };
    Client.prototype.opsupport_queue_jobchains_get = function () {
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobchains_get());
    };
    Client.prototype.opsupport_queue_jobperformance_get = function (queue, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobperformance_get(queue, OrderBy, StartIndex, PageSize, filter, withProperties, search));
    };
    Client.prototype.opsupport_queue_jobperformancequeues_get = function () {
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobperformancequeues_get());
    };
    Client.prototype.opsupport_queue_jobs_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, state, queue) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobs_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, state, queue));
    };
    /** Returns data model information about query options for the queue/jobs endpoint. */
    Client.prototype.opsupport_queue_jobs_datamodel_get = function (filter) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobs_datamodel_get(filter));
    };
    Client.prototype.opsupport_queue_object_get = function (table, uid) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_object_get(table, uid));
    };
    Client.prototype.opsupport_queue_overview_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_overview_get(OrderBy, StartIndex, PageSize, filter, withProperties, search));
    };
    Client.prototype.opsupport_queue_overview_stream_get = function () {
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_overview_stream_get());
    };
    Client.prototype.opsupport_queue_reactivatejob_post = function (inputParameterName) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_reactivatejob_post(inputParameterName));
    };
    Client.prototype.opsupport_queue_tree_get = function (uidtree) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_tree_get(uidtree));
    };
    Client.prototype.opsupport_search_get = function (term, tables) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_search_get(term, tables));
    };
    /** Returns the list of tables that are included in the search index. */
    Client.prototype.opsupport_search_indexedtables_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_search_indexedtables_get(OrderBy, StartIndex, PageSize, filter, withProperties, search));
    };
    Client.prototype.opsupport_streamconfig_get = function () {
        return this.apiClient.processRequest(this.methodFactory.opsupport_streamconfig_get());
    };
    Client.prototype.opsupport_systemoverview_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_systemoverview_get(OrderBy, StartIndex, PageSize, filter, withProperties, search));
    };
    Client.prototype.opsupport_systemstatus_get = function () {
        return this.apiClient.processRequest(this.methodFactory.opsupport_systemstatus_get());
    };
    Client.prototype.opsupport_systemstatus_post = function (IsDbSchedulerDisabled, IsJobServiceDisabled, inputParameterName) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_systemstatus_post(IsDbSchedulerDisabled, IsJobServiceDisabled, inputParameterName));
    };
    /** Returns the list of permissions groups that the current user is assigned to. */
    Client.prototype.opsupport_usergroups_get = function () {
        return this.apiClient.processRequest(this.methodFactory.opsupport_usergroups_get());
    };
    Client.prototype.opsupport_webapplications_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return this.apiClient.processRequest(this.methodFactory.opsupport_webapplications_get(OrderBy, StartIndex, PageSize, filter, withProperties, search));
    };
    return Client;
}());
var V2ApiClientMethodFactory = /** @class */ (function () {
    function V2ApiClientMethodFactory() {
    }
    V2ApiClientMethodFactory.prototype.admin_apiconfig_get = function (appId, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/admin/apiconfig/{appId}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.admin_apiconfig_post = function (appId, inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/admin/apiconfig/{appId}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.admin_apiconfigsingle_get = function (appId, path, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/admin/apiconfig/{appId}/{path}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'path',
                    value: path,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.admin_apiconfigsingle_post = function (appId, path, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/admin/apiconfig/{appId}/{path}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'path',
                    value: path,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.admin_apiconfig_convert_post = function (appId, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/admin/apiconfig/convert/{appId}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.admin_apiconfig_revert_post = function (appId, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/admin/apiconfig/revert/{appId}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.admin_apiconfig_values_get = function (appId, path, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/admin/apiconfig/values/{appId}/{path}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'path',
                    value: path,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.admin_cache_get = function (appId, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/admin/cache/{appId}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.admin_cache_post = function (appId, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/admin/cache/{appId}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.admin_cachebyid_get = function (appId, cacheid, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/admin/cache/{appId}/{cacheid}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'cacheid',
                    value: cacheid,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.admin_cachebyid_post = function (appId, cacheid, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/admin/cache/{appId}/{cacheid}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'cacheid',
                    value: cacheid,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.admin_config_get = function (options) {
        return {
            path: '/admin/config',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.admin_config_post = function (inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/admin/config',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.admin_packages_get = function (options) {
        return {
            path: '/admin/packages',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.admin_performance_get = function (options) {
        return {
            path: '/admin/performance',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.admin_projects_get = function (options) {
        return {
            path: '/admin/projects',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.admin_status_get = function (options) {
        return {
            path: '/admin/status',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.admin_systeminfo_log_get = function (dir, file, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/admin/systeminfo/log/{dir}/{file}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'dir',
                    value: dir,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'file',
                    value: file,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.admin_systeminfo_logs_get = function (options) {
        return {
            path: '/admin/systeminfo/logs',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.admin_systeminfo_plugins_get = function (options) {
        return {
            path: '/admin/systeminfo/plugins',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.admin_systeminfo_software_status_get = function (options) {
        return {
            path: '/admin/systeminfo/software/status',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.admin_systeminfo_software_update_post = function (options) {
        return {
            path: '/admin/systeminfo/software/update',
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.imx_activeverbs_get = function (appId, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/imx/activeverbs/{appId}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.imx_applications_get = function (options) {
        return {
            path: '/imx/applications',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.imx_config_get = function (options) {
        return {
            path: '/imx/config',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.imx_entityschema_get = function (options) {
        return {
            path: '/imx/entityschema',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.imx_login_post = function (appId, inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/imx/login/{appId}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.imx_logout_post = function (appId, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/imx/logout/{appId}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.imx_metadata_table_get = function (tableName, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/imx/metadata/table/{tableName}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'tableName',
                    value: tableName,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.imx_modelcss_get = function (options) {
        return {
            path: '/imx/modelcss',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.imx_modelimage_get = function (key, size, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/imx/modelimage/{key}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'key',
                    value: key,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'size',
                    value: size,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.imx_multilanguage_getcaptions_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/imx/multilanguage/getcaptions',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.imx_multilanguage_translations_get = function (appId, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/imx/multilanguage/translations/{appId}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.imx_multilanguage_uicultures_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/imx/multilanguage/uicultures',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.imx_oauth_get = function (authentifier, appId, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/imx/oauth/{appId}/{authentifier}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'authentifier',
                    value: authentifier,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.imx_ping_get = function (options) {
        return {
            path: '/imx/ping',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.imx_sessions_get = function (appId, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/imx/sessions/{appId}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'appId',
                    value: appId,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.imx_system_get = function (options) {
        return {
            path: '/imx/system',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.imx_systeminfo_thirdparty_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/imx/systeminfo/thirdparty',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_assignment_get = function (tableName, uid, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/assignment/{tableName}/{uid}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'tableName',
                    value: tableName,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_config_get = function (options) {
        return {
            path: '/opsupport/config',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_dbobject_get = function (tableName, uid, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/dbobject/{tableName}/{uid}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'tableName',
                    value: tableName,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_history_get = function (table, uid, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/history/{table}/{uid}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'table',
                    value: table,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_history_comparison_get = function (table, uid, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/history/{table}/{uid}/comparison',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'table',
                    value: table,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_hyperview_get = function (table, uid, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/hyperview/{table}/{uid}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'table',
                    value: table,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_jobserver_get = function (server, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/jobserver/{server}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'server',
                    value: server,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_jobservers_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/jobservers',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_journal_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/journal',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_journal_datamodel_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/journal/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_journal_stat_get = function (options) {
        return {
            path: '/opsupport/journal/stat',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_queue_dbqueue_get = function (options) {
        return {
            path: '/opsupport/queue/dbqueue',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_queue_frozenjobs_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/queue/frozenjobs',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_queue_frozenjobsbyqueue_get = function (options) {
        return {
            path: '/opsupport/queue/frozenjobsbyqueue',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_queue_jobaffects_get = function (uidjob, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/queue/jobaffects/{uidjob}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uidjob',
                    value: uidjob,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_queue_jobchains_get = function (options) {
        return {
            path: '/opsupport/queue/jobchains',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_queue_jobperformance_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/queue/jobperformance',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_queue_jobperformancequeues_get = function (options) {
        return {
            path: '/opsupport/queue/jobperformancequeues',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_queue_jobs_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/queue/jobs',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_queue_jobs_datamodel_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/queue/jobs/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_queue_object_get = function (table, uid, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/queue/object/{table}/{uid}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'table',
                    value: table,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_queue_overview_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/queue/overview',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_queue_overview_stream_get = function (options) {
        return {
            path: '/opsupport/queue/overview/stream',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_queue_reactivatejob_post = function (inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/queue/reactivatejob',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_queue_tree_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/queue/tree',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_search_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/search',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_search_indexedtables_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/search/indexedtables',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_streamconfig_get = function (options) {
        return {
            path: '/opsupport/streamconfig',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_systemoverview_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/systemoverview',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_systemstatus_get = function (options) {
        return {
            path: '/opsupport/systemstatus',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_systemstatus_post = function (inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/systemstatus',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_usergroups_get = function (options) {
        return {
            path: '/opsupport/usergroups',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.opsupport_webapplications_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/opsupport/webapplications',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    return V2ApiClientMethodFactory;
}());
var V2Client = /** @class */ (function () {
    function V2Client(apiClient, schemaProvider) {
        this.apiClient = apiClient;
        this.schemaProvider = schemaProvider;
        this.methodFactory = new V2ApiClientMethodFactory();
        if (!apiClient) {
            throw new Error("The value for the apiClient parameter is undefined.");
        }
    }
    Object.defineProperty(V2Client.prototype, "schemas", {
        get: function () {
            if (!this.schemaProvider) {
                throw new Error("The schema has not been loaded.");
            }
            return this.schemaProvider.schemas;
        },
        enumerable: false,
        configurable: true
    });
    V2Client.prototype.loadSchema = function (language) {
        return __awaiter(this, void 0, void 0, function () {
            var headers, dtos, schemas, key, dto, columns;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        headers = {};
                        if (language)
                            headers['Accept-Language'] = language;
                        return [4 /*yield*/, this.apiClient.processRequest({
                                path: '/imx/entityschema',
                                parameters: [],
                                method: 'GET',
                                headers: headers,
                                credentials: 'include',
                                observe: 'response',
                                responseType: 'json'
                            })];
                    case 1:
                        dtos = _a.sent();
                        schemas = {};
                        for (key in dtos) {
                            dto = dtos[key];
                            columns = dto.Properties;
                            columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
                            columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
                            schemas[key] = {
                                TypeName: dto.TypeName,
                                DisplayPattern: new DisplayPattern(dto.DisplayPattern),
                                Display: dto.Display,
                                DisplaySingular: dto.DisplaySingular,
                                FkCandidateRoutes: dto.FkCandidateRoutes,
                                Columns: columns
                            };
                        }
                        this.schemaProvider = { schemas: schemas };
                        return [2 /*return*/];
                }
            });
        });
    };
    V2Client.prototype.getFkProviderItems = function (methodKey) {
        var _a;
        return new FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
    };
    /** Returns the runtime schema for the named method. */
    V2Client.prototype.getSchema = function (methodKey) {
        var result = this.schemas[methodKey];
        if (!result)
            throw new Error('Unknown method: ' + methodKey);
        return result;
    };
    /** Returns the currently active configuration for the specified project. */
    V2Client.prototype.admin_apiconfig_get = function (appId, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.admin_apiconfig_get(appId, options));
    };
    /** Updates the configuration with the supplied values. */
    V2Client.prototype.admin_apiconfig_post = function (appId, inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.admin_apiconfig_post(appId, inputParameterName, options));
    };
    /** Returns the currently active configuration value for the specified path. */
    V2Client.prototype.admin_apiconfigsingle_get = function (appId, path, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.admin_apiconfigsingle_get(appId, path, options));
    };
    /** Adds a new configuration key on the specified path. */
    V2Client.prototype.admin_apiconfigsingle_post = function (appId, path, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.admin_apiconfigsingle_post(appId, path, options));
    };
    V2Client.prototype.admin_apiconfig_convert_post = function (appId, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.admin_apiconfig_convert_post(appId, options));
    };
    /** Reverts all global or local customizations */
    V2Client.prototype.admin_apiconfig_revert_post = function (appId, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.admin_apiconfig_revert_post(appId, options));
    };
    /** Returns valid values for the configuration setting identified by specified path. */
    V2Client.prototype.admin_apiconfig_values_get = function (appId, path, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.admin_apiconfig_values_get(appId, path, options));
    };
    /** Returns cache data for the specified project. */
    V2Client.prototype.admin_cache_get = function (appId, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.admin_cache_get(appId, options));
    };
    /** Returns cache data for the specified project. */
    V2Client.prototype.admin_cache_post = function (appId, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.admin_cache_post(appId, options));
    };
    /** Manages the specified cache for the specified project. */
    V2Client.prototype.admin_cachebyid_get = function (appId, cacheid, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.admin_cachebyid_get(appId, cacheid, options));
    };
    /** Manages the specified cache for the specified project. */
    V2Client.prototype.admin_cachebyid_post = function (appId, cacheid, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.admin_cachebyid_post(appId, cacheid, options));
    };
    V2Client.prototype.admin_config_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.admin_config_get(options));
    };
    V2Client.prototype.admin_config_post = function (inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.admin_config_post(inputParameterName, options));
    };
    V2Client.prototype.admin_packages_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.admin_packages_get(options));
    };
    /** Returns the most recently recorded performance data. */
    V2Client.prototype.admin_performance_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.admin_performance_get(options));
    };
    V2Client.prototype.admin_projects_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.admin_projects_get(options));
    };
    V2Client.prototype.admin_status_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.admin_status_get(options));
    };
    V2Client.prototype.admin_systeminfo_log_get = function (dir, file, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_log_get(dir, file, options));
    };
    V2Client.prototype.admin_systeminfo_logs_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_logs_get(options));
    };
    V2Client.prototype.admin_systeminfo_plugins_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_plugins_get(options));
    };
    V2Client.prototype.admin_systeminfo_software_status_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_software_status_get(options));
    };
    /** Starts the software update process */
    V2Client.prototype.admin_systeminfo_software_update_post = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_software_update_post(options));
    };
    /** Returns the set of currently active endpoints, and a flag indicating whether an endpoint is active for the current user. */
    V2Client.prototype.imx_activeverbs_get = function (appId, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.imx_activeverbs_get(appId, options));
    };
    V2Client.prototype.imx_applications_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.imx_applications_get(options));
    };
    V2Client.prototype.imx_config_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.imx_config_get(options));
    };
    V2Client.prototype.imx_entityschema_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.imx_entityschema_get(options));
    };
    V2Client.prototype.imx_login_post = function (appId, inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.imx_login_post(appId, inputParameterName, options));
    };
    V2Client.prototype.imx_logout_post = function (appId, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.imx_logout_post(appId, options));
    };
    /** Returns metadata for a specific database table. */
    V2Client.prototype.imx_metadata_table_get = function (tableName, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.imx_metadata_table_get(tableName, options));
    };
    /** Returns the model-generated stylesheet. */
    V2Client.prototype.imx_modelcss_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.imx_modelcss_get(options));
    };
    /** Returns an image stored from data model. */
    V2Client.prototype.imx_modelimage_get = function (key, size, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.imx_modelimage_get(key, size, options));
    };
    /** Returns web UI translations for a specific culture. */
    V2Client.prototype.imx_multilanguage_getcaptions_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.imx_multilanguage_getcaptions_get(options));
    };
    /** Returns translations for the data model for an API project. */
    V2Client.prototype.imx_multilanguage_translations_get = function (appId, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.imx_multilanguage_translations_get(appId, options));
    };
    /** Returns all cultures that are available to frontends. */
    V2Client.prototype.imx_multilanguage_uicultures_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.imx_multilanguage_uicultures_get(options));
    };
    V2Client.prototype.imx_oauth_get = function (authentifier, appId, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.imx_oauth_get(authentifier, appId, options));
    };
    /** Returns an object indicating whether this API server was able to start up and establish a database connection. */
    V2Client.prototype.imx_ping_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.imx_ping_get(options));
    };
    V2Client.prototype.imx_sessions_get = function (appId, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.imx_sessions_get(appId, options));
    };
    V2Client.prototype.imx_system_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.imx_system_get(options));
    };
    /** Returns a list of all third party components. */
    V2Client.prototype.imx_systeminfo_thirdparty_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.imx_systeminfo_thirdparty_get(options));
    };
    /** Returns the objects that are part of assignment, specified by the assignment's 'table name and the uid. */
    V2Client.prototype.opsupport_assignment_get = function (tableName, uid, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_assignment_get(tableName, uid, options));
    };
    V2Client.prototype.opsupport_config_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_config_get(options));
    };
    /** Returns basic information about an object specified by the table name and the uid. */
    V2Client.prototype.opsupport_dbobject_get = function (tableName, uid, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_dbobject_get(tableName, uid, options));
    };
    V2Client.prototype.opsupport_history_get = function (table, uid, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_history_get(table, uid, options));
    };
    V2Client.prototype.opsupport_history_comparison_get = function (table, uid, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_history_comparison_get(table, uid, options));
    };
    V2Client.prototype.opsupport_hyperview_get = function (table, uid, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_hyperview_get(table, uid, options));
    };
    V2Client.prototype.opsupport_jobserver_get = function (server, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_jobserver_get(server, options));
    };
    V2Client.prototype.opsupport_jobservers_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_jobservers_get(options));
    };
    /** Returns entries in the journal, returning the newest entries first. */
    V2Client.prototype.opsupport_journal_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_journal_get(options));
    };
    /** Returns data model information about query options for the journal endpoint. */
    V2Client.prototype.opsupport_journal_datamodel_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_journal_datamodel_get(options));
    };
    V2Client.prototype.opsupport_journal_stat_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_journal_stat_get(options));
    };
    V2Client.prototype.opsupport_queue_dbqueue_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_dbqueue_get(options));
    };
    V2Client.prototype.opsupport_queue_frozenjobs_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_frozenjobs_get(options));
    };
    V2Client.prototype.opsupport_queue_frozenjobsbyqueue_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_frozenjobsbyqueue_get(options));
    };
    V2Client.prototype.opsupport_queue_jobaffects_get = function (uidjob, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobaffects_get(uidjob, options));
    };
    V2Client.prototype.opsupport_queue_jobchains_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobchains_get(options));
    };
    V2Client.prototype.opsupport_queue_jobperformance_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobperformance_get(options));
    };
    V2Client.prototype.opsupport_queue_jobperformancequeues_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobperformancequeues_get(options));
    };
    V2Client.prototype.opsupport_queue_jobs_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobs_get(options));
    };
    /** Returns data model information about query options for the queue/jobs endpoint. */
    V2Client.prototype.opsupport_queue_jobs_datamodel_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobs_datamodel_get(options));
    };
    V2Client.prototype.opsupport_queue_object_get = function (table, uid, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_object_get(table, uid, options));
    };
    V2Client.prototype.opsupport_queue_overview_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_overview_get(options));
    };
    V2Client.prototype.opsupport_queue_overview_stream_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_overview_stream_get(options));
    };
    V2Client.prototype.opsupport_queue_reactivatejob_post = function (inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_reactivatejob_post(inputParameterName, options));
    };
    V2Client.prototype.opsupport_queue_tree_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_queue_tree_get(options));
    };
    V2Client.prototype.opsupport_search_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_search_get(options));
    };
    /** Returns the list of tables that are included in the search index. */
    V2Client.prototype.opsupport_search_indexedtables_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_search_indexedtables_get(options));
    };
    V2Client.prototype.opsupport_streamconfig_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_streamconfig_get(options));
    };
    V2Client.prototype.opsupport_systemoverview_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_systemoverview_get(options));
    };
    V2Client.prototype.opsupport_systemstatus_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_systemstatus_get(options));
    };
    V2Client.prototype.opsupport_systemstatus_post = function (inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_systemstatus_post(inputParameterName, options));
    };
    /** Returns the list of permissions groups that the current user is assigned to. */
    V2Client.prototype.opsupport_usergroups_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_usergroups_get(options));
    };
    V2Client.prototype.opsupport_webapplications_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.opsupport_webapplications_get(options));
    };
    return V2Client;
}());

export { ApiClientMethodFactory, AuthPropType, AuthType, Client, ConfigSettingType, ImxMultilanguageUicultures, ImxMultilanguageUiculturesWrapper, ImxSysteminfoThirdparty, ImxSysteminfoThirdpartyWrapper, OpsupportJobservers, OpsupportJobserversWrapper, OpsupportJournal, OpsupportJournalWrapper, OpsupportQueueDbqueue, OpsupportQueueDbqueueWrapper, OpsupportQueueFrozenjobs, OpsupportQueueFrozenjobsWrapper, OpsupportQueueFrozenjobsbyqueue, OpsupportQueueFrozenjobsbyqueueWrapper, OpsupportQueueJobaffects, OpsupportQueueJobaffectsWrapper, OpsupportQueueJobchains, OpsupportQueueJobchainsWrapper, OpsupportQueueJobperformance, OpsupportQueueJobperformanceWrapper, OpsupportQueueJobs, OpsupportQueueJobsWrapper, OpsupportQueueOverview, OpsupportQueueOverviewWrapper, OpsupportQueueTree, OpsupportQueueTreeWrapper, OpsupportSearchIndexedtables, OpsupportSearchIndexedtablesWrapper, OpsupportSystemoverview, OpsupportSystemoverviewWrapper, OpsupportWebapplications, OpsupportWebapplicationsWrapper, ReactivateJobMode, TypedClient, UpdaterState, V2ApiClientMethodFactory, V2Client };
