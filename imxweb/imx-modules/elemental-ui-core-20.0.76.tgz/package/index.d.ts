import * as i36 from '@angular/cdk/a11y';
import { HighContrastModeDetector } from '@angular/cdk/a11y';
import * as rxjs from 'rxjs';
import { Observable, Subscription, BehaviorSubject, Subject, ReplaySubject } from 'rxjs';
import * as i0 from '@angular/core';
import { InjectionToken, OnInit, OnChanges, EventEmitter, NgZone, OnDestroy, ElementRef, PipeTransform, ChangeDetectorRef, AfterContentInit, AfterViewInit, QueryList, ViewContainerRef, AfterContentChecked, Renderer2, Injector, Type, DestroyRef, AfterViewChecked, TemplateRef, RendererFactory2 } from '@angular/core';
import * as i26 from '@angular/material/snack-bar';
import { MatSnackBarConfig, MatSnackBarRef, MatSnackBar } from '@angular/material/snack-bar';
import { ChartOptions, Chart } from 'billboard.js';
import * as i54 from '@angular/forms';
import { FormControl, ValidationErrors, ControlValueAccessor, NgModel } from '@angular/forms';
import * as i8 from '@angular/material/datepicker';
import { DateFilterFn } from '@angular/material/datepicker';
import moment from 'moment-timezone';
import { Direction, Directionality } from '@angular/cdk/bidi';
import * as i12 from '@angular/material/form-field';
import { MatFormFieldControl, MatFormField, MatPrefix, MatSuffix } from '@angular/material/form-field';
import * as i3 from '@angular/material/button';
import { MatButton } from '@angular/material/button';
import * as i22 from '@angular/material/select';
import { MatSelect, MatSelectChange } from '@angular/material/select';
import * as i15 from '@angular/material/input';
import { MatInput } from '@angular/material/input';
import { OverlayRef, Overlay, ConnectedOverlayPositionChange, ConnectedPosition } from '@angular/cdk/overlay';
import { AnimationEvent as AnimationEvent$1 } from '@angular/animations';
import { ScrollbarOptions, ScrollStatus, ScrollToOptions, ScrollIntoViewOptions } from 'smooth-scrollbar/interfaces';
import * as i27 from '@angular/material/sort';
import { Sort } from '@angular/material/sort';
import * as i38 from '@angular/cdk/drag-drop';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import * as i6 from '@angular/material/checkbox';
import { MatCheckboxChange } from '@angular/material/checkbox';
import * as i9 from '@angular/material/dialog';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import * as i55 from '@angular/router';
import { IsActiveMatchOptions, Params, QueryParamsHandling, ActivatedRoute, Router, UrlTree, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import * as i17 from '@angular/material/menu';
import { MatMenu } from '@angular/material/menu';
import { HttpClient } from '@angular/common/http';
import * as file_saver from 'file-saver';
import { FileSaverOptions } from 'file-saver';
import { MomentInput } from 'moment';
import * as i1 from '@angular/material/tooltip';
import { MatTooltip } from '@angular/material/tooltip';
import * as i52 from '@angular/common';
import * as i1$1 from '@angular/material/autocomplete';
import * as i2 from '@angular/material/badge';
import * as i4 from '@angular/material/button-toggle';
import * as i5 from '@angular/material/card';
import * as i7 from '@angular/material/chips';
import * as i10 from '@angular/material/divider';
import * as i11 from '@angular/material/expansion';
import * as i13 from '@angular/material/grid-list';
import * as i14 from '@angular/material/icon';
import * as i16 from '@angular/material/list';
import * as i18 from '@angular/material/paginator';
import * as i19 from '@angular/material/progress-spinner';
import * as i20 from '@angular/material/progress-bar';
import * as i21 from '@angular/material/radio';
import * as i23 from '@angular/material/sidenav';
import * as i24 from '@angular/material/slider';
import * as i25 from '@angular/material/slide-toggle';
import * as i28 from '@angular/material/stepper';
import * as i29 from '@angular/material/table';
import * as i30 from '@angular/material/tabs';
import * as i31 from '@angular/material/toolbar';
import * as i33 from '@angular/material/tree';
import * as i34 from '@angular/material/core';
import * as i35 from '@angular/material/bottom-sheet';
import * as i37 from '@angular/cdk/scrolling';

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare const EUI_THEME_DEFAULT: InjectionToken<EuiTheme>;
declare const EUI_THEME_AUTO_LIGHT: InjectionToken<EuiTheme>;
declare const EUI_THEME_STORAGE_KEY: InjectionToken<string>;
declare const EUI_THEME_SKIP_SAVE: InjectionToken<boolean>;
declare const EUI_THEME_SKIP_LOAD: InjectionToken<boolean>;
declare enum EuiTheme {
    DARK = "eui-dark-theme",
    LIGHT = "eui-light-theme",
    CONTRAST = "eui-contrast-theme",
    AUTO = "eui-auto-theme"
}
interface CustomTheme {
    name: string;
    class: string;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Gives ability to change the global theme
 */
declare class EuiThemeService {
    private highContrastModeDetector;
    private document;
    private actualTheme;
    private preferredColorScheme;
    private themeSwitcherState;
    private autoLightTheme;
    private defaultTheme;
    private storageKey;
    private skipSave;
    private skipLoad;
    constructor(highContrastModeDetector: HighContrastModeDetector, document: any, defaultTheme: EuiTheme, autoLightTheme: EuiTheme, storageKey: string, skipSave: boolean, skipLoad: boolean);
    /**
     * Setting the actual theme
     *
     * @param theme This theme set
     */
    setTheme(theme: EuiTheme): void;
    /**
     * Get notification from the theme changing, that contains the automatic switches too.
     */
    getActualTheme(): Observable<EuiTheme>;
    /**
     * Get notification from the theme switcher state changing
     */
    getThemeSwitcherState(): Observable<EuiTheme>;
    /**
     * Reset the theme to the default
     */
    resetToDefault(): void;
    private highContrastThemeSupport;
    private watchPrefersColorSchemeChanges;
    private watchForcedColorsChange;
    private onAutomaticThemeChange;
    private updateTheme;
    private isDarkMode;
    private saveTheme;
    private loadTheme;
    private clearClasses;
    private addClass;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiThemeService, [null, null, { optional: true; }, { optional: true; }, { optional: true; }, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EuiThemeService>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Configuration options for EUI Alert Banner.
 */
interface EuiAlertBannerOptions extends MatSnackBarConfig {
    /**
     * Sets the alert banner type. Pre-defined options:
     *
     * - info
     * - warning
     * - error
     * - success
     */
    type: string;
    /**
     * Sets whether the alert banner can be dismissed or not
     */
    dismissable?: boolean;
    /**
     * Optional value to set how far down the screen the banner is displayed
     */
    top?: string;
    /**
     * Value to be assigned to the aria-label attribute for close icon
     */
    closeAriaLabel?: string;
    /**
     * Sets the text displayed within the alert banner
     */
    message: string;
    /**
     * Sets the role attribute
     */
    role?: string;
    /**
     * Sets the text size for the alert banner message (small, medium, large)
     */
    size?: string;
    /**
     * Sets a custom class on the snack bar container
     */
    panelClass?: string;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiAlertBannerComponent implements OnInit {
    private snackBarRef;
    options: EuiAlertBannerOptions;
    constructor(snackBarRef: MatSnackBarRef<EuiAlertBannerComponent>, options: EuiAlertBannerOptions);
    /** @internal */
    get icon(): string;
    /** @internal */
    get sizeClass(): string;
    /** @internal */
    get typeClass(): string;
    /** @internal */
    get classes(): string;
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    dismiss(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiAlertBannerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiAlertBannerComponent, "eui-alert-banner", never, {}, {}, never, never, false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiAlertComponent implements OnInit, OnChanges {
    /**
     * Sets whether the alert is colored or not
     *
     * @category Input
     */
    colored: boolean;
    /**
     * Sets whether the alert is condensed or not
     *
     * @category Input
     */
    condensed: boolean;
    /**
     * Sets the alert type. Pre-defined options:
     * - info
     * - warning
     * - error
     * - success
     *
     * @category Input
     */
    type: string;
    /**
     * Sets whether the alert can be dismissed or not
     *
     * @category Input
     */
    dismissable: boolean;
    /**
     * Value to be assigned to the aria-label attribute for close icon
     *
     * @category Input
     */
    closeAriaLabel: string;
    /**
     * Properties for customising the alert style. Provide an icon and a class name
     *
     * @category Input
     */
    custom: {
        icon: string;
        className: string;
    };
    /**
     * Emits an event when the alert is dismissed
     *
     * @category Output
     * @event
     */
    dismissed: EventEmitter<any>;
    /**
     * Value to be used for the role attribute
     *
     * @category Input
     */
    role: string;
    /** @internal */
    isDismissed: boolean;
    /** @internal */
    classList: string[];
    /** @internal */
    get icon(): string;
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    ngOnChanges(): void;
    /** @internal */
    setupComponent(): void;
    /** @internal */
    dismiss($event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiAlertComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiAlertComponent, "eui-alert", never, { "colored": { "alias": "colored"; "required": false; }; "condensed": { "alias": "condensed"; "required": false; }; "type": { "alias": "type"; "required": false; }; "dismissable": { "alias": "dismissable"; "required": false; }; "closeAriaLabel": { "alias": "closeAriaLabel"; "required": false; }; "custom": { "alias": "custom"; "required": false; }; "role": { "alias": "role"; "required": false; }; }, { "dismissed": "dismissed"; }, never, ["*", "eui-alert-header", "eui-alert-content"], false, never>;
}
declare class EuiAlertHeaderDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiAlertHeaderDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<EuiAlertHeaderDirective, "eui-alert-header", never, {}, {}, never, never, false, never>;
}
declare class EuiAlertContentDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiAlertContentDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<EuiAlertContentDirective, "eui-alert-content", never, {}, {}, never, never, false, never>;
}

declare class EuiBadgeComponent {
    /** @internal */
    class: string;
    /**
     * Set the background color of the badge
     *
     * Can be set as a custom hex value or one of the following palette colors:
     * primary, accent, warn, blue, darkblue, red, orange, green, yellow, pink, white, gray, gunmetal, black, purple
     *
     * @category Input
     */
    color: string;
    /**
     * Set the text color of the badge
     *
     * Can be set as a custom hex value or one of the following palette colors:
     * black, white
     *
     * @category Input
     */
    textColor: string;
    /**
     * Set the size of the badge
     *
     * Defauls to "small", but can be set as one of the following sizes:
     * small, medium, large
     *
     * @category Input
     */
    size: 'small' | 'medium' | 'large';
    /** @internal */
    possibleBgColors: string[];
    /** @internal */
    possibleTextColors: string[];
    /** @internal */
    get colorClass(): string;
    /** @internal */
    get textColorClass(): string;
    /** @internal */
    get sizeClass(): string;
    /** @internal */
    get cssClasses(): string;
    /** @internal */
    get isCustomBg(): boolean;
    /** @internal */
    get isCustomText(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiBadgeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiBadgeComponent, "eui-badge", never, { "color": { "alias": "color"; "required": false; }; "textColor": { "alias": "textColor"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, ["*"], false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiBillboardService {
    private ngZone;
    constructor(ngZone: NgZone);
    /**
     * Generate function which call original billboard generate function
     */
    generate(options: ChartOptions): Chart;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiBillboardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EuiBillboardService>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiBillboardComponent implements OnDestroy, OnInit {
    private elementRef;
    private euiThemeService;
    private chartService;
    /**
     * You can set billboard.js options with this input, more details see ChartOptions type
     *
     * @category Input
     */
    set options(options: ChartOptions);
    /**
     * Emit the generated chart to use for advanced functionality
     *
     * @category Output
     * @event
     */
    chart: EventEmitter<Chart>;
    /**
     * Emit event before chart destroy
     *
     * @category Output
     * @event
     */
    beforeDestroy: EventEmitter<boolean>;
    private _chart;
    private _options;
    private _currentTheme;
    constructor(elementRef: ElementRef, euiThemeService: EuiThemeService, chartService: EuiBillboardService);
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    ngOnDestroy(): void;
    private setupChart;
    private updateColors;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiBillboardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiBillboardComponent, "eui-billboard", never, { "options": { "alias": "options"; "required": false; }; }, { "chart": "chart"; "beforeDestroy": "beforeDestroy"; }, never, never, false, never>;
}

declare class EuiDatePickerComponent {
    /**
     * FormControl used to managing component
     *
     * @category Input
     */
    dateControl: FormControl<moment.Moment>;
    /**
     * Controls whether the legacy floating label is displayed or a label above the form field
     *
     * @category Input
     */
    useLegacyFloatingLabel: boolean;
    /**
     * Text to be displayed within mat-label element
     *
     * @category Input
     */
    label: string;
    /**
     * Text to be displayed for placeholder of the input field
     *
     * @category Input
     */
    placeholder: string;
    /**
     * Appearance mode of the mat-form-field element
     *
     * @category Input
     */
    appearance: string;
    /**
     * Sets whether the component is required or not
     *
     * @category Input
     */
    required: boolean;
    /**
     * Sets whether the component is read-only or not
     *
     * @category Input
     */
    readonly: boolean;
    /**
     * When true the 'eui-input--no-margin' class will be applied to the mat-form-field
     * Note: this needs to be set to 'false' when showing validation errors in the <mat-error> section, so that they display correctly
     *
     * @category Input
     */
    hideMargins: boolean;
    /**
     * Sets minimum accepted value for the component
     *
     * @category Input
     */
    min: moment.Moment;
    /**
     * Sets maximum accepted value for the component
     *
     * @category Input
     */
    max: moment.Moment;
    /**
     * Sets the width of the component
     *
     * @category Input
     */
    width: string;
    /**
     *  Filter out dates within the datepicker of the component
     *
     * @category Input
     */
    dateFilter: DateFilterFn<moment.Moment>;
    /**
     * Allow the touchUi mode to be set for the mat-datepicker
     *
     * @category Input
     */
    touchUi: boolean;
    /**
     * When set to false, allows user to trigger the date picker by clicking or moving focus to the input field
     *
     * @category Input
     */
    allowTextInput: boolean;
    /**
     * Replaces date picker with a clear button to allow the value to be cleared. Usually used when allowTextInput is set to false
     *
     * @category Input
     */
    useClearIcon: boolean;
    /**
     * When set to true, displays a red error icon, representing the error state if the control is required and has been touched
     *
     * @category Input
     */
    showErrorState: boolean;
    /**
     * Sets the disabled state of the component
     *
     * @category Input
     */
    set disabled(disabled: boolean);
    /**
     * Gets the disabled state of the component
     */
    /** @internal */
    get disabled(): boolean;
    /** @internal */
    _disabled: boolean;
    /** @internal */
    get isRequired(): boolean;
    /**
     * Function called when the mat-datepicker is closed to prevent open/close loop
     *
     * @param dateInput: A reference to the input field
     */
    /** @internal */
    blurPicker(dateInput: HTMLElement): void;
    /**
     * Function called when clear button is pressed. Clears value of dateControl FormControl
     *
     * @param dateInput: A reference to the input field
     * @param event: The mouse click / key press event
     */
    /** @internal */
    clearValue(dateInput: HTMLElement, event: MouseEvent): void;
    /**
     * Returns whether the dateControl FormControl contains errors
     */
    /** @internal */
    hasErrors(): boolean;
    /**
     * Returns all errors associated with the dateControl FormControl
     */
    /** @internal */
    getErrors(): ValidationErrors;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiDatePickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiDatePickerComponent, "eui-date-picker", never, { "dateControl": { "alias": "dateControl"; "required": false; }; "useLegacyFloatingLabel": { "alias": "useLegacyFloatingLabel"; "required": false; }; "label": { "alias": "label"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "appearance": { "alias": "appearance"; "required": false; }; "required": { "alias": "required"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "hideMargins": { "alias": "hideMargins"; "required": false; }; "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "width": { "alias": "width"; "required": false; }; "dateFilter": { "alias": "dateFilter"; "required": false; }; "touchUi": { "alias": "touchUi"; "required": false; }; "allowTextInput": { "alias": "allowTextInput"; "required": false; }; "useClearIcon": { "alias": "useClearIcon"; "required": false; }; "showErrorState": { "alias": "showErrorState"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, {}, never, ["eui-readonly-label", "mat-error"], false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

interface EuiHrMinStruct {
    hour: number;
    hourText: string;
    minute: number;
    minuteText: string;
    disabled: boolean;
}
declare class EuiTimePickerComponent implements OnInit {
    /**
     * Test Id prefix
     *
     * @category Input
     */
    testId: string;
    /**
     * FormControl used to manage component
     *
     * @category Input
     */
    set timeControl(control: FormControl<moment.Moment>);
    /**
     * Gets the FormControl used to manage component
     *
     * @internal */
    get timeControl(): FormControl<moment.Moment>;
    /**
     * When set to false, the user is not allowed to type into the text fields
     *
     * @category Input
     */
    allowTextInput: boolean;
    /**
     * Text to be displayed within mat-label element
     *
     * @category Input
     */
    label: string;
    /**
     * Appearance mode of the mat-form-field element
     *
     * @category Input
     */
    appearance: string;
    /**
     * Sets the disabled state of the component
     *
     * @category Input
     */
    set disabled(disabled: boolean);
    /**
     * Gets the disabled state of the component
     *
     * @internal */
    get disabled(): boolean;
    /**
     * Sets whether the component is required or not
     *
     * @category Input
     */
    required: boolean;
    /** @internal */
    get isRequired(): boolean;
    /**
     * Sets whether the component is read-only or not
     *
     * @category Input
     */
    readonly: boolean;
    /**
     * Sets minimum accepted value for the component
     *
     * @category Input
     */
    set min(minvalue: moment.Moment);
    /**
     * Gets minimum accepted value for the component
     *
     * @internal */
    get min(): moment.Moment;
    /**
     * Sets maximum accepted value for the component
     *
     * @category Input
     */
    set max(maxvalue: moment.Moment);
    /**
     * Gets maximum accepted value for the component
     *
     * @internal */
    get max(): moment.Moment;
    /**
     * Sets the width of the component
     *
     * @category Input
     */
    width: string;
    /**
     * If true, the minute field will be disabled and set to "00"
     *
     * @category Input
     */
    set hourOnly(hronly: boolean);
    /**
     * Gets whether or not the component is set to allow hours only
     *
     * @internal */
    get hourOnly(): boolean;
    /**
     * Sets an array of hours that can be selected (values from 0 - 23).
     *
     * @category Input
     */
    set permittedHours(hours: number[]);
    /**
     * An array of hours that can be selected (values from 0 - 23).
     *    If none are supplied, then all hours are allowed. If any are passed in,
     *    the hours select list will have disabled and enabled items, and the
     *    validation will reject any hour of the day that's not in the permitted list.
     *
     * @internal */
    get permittedHours(): number[];
    /**
     * Sets whether there is a margin at the bottom of the component
     *
     * @category Input
     */
    noMargin: boolean;
    /**
     * Sets the value of the picker to the passed in Moment object
     *
     * @category Input
     */
    set value(val: moment.Moment);
    /**
     * Gets the value of the picker as a Moment object
     *
     * @internal */
    get value(): moment.Moment;
    /**
     * Sets the minute resolution of the items in the minute drop-down (must be a divisor of 60).
     *    For a value of 15, the minute drop-down list will contain [0, 15, 30, 45].
     *    For a value of 10, the minute drop-down list will contain [0, 10, 20, 30, 40, 50].
     *    If the value is not a divisor of 60, it will be set to 15.
     *    Default: 15
     *
     * @category Input
     */
    set minuteResolution(minutes: number);
    /**
     * Gets the minute resolution of the items in the minute drop-down (must be a divisor of 60).
     *    For a value of 15, the minute drop-down list will contain [0, 15, 30, 45].
     *    For a value of 10, the minute drop-down list will contain [0, 10, 20, 30, 40, 50].
     *    If the value is not a divisor of 60, it will be set to 15.
     *    Default: 15
     *
     * @internal */
    get minuteResolution(): number;
    /**
     * Emits an event when the value of the picker changes
     *
     * @category Output
     * @event
     */
    valueChange: EventEmitter<moment.Moment>;
    /** @internal */
    hourControl: FormControl<string>;
    /** @internal */
    minuteControl: FormControl<string>;
    /** @internal */
    hours: EuiHrMinStruct[];
    /** @internal */
    minutes: EuiHrMinStruct[];
    /**
     * Contains style key-value pairs for mat-form-field element
     *
     * @internal */
    fieldStyles: {};
    /**
     * Gets whether the current time is in the AM or PM hours
     *
     * @internal */
    get amOrPm(): string;
    /**
     * Sets whether the current time is in the AM or PM hours
     *
     * @internal */
    set amOrPm(ampm: string);
    /**
     * Returns when the AM/PM button should be shown
     *
     * @internal */
    get showAmPm(): boolean;
    /** @internal */
    _timeControl: FormControl<moment.Moment>;
    /** @internal */
    _timeControlSub: Subscription;
    private _showAmPm;
    private _disabled;
    private _min;
    private _max;
    private _hourOnly;
    private _permittedHours;
    private _value;
    private _minuteResolution;
    private _amOrPm;
    private get isAm();
    constructor();
    /** @internal */
    ngOnInit(): void;
    /**
     * Gets the hours to show in the drop-down
     *
     * @internal */
    get clockHours(): EuiHrMinStruct[];
    /**
     * Gets whether the current time is "AM" or "PM"
     *
     * @internal */
    get timeAmPm(): string;
    /**
     * Toggles the current time between "AM" and "PM"
     *
     * @internal */
    toggleAmPm(): void;
    /**
     * Sets the value of the hour or minute field to the selected value from the drop-down
     *
     * @param value: The numeric to set the field to
     * @param which: The field to set ('hour' or 'minute')
     * @internal */
    timeMenu(value: EuiHrMinStruct, which: 'hour' | 'minute'): void;
    /**
     * Returns whether the hour and minute fields' FormControls contains errors
     *
     * @internal */
    hasErrors(): boolean;
    /**
     * Returns all errors associated with the hour and minute fields' FormControls
     *
     * @internal */
    getErrors(): ValidationErrors;
    /**
     * If allowTextInput=false, this prevents the user from typing in the field.
     *
     * @internal */
    onKeyDown(event: KeyboardEvent): void;
    /**
     * Returns the hour value, accounting for AM/PM, for the passed-in value
     */
    private hour24;
    /**
     * Called when the user changes the value of the hour or minute input field
     */
    private timeChanged;
    /**
     * Maps a key event to a standard set of key codes.
     */
    private mapKey;
    /**
     * Sends notification that the value has changed
     */
    private valueOutput;
    /**
     * Populates the arrays used in the drop-down lists
     */
    private setTimeSelects;
    /**
     * Internal method to set the current value, if changed
     */
    private setValue;
    /**
     * Gets a validator for the minutes field
     */
    private getMinuteValidator;
    /**
     * Gets a validator for the hours field
     */
    private getHourValidator;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiTimePickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiTimePickerComponent, "eui-time-picker", never, { "testId": { "alias": "testId"; "required": false; }; "timeControl": { "alias": "timeControl"; "required": false; }; "allowTextInput": { "alias": "allowTextInput"; "required": false; }; "label": { "alias": "label"; "required": false; }; "appearance": { "alias": "appearance"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "required": { "alias": "required"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "width": { "alias": "width"; "required": false; }; "hourOnly": { "alias": "hourOnly"; "required": false; }; "permittedHours": { "alias": "permittedHours"; "required": false; }; "noMargin": { "alias": "noMargin"; "required": false; }; "value": { "alias": "value"; "required": false; }; "minuteResolution": { "alias": "minuteResolution"; "required": false; }; }, { "valueChange": "valueChange"; }, never, ["eui-readonly-label", "mat-error"], false, never>;
}

/**
 * -----------------------------------------------------------------------
 * THIS FILE IS AUTO-GENERATED. DO NOT EDIT OR MODIFY THIS FILE DIRECTLY.
 * -----------------------------------------------------------------------
 *
 * This JavaScript file was generated automatically by the npm postinstall script.
 * Any manual changes made to this file will be lost the next time
 * the file is regenerated.
 */
type CadenceIconsType = 'home' | 'refresh' | 'add' | 'remove' | 'search' | 'settings' | 'delete' | 'help' | 'warning' | 'error' | 'check' | 'removetask' | 'back' | 'forward' | 'info' | 'save' | 'export' | 'import' | 'lock' | 'unlock' | 'admin' | 'calendar' | 'filter' | 'folder' | 'openfolder' | 'print' | 'email' | 'star' | 'user' | 'usergroup' | 'approvals' | 'request' | 'sync' | 'download' | 'upload' | 'reports' | 'performance' | 'link' | 'collapsedown' | 'collapseup' | 'popout' | 'language' | 'config' | 'edit' | 'contactinfo' | 'idp' | 'password' | 'view' | 'location' | 'camera' | 'application' | 'database' | 'server' | 'asset' | 'networkdevice' | 'network' | 'assetgroup' | 'desktop' | 'reviewer' | 'policy' | 'scope' | 'account' | 'profile' | 'role' | 'time' | 'copy' | 'library' | 'batch' | 'serviceaccount' | 'permissions' | 'close' | 'setdefault' | 'partition' | 'passwordhistory' | 'collapseleft' | 'collapseright' | 'activitycenter' | 'attributes' | 'accountgroup' | 'safeguard' | 'restore' | 'passwordworkflow' | 'passwordcheckchange' | 'passwordrefresh' | 'manage' | 'ignore' | 'discovery' | 'run' | 'hide' | 'clusternode' | 'stop' | 'elipsisasterisk' | 'toc' | 'index' | 'scrollupdown' | 'scrollup' | 'scrolldown' | 'secured' | 'power' | 'heart' | 'columns' | 'pbote' | 'cback' | 'cforward' | 'openstarhalf' | 'arrows' | 'openheart' | 'resizehorizontal' | 'resizevertical' | 'arrowsvertical' | 'arrowshorizontal' | 'comments' | 'hdd' | 'share' | 'compress' | 'sliders' | 'task' | 'taskcomplete' | 'random' | 'piechart' | 'boxx' | 'boxcheck' | 'linechart' | 'areachart' | 'chevronupdouble' | 'chevrondowndouble' | 'levelup' | 'cursor' | 'microphonemute' | 'microphone' | 'wrench' | 'openbookmark' | 'bookmark' | 'backbar' | 'opencheckbox' | 'signout' | 'editalt' | 'drop' | 'circlehalf' | 'image' | 'record' | 'indent' | 'indentinverse' | 'text' | 'alignright' | 'aligncenter' | 'alignleft' | 'tagdouble' | 'tag' | 'volume3' | 'volume2' | 'volume1' | 'volume0' | 'lockalt' | 'listalt' | 'playcircle' | 'inbox' | 'arrowleftring' | 'arrowdownring' | 'arrowrightring' | 'arrowupring' | 'downloadalt' | 'wlan' | 'zoomout' | 'zoomin' | 'gridsmall' | 'gridbig' | 'film' | 'music' | 'question' | 'asterisk' | 'flag' | 'usermd' | 'code' | 'bug' | 'key' | 'codesplit' | 'clipboard' | 'megaphone' | 'book' | 'box' | 'anchor' | 'magic' | 'opencomment' | 'comment' | 'compass' | 'lightbulb' | 'mobile' | 'phone' | 'reorder' | 'undo' | 'sort' | 'sortup' | 'sortdown' | 'terminal' | 'opentrash' | 'crossquare' | 'arrowup' | 'arrowdown' | 'crosshair' | 'crosscircle' | 'rewind' | 'fastforward' | 'toend' | 'tobeginning' | 'pause' | 'globe' | 'exchange' | 'ellipsishorizontal' | 'ellipsisvertical' | 'circle' | 'ring' | 'opencloud' | 'barchart' | 'battery4' | 'battery3' | 'battery2' | 'battery1' | 'battery0' | 'arrowlocation' | 'starhalf' | 'openstar' | 'opensquare' | 'signin' | 'userremove' | 'usersubtract' | 'useradd' | 'rsssquare' | 'rss' | 'openmail' | 'chevrondownsquare' | 'chevronleftsquare' | 'chevronrightsquare' | 'chevronupsquare' | 'chevrondowncircle' | 'chevronleftcircle' | 'chevronrightcircle' | 'chevronupcircle' | 'chevrondown' | 'chevronleft' | 'chevronright' | 'chevronup' | 'android' | 'apple' | 'google' | 'linkedin' | 'facebook' | 'twitter' | 'bullseye' | 'cloud' | 'expand' | 'heartcrossout' | 'diagnose' | 'failover' | 'healthcheck' | 'systemcheck' | 'unjoin' | 'reboot' | 'activate' | 'dynamicaccountgroup' | 'dynamicassetgroup' | 'dynamic' | 'hybrid' | 'sconnect' | 'keyboard' | 'credit-card' | 'content-alert' | 'accessrequest' | 'accesscertification' | 'governance' | 'clock' | 'lan' | 'sankey' | 'fis' | 'date' | 'windows' | 'oi-circle' | 'oi-stacked' | 'oi-horizontal' | 'applications' | 'building' | 'hashtag' | 'safeguard-authentication-services' | 'safeguard-sessions' | 'safeguard-passwords' | 'safeguard-sudo' | 'safeguard-player' | 'safeguard-search-portal' | 'copy-user' | 'copy-password' | 'isolate' | 'integrate' | 'remove-user' | 'appliance' | 'rejected-approval' | 'draghandles' | 'workflow' | 'table' | 'unlink' | 'job-queue' | 'external-link' | 'cart' | 'addasset' | 'checkpoint-logo' | 'suse-logo' | 'sonicwall-logo' | 'sap-logo' | 'paloaltonetworks-logo' | 'linux-logo' | 'openldap-logo' | 'junos-logo' | 'fortinet-logo' | 'f5-logo' | 'vmware-logo' | 'cisco-logo' | 'aix-logo' | 'catech-logo' | 'ubuntu-logo' | 'redhat-logo' | 'postgresql-logo' | 'oracle-logo' | 'mysql-logo' | 'mongodb-logo' | 'dell-logo' | 'fedora-logo' | 'ibm-logo' | 'hp-logo' | 'freebsd-logo' | 'debian-logo' | 'centos-logo' | 'aws-logo' | 'safeguard-starling-remote-access' | 'waiting' | 'lab' | 'bell' | 'cloud-assistant' | 'active-roles' | 'password-manager' | 'identity-manager' | 'directory' | 'directory-ad' | 'jump-last' | 'jump-first' | 'azure' | 'hourglass-top' | 'error-circle' | 'document-add' | 'server-add' | 'office365-logo' | 'mfa-otp' | 'safeguard-scalus' | 'community-scalus' | 'folder-tree' | 'document' | 'powerbi-logo' | 'privilege-manager' | 'mfa-protect' | 'mfa-fido' | 'google-secrets-logo' | 'jenkins-secrets-logo' | 'kubernetes-secrets-logo' | 'rdp-session' | 'ssh-session' | 'api-key' | 'ssh-key' | 'in-progress' | 'onelogin-logo' | 'entra-logo' | 'exchange-logo' | 'google-logo' | 'sharepoint-logo';

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiIconComponent implements OnInit {
    private eRef;
    /** @internal */
    fontSize: string;
    /** @internal */
    lineHeight: string;
    /** @internal */
    innerHTML: string;
    /**
     * Sets the value of the aria-hidden attribute
     *
     * @category Input
     */
    ariaHidden: boolean;
    /**
     * When true, sets the icons line-height to match the font-size
     *
     * @category Input
     */
    set setLineHeight(val: boolean);
    private _setLineHeight;
    private _unicode;
    private iconPresetSize;
    constructor(eRef: ElementRef);
    /** @internal */
    ngOnInit(): void;
    /**
     * The selected icon's name to render. See the
     * [guideline](https://elemental.dev.oneidentity.com/design/iconography) for available options.
     *
     * The 'CadenceIconsType' is auto generated from '@elemental-ui/cadence-icon/codepoints.js' file during the npm postinstall step.
     *
     * @category Input
     */
    set icon(i: CadenceIconsType | string);
    /**
     * Sets the icon's size in pixel. Pre-defined options:
     *
     * - s (small): 16px height
     * - m (medium): 24px height (default)
     * - l (large): 36px height
     * - xl (x-large): 48px height
     *
     * @category Input
     */
    set size(size: string);
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiIconComponent, "eui-icon", never, { "ariaHidden": { "alias": "aria-hidden"; "required": false; }; "setLineHeight": { "alias": "setLineHeight"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiJoinPipe implements PipeTransform {
    /**
     * A method that joins the array elements using the provided separator.
     *
     * @param value The array to be joined
     * @param separator The separator to apply
     * @memberof EuiJoinPipe
     */
    transform(value: any, separator?: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiJoinPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<EuiJoinPipe, "euiJoin", false>;
}

declare class EuiLoadingComponent {
    ariaLabel: string;
    constructor(ariaLabel: string);
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiLoadingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiLoadingComponent, "eui-loading", never, {}, {}, never, never, false, never>;
}

declare class EuiLogoComponent {
    /** @internal */
    height: string;
    /**
     * Sets the logo's height in pixel
     *
     * @category Input
     */
    set size(val: number);
    /** @internal */
    _size: number;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiLogoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiLogoComponent, "eui-logo", never, { "size": { "alias": "size"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiMastheadComponent {
    /**
     * Choose an icon do display in the masthead. Renders One Identity logo
     * if not specified.
     *
     * @category Input
     */
    icon: string;
    /**
     * Sets whether the masthead will show in the centered position or not.
     * Set to true will add .eui-masthead-centered css class
     *
     * @category Input
     */
    centeredMasthead: boolean;
    /**
     * Emits a MouseEvent when the logo is clicked.
     *
     * @category Output
     * @event
     */
    logoClicked: EventEmitter<MouseEvent>;
    /** @internal */
    get logoClickObserved(): boolean;
    /** @internal */
    onLogoClick(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiMastheadComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiMastheadComponent, "eui-masthead", never, { "icon": { "alias": "icon"; "required": false; }; "centeredMasthead": { "alias": "centeredMasthead"; "required": false; }; }, { "logoClicked": "logoClicked"; }, never, ["*"], false, never>;
}

declare class EuiReadonlyLabelComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiReadonlyLabelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiReadonlyLabelComponent, "eui-readonly-label", never, {}, {}, never, ["*"], false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiLabelComponent {
    private cdRef;
    /** @internal */
    class: string;
    /**
     * Sets for attribute of label
     *
     * @category Input
     */
    for: string;
    /**
     * Sets whether the required indicator should be shown
     *
     * @category Input
     */
    required: boolean;
    /**
     * Sets whether the label should be displayed in the error state
     *
     * @category Input
     */
    errorState: boolean;
    /**
     * Sets whether the label should be displayed in a disabled state
     *
     * @category Input
     */
    disabled: boolean;
    constructor(cdRef: ChangeDetectorRef);
    /** @internal */
    checkChanges(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiLabelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiLabelComponent, "eui-label", never, { "for": { "alias": "for"; "required": false; }; "required": { "alias": "required"; "required": false; }; "errorState": { "alias": "errorState"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, {}, never, ["*", "[euiLabelSuffix]"], false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiFormFieldComponent implements AfterContentInit, AfterViewInit, OnDestroy {
    private cdRef;
    private ref;
    /** @internal */
    class: string;
    /** @internal */
    hostWidth: string;
    /** @internal */
    matFormControl: MatFormFieldControl<unknown>;
    /** @internal */
    matInput: MatInput;
    /** @internal */
    euiLabel: EuiLabelComponent;
    /** @internal */
    matFormField: MatFormField;
    /** @internal */
    _prefixChildren: QueryList<MatPrefix>;
    /** @internal */
    _suffixChildren: QueryList<MatSuffix>;
    /**
     * Appearance mode of the mat-form-field element
     *
     * @category Input
     */
    appearance: string;
    /**
     * When true the 'eui-input--no-margin' class will be applied to the mat-form-field
     * Note: this needs to be set to 'false' when showing validation errors in the <mat-error> section, so that they display correctly
     *
     * @category Input
     */
    hideMargins: boolean;
    /**
     * Sets the width of the component
     *
     * @category Input
     */
    set width(val: string);
    /**
     * Controls whether the legacy floating label is displayed or a label above the form field
     *
     * @category Input
     */
    useLegacyFloatingLabel: boolean;
    /**
     * Controls whether the form field should be displayed as readonly
     *
     * @category Input
     */
    get readonly(): boolean;
    set readonly(value: boolean);
    /**
     * Contains style key-value pairs for mat-form-field element
     */
    /** @internal */
    fieldStyles: {};
    /** @internal */
    isBeforeViewInit$$: BehaviorSubject<boolean>;
    /** @internal */
    showFormElements: {
        matPrefix: boolean;
        matTextPrefix: boolean;
        matSuffix: boolean;
        matTextSuffix: boolean;
    };
    /** @internal */
    destroy: Subject<boolean>;
    /** @internal */
    get elementRef(): ElementRef;
    /** @internal */
    get id(): string;
    private _id;
    private _readonly;
    constructor(cdRef: ChangeDetectorRef, ref: ElementRef);
    /** @internal */
    ngAfterContentInit(): void;
    /** @internal */
    ngAfterViewInit(): void;
    /** @internal */
    ngOnDestroy(): void;
    private checkFormElements;
    private overrideReadonlyProperty;
    private updateLabel;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiFormFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiFormFieldComponent, "eui-form-field", never, { "appearance": { "alias": "appearance"; "required": false; }; "hideMargins": { "alias": "hideMargins"; "required": false; }; "width": { "alias": "width"; "required": false; }; "useLegacyFloatingLabel": { "alias": "useLegacyFloatingLabel"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; }, {}, ["matFormControl", "matInput", "euiLabel", "_prefixChildren", "_suffixChildren"], ["eui-label", "eui-readonly-label", "mat-label", "*", "[matTextPrefix]", "[matPrefix], [matIconPrefix]", "[matTextSuffix]", "[matSuffix], [matIconSuffix]", "mat-hint", "mat-error"], false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
declare const FILTER_OPERATORS: {
    readonly string: readonly [{
        readonly key: "contains";
        readonly expression: "{FIELD_NAME} co '{VALUE}'";
    }, {
        readonly key: "doesNotContain";
        readonly expression: "not ({FIELD_NAME} co '{VALUE}')";
    }, {
        readonly key: "equals";
        readonly expression: "{FIELD_NAME} eq '{VALUE}'";
    }, {
        readonly key: "doesNotEqual";
        readonly expression: "{FIELD_NAME} ne '{VALUE}'";
    }, {
        readonly key: "beginsWith";
        readonly expression: "{FIELD_NAME} sw '{VALUE}'";
    }, {
        readonly key: "doesNotBeginWith";
        readonly expression: "not ({FIELD_NAME} sw '{VALUE}')";
    }, {
        readonly key: "endsWith";
        readonly expression: "{FIELD_NAME} ew '{VALUE}'";
    }, {
        readonly key: "doesNotEndWith";
        readonly expression: "not ({FIELD_NAME} ew '{VALUE}')";
    }];
    readonly number: readonly [{
        readonly key: "equals";
        readonly expression: "{FIELD_NAME} eq {VALUE}";
    }, {
        readonly key: "doesNotEqual";
        readonly expression: "{FIELD_NAME} ne {VALUE}";
    }, {
        readonly key: "isGreaterThan";
        readonly expression: "{FIELD_NAME} gt {VALUE}";
    }, {
        readonly key: "isGreaterThanOrEqualTo";
        readonly expression: "{FIELD_NAME} ge {VALUE}";
    }, {
        readonly key: "isLessThan";
        readonly expression: "{FIELD_NAME} lt {VALUE}";
    }, {
        readonly key: "isLessThanOrEqualTo";
        readonly expression: "{FIELD_NAME} le {VALUE}";
    }];
    readonly date: readonly [{
        readonly key: "equals";
        readonly expression: "({FIELD_NAME} ge '{SELECTED_DATE}') and ({FIELD_NAME} lt '{NEXT_DAY}')";
    }, {
        readonly key: "doesNotEqual";
        readonly expression: "({FIELD_NAME} lt '{SELECTED_DATE}') or ({FIELD_NAME} ge '{NEXT_DAY}')";
    }, {
        readonly key: "isAfter";
        readonly expression: "{FIELD_NAME} ge '{NEXT_DAY}'";
    }, {
        readonly key: "isOnOrAfter";
        readonly expression: "{FIELD_NAME} ge '{SELECTED_DATE}'";
    }, {
        readonly key: "isBefore";
        readonly expression: "{FIELD_NAME} lt '{SELECTED_DATE}'";
    }, {
        readonly key: "isOnOrBefore";
        readonly expression: "{FIELD_NAME} lt '{NEXT_DAY}'";
    }];
};

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

interface EuiFilterGroup {
    matchSelection: 'and' | 'or';
    conditionsAndGroups: (EuiFilterCondition | EuiFilterGroup)[];
}
interface EuiFilterCondition {
    fieldName?: string;
    operator?: EuiFilterFieldSingleOperatorKey;
    value?: string | boolean | number | null | undefined;
}
interface EuiFilterField {
    name: string;
    type: EuiFilterFieldDataType;
    label: string;
}
interface EuiFilterLabelTranslations {
    sidesheetTitle: string;
    customFilterIcon: {
        tooltip: string;
        badgeDescription: string;
    };
    clearFiltersBtn: string;
    sidesheet: {
        actions: {
            resetBtn: string;
            cancelBtn: string;
            applyBtn: string;
        };
        filterGroup: {
            matchSelection: {
                ariaLabel: string;
                radio: {
                    and: string;
                    or: string;
                };
            };
            actions: {
                addConditionBtn: string;
                addGroupBtn: string;
            };
            individualActions: {
                duplicateTooltip: string;
                clearTooltip: string;
            };
            condition: {
                selectField: string;
                operator: {
                    description: string;
                    selectableValue: {
                        string?: {
                            contains: string;
                            doesNotContain: string;
                            equals: string;
                            doesNotEqual: string;
                            beginsWith: string;
                            doesNotBeginWith: string;
                            endsWith: string;
                            doesNotEndWith: string;
                        };
                        number?: {
                            equals: string;
                            doesNotEqual: string;
                            isGreaterThan: string;
                            isGreaterThanOrEqualTo: string;
                            isLessThan: string;
                            isLessThanOrEqualTo: string;
                        };
                        date?: {
                            equals: string;
                            doesNotEqual: string;
                            isAfter: string;
                            isOnOrAfter: string;
                            isBefore: string;
                            isOnOrBefore: string;
                        };
                    };
                };
                input: {
                    date?: string;
                    value: string;
                    string?: string;
                    number?: string;
                    boolean?: {
                        ariaLabel: string;
                        true: string;
                        false: string;
                    };
                };
            };
        };
    };
}
interface EuiCustomFiltersConfig {
    fields: EuiFilterField[];
    labelTranslations: EuiFilterLabelTranslations;
}
interface EuiFilterGroupOrConditionDuplicateData {
    parent: EuiFilterGroup;
    conditionOrFilterGroup: EuiFilterCondition | EuiFilterGroup;
}
interface EuiFilterGroupClearData {
    parent: EuiFilterGroup;
    filterGroup: EuiFilterGroup;
}
interface EuiFilterConditionClearData {
    parent: EuiFilterGroup;
    condition: EuiFilterCondition;
}
type EuiFilterFieldDataTypeWithOperator = keyof typeof FILTER_OPERATORS;
type EuiFilterFieldOperators = typeof FILTER_OPERATORS[EuiFilterFieldDataTypeWithOperator];
type EuiFilterFieldSingleOperatorKey = EuiFilterFieldOperators[number]['key'];
type EuiFilterFieldDataType = EuiFilterFieldDataTypeWithOperator | 'boolean';

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiSidesheetHeaderDirective {
    viewContainerRef: ViewContainerRef;
    constructor(viewContainerRef: ViewContainerRef);
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiSidesheetHeaderDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<EuiSidesheetHeaderDirective, "[euiSidesheetHeader]", never, {}, {}, never, never, false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiSidesheetDirective {
    viewContainerRef: ViewContainerRef;
    constructor(viewContainerRef: ViewContainerRef);
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiSidesheetDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<EuiSidesheetDirective, "[euiSidesheet]", never, {}, {}, never, never, false, never>;
}

declare class EuiSidesheetContentService {
    get contentComponent(): any;
    set contentComponent(comp: any);
    private _contentComponent;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiSidesheetContentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EuiSidesheetContentService>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiSidesheetComponent implements OnInit, OnDestroy, AfterContentChecked {
    private sidesheetRef;
    config: EuiSidesheetConfig;
    private sidesheetContent;
    private renderer;
    private injector;
    private cdr;
    title: string;
    subTitle: string;
    headerBackground: string;
    icon: string;
    width: string;
    padding: string;
    direction: string;
    closeAriaLabel: string;
    disableClose: boolean;
    data: any;
    testId: string;
    /** @internal */
    sheetDirective?: EuiSidesheetDirective;
    /** @internal */
    sheetHeaderDirective?: EuiSidesheetHeaderDirective;
    /** @internal */
    sidesheetclose?: ElementRef;
    /** @internal */
    sidesheetWrapper: ElementRef;
    /** @internal */
    private titleTextElement;
    /** @internal */
    private subTitleTextElement;
    /** @internal */
    animationState: 'void' | 'enter' | 'leave';
    /** @internal */
    animationStateChanged: EventEmitter<AnimationEvent$1>;
    /** @internal */
    onOpenSubject: ReplaySubject<void>;
    /** @internal */
    titleTooltip: string | null;
    /** @internal */
    subtitleTooltip: string | null;
    /**
     * Checks the screen width to see if it is 'mobile' size
     *
     * @internal */
    get isMobile(): boolean;
    /**
     * Gets the desired sidesheet width, overriding to 100% if the screen width is 'mobile' size
     *
     * @internal
     */
    get sidesheetWidth(): string;
    get contentWidth(): string;
    get translateXDirection(): string;
    private titleTextElementChecked;
    constructor(sidesheetRef: EuiSidesheetRef, config: EuiSidesheetConfig, sidesheetContent: EuiSidesheetContentService, renderer: Renderer2, injector: Injector, cdr: ChangeDetectorRef, title: string, subTitle: string, headerBackground: string, icon: string, width: string, padding: string, direction: string, closeAriaLabel: string, disableClose: boolean, data: any, testId: string);
    /** @ignore */
    ngOnInit(): void;
    /** @ignore */
    ngOnDestroy(): void;
    /** @ignore */
    ngAfterContentChecked(): void;
    /**
     * Gets the CSS background class based on the passed in colour name.
     *
     * @param colour Valid values: 'black', 'blue', 'gray', 'green', 'orange', 'pink', 'purple', 'red', 'white', 'yellow', 'primary', 'accent', 'warn'
     *
     *    Deprecated values: 'gunmetal', 'iris-blue', 'iris-tint', 'iris-shade', 'iris-pastel', 'asher-gray', 'phoenix-red', 'phoenix-tint', 'phoenix-shade', 'phoenix-pastel',
     *    'corbin-orange', 'corbin-tint', 'corbin-shade', 'corbin-pastel', 'aspen-green', 'aspen-tint', 'aspen-shade', 'aspen-pastel',
     *    'tiki-sunrise', 'tiki-tint', 'tiki-shade', 'tiki-pastel', 'maui-sunset', 'maui-tint', 'maui-shade', 'maui-pastel',
     *    'azalea-pink', 'azalea-tint', 'azalea-shade', 'azalea-pastel', 'black-3', 'black-4', 'black-6', 'black-7', 'black-9', 'black-b', 'black-c'
     * @internal
     */
    getBackgroundClass(colour: string): string;
    /** @ignore */
    onAnimationStart(event: AnimationEvent$1): void;
    /** @ignore */
    onAnimationDone(event: AnimationEvent$1): void;
    /**
     * An observable that fires when the sheet has been opened and the slide animation has completed.
     *
     * @internal */
    onOpen(): Observable<void>;
    /** @ignore */
    startExitAnimation(): void;
    /**
     * Loads the components that were passed to the sidesheet.
     *
     * @internal */
    loadComponents(): void;
    /**
     * Closes the sidesheet.
     *
     * @internal */
    close(): void;
    /**
     * Sets focus within the sidesheet
     *
     * @internal */
    setFocus(): void;
    /**
     * Creates a component and assigns it to the view container.
     */
    private createComponent;
    /**
     * Builds an injector to pass to the content and header components
     */
    private buildInjector;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiSidesheetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiSidesheetComponent, "eui-sidesheet", never, {}, {}, never, never, false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * A reference to a sidesheet component.
 */
declare class EuiSidesheetRef {
    private overlayRef;
    componentInstance?: EuiSidesheetComponent;
    private _beforeClose;
    private _afterClosed;
    private _closeClicked;
    constructor(overlayRef: OverlayRef);
    /**
     * A method to get an observable that triggers after the sidesheet is closed.
     */
    afterClosed(): Observable<any>;
    /**
     * A method to get an observable that triggers before the sidesheet is closed.
     */
    beforeClose(): Observable<any>;
    /**
     * A method to get an observable that triggers when the sidesheet is closed via the header close button, escape key or backdrop.
     */
    closeClicked(): Observable<any>;
    /**
     * Closes the sidesheet.
     */
    close(data?: any): void;
    private closeSidesheet;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/** @internal */
declare const SIDESHEET_TITLE: InjectionToken<string>;
/** @internal */
declare const SIDESHEET_SUB_TITLE: InjectionToken<string>;
/** @internal */
declare const SIDESHEET_HEADER_COLOUR: InjectionToken<string>;
/** @internal */
declare const SIDESHEET_ICON: InjectionToken<string>;
/** @internal */
declare const SIDESHEET_WIDTH: InjectionToken<string>;
/** @internal */
declare const SIDESHEET_PADDING: InjectionToken<string>;
/** @internal */
declare const SIDESHEET_TEXT_DIRECTION: InjectionToken<string>;
/** @internal */
declare const SIDESHEET_CLOSE_ARIA_LABEL: InjectionToken<string>;
/** @internal */
declare const SIDESHEET_DISABLE_CLOSE: InjectionToken<boolean>;
/** @internal */
declare const EUI_SIDESHEET_TEST_ID: InjectionToken<string>;
/** @internal */
declare const EUI_SIDESHEET_REF: InjectionToken<EuiSidesheetRef>;
/** @internal */
declare const SIDESHEET_INTERNAL_CLOSE_ID = "eui_sidesheet_internal_close_click";
/**
 * Injection token used to inject sidesheet data into component.
 */
declare const EUI_SIDESHEET_DATA: InjectionToken<any>;
/**
 * Configuration options for a sidesheet opened through EuiSidesheetService.
 */
declare abstract class EuiSidesheetConfig {
    /** The title shown in the header bar of the sidesheet. */
    title: string;
    /** Optional sub-title shown in the header bar of the sidesheet. */
    subTitle?: string;
    /** The background colour of the header bar. */
    headerColour?: string;
    /** When true, the body color of the sidesheet will switch to white (light theme) or black (dark theme) */
    useAltBodyColor?: boolean;
    /** Optional icon that can be shown in the header bar. */
    icon?: string;
    /** The desired width of the sidesheet. */
    width?: string;
    /** The left/right padding of the sidesheet. */
    padding?: string;
    /** The direction the text should display. Also affects which side of the screen the sidesheet will come in from. */
    textDirection?: Direction;
    /** The class to assign to the backdrop panel. */
    panelClass?: string;
    /** Whether or not a backdrop overlay is shown. */
    hasBackdrop?: boolean;
    /** The class to assign to the backdrop overlay. */
    backdropClass?: string;
    /** The value to be assigned to the aria-label attribute for close icon */
    closeAriaLabel?: string;
    /** Data that will be passed to the component within the sidesheet */
    data?: any;
    /** Test Id to be applied to the sidesheet contents */
    testId?: string;
    /** Setting this to true will stop the sidesheet from closing when the close button or backdrop are clicked */
    disableClose?: boolean;
    /*** If set to true, the close button in the header bar will be given focus when the sheet is opened or when a sheet on top of it is closed */
    autoFocus?: boolean;
    /*** If provided, the component will be displayed between the header title and the close button */
    headerComponent?: any;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiSidesheetConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EuiSidesheetConfig>;
}
/** @internal */
declare const DEFAULT_CONFIG: EuiSidesheetConfig;
/**
 * The action taken when the escape key is pressed
 */
declare enum EuiSidesheetEscapeKeyAction {
    None = "None",
    CloseTop = "CloseTop",
    CloseAll = "CloseAll"
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * A service that opens sidesheets (with optional background overlays).
 */
declare class EuiSidesheetService {
    private injector;
    private overlay;
    private sidesheetContent;
    /** @ignore */
    get contentComponent(): any;
    /** @ignore */
    set contentComponent(comp: any);
    /**
     * Returns the sidesheet that is currently displayed
     */
    get topSidesheet(): EuiSidesheetRef | undefined;
    private _sidesheetRefs;
    private _contentComponent;
    private _escapeKeyAction;
    private _triggerElement;
    constructor(injector: Injector, overlay: Overlay, sidesheetContent: EuiSidesheetContentService);
    /**
     * Opens a new instance of a sidesheet, sliding out from the side of the screen.
     *
     * @param component The component to show in the sidesheet.
     * @param config Configuration options for the sidesheet. See the [[EuiSidesheetConfig]] interface for more information.
     */
    open(component: any, config: EuiSidesheetConfig): EuiSidesheetRef;
    /**
     *  Closes the last opened sidesheet (top of the stack).
     *
     *  @param data Data that can be passed to the parent component via the EuiSidesheetRef beforeClose and afterClosed observables
     */
    close(data?: any): void;
    /**
     *  Closes all open sidesheets.
     *
     *  @param data Data that can be passed to the parent component via the EuiSidesheetRef beforeClose and afterClosed observables
     */
    closeAll(data?: any): void;
    /**
     *  Sets what should happen when the escape key is pressed.
     */
    setEscapeKeyAction(escapeKeyAction: EuiSidesheetEscapeKeyAction): void;
    private removeSidesheetRef;
    private getOverlayConfig;
    private createInjector;
    private attachDialogContainer;
    private handleKeyDown;
    private getTopSidesheetRef;
    private setTopSidesheetFocus;
    private setSidesheetWidths;
    private getWidthUpdateRemoving;
    private getStartingWidthNum;
    private getNumVal;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiSidesheetService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EuiSidesheetService>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiCustomFilterService {
    private readonly _sidesheetService;
    private readonly INITIAL_STATE;
    private readonly activeFilters;
    readonly activeFilters$: Observable<EuiFilterGroup>;
    readonly activeFiltersCount$: Observable<number>;
    private readonly moment;
    fields: EuiFilterField[];
    constructor(_sidesheetService: EuiSidesheetService);
    openSideSheet$({ fields, labelTranslations }: EuiCustomFiltersConfig, component: Type<any>): Observable<string>;
    clearFilters(): void;
    resetFilters(rootFilterGroup: EuiFilterGroup): void;
    cancel(): void;
    apply(rootFilterGroup: EuiFilterGroup): void;
    addCondition(filterGroup: EuiFilterGroup): void;
    addGroup(filterGroup: EuiFilterGroup): void;
    duplicateConditionOrGroup(parent: EuiFilterGroup, conditionOrGroup: EuiFilterCondition | EuiFilterGroup): void;
    clearGroup(parent: EuiFilterGroup, filterGroup: EuiFilterGroup): void;
    clearCondition(parent: EuiFilterGroup, condition: EuiFilterCondition): void;
    hasInvalidCondition(filterGroup: EuiFilterGroup): boolean;
    haveActiveFiltersNotChanged(rootFilterGroup: EuiFilterGroup): boolean;
    private isConditionEmpty;
    private getActiveFiltersCountRecursively;
    private isFilterGroup;
    private getConditionsAndGroupsSeparately;
    private mapToFilterExpression;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiCustomFilterService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EuiCustomFilterService>;
}

declare class EuiSearchComponent implements OnInit {
    private readonly _customFilterService;
    private readonly _destroyRef;
    /**
     * Expose HTML element to allow HTML attribute customizations.
     *
     * @internal */
    inputElementRef: ElementRef<HTMLInputElement>;
    /**
     * Configuration object for enabling and customizing the custom filters feature.
     *
     * If provided, this input enables the custom filters functionality, allowing users to define and apply complex filtering criteria.
     * The `EuiCustomFiltersConfig` interface defines the structure of this configuration.
     *
     * @category Input
     * @example
     * ```html
     *  <eui-search [customFiltersConfig]="customFiltersConfig" />
     * ```
     * ```typescript
     * // Example of providing a custom filters configuration:
     * import { EuiCustomFiltersConfig } from '@elemental-ui/core';
     *
     * customFiltersConfig: EuiCustomFiltersConfig = {
     *  fields: [
     *    { name: 'user_name', type: 'string', label: 'User name' },
     *    { name: 'report_date', type: 'date', label: 'Report date' },
     *  ],
     *  labelTranslations: {
     *    // ... other configuration properties ...
     *  }
     * };
     * ```
     */
    customFiltersConfig?: EuiCustomFiltersConfig;
    /**
     * Allows the placeholder attribute of the input field to be set
     *
     * @category Input
     */
    placeholder: string;
    /**
     * Allows a FormControl to be passed to the component so that state and value changes can be viewed
     *
     * @category Input
     */
    searchControl: FormControl<string>;
    /**
     * Emits an event when the search icon is clicked
     *
     * @category Output
     * @event
     */
    searchIconClick: EventEmitter<any>;
    /**
     * Emits an event when the custom filters changed.
     *
     * This event provides the newly parsed filter expression as a string.
     * The filter expression adheres to a specific syntax (e.g., `((not (user_name co 'a')))`).
     *
     * @category Output
     * @type {string}
     * @description The emitted string represents the parsed filter expression.
     * @example
     * ```html
     *  <eui-search (customFiltersChanged)="onCustomFiltersChanged($event)" />
     * ```
     * ```typescript
     * // Example callback to the event:
     * onCustomFiltersChanged(filterExpression: string): void {
     *  console.log(filterExpression);
     * }
     * ```
     */
    customFiltersChanged: EventEmitter<string>;
    /**
     * Sets the component width
     *
     * @category Input
     */
    width: string;
    /** @internal */
    hasSearchIconClickHandler: boolean;
    /**
     * Sets the disabled state of the component
     *
     * @category Input
     */
    set disabled(value: boolean);
    readonly activeFiltersCount$: rxjs.Observable<number>;
    /**
     * Gets the disabled state of the component
     */
    /** @internal */
    get disabled(): boolean;
    private _disabled;
    constructor(_customFilterService: EuiCustomFilterService, _destroyRef: DestroyRef);
    /** @internal */
    ngOnInit(): void;
    /**
     * Clears the input field when the close icon is clicked
     *
     * @internal */
    clearSearch(): void;
    /**
     * Emits an event when the search icon is clicked
     *
     * @internal */
    searchIconClicked($event: MouseEvent): void;
    openCustomFiltersSidesheet(): void;
    onClearFiltersClick(): void;
    private setDisabled;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiSearchComponent, [{ self: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiSearchComponent, "eui-search", never, { "customFiltersConfig": { "alias": "customFiltersConfig"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "searchControl": { "alias": "searchControl"; "required": false; }; "width": { "alias": "width"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, { "searchIconClick": "searchIconClick"; "customFiltersChanged": "customFiltersChanged"; }, never, never, false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Smooth Scrollbar wrapper
 *
 * @see https://www.npmjs.com/package/smooth-scrollbar
 * @see https://idiotwu.github.io/smooth-scrollbar
 * @see https://github.com/idiotWu/smooth-scrollbar
 */
declare class EuiScrollComponent implements OnInit, AfterViewInit, AfterViewChecked, OnDestroy {
    private zone;
    /** @internal */
    class: string;
    /** @internal */
    scrollContainer: ElementRef;
    /**
     * Turns the scroll bar real event dispatching on document.
     *
     * @category Input
     */
    dispatchEvent: boolean;
    /**
     * Smooth scrollbar options
     *
     * @category Input
     * @see https://github.com/idiotWu/smooth-scrollbar/blob/develop/docs/README.md#available-options-for-scrollbar
     */
    set options(options: Partial<ScrollbarOptions>);
    /** @internal */
    set scrollStatus(scrollStatus: ScrollStatus);
    private _scrollStatus;
    private instance;
    private settings;
    private defaultSettings;
    constructor(zone: NgZone);
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    ngAfterViewInit(): void;
    /** @internal */
    ngAfterViewChecked(): void;
    /** @internal */
    ngOnDestroy(): void;
    /**
     * Forces scrollbar to update geometry information.
     *
     * @see https://github.com/idiotWu/smooth-scrollbar/blob/develop/docs/api.md#scrollbarupdate
     * @internal */
    update(): void;
    /**
     * Scrolls to given position with easing function.
     *
     * @see https://github.com/idiotWu/smooth-scrollbar/blob/develop/docs/api.md#scrollbarscrollto
     *
     * @param x - Scrolling offset in x-axis.
     * @param y - Scrolling offset in y-axis.
     * @param duration - Easing duration, default is 0 (non-easing).
     * @param options - Smooth Scrollbar ScrollToOptions.
     * @internal */
    scrollTo(x: number, y: number, duration?: number, options?: Partial<ScrollToOptions>): void;
    /**
     * Scrolls the target element into visible area of scrollbar, likes DOM method element.scrollIntoView().
     * This method will be helpful when you want to create some anchors.
     *
     * @see https://github.com/idiotWu/smooth-scrollbar/blob/develop/docs/api.md#scrollbarscrollintoview
     *
     * @param elem - Target element.
     * @param options - Smooth Scrollbar ScrollIntoViewOptions.
     * @internal */
    scrollIntoView(elem: HTMLElement, options?: Partial<ScrollIntoViewOptions>): void;
    /**
     * Returns scrolling status observable
     *
     * @internal
     */
    getScrollStatus(): BehaviorSubject<ScrollStatus>;
    private init;
    private createInstance;
    private destroyInstance;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiScrollComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiScrollComponent, "eui-scroll", never, { "dispatchEvent": { "alias": "dispatchEvent"; "required": false; }; "options": { "alias": "options"; "required": false; }; }, {}, never, ["*"], false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
/**
 * Interface for EUI Select option
 */
interface EuiSelectOption {
    /** @internal */
    [key: string]: any;
    /**
     * Option text to display. Will appear as selected value when select is closed.
     */
    display: string;
    /**
     * Second line of option text to display in dropped select panel.
     */
    displayDetail?: string;
    /**
     * Name of eui-icon name to display with option. Selected option icon will also appear in control when select is closed.
     */
    icon?: string;
    /**
     * Value to return when option is selected. Can be a simple value type (number, string, etc.) or a Typescript object.
     */
    value: any;
    /**
     * Set to true to diable option. Disabled options cannot be selected.
     */
    disabled?: boolean;
}
/**
 * Interface for feedback messages to allow i18n of eui-select.
 */
interface EuiSelectFeedbackMessages {
    /**
     * Default: "{{value}} selected"<br/><br/>
     * Text to use for multi-select when adding "(X <var>selected</var>)" to label. <var>{{value}}</var> placeholder will be replaced with the number of selected options.
     */
    selected: string;
    /**
     * Default: "Clear"<br/><br/>
     * Tooltip text for clear option button
     */
    clear: string;
    /**
     * Default: "Search"<br/><br/>
     * Placeholder text for search control when select is dropped
     */
    search: string;
    /**
     * Default: "+1 other"<br/><br/>
     * Text to use for multi-select value when two options are selected, "SelectedValue (<var>plusOther</var>)"
     */
    plusOther: string;
    /**
     * Default: "+{{value}} others"<br/><br/>
     * Plural version of plusOther. Text to use for multi-select value when more than two options are selected. <var>{{value}}</var> placeholder will be replaced with the number of selected options.
     */
    plusOtherPlural: string;
    /**
     * Default: "Unsupported character"<br/><br/>
     * Text to display when an unsupported character has been entered in the search control
     */
    unsupportedCharacter: string;
    /**
     * Default: "No results"<br/><br/>
     * Text to display when search finds no results.
     */
    noResults: string;
    /**
     * Default: "Clear all"<br/><br/>
     * Button text for multi-select "Clear all" button
     */
    clearAll: string;
    /**
     * Default: "OK"<br/><br/>
     * Button text for multi-select "OK" button
     */
    ok: string;
    /**
     * Default: "Use the arrow keys to navigate the options"<br/><br/>
     * Aria text for keyboard helper in search.
     */
    keyboardOptionsListAria: string;
    /**
     * Default: "Select all"<br/><br/>
     * Button text for multi-select "Select all" button
     */
    selectAll?: string;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiSelectComponent implements OnInit, OnDestroy, ControlValueAccessor, AfterViewInit {
    private cdRef;
    private directionality;
    private sidesheetDirection?;
    /** @internal */
    class: string;
    /** @internal */
    searchInput: EuiSearchComponent;
    /** @internal */
    select: MatSelect;
    /** @internal */
    formField: EuiFormFieldComponent;
    /** @internal */
    optionsScroll: EuiScrollComponent;
    /** @internal */
    multiSubmitClear: MatButton;
    /** @internal */
    multiSubmitOk: MatButton;
    /** @internal */
    keyboardHelper: ElementRef;
    /** @internal */
    _prefixChildren: QueryList<MatPrefix>;
    /** @internal */
    _suffixChildren: QueryList<MatSuffix>;
    /**
     * Sets whether the component is required or not
     *
     * @category Input
     */
    required: boolean;
    /**
     * Sets whether the component is read-only or not
     *
     * @category Input
     */
    readonly: boolean;
    /**
     * Sets whether the component's read-only label is abbreviated or not
     *
     * @category Input
     */
    readonlyAbbr: boolean;
    /**
     * Sets the component width.<br/>
     * <br/>
     * <strong>Note:</strong> When using a multi-select and setting width it is up to the developer to keep the control from
     * getting too narrow to display the options footer buttons.
     *
     * @category Input
     */
    width: string;
    /**
     * Toggle pending state
     *
     * @category Input
     */
    isPending: boolean;
    /**
     * Set select Form Control.
     *
     * Possible application areas: Set default selected values
     *
     * @category Input
     */
    inputControl: FormControl<string | string[]>;
    /**
     * Specify Form Control to filter input, that allows to add validators.
     *
     * @category Input
     */
    searchFormControl: FormControl<string>;
    /**
     * Set custom filter function, what specify the options filtering. Example: Search input text exact match to options or includes options.
     *
     * @category Input
     */
    filterFunction: (option: EuiSelectOption, searchInputValue: string) => boolean;
    /**
     * Input placeholder
     *
     * @category Input
     */
    placeholder: string;
    /**
     * Title of the select. Set to null to omit label (this will also override the multi-select "(X selected)" addition to a blank label).
     *
     * @category Input
     */
    label: string | null;
    /**
     * Controls whether the legacy floating label is displayed or a label above the form field. Overridden by setting label = null.
     *
     * @category Input
     */
    useLegacyFloatingLabel: boolean;
    /**
     * Toggle multiple chooser<br/>
     * <br/>
     * <strong>Note:</strong> When using a multi-select and setting width it is up to the developer to keep the control from
     * getting too narrow to display the options footer buttons.
     *
     * @category Input
     */
    multiple: boolean;
    /**
     * When true the 'eui-input--no-margin' class won't be applied to the mat-form-field<br/>
     * <br/>
     * <strong>Note:</strong> this needs to be set to 'true' when showing validation errors in the <mat-error> section, so that they display correctly
     *
     * @category Input
     */
    enableFormFieldMargin: boolean;
    /**
     * When true the clear selection button in the title container will not be shown
     *
     * @category Input
     */
    hideClearButton: boolean;
    /**
     * When true the footer at the bottom of the options panel will not be shown
     *
     * @category Input
     */
    hidePanelFooter: boolean;
    /**
     * When true, the search bar at the top of the options panel will not be shown
     *
     * @category Input
     */
    hideSearch: boolean;
    /**
     * Disable select input
     *
     * @category Input
     */
    set disabled(value: boolean);
    /**
     * Optional text to display when all options are selected instead of "X (+5 others)"
     *
     * @category Input
     */
    allSelectedText: string;
    /** @internal */
    get showAllSelectedText(): boolean;
    /**
     * Provide text to override the default text used within the component
     *
     * @category Input
     */
    feedbackMessages: EuiSelectFeedbackMessages;
    /** @internal
     * Default feedback messages in English.
     * If new properties are added to EuiSelectFeedbackMessages they should be
     * marked as nullable and default values added here.
    */
    get defaultFeedbackMessages(): EuiSelectFeedbackMessages;
    /**
     * Triggered when search input changed
     *
     * @category Output
     * @event
     */
    searchFieldChange: EventEmitter<string>;
    /**
     * Triggered when selected options changed
     *
     * @category Output
     * @event
     */
    selectionChange: EventEmitter<EuiSelectOption | EuiSelectOption[]>;
    /**
     * Trigger when open state changed
     *
     * @category Output
     * @event
     */
    openChange: EventEmitter<boolean>;
    /**
     * Trigger when select clicked
     *
     * @category Output
     * @event
     */
    triggerClick: EventEmitter<MouseEvent>;
    /**
     * Trigger when options cleared
     *
     * @category Output
     * @event
     */
    optionsClear: EventEmitter<EuiSelectOption[]>;
    /** @internal */
    _disabled: boolean;
    /** @internal */
    _options: Array<EuiSelectOption>;
    /** @internal */
    _sortFunction: (first: EuiSelectOption, second: EuiSelectOption) => number;
    /** @internal */
    error: BehaviorSubject<ValidationErrors>;
    /** @internal */
    filteredOptions: BehaviorSubject<EuiSelectOption[]>;
    /** @internal */
    hasResults: boolean;
    /** @internal */
    direction: string;
    /** @internal */
    showFormElements: {
        matPrefix: boolean;
        matTextPrefix: boolean;
        matSuffix: boolean;
        matTextSuffix: boolean;
    };
    /**
     * When greater than 0, if the number of options is less than or equal to the value, the search bar will be hidden.
     * If the 'hideSearch' input is set to true, the search bar will be hidden regardless of this value.
     */
    /** @internal */
    readonly autoHideSearchLimit = 5;
    /**
     * Set options
     *
     * @category Input
     */
    set options(options: Array<EuiSelectOption>);
    /** @internal */
    get showPrefixIcon(): boolean;
    /**
     * Set sort function to specify search input filter operation
     *
     * @category Input
     * @default not sorting
     */
    set sortFunction(value: (first: EuiSelectOption, second: EuiSelectOption) => number);
    private destroy;
    /** @internal */
    get plusOthersText(): string;
    /** @internal */
    get selectedText(): string;
    /** @internal */
    get showLabel(): boolean;
    /** @internal */
    get isRequired(): boolean;
    /** @internal */
    get enabledOptions(): EuiSelectOption[];
    /** @internal */
    get allOptionsSelected(): boolean;
    constructor(cdRef: ChangeDetectorRef, directionality: Directionality, sidesheetDirection?: string);
    /** @internal */
    ngAfterViewInit(): void;
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    ngOnDestroy(): void;
    /** @internal */
    checkFormElements(): void;
    /** @internal */
    defaultFilter: (option: EuiSelectOption, searchInputValue: string) => boolean;
    /** @internal */
    filterValueChange: () => void;
    /** @internal */
    filterOptions(): void;
    /** @internal */
    scrollActiveOptionIntoView(): void;
    /** @internal */
    onOptionFocus(event: FocusEvent): void;
    /** @internal */
    keyboardHelperKeyDown(event: KeyboardEvent): void;
    /** @internal */
    submitButtonsKeyDown(event: KeyboardEvent): void;
    /** @internal */
    onOptionChange(event: MatSelectChange): void;
    /** @internal */
    findOptionByValue(value: any): EuiSelectOption;
    /** @internal */
    validate: () => boolean;
    /** @internal */
    onDropdownOpen(): void;
    /** @internal */
    clearSelectionsOutside(): void;
    /** @internal */
    clearSelectionsInside(isFromOutside?: boolean): void;
    /** @internal */
    selectAllInside(isFromOutside?: boolean): void;
    /** @internal */
    close(): void;
    /** @internal */
    onTouched(): void;
    /** @internal */
    registerOnChange(onChange: (value: any | any[] | null) => void): void;
    /** @internal */
    registerOnTouched(onTouched: () => void): void;
    /** @internal */
    setDisabledState(isDisabled: boolean): void;
    /** @internal */
    writeValue(value: any | any[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiSelectComponent, [null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiSelectComponent, "eui-select", never, { "required": { "alias": "required"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "readonlyAbbr": { "alias": "readonlyAbbr"; "required": false; }; "width": { "alias": "width"; "required": false; }; "isPending": { "alias": "isPending"; "required": false; }; "inputControl": { "alias": "inputControl"; "required": false; }; "searchFormControl": { "alias": "searchFormControl"; "required": false; }; "filterFunction": { "alias": "filterFunction"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "label": { "alias": "label"; "required": false; }; "useLegacyFloatingLabel": { "alias": "useLegacyFloatingLabel"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; "enableFormFieldMargin": { "alias": "enableFormFieldMargin"; "required": false; }; "hideClearButton": { "alias": "hideClearButton"; "required": false; }; "hidePanelFooter": { "alias": "hidePanelFooter"; "required": false; }; "hideSearch": { "alias": "hideSearch"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "allSelectedText": { "alias": "allSelectedText"; "required": false; }; "feedbackMessages": { "alias": "feedbackMessages"; "required": false; }; "options": { "alias": "options"; "required": false; }; "sortFunction": { "alias": "sortFunction"; "required": false; }; }, { "searchFieldChange": "searchFieldChange"; "selectionChange": "selectionChange"; "openChange": "openChange"; "triggerClick": "triggerClick"; "optionsClear": "optionsClear"; }, ["_prefixChildren", "_suffixChildren"], ["eui-readonly-label", "[matTextPrefix]", "[matPrefix], [matIconPrefix]", "[matTextSuffix]", "[matSuffix], [matIconSuffix]", "mat-error", "mat-hint"], false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
declare enum EuiOperator {
    AND = "AND",
    NOT = "NOT",
    OR = "OR"
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
interface EuiPermissionObject {
    [key: string]: EuiPermissionObject;
}
interface EuiPermissionArray extends Array<string> {
}
type EuiPermission = EuiPermissionObject | EuiPermissionArray;

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiPermissionService {
    splitSeparator: string;
    permissionInitialized: BehaviorSubject<boolean>;
    permissionChanged: Subject<boolean>;
    private userPermission;
    private unsupportedOperatorMessage;
    /**
     * Set the user permissions.
     * This method rewrites the previous settings.
     * If you would like to reset permissions, you enough to set empty array eg.: []
     *
     * You are able to use two styles. Object and Array.:
     *
     * - Object style: \{'profile': \{'get': \{\}, 'delete': \{\}\}\}
     * Object style better for hierarchical permission (like REST API endpoint and method pairs).
     *
     * - Array style: ['search', 'configuration']
     * Array style better for simple list permission.
     *
     * @param userPermission - "EuiPermission" interface.
     */
    setPermission(userPermission: EuiPermission): void;
    /**
     * Check user permission.
     * This method is able to check user permission (one or more).
     *
     * @example
     * .hasPermission(['profile'])
     * .hasPermission(['search', 'configuration'], EuiOperator.OR)
     * @param expectedPermission - "EuiPermission" interface.
     * @param operator - "EuiOperator" enum (default EuiOperator.AND).
     */
    hasPermission(expectedPermission: EuiPermission | null, operator?: EuiOperator | string | null): boolean;
    private setPermissionArray;
    private setPermissionObject;
    private hasPermissionArray;
    private hasPermissionArrayAND;
    private hasPermissionArrayOR;
    private hasPermissionObject;
    private hasPermissionObjectAND;
    private hasPermissionObjectOR;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiPermissionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EuiPermissionService>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * This directive can handle the permission sensitive template contents.
 * It depends on EuiPermissionService.
 *
 * @example
 *   <ng-container *euiPermission="{permission: ['admin']}">
 *     "Admin" only content
 *   </ng-container>
 *
 *   <ng-container *euiPermission="{permission: ['admin', 'general-user'], operator: 'OR'}">
 *     "Admin" OR "General user" only content
 *   </ng-container>
 */
declare class EuiPermissionDirective implements OnDestroy {
    private changeDetectorRef;
    private permissionService;
    private templateRef;
    private viewContainerRef;
    private expectedPermission;
    private subscription;
    private operator;
    /**
     * Set the expected permissions and operator.
     *
     * @category Input
     * @param params - \{ permission: EuiPermission, operator?: EuiOperator | string | null \}
     */
    set permission(params: {
        permission: EuiPermission;
        operator?: EuiOperator | string | null;
    });
    constructor(changeDetectorRef: ChangeDetectorRef, permissionService: EuiPermissionService, templateRef: TemplateRef<any>, viewContainerRef: ViewContainerRef);
    ngOnDestroy(): void;
    private checkPermission;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiPermissionDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<EuiPermissionDirective, "[euiPermission]", never, { "permission": { "alias": "euiPermission"; "required": false; }; }, {}, never, never, false, never>;
}

declare class EuiSearchCustomFiltersComponent {
    private readonly _customFilterService;
    readonly rootFilterGroup: EuiFilterGroup;
    readonly fields: EuiFilterField[];
    readonly labelTranslations: EuiFilterLabelTranslations['sidesheet'];
    constructor(data: {
        rootFilterGroup: EuiFilterGroup;
        labelTranslations: EuiFilterLabelTranslations['sidesheet'];
    }, _customFilterService: EuiCustomFilterService);
    onResetClick(): void;
    onCancelClick(): void;
    onApplyClick(): void;
    onConditionAdded(filterGroup: EuiFilterGroup): void;
    onGroupAdded(filterGroup: EuiFilterGroup): void;
    onConditionOrGroupDuplicated({ parent, conditionOrFilterGroup }: EuiFilterGroupOrConditionDuplicateData): void;
    onGroupCleared({ parent, filterGroup }: EuiFilterGroupClearData): void;
    onConditionCleared({ parent, condition }: EuiFilterConditionClearData): void;
    hasInvalidCondition(): boolean;
    haveActiveFiltersNotChanged(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiSearchCustomFiltersComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiSearchCustomFiltersComponent, "eui-search-custom-filters", never, {}, {}, never, never, false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiSearchCustomFiltersGroupComponent {
    byConditionAdded: EventEmitter<EuiFilterGroup>;
    byGroupAdded: EventEmitter<EuiFilterGroup>;
    byConditionOrGroupDuplicated: EventEmitter<EuiFilterGroupOrConditionDuplicateData>;
    byGroupCleared: EventEmitter<EuiFilterGroupClearData>;
    byConditionClearedInGroup: EventEmitter<EuiFilterConditionClearData>;
    filterGroup: EuiFilterGroup;
    hideActions?: boolean;
    fields: EuiFilterField[];
    labelTranslations: EuiFilterLabelTranslations['sidesheet']['filterGroup'];
    parent?: EuiFilterGroup;
    outerIdx: number;
    loopIdx: number;
    path: string;
    set parentCounter(parentCount: number);
    parentCount: number;
    onAddConditionClick(filterGroup: EuiFilterGroup): void;
    onAddGroupClick(filterGroup: EuiFilterGroup): void;
    onDuplicate(filterGroupOrConditionDuplicateData: EuiFilterGroupOrConditionDuplicateData): void;
    onClear(filterGroupClearData: EuiFilterGroupClearData): void;
    onConditionCleared(filterConditionClearData: EuiFilterConditionClearData): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiSearchCustomFiltersGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiSearchCustomFiltersGroupComponent, "eui-search-custom-filters-group", never, { "filterGroup": { "alias": "filterGroup"; "required": true; }; "hideActions": { "alias": "hideActions"; "required": false; }; "fields": { "alias": "fields"; "required": true; }; "labelTranslations": { "alias": "labelTranslations"; "required": true; }; "parent": { "alias": "parent"; "required": false; }; "outerIdx": { "alias": "outerIdx"; "required": false; }; "loopIdx": { "alias": "loopIdx"; "required": false; }; "path": { "alias": "path"; "required": true; }; "parentCounter": { "alias": "parentCounter"; "required": true; }; }, { "byConditionAdded": "byConditionAdded"; "byGroupAdded": "byGroupAdded"; "byConditionOrGroupDuplicated": "byConditionOrGroupDuplicated"; "byGroupCleared": "byGroupCleared"; "byConditionClearedInGroup": "byConditionClearedInGroup"; }, never, never, false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiSearchCustomFiltersConditionComponent implements OnInit {
    private readonly _destroyRef;
    byConditionDuplicated: EventEmitter<EuiFilterGroupOrConditionDuplicateData>;
    byConditionCleared: EventEmitter<EuiFilterConditionClearData>;
    inputModel: NgModel;
    condition: EuiFilterCondition;
    isLastObject: boolean;
    fields: EuiFilterField[];
    labelTranslations: EuiFilterLabelTranslations['sidesheet']['filterGroup'];
    parent: EuiFilterGroup;
    outerIdx: number;
    loopIdx: number;
    path: string;
    operators: EuiFilterFieldOperators | null;
    dataType: EuiFilterFieldDataType;
    readonly dateControl: FormControl<any>;
    readonly booleanValues: Exclude<keyof EuiFilterLabelTranslations['sidesheet']['filterGroup']['condition']['input']['boolean'], 'ariaLabel'>[];
    constructor(_destroyRef: DestroyRef);
    ngOnInit(): void;
    onDuplicate(): void;
    onClear(): void;
    onFieldSelectionChange(): void;
    private resetControls;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiSearchCustomFiltersConditionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiSearchCustomFiltersConditionComponent, "eui-search-custom-filters-condition", never, { "condition": { "alias": "condition"; "required": true; }; "isLastObject": { "alias": "isLastObject"; "required": true; }; "fields": { "alias": "fields"; "required": true; }; "labelTranslations": { "alias": "labelTranslations"; "required": true; }; "parent": { "alias": "parent"; "required": true; }; "outerIdx": { "alias": "outerIdx"; "required": true; }; "loopIdx": { "alias": "loopIdx"; "required": true; }; "path": { "alias": "path"; "required": true; }; }, { "byConditionDuplicated": "byConditionDuplicated"; "byConditionCleared": "byConditionCleared"; }, never, never, false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiSearchCustomFiltersIndividualActionsComponent {
    byDuplicate: EventEmitter<void>;
    byClear: EventEmitter<void>;
    isClearDisabled: boolean;
    labelTranslations: EuiFilterLabelTranslations['sidesheet']['filterGroup']['individualActions'];
    path: string;
    onDuplicateClick(): void;
    onClearClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiSearchCustomFiltersIndividualActionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiSearchCustomFiltersIndividualActionsComponent, "eui-search-custom-filters-individual-actions", never, { "isClearDisabled": { "alias": "isClearDisabled"; "required": false; }; "labelTranslations": { "alias": "labelTranslations"; "required": true; }; "path": { "alias": "path"; "required": true; }; }, { "byDuplicate": "byDuplicate"; "byClear": "byClear"; }, never, never, false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
declare enum EuiSidebarEnum {
    COLLAPSE_START = "COLLAPSE_START",
    COLLAPSE_END = "COLLAPSE_END",
    EXPAND_START = "EXPAND_START",
    EXPAND_END = "EXPAND_END"
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/** @internal */
declare const DUE_TIME = 30;
/** @internal */
declare const USER_EVENT_DUE_TIME = 100;
/**
 * Simple sidebar with three optional content area.:
 * <eui-sidebar>
 *   <div data-content-area="header">Header content</div>
 *   Main content
 *   <div data-content-area="footer">Footer content</div>
 * </eui-sidebar>
 */
declare class EuiSidebarComponent implements OnDestroy {
    private readonly hostElementRef;
    private readonly dir;
    /**
     * Sets the height of the sidebar component when minimized.
     *
     * @category Input
     * @default '100%'
     */
    minimizedHeight: string;
    /**
     * This affects which side the menu opens on when minimized.
     *
     * @category Input
     */
    direction: Direction;
    /**
     * Collapse/Toggle Start/Stop events.
     * It's a useful event if you would like to control of sidebar content elements.
     *
     * Use EuiSidebarEnum:
     * - COLLAPSE_START
     * - COLLAPSE_END
     * - EXPAND_START
     * - EXPAND_END
     *
     * @internal */
    event: BehaviorSubject<EuiSidebarEnum>;
    /**
     * Sidebar minimized/maximized state.
     *
     * @internal */
    minimized: BehaviorSubject<boolean>;
    /** @internal */
    _collapse: BehaviorSubject<boolean>;
    private debounce;
    private debounceUserEvent;
    private destroy;
    constructor(hostElementRef: ElementRef, dir: Directionality);
    /** @internal */
    onEnter(): void;
    /** @internal */
    onLeave(): void;
    /** @internal */
    onFocus(): void;
    /** @internal */
    onBlur(): void;
    /** @internal */
    ngOnDestroy(): void;
    /**
     * Minimize / maximize sidebar
     * Min size: 48px
     * Max size: content size or container size
     *
     * @internal */
    toggleMinimize(): void;
    /** @internal */
    _onAnimationStart(event: AnimationEvent$1): void;
    /** @internal */
    _onAnimationEnd(event: AnimationEvent$1): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiSidebarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiSidebarComponent, "eui-sidebar", never, { "minimizedHeight": { "alias": "minimizedHeight"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; }, {}, never, ["[data-content-area=header]", "*", "[data-content-area=footer]"], false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
/** Pre-localized text to supply to the dialog. Defaults will be US English if not supplied. */
interface EuiUnsavedChangesDialogText {
    /** Dialog title. Default "Unsaved Changes" */
    title?: string;
    /** Body text of dialog. Default "There are unsaved changes on this page. Your changes will be lost if you leave without saving." */
    body?: string;
    /** Text for Cancel button. Default "Cancel" */
    cancelButton?: string;
    /** Text for Discard button. Default "Discard changes" */
    discardButton?: string;
}
/** @ignore */
declare const EUI_UC_DIALOG_TEXT_DEFAULTS: EuiUnsavedChangesDialogText;

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/** Describes the table layout */
interface EuiTableColumnManagementTableLayout {
    /** Name of the table */
    name: string;
    /** Table sort information */
    sort: {
        /** Default sort column and direction */
        default: Sort;
        /** Current sort column and direction */
        current: Sort;
    };
    /** List of table columns */
    columns: EuiTableColumnManagementTableColumn[];
}
/** Type of underlying column data */
type EuiTableColumnManagementDataType = 'date' | 'boolean' | 'number' | 'text';
/** Valid button types for open button */
type EuiTableColumnManagementButtonType = 'icon' | 'button' | 'link';
/** Description of a table column */
interface EuiTableColumnManagementTableColumn {
    /** Name of the table column */
    name: string;
    /** Display name of the table column (translated if necessary) */
    displayValue: string;
    /** True if the column is required and cannot be unselected */
    required: boolean;
    /** Optional type of data in the column: date, boolean, number or text. Default is text */
    dataType?: EuiTableColumnManagementDataType;
    /** Default selection and sequence of the column */
    default: EuiTableColumnManagementTableColumnOption;
    /** Current selection and sequence of the column */
    current: EuiTableColumnManagementTableColumnOption;
}
/** Describes the selection and sequence of a column */
interface EuiTableColumnManagementTableColumnOption {
    /** True to indicate the column is selected */
    selected: boolean;
    /** The position of the column in the list (zero-based). */
    sequence: number;
}
/** Describes the table layout in a simplified form to save to user preferences. Emitted via the saveData output event on the component or the service openSidesheet Observable. */
interface EuiTableColumnManagementSavedTableLayout {
    /** The saved sort column description */
    sort: Sort;
    /** The list of saved column data */
    columns: EuiTableColumnManagementSavedTableColumn[];
}
/** The column in the Saved table layout */
interface EuiTableColumnManagementSavedTableColumn {
    /** Name of the column */
    name: string;
    /** True when the column is selected */
    selected: boolean;
    /** The zero-based display order of the column */
    sequence: number;
}
/**
 * Structure to hold all label and string translations for the table column management component.
 * All text must be translated to the local lanugage by the caller before opening the sidesheet.
 * All members are optional and will be populated by default US English values if empty, null, or undefined.
 */
interface EuiTableColumnManagementLabelTranslations {
    /** Text for action controls at the top and bottom of the sheet */
    actionButtons?: {
        /** Label text for selection action buttons. Default "Select:" */
        selectLabel?: string;
        /** Button text to select all columns. Default "All". */
        allButton?: string;
        /** Tooltip for All button. Default "Select all columns". */
        allButtonTooltip?: string;
        /** Button text to unselect all columns. Default "None" */
        noneButton?: string;
        /** Tooltip for None button.  Default "Remove all column selections that are not required" */
        noneButtonTooltip?: string;
        /** Button text to reset all column selections to default state. Default "Default" */
        resetButton?: string;
        /** Button tooltip for the reset to default button.  Default "Resets selection and order of all columns to the default." */
        resetButtonTooltip?: string;
        /** Slide toggle text to show only active / selected columns or all columns. Default "Selected" */
        activeOnlyToggle?: string;
        /** Tooltip when activeOnly is toggled ON. Default "Show all" */
        showAllTooltip?: string;
        /** Tooltip when activeOnly is toggled OFF. Default "Show selected only" */
        showSelectedTooltip?: string;
        /** Button text for Apply button at bottom of sheet. Only present when config.useApplyCancel is true. Default "Apply" */
        applyButton?: string;
        /** Button text for Cancel button at bottom of sheet. Only present when config.useApplyCancel is true. Default "Cancel" */
        cancelButton?: string;
    };
    /** Text for controls and tooltips in the list of columns */
    list?: {
        /** Placeholder text for the eui-search control. Only used when config.hideSearch is false. Default "Search column names" */
        searchPlaceholder?: string;
        /** Tooltip when hovering over the drag handle icon. Default "Drag to reorder columns" */
        dragHandleTooltip?: string;
        /** Aria label text for the column order input. Must have the text "{columnName}" included. Default "Enter the column order for the {columnName} column" */
        inputAriaLabel?: string;
        /** Tooltip for required columns. Default "This column is required" */
        requiredColumn?: string;
        /** Text to show when no columns match the search. Only used when config.hideSearch is false. Default "No columns match your search" */
        noMatchingColumns?: string;
        /** Text to show when no columns match the search and active only is toggled. Only used when config.hideSearch is false. Default "No active columns match your search" */
        noActiveMatchingColumns?: string;
        /** Tooltip for the sequence input. The same tooltip will apply to all columns. Default "Set column order number then press the Enter/Return key" */
        inputTooltip?: string;
        /** Tooltip text for the sort icon */
        sort?: {
            /** Tooltip when sorted column is a string. */
            text?: {
                /** Default "Active sort (A - Z)" */
                asc?: string;
                /** Default "Active sort (Z - A)" */
                desc?: string;
            };
            /** Tooltip when sorted column is a date. */
            date?: {
                /** Default "Active sort (oldest first)" */
                asc?: string;
                /** Default "Active sort (newest first)" */
                desc?: string;
            };
            /** Tooltip when sorted column is a boolean. */
            boolean?: {
                /** Default "Active sort (False - True)" */
                asc?: string;
                /** Default "Active sort (True - False)" */
                desc?: string;
            };
            /** Tooltip text when sorted column is a number. */
            number?: {
                /** Default "Active sort (0 - 9)" */
                asc?: string;
                /** Default "Active sort (9 - 0)" */
                desc?: string;
            };
        };
    };
    sidesheet?: {
        /** Text for the button or link that opens the column selection sidesheet. Default "Show/Hide Columns" */
        openButton?: string;
        /** Tooltip for the button used to open the sidesheet. Default "Manage table columns" */
        openerButtonTooltip?: string;
        /** Sidesheet title. Default "Table Columns" */
        title?: string;
        /** Text sent to "unsaved changes" dialog. Only used when useApplyCancel is true. */
        unsavedChanges: EuiUnsavedChangesDialogText;
    };
}
/**
 * Configuration options for a table column management component
 */
interface EuiTableColumnManagementConfig {
    /** Current table column layout including sort */
    tableLayout: EuiTableColumnManagementTableLayout;
    /** Optional structure of translated strings for labels, tooltips, etc. If not supplied component defaults will be used. */
    labelTranslations?: EuiTableColumnManagementLabelTranslations;
    /** Optional class for the sidesheet */
    panelClass?: string;
    /** Optional testId prefix to apply to controls */
    testId?: string;
    /** Optional. When set to true the table layout changes are NOT applied live and
     * must be saved with an Apply button at the bottom of the page.
     */
    useApplyCancel?: boolean;
    /** Optional. Hides search control at the top of the column list. */
    hideSearch?: boolean;
}
/** @internal */
declare const EUI_TCM_DEFAULT_LABEL_TRANSLATIONS: EuiTableColumnManagementLabelTranslations;
/** @internal */
declare const EUI_TCM_NEW_TABLE_LAYOUT: EuiTableColumnManagementTableLayout;
/** @internal */
declare const EUI_TCM_NEW_SAVED_TABLE_LAYOUT: EuiTableColumnManagementSavedTableLayout;
/** @internal */
declare const EUI_TCM_NEW_CONFIG: EuiTableColumnManagementConfig;

/**
 * A service that opens the table column selection sidesheet
 */
declare class EuiTableColumnManagementService {
    private readonly _sidesheetService;
    /** @ignore */
    dataToSave$: Subject<EuiTableColumnManagementSavedTableLayout>;
    private tableLayout;
    private config;
    private originalConfig;
    private savedData;
    /** @ignore */
    constructor(_sidesheetService: EuiSidesheetService);
    /**
     * Opens the column selection sidesheet
     *
     * Can be used to open from code where the caller either is not using the
     * EuiTableColumnManagement in an html template or needs additional control.
     *
     * @param config A EuiTableColumnManagementConfig object describing the table
     * layout, parameters for the sidesheet, and localized text for display
     * @return Observable<EuiTableColumnManagementSavedTableLayout> Saved layout
     * is returned when sidesheet is dismissed. If config.useApplyCancel is true
     * data is only returned when Apply button is clicked
     *
     */
    openSidesheet(config: EuiTableColumnManagementConfig): Observable<EuiTableColumnManagementSavedTableLayout>;
    private saveLayout;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiTableColumnManagementService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EuiTableColumnManagementService>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiTableColumnManagementComponent implements OnInit {
    private readonly management;
    private readonly destroyRef;
    /**
     * Required. The configuration data for the component.
     *
     * @category Input
     */
    config: EuiTableColumnManagementConfig;
    /**
     * Controls whether the button that opens the sidesheet is enabled or disabled.
     *
     * @category Input
     */
    disabled: boolean;
    /**
     * Optional type of button to display. Predefined options:
     * - icon
     * - button (a mat-stroked-button)
     * - link
     *
     * @category Input
     */
    buttonType: EuiTableColumnManagementButtonType;
    /**
     * Emits an event on sidesheet close when table layout has been changed. If no
     * changes from the original layout are detected the event is not emitted.
     *
     * Data is emitted in a EuiTableColumnManagementSavedTableLayout object that can
     * be written to a user preferences data store by the caller.
     * - When config.useApplyCancel is false this event is emitted when the sidesheet is closed.
     * - When config.useApplyCancel is true this event is only emitted when the Apply button is clicked.
     *
     * @category Output
     * @event
     */
    saveData: EventEmitter<EuiTableColumnManagementSavedTableLayout>;
    /** @ignore */
    testId: string;
    private readonly destroy;
    /** @ignore */
    constructor(management: EuiTableColumnManagementService, destroyRef: DestroyRef);
    /** @ignore */
    ngOnInit(): void;
    /** @ignore */
    openTableColumnManagement(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiTableColumnManagementComponent, [{ self: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiTableColumnManagementComponent, "eui-table-column-management", never, { "config": { "alias": "config"; "required": true; }; "disabled": { "alias": "disabled"; "required": false; }; "buttonType": { "alias": "buttonType"; "required": false; }; }, { "saveData": "saveData"; }, never, never, false, never>;
}

declare class EuiUnsavedChangesService {
    private dialog;
    /** @ignore */
    constructor(dialog: MatDialog);
    /**
     * Displays the "Unsaved changes" dialog.
     *
     * Can be used in places where the controlled element is a sidesheet.
     *
     * @param ref Reference to the sidesheet.
     * @param hasUnsavedChanges Function which controls when to display the warning (if true the warning will appear).
     * @param dialogText a structure containing pre-translated text to display in the dialog. Default English US text will be used if not supplied.
     * @param closeWith Optional parameter to pass when closing the sidesheet
     *
     */
    handleSidesheetUnsavedChanges(ref: EuiSidesheetRef, hasUnsavedChanges: () => boolean, dialogText?: EuiUnsavedChangesDialogText, closeWith?: () => any): Observable<any>;
    /**
     * Displays the "Unsaved changes" dialog.
     *
     * Can be used in places where the controlled element is a dialog.
     *
     * @param ref Reference to the dialog.
     * @param hasUnsavedChanges Function which controls when to display the warning (if true the warning will appear).
     * @param dialogText a structure containing pre-translated text to display in the dialog. Default English US text will be used if not supplied.
     *
     */
    handleDialogUnsavedChanges(ref: MatDialogRef<any>, hasUnsavedChanges: () => boolean, dialogText?: EuiUnsavedChangesDialogText): Observable<any>;
    /**
     * Displays the "Unsaved changes" dialog.
     *
     * @param dialogText a structure containing pre-translated text to display in the dialog. Default English US text will be used if not supplied.
     * @return True if discard changes option is clicked
     * @return False if cancel option is clicked
     *
     */
    showUnsavedChangesWarning(dialogText?: EuiUnsavedChangesDialogText): Observable<boolean>;
    private openDialog;
    private populateTranslations;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiUnsavedChangesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EuiUnsavedChangesService>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiTableColumnManagementSelectColumnsComponent implements OnInit {
    private data;
    private readonly sidesheet;
    private readonly sidesheetRef;
    private readonly destroyRef;
    private readonly unsavedChanges;
    searchInput: EuiSearchComponent;
    showOnlySelected: FormControl<boolean>;
    searchFormControl: FormControl<string>;
    isDragging: boolean;
    useApplyCancel: boolean;
    showSearch: boolean;
    isFiltered: boolean;
    readonly labelTranslations: EuiTableColumnManagementLabelTranslations;
    readonly tableLayout: EuiTableColumnManagementTableLayout;
    readonly testId: string;
    get filteredColumns(): EuiTableColumnManagementTableColumn[];
    get allDefaults(): boolean;
    get noneSelected(): boolean;
    get allSelected(): boolean;
    get allRequired(): boolean;
    get anyEdits(): boolean;
    private readonly originalLayout?;
    private filteredColumnNames;
    private destroy;
    private saving;
    constructor(data: EuiTableColumnManagementConfig, sidesheet: EuiSidesheetService, sidesheetRef: EuiSidesheetRef, destroyRef: DestroyRef, unsavedChanges: EuiUnsavedChangesService);
    ngOnInit(): void;
    selectColumn(selectedColumn: EuiTableColumnManagementTableColumn, event: MatCheckboxChange): void;
    moveColumn(event: CdkDragDrop<EuiTableColumnManagementTableColumn[], EuiTableColumnManagementTableColumn[], any>): void;
    setDragging(dragging: boolean): void;
    selectAll(): void;
    selectNone(): void;
    resetToDefault(): void;
    editColumnSequence(event: any, column: EuiTableColumnManagementTableColumn): void;
    cancel(): void;
    apply(): void;
    private filterValueChange;
    private filterColumns;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiTableColumnManagementSelectColumnsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiTableColumnManagementSelectColumnsComponent, "eui-table-column-management-select-columns", never, {}, {}, never, never, false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Enum for valid types of top navigation items.
 */
declare enum EuiTopNavigationItemType {
    RouterLink = 0,
    ExternalLink = 1,
    Menu = 2,
    Custom = 3
}
/**
 * Options for RouterLink items. See https://angular.io/api/router/RouterLink
 */
interface EuiRouterLinkOptions {
    queryParams?: Params | null;
    fragment?: string;
    queryParamsHandling?: QueryParamsHandling | null;
    preserveFragment?: boolean;
    skipLocationChange?: boolean;
    replaceUrl?: boolean;
    state?: {
        [l: string]: any;
    };
    relativeTo?: ActivatedRoute | null;
}
/**
 * Properties for top navigation items.
 */
interface EuiTopNavigationItem {
    /** The type of the top navigation item. See EuiTopNavigiationItemType enum. */
    type: EuiTopNavigationItemType;
    /** The text displayed on the top navigation item. */
    text?: string;
    /** The URL used for the RouterLink and ExternalLink types. */
    url?: string | any[];
    /** The sub-items used for the Menu type. */
    items?: EuiTopNavigationItem[];
    /** The component used for the Custom type. */
    component?: any;
    /** The routerLinkActiveOptions that can be used for the RouterLink type. */
    routerLinkActiveOptions?: IsActiveMatchOptions;
    /** The options that can be used for the RouterLink type. */
    routerLinkOptions?: EuiRouterLinkOptions;
    /** Whether the top navigation item is expanded or not (used in mobile view) */
    expanded?: boolean;
    /** Use to override the default test ID suffix */
    testIdSuffix?: string;
}

declare class EuiTopNavigationService {
    private router;
    constructor(router: Router);
    /**
     * Returns a boolean for whether the top navigation item passed to it is active or not.
     *
     * @param item Top navigation item that needs the isActive check
     * @param children Optional array of top navigation item children that should be checked for isActive
     */
    isActive(item: EuiTopNavigationItem, children?: EuiTopNavigationItem[]): boolean;
    /**
     * Collapses all items that are not active.
     *
     * @param items Items array that needs to be collapsed if not active
     */
    collapseItems(items: EuiTopNavigationItem[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiTopNavigationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EuiTopNavigationService>;
}

declare class EuiTopNavigationComponent {
    private router;
    private changeRef;
    private topNav;
    /**
     * The items displayed within the top navigation.
     *
     * @category Input
     */
    items: EuiTopNavigationItem[];
    /**
     * The direction that the text should display. This affects which side the menu opens on.
     *
     * @category Input
     */
    direction: Direction;
    /**
     * Sets whether the navigation will show in the centered position or not.
     * Set to true will add .eui-top-navigation-centered  css class
     *
     * @category Input
     */
    centered: boolean;
    /**
     * Allows the EuiTopNavigationItemType enum to be used within the component HTML.
     *
     * @internal
     */
    itemTypes: typeof EuiTopNavigationItemType;
    /**
     * Defines whether the mobile menu sidebar is displayed.
     *
     * @internal
     */
    showMobileMenu: boolean;
    constructor(router: Router, changeRef: ChangeDetectorRef, topNav: EuiTopNavigationService);
    /**
     * Triggered when the window size changes. Hides the mobile menu if the viewport size is greater than the mobile breakpoint size.
     *
     * @internal
     */
    onResize(): void;
    /**
     * Checks the viewport width to see if it is smaller than or equal to the mobile breakpoint size.
     *
     * @internal
     */
    get isMobile(): boolean;
    /**
     * Determines whether the navigation item or any of its children are active
     *
     * @internal
     */
    isActive(item: EuiTopNavigationItem, children?: EuiTopNavigationItem[]): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiTopNavigationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiTopNavigationComponent, "eui-top-navigation", never, { "items": { "alias": "items"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; "centered": { "alias": "centered"; "required": false; }; }, {}, never, ["[eui-top-navigation-mobile-footer]"], false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiTopNavigationCustomMenuItemComponent implements OnInit {
    /**
     * Component that should be displayed within the custom menu item.
     *
     * @category Input
     */
    component: any;
    /**
     * ViewContainerRef for the ng-template element that the component will be created within.
     */
    viewContainerRef: ViewContainerRef;
    /** @internal */
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiTopNavigationCustomMenuItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiTopNavigationCustomMenuItemComponent, "eui-top-navigation-custom-menu-item", never, { "component": { "alias": "component"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiTopNavigationMenuItemComponent {
    router: Router;
    /**
     * The top navigation items to be displayed within the menu.
     *
     * @category Input
     */
    items: EuiTopNavigationItem[];
    /**
     * The direction that the text should display. This affects which side the menu opens on.
     *
     * @category Input
     */
    direction: Direction;
    /**
     * ViewChild for the mat-menu element.
     */
    childMenu: MatMenu;
    /**
     * Allows the EuiTopNavigationItemType enum to be used within the component HTML.
     *
     * @internal */
    itemTypes: typeof EuiTopNavigationItemType;
    constructor(router: Router);
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiTopNavigationMenuItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiTopNavigationMenuItemComponent, "eui-top-navigation-menu-item", never, { "items": { "alias": "items"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; }, {}, never, never, false, never>;
}

declare class EuiTopNavigationMobileMenuItemComponent {
    router: Router;
    topNav: EuiTopNavigationService;
    /**
     * The top navigation items to be displayed within the menu.
     *
     * @category Input
     */
    items: EuiTopNavigationItem[];
    /**
     * Menu depth level. 1 is top level, higher number is deeper level.
     *
     * @category Input
     */
    level: number;
    /**
     * Allows the EuiTopNavigationItemType enum to be used within the component HTML.
     */
    itemTypes: typeof EuiTopNavigationItemType;
    constructor(router: Router, topNav: EuiTopNavigationService);
    /**
     * Updates expanded property of item passed to it.
     *
     * @param item Item whose expanded property will be updated.
     * @internal */
    expand(item: EuiTopNavigationItem): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiTopNavigationMobileMenuItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiTopNavigationMobileMenuItemComponent, "eui-top-navigation-mobile-menu-item", never, { "items": { "alias": "items"; "required": false; }; "level": { "alias": "level"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
declare enum EuiVerticalNavigationItemType {
    EXTERNAL_LINK = "EXTERNAL_LINK",
    NODE = "NODE",
    ROUTER_LINK = "ROUTER_LINK"
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
declare enum EuiLinkTarget {
    BLANK = "_blank",
    PARENT = "_parent",
    SELF = "_self",
    TOP = "_top"
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

interface EuiVerticalNavigationItemOptions {
    testId?: string;
    title: string;
    icon?: string;
    permission?: EuiPermission;
    permissionOperator?: EuiOperator;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

interface EuiVerticalNavigationExternalLinkOptions extends EuiVerticalNavigationItemOptions {
    href: string;
    target?: EuiLinkTarget;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare abstract class EuiVerticalNavigationItem {
    readonly testId: string | null;
    readonly type: EuiVerticalNavigationItemType;
    readonly title: string;
    readonly icon: string | null;
    permission: EuiPermission | null;
    permissionOperator: EuiOperator | null;
    parent: EuiVerticalNavigationNode;
    protected constructor(options: EuiVerticalNavigationItemOptions);
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiVerticalNavigationExternalLink extends EuiVerticalNavigationItem {
    readonly type = EuiVerticalNavigationItemType.EXTERNAL_LINK;
    readonly href: string;
    readonly target: string;
    constructor(options: EuiVerticalNavigationExternalLinkOptions);
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

interface EuiVerticalNavigationRouterLinkOptions extends EuiVerticalNavigationItemOptions {
    url: string | UrlTree;
    exact?: IsActiveMatchOptions;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiVerticalNavigationRouterLink extends EuiVerticalNavigationItem {
    readonly type = EuiVerticalNavigationItemType.ROUTER_LINK;
    readonly url: string | UrlTree;
    readonly exact: IsActiveMatchOptions;
    active: boolean;
    constructor(options: EuiVerticalNavigationRouterLinkOptions);
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

interface EuiVerticalNavigationItems extends Array<EuiVerticalNavigationExternalLink | EuiVerticalNavigationNode | EuiVerticalNavigationRouterLink> {
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

interface EuiVerticalNavigationNodeOptions extends EuiVerticalNavigationItemOptions {
    children: EuiVerticalNavigationItems;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiVerticalNavigationNode extends EuiVerticalNavigationItem {
    readonly type = EuiVerticalNavigationItemType.NODE;
    opened: boolean;
    active: boolean;
    children: EuiVerticalNavigationItems;
    constructor(options: EuiVerticalNavigationNodeOptions);
}

declare class EuiVerticalNavigationComponent implements OnInit, OnDestroy {
    private router;
    /**
     * Collapse/expand animation ended.
     *
     * @internal */
    onAnimationEnd: Subject<boolean>;
    /** @internal */
    menuItems: BehaviorSubject<EuiVerticalNavigationItems>;
    /** @internal */
    type: typeof EuiVerticalNavigationItemType;
    /**
     * Menu data structure.
     * Use the "SgMenuItems" interface.
     *
     * @category Input
     * @default [] (empty array)
     */
    set items(items: EuiVerticalNavigationItems | null);
    /**
     * Web Accessibility requirement ("nav" element "aria-label" property).
     * Label menus to make them easier to find and understand.
     * Labels should be short but descriptive, to allow users to distinguish between multiple menus on a web page.
     * [guideline] https://www.w3.org/WAI/tutorials/menus/structure/
     *
     * @category Input
     * @default Main Navigation
     */
    set name(name: string);
    /** @internal */
    get name(): string;
    private savedNodes;
    private activeItems;
    private destroy;
    private _name;
    constructor(router: Router);
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    ngOnDestroy(): void;
    /**
     * Collapse currently open menu nodes.
     *
     * @internal */
    collapse(): void;
    /**
     * Expand previously opened menu nodes.
     *
     * @internal */
    expand(): void;
    /** @internal */
    toggleNode(item: EuiVerticalNavigationNode): void;
    /** @internal */
    routerLinkOnClick(item: EuiVerticalNavigationRouterLink): void;
    /** @internal */
    onToggleEnd(): void;
    private setSavedNodesOpenedState;
    private setItems;
    private closeAllOpenedNodes;
    private resetAllActiveItems;
    private setActiveItems;
    private setActiveItemsRecursive;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiVerticalNavigationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiVerticalNavigationComponent, "eui-vertical-navigation", never, { "items": { "alias": "items"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Options used to update the splash screen opened through EuiSplashScreenService.
 */
interface EuiSplashScreenOptions {
    applicationName?: string;
    icon?: string;
    showSpinner?: boolean;
    copyright?: string;
    message?: string;
    customLogo?: {
        url: string;
        height?: string;
        altText?: string;
    };
}
/**
 * Configuration options for a splash screen opened through EuiSplashScreenService.
 */
interface EuiSplashScreenConfig {
    textDirection?: Direction;
    applicationName?: string;
    icon?: string;
    showSpinner: boolean;
    copyright?: string;
    message?: string;
    customLogo?: {
        url: string;
        height?: string;
        altText?: string;
    };
}
/** @internal */
declare const SPLASH_SCREEN_OPTIONS: InjectionToken<EuiSplashScreenOptions>;

declare class EuiSplashScreenComponent {
    options: EuiSplashScreenOptions;
    /** @internal */
    class: string;
    /** @internal */
    testId: string;
    /** @internal */
    isVisible: boolean;
    /** @internal */
    animationStateChanged: EventEmitter<AnimationEvent>;
    constructor(options: EuiSplashScreenOptions);
    /** @internal */
    close(): void;
    /** @internal */
    onAnimationDone(event: AnimationEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiSplashScreenComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiSplashScreenComponent, "eui-splash-screen", never, {}, {}, never, never, false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Configuration options that are passed to the EUI download loader component.
 */
interface EuiDownloadLoaderConfig {
    /** Helper text to display. Default text will be displayed if this not specified. */
    helperText?: string;
    /** Button text to display. Default text will be displayed if this not specified. */
    buttonText?: string;
    /** ARIA label to set on spinner. Default ARIA label will be set if this not specified. */
    spinnerAriaLabel?: string;
    /** Whether the cancel button should be hidden */
    disableCancel?: boolean;
}
/**
 * Configuration options for the EUI download directive.
 */
interface EuiDownloadOptions {
    /** URL of the file or API endpoint. */
    url: string;
    /** HTTP method that should be used when calling an API endpoint for the download. Defaults to GET. */
    method?: string;
    /** Body content to pass to API endpoint. */
    body?: any;
    /** Options to use as part of the HTTP request */
    requestOptions?: any;
    /** The file name that will be displayed to the user for the download. Content-disposition header is used if this is not set. */
    fileName?: string;
    /** Whether the EUI loading service should be used to display a loader. Defaults to true. */
    showLoader?: boolean;
    /** Whether the element used to trigger the download should be disabled during download. Defaults to true. */
    disableElement?: boolean;
    /** The MIME type of the file contents. Falls back to responseType or Content-Type header if not provided. */
    fileMimeType?: string;
    /** Content length in bytes for the file being downloaded. Used to display progress when the Content-Length header is not returned by the server */
    contentLength?: number;
    /** Configuration options for download loader component. */
    loaderConfig?: EuiDownloadLoaderConfig;
}
/** @internal */
declare const DOWNLOAD_REQUEST_SUBSCRIPTION: InjectionToken<string>;
/** @internal */
declare const DOWNLOAD_LOADER_CONFIG: InjectionToken<string>;

declare class EuiDownloadService {
    /** @internal */
    helpers: {
        saveAs: typeof file_saver;
    };
    /** @internal */
    saveAs(data: string | Blob, filename?: string, options?: FileSaverOptions): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiDownloadService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EuiDownloadService>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiDownloadDirective {
    private http;
    private overlay;
    private injector;
    private downloadSvc;
    /**
     * Emits an event when the download completes
     *
     * @category Output
     * @event
     */
    downloadComplete: EventEmitter<any>;
    /**
     * Emits an event when the download starts. Returns the Subscription associated with the HTTP request. This can be used to cancel the download by calling unsubscribe().
     *
     * @category Output
     * @event
     */
    downloadStarted: EventEmitter<Subscription>;
    /**
     * Emits an event if the download fails
     *
     * @category Output
     * @event
     */
    downloadError: EventEmitter<any>;
    private element;
    private options;
    private loaderRef;
    private componentRef;
    constructor(el: ElementRef, http: HttpClient, overlay: Overlay, injector: Injector, downloadSvc: EuiDownloadService);
    /**
     * Configuration options for the download directive. See the [[EuiDownloadOptions]] interface for more information.
     *
     * @category Input
     */
    set downloadOptions(options: EuiDownloadOptions);
    /** @internal */
    onClick(): void;
    private download;
    private handleEvents;
    private handleResponse;
    private handleError;
    private getFilenameFromHeaders;
    private beforeDownload;
    private afterDownload;
    private openLoader;
    private hideLoader;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiDownloadDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<EuiDownloadDirective, "[euiDownload]", never, { "downloadOptions": { "alias": "euiDownload"; "required": false; }; }, { "downloadComplete": "downloadComplete"; "downloadStarted": "downloadStarted"; "downloadError": "downloadError"; }, never, never, false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiDownloadLoaderComponent implements AfterContentInit {
    requestSubscription: Subscription;
    config: EuiDownloadLoaderConfig;
    cancelBtn: MatButton;
    progress: number;
    constructor(requestSubscription: Subscription, config: EuiDownloadLoaderConfig);
    ngAfterContentInit(): void;
    /** @internal */
    cancelDownload(): void;
    private setCancelBtnFocus;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiDownloadLoaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiDownloadLoaderComponent, "eui-download-loader", never, {}, {}, never, never, false, never>;
}

declare class EuiSidesheetContentDirective {
    class: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiSidesheetContentDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<EuiSidesheetContentDirective, "[eui-sidesheet-content], eui-sidesheet-content, [euiSidesheetContent]", never, {}, {}, never, never, false, never>;
}

declare class EuiSidesheetActionsDirective {
    class: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiSidesheetActionsDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<EuiSidesheetActionsDirective, "[eui-sidesheet-actions], eui-sidesheet-actions, [euiSidesheetActions]", never, {}, {}, never, never, false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiClickableDirective implements OnDestroy {
    /** @internal */
    tabindex: number;
    /** @internal */
    class: string;
    /**
     * Focus and hover color for the element
     *
     * @category Input
     */
    set color(color: 'primary' | 'accent' | 'disabled' | '');
    /**
     * Focus and hover color for the element
     *
     * @category Input
     */
    set disabled(disabled: boolean);
    private _color;
    private _disabled;
    private _forceDisabled;
    private element;
    private clickSubscription;
    constructor(el: ElementRef);
    /** @internal */
    keyDown(event: KeyboardEvent): void;
    ngOnDestroy(): void;
    private setupClasses;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiClickableDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<EuiClickableDirective, "[euiClickable]", never, { "color": { "alias": "euiClickable"; "required": false; }; "disabled": { "alias": "euiClickableDisabled"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiTestIdPipe implements PipeTransform {
    transform(value: string, ...args: string[]): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiTestIdPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<EuiTestIdPipe, "euiTestId", false>;
}

declare class DummyComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DummyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DummyComponent, "ng-component", never, {}, {}, never, never, false, never>;
}

declare class EuiThemeSwitcherComponent {
    private euiThemeService;
    /**
     * Label of the theme switcher
     *
     * @category Input
     */
    label: string;
    /**
     * Controls whether the legacy floating label is displayed or a label above the form field
     *
     * @category Input
     */
    useLegacyFloatingLabel: boolean;
    /**
     * Text of the light theme option
     *
     * @category Input
     */
    lightThemeDisplayText: string;
    /**
     * Text of the dark theme option
     *
     * @category Input
     */
    darkThemeDisplayText: string;
    /**
     * Text of the auto theme option
     *
     * @category Input
     */
    autoThemeDisplayText: string;
    /**
     * Text of the contrast theme option
     *
     * @category Input
     */
    contrastThemeDisplayText: string;
    /**
     * Hiding the light theme option
     *
     * @category Input
     */
    hideLightTheme: boolean;
    /**
     * Hiding the dark theme option
     *
     * @category Input
     */
    hideDarkTheme: boolean;
    /**
     * Hiding the contrast theme option
     *
     * @category Input
     */
    hideContrastTheme: boolean;
    /**
     * Hiding the auto theme option
     *
     * @category Input
     */
    hideAutoTheme: boolean;
    /**
     * Display custom themes in theme switcher
     *
     * @category Input
     */
    customThemes: CustomTheme[];
    /** @internal */
    themeSwitcherState: Observable<EuiTheme>;
    /** @internal */
    EuiTheme: typeof EuiTheme;
    constructor(euiThemeService: EuiThemeService);
    /** @internal */
    onChange(event: MatSelectChange): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiThemeSwitcherComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiThemeSwitcherComponent, "eui-theme-switcher", never, { "label": { "alias": "label"; "required": false; }; "useLegacyFloatingLabel": { "alias": "useLegacyFloatingLabel"; "required": false; }; "lightThemeDisplayText": { "alias": "lightThemeDisplayText"; "required": false; }; "darkThemeDisplayText": { "alias": "darkThemeDisplayText"; "required": false; }; "autoThemeDisplayText": { "alias": "autoThemeDisplayText"; "required": false; }; "contrastThemeDisplayText": { "alias": "contrastThemeDisplayText"; "required": false; }; "hideLightTheme": { "alias": "hideLightTheme"; "required": false; }; "hideDarkTheme": { "alias": "hideDarkTheme"; "required": false; }; "hideContrastTheme": { "alias": "hideContrastTheme"; "required": false; }; "hideAutoTheme": { "alias": "hideAutoTheme"; "required": false; }; "customThemes": { "alias": "customThemes"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiNumberComponent implements OnInit {
    /**
     * Expose HTML element to allow HTML attribute customizations.
     *
     * @internal */
    inputElementRef: ElementRef<HTMLInputElement>;
    /**
     * Sets whether the component is required or not
     *
     * @category Input
     */
    required: boolean;
    /**
     * Sets whether the component is read-only or not
     *
     * @category Input
     */
    readonly: boolean;
    /**
     * Sets the native 'min' attribute
     *
     * @category Input
     */
    min?: number;
    /**
     * Sets the native 'max' attribute
     *
     * @category Input
     */
    max?: number;
    /**
     * Sets the native 'step' attribute
     *
     * @category Input
     */
    step: number;
    /**
     * Allows the placeholder attribute of the input field to be set
     *
     * @category Input
     */
    placeholder: string;
    /**
     * Allows the label attribute of the input field to be set
     *
     * @category Input
     */
    label: string;
    /**
     * Controls whether the legacy floating label is displayed or a label above the form field
     *
     * @category Input
     */
    useLegacyFloatingLabel: boolean;
    /**
     * When true the 'eui-input--no-margin' class won't be applied to the mat-form-field
     * Note: this needs to be set to 'false' when showing no validation errors in the <mat-error> section, so that they display correctly
     *
     * @category Input
     */
    enableFormFieldMargin: boolean;
    /**
     * Allows a FormControl to be passed to the component so that state and value changes can be viewed
     *
     * @category Input
     */
    numberControl: FormControl<number>;
    /**
     * Sets the component width
     *
     * @category Input
     */
    width: string;
    /**
     * Sets the input suffix
     *
     * @category Input
     */
    suffix: string;
    /**
     * Sets the disabled state of the component
     *
     * @category Input
     */
    set disabled(value: boolean);
    /**
     * Gets the disabled state of the component
     */
    /** @internal */
    get disabled(): boolean;
    private _disabled;
    /** @internal */
    get canIncrease(): boolean;
    /** @internal */
    get canDecrease(): boolean;
    /** @internal */
    get isRequired(): boolean;
    private get isValueEmpty();
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    subtractButtonClicked(): void;
    /** @internal */
    addButtonClicked(): void;
    private validateValueUpdate;
    private setDisabled;
    private updateValue;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiNumberComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiNumberComponent, "eui-number", never, { "required": { "alias": "required"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "step": { "alias": "step"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "label": { "alias": "label"; "required": false; }; "useLegacyFloatingLabel": { "alias": "useLegacyFloatingLabel"; "required": false; }; "enableFormFieldMargin": { "alias": "enableFormFieldMargin"; "required": false; }; "numberControl": { "alias": "numberControl"; "required": false; }; "width": { "alias": "width"; "required": false; }; "suffix": { "alias": "suffix"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, {}, never, ["eui-readonly-label", "mat-error", "mat-hint"], false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

type EuiGenericType<T> = T | {
    [key: string]: T;
};
type EuiObservableType = EuiGenericType<Observable<any>>;
type EuiSubscriptionType = EuiGenericType<Subscription>;
declare class EuiSubscribeContext {
    $implicit: any;
    euiSubscribe: EuiObservableType | null;
}
/**
 * This directive can subscribe to multiple observables so that they are available within
 * the template. It will also unsubscribe when this directive is destroyed.
 *
 * @example
 * <ng-container *euiSubscribe="{
 *   timelineConfig: timelineConfig,
 *   fetchProgress: fetchProgress,
 *   seekedIndex: seekedIndex,
 *   selectedElement: selectedElement
 * } as _subs">
 *     <div>{{ _subs.selectedElement.time }}</div>
 * </ng-container>
 */
declare class EuiSubscribeDirective implements OnInit, OnDestroy {
    private viewContainer;
    private cdr;
    private templateReference;
    private context;
    private observable;
    private subscription;
    /**
     * Set the observables to subscribe to.
     *
     * @category Input
     * @param inputObservable An observable or array of observables to subscribe to.
     */
    set euiSubscribe(inputObservable: EuiObservableType);
    constructor(viewContainer: ViewContainerRef, cdr: ChangeDetectorRef, templateReference: TemplateRef<any>);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiSubscribeDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<EuiSubscribeDirective, "[euiSubscribe]", never, { "euiSubscribe": { "alias": "euiSubscribe"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiDateFormatPipe implements PipeTransform {
    /**
     * A method that transforms the given date value into a moment format
     *
     * @param value The date to be formatted
     * @param format The format to apply
     * @memberof EuiDateFormatPipe
     */
    transform(value: MomentInput, format: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiDateFormatPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<EuiDateFormatPipe, "euiDateFormat", false>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

type EuiFlyoutPositionX = 'before' | 'after' | 'center';
type EuiFlyoutPositionY = 'above' | 'below' | 'center';
/**
 * Configuration options for an EUI flyout component.
 */
interface EuiFlyoutOptions {
    /** The direction the text should display. */
    direction?: Direction;
    /** The horizontal position for which side of the trigger that the flyout opens */
    xPosition?: EuiFlyoutPositionX;
    /** The vertical position for which side of the trigger that the flyout opens */
    yPosition?: EuiFlyoutPositionY;
    /** The class to assign to the overlay panel */
    panelClass?: string;
    /** Whether focus should be automatically set on the first focusable element within the flyout. Default: true */
    autoFocus?: boolean;
    /** Whether the pointer part of the flyout should be hidden or not */
    hidePointer?: boolean;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiFlyoutPositionsService {
    private readonly offset;
    positionChanged(elementRef: ElementRef, overlayElement: HTMLElement, change: ConnectedOverlayPositionChange): void;
    getPositions(elementRef: ElementRef, options?: EuiFlyoutOptions): ConnectedPosition[];
    private generatePositions;
    private getBasePositions;
    private getExtraPositions;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiFlyoutPositionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EuiFlyoutPositionsService>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiFlyoutTriggerDirective {
    private overlay;
    private elementRef;
    private viewContainerRef;
    private renderer2;
    private positions;
    /**
     * Reference to the EUI flyout component that should be opened by the trigger.
     */
    set flyout(flyout: EuiFlyoutComponent);
    get flyout(): EuiFlyoutComponent;
    private _flyout;
    private isOpen;
    private overlayRef;
    constructor(overlay: Overlay, elementRef: ElementRef, viewContainerRef: ViewContainerRef, renderer2: RendererFactory2, positions: EuiFlyoutPositionsService);
    /** @internal */
    onClick(): void;
    /** @internal */
    onKeydown(event: KeyboardEvent): void;
    /**
     * Open the flyout.
     */
    open(): void;
    /**
     * Close the flyout.
     */
    close(): void;
    private getOverlayConfig;
    private setFocusFirstElement;
    private onOverlayKeydown;
    private handleBackgroundClick;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiFlyoutTriggerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<EuiFlyoutTriggerDirective, "[euiFlyoutTriggerFor]", never, { "flyout": { "alias": "euiFlyoutTriggerFor"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiFlyoutComponent {
    /** @internal */
    templateRef: TemplateRef<any>;
    /**
     * Configuration options for an EUI flyout.
     */
    options?: EuiFlyoutOptions;
    /**
     * Emits an event when the flyout opens.
     *
     * @category Output
     * @event
     */
    opened: EventEmitter<boolean>;
    /**
     * Emits an event when the flyout is closed.
     *
     * @category Output
     * @event
     */
    closed: EventEmitter<boolean>;
    loaded: EventEmitter<boolean>;
    /** @internal */
    trigger?: EuiFlyoutTriggerDirective;
    /**
     * Open the flyout.
     */
    open(): void;
    /**
     * Close the flyout.
     */
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiFlyoutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiFlyoutComponent, "eui-flyout", ["euiFlyout"], { "options": { "alias": "options"; "required": false; }; }, { "opened": "opened"; "closed": "closed"; "loaded": "loaded"; }, never, ["*"], false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiOrderByPipe implements PipeTransform {
    transform<T>(array: T[], orderByKey: keyof T, order?: 'asc' | 'desc'): any[];
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiOrderByPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<EuiOrderByPipe, "euiOrderBy", false>;
}

declare class EuiUnsavedChangesDialogComponent {
    readonly dialogText: EuiUnsavedChangesDialogText;
    private readonly dialogRef;
    /** @ignore */
    constructor(dialogText: EuiUnsavedChangesDialogText, dialogRef: MatDialogRef<EuiUnsavedChangesDialogComponent>);
    /** @ignore */
    buttonClicked(discard: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiUnsavedChangesDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EuiUnsavedChangesDialogComponent, "eui-unsaved-changes-dialog", never, {}, {}, never, never, false, never>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Configuration options for the EUI tooltip directives.
 *
 * This interface allows consumers to globally configure default behavior
 * for both EuiOverflowTooltipDirective and EuiTooltipDirective via
 * the EUI_TOOLTIP_DEFAULTS injection token.
 */
interface EuiTooltipConfig {
    /**
     * The name of the CSS variable used to determine fallback max-width.
     * If the element has no defined max-width, this variable will be read from
     * computed styles. If not set or not found, fallbackWidth is used.
     *
     * @default '--eui-default-max-width'
     */
    cssFallbackWidthVariableName?: string;
    /**
     * The CSS class applied to elements to enable text truncation.
     * Typically includes styles like text-overflow: ellipsis.
     *
     * @default 'eui-text-ellipsis'
     */
    globalOverflowClass?: string;
    /**
     * Delay in milliseconds before the tooltip is shown.
     * Passed directly to Angular Material's MatTooltip.
     *
     * @default 500
     */
    matTooltipShowDelay?: number;
}
declare const EUI_TOOLTIP_DEFAULTS: InjectionToken<EuiTooltipConfig>;

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Directive that applies tooltip behavior to overflowing text elements.
 *
 * This directive automatically applies an overflow styling class and sets a fallback width
 * if the element does not have a defined width. It also configures the tooltip message and delay.
 *
 * Configuration:
 * - Accepts optional injection of EUI_TOOLTIP_DEFAULTS to override default values.
 *
 * Host Directives:
 * - MatTooltip: Inherited tooltip behavior from Angular Material.
 */
declare class EuiOverflowTooltipDirective implements AfterViewInit, OnInit {
    /**
     * Tooltip message to display. If not provided, the element's text content is used.
     *
     * @category Input
     */
    set euiOverflowTooltip(value: string | null);
    get euiOverflowTooltip(): string | null;
    /**
     * Delay in milliseconds before showing the tooltip (default is 500ms).
     *
     * @category Input
     */
    matTooltipShowDelay: number;
    /**
     * CSS variable name to use for fallback width. (default is '--eui-default-max-width').
     *
     * @category Input
     */
    cssFallbackWidthVariableName: string;
    /** @internal */
    protected readonly matTooltip: MatTooltip;
    /** @internal */
    protected readonly elementRef: ElementRef<any>;
    /** @internal */
    protected readonly renderer: Renderer2;
    /** @internal */
    protected readonly cdr: ChangeDetectorRef;
    private readonly globalOverflowClass;
    private _euiOverflowTooltip;
    /** @internal */
    constructor(config?: EuiTooltipConfig);
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    ngAfterViewInit(): void;
    /** @internal */
    updateTooltip(): void;
    /** @internal */
    protected applyOverflowStyling(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiOverflowTooltipDirective, [{ optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<EuiOverflowTooltipDirective, "[euiOverflowTooltip]", never, { "euiOverflowTooltip": { "alias": "euiOverflowTooltip"; "required": false; }; "matTooltipShowDelay": { "alias": "matTooltipShowDelay"; "required": false; }; "cssFallbackWidthVariableName": { "alias": "cssFallbackWidthVariableName"; "required": false; }; }, {}, never, never, false, [{ directive: typeof i1.MatTooltip; inputs: { "matTooltipPosition": "matTooltipPosition"; "matTooltipDisabled": "matTooltipDisabled"; "matTooltipHideDelay": "matTooltipHideDelay"; "matTooltipTouchGestures": "matTooltipTouchGestures"; "matTooltipClass": "matTooltipClass"; }; outputs: {}; }]>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Tooltip directive that wraps Angular Material's MatTooltip with simplified input and optional configuration.
 *
 * This directive allows developers to display tooltips with default show delay,
 * while inheriting all behavior from MatTooltip via hostDirectives.
 *
 * Configuration:
 * - Accepts optional injection of EUI_TOOLTIP_DEFAULTS to override default value for mat tooltip show delay.
 *
 * Host Directives:
 * - MatTooltip: Inherits tooltip behavior and inputs from Angular Material.
 */
declare class EuiTooltipDirective implements AfterViewInit {
    /**
     * Tooltip message to display. If not provided, the element's text content is used.
     *
     * @category Input
     */
    set euiTooltip(value: string | null);
    get euiTooltip(): string | null;
    /**
     * Delay in milliseconds before showing the tooltip (default is 500ms).
     *
     * @category Input
     */
    matTooltipShowDelay: number;
    /** @internal */
    protected readonly matTooltip: MatTooltip;
    /** @internal */
    protected readonly elementRef: ElementRef<any>;
    /** @internal */
    protected readonly cdr: ChangeDetectorRef;
    private _euiTooltip;
    /** @internal */
    constructor(config?: EuiTooltipConfig);
    /** @internal */
    ngAfterViewInit(): void;
    /** @internal */
    updateTooltip(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiTooltipDirective, [{ optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<EuiTooltipDirective, "[euiTooltip]", never, { "euiTooltip": { "alias": "euiTooltip"; "required": false; }; "matTooltipShowDelay": { "alias": "matTooltipShowDelay"; "required": false; }; }, {}, never, never, false, [{ directive: typeof i1.MatTooltip; inputs: { "matTooltipPosition": "matTooltipPosition"; "matTooltipDisabled": "matTooltipDisabled"; "matTooltipHideDelay": "matTooltipHideDelay"; "matTooltipTouchGestures": "matTooltipTouchGestures"; "matTooltipClass": "matTooltipClass"; }; outputs: {}; }]>;
}

declare class EuiMaterialModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiMaterialModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<EuiMaterialModule, never, [typeof i1$1.MatAutocompleteModule, typeof i2.MatBadgeModule, typeof i3.MatButtonModule, typeof i4.MatButtonToggleModule, typeof i5.MatCardModule, typeof i6.MatCheckboxModule, typeof i7.MatChipsModule, typeof i8.MatDatepickerModule, typeof i9.MatDialogModule, typeof i10.MatDividerModule, typeof i11.MatExpansionModule, typeof i12.MatFormFieldModule, typeof i13.MatGridListModule, typeof i14.MatIconModule, typeof i15.MatInputModule, typeof i16.MatListModule, typeof i17.MatMenuModule, typeof i18.MatPaginatorModule, typeof i19.MatProgressSpinnerModule, typeof i20.MatProgressBarModule, typeof i21.MatRadioModule, typeof i22.MatSelectModule, typeof i23.MatSidenavModule, typeof i24.MatSliderModule, typeof i25.MatSlideToggleModule, typeof i26.MatSnackBarModule, typeof i27.MatSortModule, typeof i28.MatStepperModule, typeof i29.MatTableModule, typeof i30.MatTabsModule, typeof i31.MatToolbarModule, typeof i1.MatTooltipModule, typeof i33.MatTreeModule, typeof i34.MatRippleModule, typeof i35.MatBottomSheetModule, typeof i36.A11yModule, typeof i37.ScrollingModule, typeof i38.DragDropModule], [typeof i1$1.MatAutocompleteModule, typeof i2.MatBadgeModule, typeof i3.MatButtonModule, typeof i4.MatButtonToggleModule, typeof i5.MatCardModule, typeof i6.MatCheckboxModule, typeof i7.MatChipsModule, typeof i8.MatDatepickerModule, typeof i9.MatDialogModule, typeof i10.MatDividerModule, typeof i11.MatExpansionModule, typeof i12.MatFormFieldModule, typeof i13.MatGridListModule, typeof i14.MatIconModule, typeof i15.MatInputModule, typeof i16.MatListModule, typeof i17.MatMenuModule, typeof i34.MatNativeDateModule, typeof i18.MatPaginatorModule, typeof i19.MatProgressSpinnerModule, typeof i20.MatProgressBarModule, typeof i21.MatRadioModule, typeof i22.MatSelectModule, typeof i23.MatSidenavModule, typeof i24.MatSliderModule, typeof i25.MatSlideToggleModule, typeof i26.MatSnackBarModule, typeof i27.MatSortModule, typeof i28.MatStepperModule, typeof i29.MatTableModule, typeof i30.MatTabsModule, typeof i31.MatToolbarModule, typeof i1.MatTooltipModule, typeof i33.MatTreeModule, typeof i34.MatRippleModule, typeof i35.MatBottomSheetModule, typeof i36.A11yModule, typeof i37.ScrollingModule, typeof i38.DragDropModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<EuiMaterialModule>;
}

declare class EuiCoreModule {
    constructor(themeService: EuiThemeService);
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<EuiCoreModule, [typeof EuiAlertBannerComponent, typeof EuiAlertComponent, typeof EuiAlertContentDirective, typeof EuiAlertHeaderDirective, typeof EuiBadgeComponent, typeof EuiBillboardComponent, typeof EuiDatePickerComponent, typeof EuiTimePickerComponent, typeof EuiIconComponent, typeof EuiJoinPipe, typeof EuiLoadingComponent, typeof EuiLogoComponent, typeof EuiMastheadComponent, typeof EuiReadonlyLabelComponent, typeof EuiSelectComponent, typeof EuiPermissionDirective, typeof EuiScrollComponent, typeof EuiSearchComponent, typeof EuiSearchCustomFiltersComponent, typeof EuiSearchCustomFiltersGroupComponent, typeof EuiSearchCustomFiltersConditionComponent, typeof EuiSearchCustomFiltersIndividualActionsComponent, typeof EuiSidebarComponent, typeof EuiTableColumnManagementComponent, typeof EuiTableColumnManagementSelectColumnsComponent, typeof EuiTopNavigationComponent, typeof EuiTopNavigationCustomMenuItemComponent, typeof EuiTopNavigationMenuItemComponent, typeof EuiTopNavigationMobileMenuItemComponent, typeof EuiVerticalNavigationComponent, typeof EuiSidesheetComponent, typeof EuiSidesheetDirective, typeof EuiSidesheetHeaderDirective, typeof EuiSplashScreenComponent, typeof EuiDownloadDirective, typeof EuiDownloadLoaderComponent, typeof EuiSidesheetContentDirective, typeof EuiSidesheetActionsDirective, typeof EuiClickableDirective, typeof EuiTestIdPipe, typeof DummyComponent, typeof EuiThemeSwitcherComponent, typeof EuiNumberComponent, typeof EuiSubscribeDirective, typeof EuiDateFormatPipe, typeof EuiFormFieldComponent, typeof EuiLabelComponent, typeof EuiFlyoutComponent, typeof EuiFlyoutTriggerDirective, typeof EuiOrderByPipe, typeof EuiUnsavedChangesDialogComponent, typeof EuiOverflowTooltipDirective, typeof EuiTooltipDirective], [typeof i52.CommonModule, typeof EuiMaterialModule, typeof i54.ReactiveFormsModule, typeof i55.RouterModule, typeof i54.FormsModule], [typeof EuiAlertBannerComponent, typeof EuiAlertComponent, typeof EuiAlertContentDirective, typeof EuiAlertHeaderDirective, typeof EuiBadgeComponent, typeof EuiBillboardComponent, typeof EuiDatePickerComponent, typeof EuiTimePickerComponent, typeof EuiIconComponent, typeof EuiJoinPipe, typeof EuiLoadingComponent, typeof EuiLogoComponent, typeof EuiMastheadComponent, typeof EuiReadonlyLabelComponent, typeof EuiSelectComponent, typeof EuiPermissionDirective, typeof EuiScrollComponent, typeof EuiSearchComponent, typeof EuiSidebarComponent, typeof EuiSidesheetComponent, typeof EuiTopNavigationComponent, typeof EuiTopNavigationCustomMenuItemComponent, typeof EuiTopNavigationMenuItemComponent, typeof EuiTopNavigationMobileMenuItemComponent, typeof EuiVerticalNavigationComponent, typeof EuiSplashScreenComponent, typeof EuiDownloadDirective, typeof EuiDownloadLoaderComponent, typeof EuiSidesheetContentDirective, typeof EuiSidesheetActionsDirective, typeof EuiClickableDirective, typeof EuiThemeSwitcherComponent, typeof EuiNumberComponent, typeof EuiSubscribeDirective, typeof EuiDateFormatPipe, typeof EuiFormFieldComponent, typeof EuiLabelComponent, typeof EuiTestIdPipe, typeof EuiFlyoutComponent, typeof EuiFlyoutTriggerDirective, typeof EuiOrderByPipe, typeof EuiTableColumnManagementComponent, typeof EuiOverflowTooltipDirective, typeof EuiTooltipDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<EuiCoreModule>;
}

declare class EuiAlertBannerService {
    private snackbar;
    /**
     * Emits an event when the alert banner is dismissed by the user
     */
    userDismissed: Subject<boolean>;
    private afterDismissed;
    constructor(snackbar: MatSnackBar);
    /**
     * Opens a new instance of an alert banner.
     *
     * @param options Configuration options for the alert banner (including snackbar config). See the [[EuiAlertBannerOptions]] interface for more information.
     */
    open(options: EuiAlertBannerOptions): void;
    /**
     * Removes the alert banner from the page.
     */
    dismiss(): void;
    private openNewBanner;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiAlertBannerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EuiAlertBannerService>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiLoadingService {
    overlay: Overlay;
    private injector;
    get overlayRefs(): OverlayRef[];
    private _overlayRefs;
    constructor(overlay: Overlay, injector: Injector);
    /**
     * Displays the loading component within an overlay
     *
     * @param debounce Optional parameter to add delay before loader is shown. Loader will not be shown if it is hidden before then end of the delay.
     */
    show(debounce?: number, ariaLabel?: string): OverlayRef;
    /**
     * Hides visible loader overlays
     *
     * @param overlayRef: Optional parameter to hide only a specific loader overlay
     */
    hide(overlayRef?: OverlayRef): void;
    private createInjector;
    private disposeOverlayRef;
    private removeOverlayRef;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiLoadingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EuiLoadingService>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiPermissionGuard {
    static canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean | UrlTree>;
    static canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean | UrlTree>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * A service that displays a splash screen
 */
declare class EuiSplashScreenService {
    private overlay;
    private injector;
    /**
     * Returns whether the splash screen is currently open or not
     */
    get isOpen(): boolean;
    private overlayRef;
    private component;
    private animationState$;
    private _isOpen;
    constructor(overlay: Overlay, injector: Injector);
    /**
     * Opens the splash screen component. Only one instance can be opened.
     *
     * @param config Configuration options for the splash screen. See the [[EuiSplashScreenConfig]] interface for more information.
     */
    open(config: EuiSplashScreenConfig): void;
    /**
     * Updates the options used to set the visual state of the splash screen.
     *
     * @param options Options for visual appearance of the splash screen. See the [[EuiSplashScreenOptions]] interface for more information.
     */
    updateState(options: EuiSplashScreenOptions): void;
    /**
     * Closes the splash screen
     */
    close(): void;
    private closeOverlay;
    private getOverlayConfig;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiSplashScreenService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EuiSplashScreenService>;
}

/**
 * A utility service with static methods to normalize the EuiTableColumnManagementConfig, convert layout structures,
 */
declare class EuiTableColumnUtilitiesService {
    /**
     * Processes a EuiTableColumnManagementConfig object to fill in default values
     *
     * @param config A EuiTableColumnManagementConfig structure. The structure is processed in place.
     */
    static normalizeConfig(config: EuiTableColumnManagementConfig): void;
    /**
     * Serializes a EuiTableColumnManagementTableLayout object to a JSON string of EuiTableColumnManagementSavedTableLayout that can then be saved to a user preferences data store.
     *
     * @param layout A EuiTableColumnManagementSavedTableLayout object to convert
     * @return A EuiTableColumnManagementSavedTableLayout as a JSON string
     *
     */
    static createSavedLayout(layout: EuiTableColumnManagementTableLayout): string;
    /**
     * Process a EuiTableColumnManagementSavedTableLayout object or a JSON string of such to populate an existing EuiTableColumnManagementTableLayout object
     *
     * @param savedLayout Either a JSON string or EuiTableColumnManagementSavedTableLayout object to process
     * @param existingLayout A EuiTableColumnManagementTableLayout to populate or update from the savedLayout
     *
     */
    static processSavedLayout(savedLayout: string | EuiTableColumnManagementSavedTableLayout, existingLayout: EuiTableColumnManagementTableLayout): void;
    /**
     * Convert a EuiTableColumnManagementTableLayout to a EuiTableColumnManagementSavedTableLayout
     *
     * @param layout A EuiTableColumnManagementTableLayout to convert
     * @return A populated EuiTableColumnManagementSavedTableLayout object
     */
    static convertToSaved(layout: EuiTableColumnManagementTableLayout): EuiTableColumnManagementSavedTableLayout;
    /**
     * Compares an original and current EuiTableColumnManagementSavedTableLayout to detect changes
     *
     * @param original EuiTableColumnManagementSavedTableLayout
     * @param current EuiTableColumnManagementSavedTableLayout
     * @return boolean True if any changes are detected in sort or column selection / sequence
     */
    static anyEdits(original: EuiTableColumnManagementSavedTableLayout, current: EuiTableColumnManagementTableLayout): boolean;
    private static normalizeDataTypes;
    private static populateLabelTranslations;
    private static doNested;
    static ɵfac: i0.ɵɵFactoryDeclaration<EuiTableColumnUtilitiesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EuiTableColumnUtilitiesService>;
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

declare class EuiVerticalNavigationPermissionUtil {
    private permissionService;
    constructor(permissionService: EuiPermissionService);
    filterItems(items: EuiVerticalNavigationItems): EuiVerticalNavigationItems;
    private filterItemsRecursive;
}

export { DEFAULT_CONFIG, DOWNLOAD_LOADER_CONFIG, DOWNLOAD_REQUEST_SUBSCRIPTION, DUE_TIME, EUI_SIDESHEET_DATA, EUI_SIDESHEET_REF, EUI_SIDESHEET_TEST_ID, EUI_TCM_DEFAULT_LABEL_TRANSLATIONS, EUI_TCM_NEW_CONFIG, EUI_TCM_NEW_SAVED_TABLE_LAYOUT, EUI_TCM_NEW_TABLE_LAYOUT, EUI_THEME_AUTO_LIGHT, EUI_THEME_DEFAULT, EUI_THEME_SKIP_LOAD, EUI_THEME_SKIP_SAVE, EUI_THEME_STORAGE_KEY, EUI_TOOLTIP_DEFAULTS, EUI_UC_DIALOG_TEXT_DEFAULTS, EuiAlertBannerComponent, EuiAlertBannerService, EuiAlertComponent, EuiAlertContentDirective, EuiAlertHeaderDirective, EuiBadgeComponent, EuiBillboardComponent, EuiBillboardService, EuiClickableDirective, EuiCoreModule, EuiDateFormatPipe, EuiDatePickerComponent, EuiDownloadDirective, EuiDownloadLoaderComponent, EuiDownloadService, EuiFlyoutComponent, EuiFlyoutPositionsService, EuiFlyoutTriggerDirective, EuiFormFieldComponent, EuiIconComponent, EuiJoinPipe, EuiLabelComponent, EuiLinkTarget, EuiLoadingComponent, EuiLoadingService, EuiLogoComponent, EuiMastheadComponent, EuiMaterialModule, EuiNumberComponent, EuiOperator, EuiOrderByPipe, EuiOverflowTooltipDirective, EuiPermissionDirective, EuiPermissionGuard, EuiPermissionService, EuiReadonlyLabelComponent, EuiScrollComponent, EuiSearchComponent, EuiSelectComponent, EuiSidebarComponent, EuiSidebarEnum, EuiSidesheetActionsDirective, EuiSidesheetComponent, EuiSidesheetConfig, EuiSidesheetContentDirective, EuiSidesheetContentService, EuiSidesheetDirective, EuiSidesheetEscapeKeyAction, EuiSidesheetHeaderDirective, EuiSidesheetRef, EuiSidesheetService, EuiSplashScreenComponent, EuiSplashScreenService, EuiSubscribeContext, EuiSubscribeDirective, EuiTableColumnManagementComponent, EuiTableColumnManagementSelectColumnsComponent, EuiTableColumnManagementService, EuiTableColumnUtilitiesService, EuiTestIdPipe, EuiTheme, EuiThemeService, EuiThemeSwitcherComponent, EuiTimePickerComponent, EuiTooltipDirective, EuiTopNavigationComponent, EuiTopNavigationCustomMenuItemComponent, EuiTopNavigationItemType, EuiTopNavigationMenuItemComponent, EuiTopNavigationMobileMenuItemComponent, EuiTopNavigationService, EuiUnsavedChangesDialogComponent, EuiUnsavedChangesService, EuiVerticalNavigationComponent, EuiVerticalNavigationExternalLink, EuiVerticalNavigationItem, EuiVerticalNavigationItemType, EuiVerticalNavigationNode, EuiVerticalNavigationPermissionUtil, EuiVerticalNavigationRouterLink, SIDESHEET_CLOSE_ARIA_LABEL, SIDESHEET_DISABLE_CLOSE, SIDESHEET_HEADER_COLOUR, SIDESHEET_ICON, SIDESHEET_INTERNAL_CLOSE_ID, SIDESHEET_PADDING, SIDESHEET_SUB_TITLE, SIDESHEET_TEXT_DIRECTION, SIDESHEET_TITLE, SIDESHEET_WIDTH, SPLASH_SCREEN_OPTIONS, USER_EVENT_DUE_TIME };
export type { CustomTheme, EuiAlertBannerOptions, EuiCustomFiltersConfig, EuiDownloadLoaderConfig, EuiDownloadOptions, EuiFilterCondition, EuiFilterConditionClearData, EuiFilterField, EuiFilterFieldDataType, EuiFilterFieldDataTypeWithOperator, EuiFilterFieldOperators, EuiFilterFieldSingleOperatorKey, EuiFilterGroup, EuiFilterGroupClearData, EuiFilterGroupOrConditionDuplicateData, EuiFilterLabelTranslations, EuiFlyoutOptions, EuiFlyoutPositionX, EuiFlyoutPositionY, EuiGenericType, EuiHrMinStruct, EuiObservableType, EuiPermission, EuiPermissionArray, EuiPermissionObject, EuiRouterLinkOptions, EuiSelectFeedbackMessages, EuiSelectOption, EuiSplashScreenConfig, EuiSplashScreenOptions, EuiSubscriptionType, EuiTableColumnManagementButtonType, EuiTableColumnManagementConfig, EuiTableColumnManagementDataType, EuiTableColumnManagementLabelTranslations, EuiTableColumnManagementSavedTableColumn, EuiTableColumnManagementSavedTableLayout, EuiTableColumnManagementTableColumn, EuiTableColumnManagementTableColumnOption, EuiTableColumnManagementTableLayout, EuiTooltipConfig, EuiTopNavigationItem, EuiUnsavedChangesDialogText, EuiVerticalNavigationExternalLinkOptions, EuiVerticalNavigationItemOptions, EuiVerticalNavigationItems, EuiVerticalNavigationNodeOptions, EuiVerticalNavigationRouterLinkOptions };
