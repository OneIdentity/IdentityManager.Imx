import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Input, HostBinding, Component, Inject, ViewEncapsulation, Injectable, EventEmitter, Output, Directive, InjectionToken, DOCUMENT, Optional, ChangeDetectionStrategy, HostListener, Pipe, ContentChildren, ViewChild, ContentChild, Injector, TemplateRef, inject, ElementRef, Self, ChangeDetectorRef, forwardRef, Renderer2, ViewContainerRef, NgModule } from '@angular/core';
import * as i6 from '@angular/forms';
import { Validators, FormControl, NgModel, NG_VALUE_ACCESSOR, ReactiveFormsModule, FormsModule } from '@angular/forms';
import * as i1$8 from '@angular/router';
import { Router, NavigationEnd, RouterModule } from '@angular/router';
import * as i1 from '@angular/material/snack-bar';
import { MAT_SNACK_BAR_DATA, MatSnackBarModule } from '@angular/material/snack-bar';
import * as i4 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as CadenceIcons from '@elemental-ui/cadence-icon/codepoints';
import * as i5 from 'rxjs';
import { Subject, ReplaySubject, BehaviorSubject, combineLatest, fromEvent, tap as tap$1, throwError, map, isObservable, Subscription, switchMap, of, finalize as finalize$1, merge, takeUntil as takeUntil$1, debounceTime as debounceTime$1, filter as filter$1, take as take$1 } from 'rxjs';
import { tap, debounceTime, takeUntil, catchError, finalize, filter, take } from 'rxjs/operators';
import * as i1$1 from '@angular/cdk/a11y';
import { HighContrastMode, A11yModule } from '@angular/cdk/a11y';
import bb from 'billboard.js';
import moment from 'moment';
import moment$1 from 'moment-timezone';
import * as i3$1 from '@angular/material/datepicker';
import { MatDatepickerModule } from '@angular/material/datepicker';
import * as i2$1 from '@angular/material/form-field';
import { MatFormField, MatFormFieldControl, MAT_PREFIX, MAT_SUFFIX, MatFormFieldModule } from '@angular/material/form-field';
import * as i3 from '@angular/material/input';
import { MatInput, MatInputModule } from '@angular/material/input';
import * as i1$2 from '@angular/material/progress-spinner';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import * as i3$2 from '@angular/material/progress-bar';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import * as i1$4 from '@angular/cdk/overlay';
import { OverlayConfig } from '@angular/cdk/overlay';
import { ComponentPortal, TemplatePortal } from '@angular/cdk/portal';
import * as i1$3 from '@angular/common/http';
import { HttpRequest, HttpEventType } from '@angular/common/http';
import { saveAs } from 'file-saver';
import Scrollbar from 'smooth-scrollbar';
import { trigger, state, transition, style, animate } from '@angular/animations';
import * as i1$5 from '@angular/cdk/bidi';
import * as i7 from '@angular/material/toolbar';
import { MatToolbarModule } from '@angular/material/toolbar';
import * as i1$6 from '@angular/material/tooltip';
import { MatTooltip, MatTooltipModule } from '@angular/material/tooltip';
import { isEqual } from 'lodash';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import * as i2$3 from '@angular/material/divider';
import { MatDividerModule } from '@angular/material/divider';
import * as i4$1 from '@angular/material/radio';
import { MatRadioModule } from '@angular/material/radio';
import * as i2$2 from '@angular/material/autocomplete';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import * as i8 from '@angular/material/select';
import { MatSelectModule } from '@angular/material/select';
import * as i3$3 from '@angular/material/badge';
import { MatBadgeModule } from '@angular/material/badge';
import * as i10 from '@angular/cdk/drag-drop';
import { moveItemInArray, DragDropModule } from '@angular/cdk/drag-drop';
import * as i1$7 from '@angular/material/dialog';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import * as i6$1 from '@angular/material/checkbox';
import { MatCheckboxModule } from '@angular/material/checkbox';
import * as i8$1 from '@angular/material/slide-toggle';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import * as i3$4 from '@angular/material/menu';
import { MatMenuModule } from '@angular/material/menu';
import * as i5$1 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i3$5 from '@angular/material/core';
import { MatNativeDateModule, MatRippleModule } from '@angular/material/core';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { MatBottomSheetModule } from '@angular/material/bottom-sheet';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCardModule } from '@angular/material/card';
import { MatChipsModule } from '@angular/material/chips';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatListModule } from '@angular/material/list';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatSliderModule } from '@angular/material/slider';
import { MatSortModule } from '@angular/material/sort';
import { MatStepperModule } from '@angular/material/stepper';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTreeModule } from '@angular/material/tree';

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiIconComponent {
    /**
     * When true, sets the icons line-height to match the font-size
     *
     * @category Input
     */
    set setLineHeight(val) {
        this._setLineHeight = val;
        if (val && this.fontSize) {
            this.size = this.fontSize;
        }
    }
    constructor(eRef) {
        this.eRef = eRef;
        /** @internal */
        this.fontSize = null;
        /** @internal */
        this.lineHeight = null;
        /**
         * Sets the value of the aria-hidden attribute
         *
         * @category Input
         */
        this.ariaHidden = true;
        this._unicode = '';
        this.iconPresetSize = 'medium';
    }
    /** @internal */
    ngOnInit() {
        this.eRef.nativeElement.classList.add('eui-icon');
        this.eRef.nativeElement.classList.add(this.iconPresetSize);
    }
    /**
     * The selected icon's name to render. See the
     * [guideline](https://elemental.dev.oneidentity.com/design/iconography) for available options.
     *
     * The 'CadenceIconsType' is auto generated from '@elemental-ui/cadence-icon/codepoints.js' file during the npm postinstall step.
     *
     * @category Input
     */
    set icon(i) {
        // if icon hasn't been initialised yet, don't try to set it
        if (!i && !this.innerHTML) {
            return;
        }
        if (Object.keys(CadenceIcons).indexOf(i) < 0) {
            throw Error(`${i} icon is not part of the Cadence Iconset.`);
        }
        this._unicode = CadenceIcons[i].toString(16);
        this.innerHTML = `&#x${this._unicode};`;
    }
    /**
     * Sets the icon's size in pixel. Pre-defined options:
     *
     * - s (small): 16px height
     * - m (medium): 24px height (default)
     * - l (large): 36px height
     * - xl (x-large): 48px height
     *
     * @category Input
     */
    set size(size) {
        this.eRef.nativeElement.classList.remove(this.iconPresetSize);
        switch (size.toLowerCase()) {
            case 's':
                this.iconPresetSize = 'small';
                this.fontSize = '16px';
                this.eRef.nativeElement.classList.add(this.iconPresetSize);
                break;
            case 'm':
                this.iconPresetSize = 'medium';
                this.fontSize = '24px';
                this.eRef.nativeElement.classList.add(this.iconPresetSize);
                break;
            case 'l':
                this.iconPresetSize = 'large';
                this.fontSize = '36px';
                this.eRef.nativeElement.classList.add(this.iconPresetSize);
                break;
            case 'xl':
                this.iconPresetSize = 'x-large';
                this.fontSize = '48px';
                this.eRef.nativeElement.classList.add(this.iconPresetSize);
                break;
            default:
                this.fontSize = size;
        }
        if (this._setLineHeight) {
            this.lineHeight = this.fontSize;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiIconComponent, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.2.1", type: EuiIconComponent, isStandalone: false, selector: "eui-icon", inputs: { ariaHidden: ["aria-hidden", "ariaHidden"], setLineHeight: "setLineHeight", icon: "icon", size: "size" }, host: { properties: { "style.fontSize": "this.fontSize", "style.lineHeight": "this.lineHeight", "innerHTML": "this.innerHTML", "attr.aria-hidden": "this.ariaHidden" } }, ngImport: i0, template: '', isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'eui-icon',
                    template: '',
                    standalone: false
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { fontSize: [{
                type: HostBinding,
                args: ['style.fontSize']
            }], lineHeight: [{
                type: HostBinding,
                args: ['style.lineHeight']
            }], innerHTML: [{
                type: HostBinding,
                args: ['innerHTML']
            }], ariaHidden: [{
                type: HostBinding,
                args: ['attr.aria-hidden']
            }, {
                type: Input,
                args: ['aria-hidden']
            }], setLineHeight: [{
                type: Input
            }], icon: [{
                type: Input
            }], size: [{
                type: Input
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiAlertBannerComponent {
    constructor(snackBarRef, options) {
        this.snackBarRef = snackBarRef;
        this.options = options;
        if (!options.closeAriaLabel) {
            options.closeAriaLabel = 'close';
        }
        if (!options.role) {
            options.role = 'alert';
        }
        if (!options.size) {
            options.size = 'l';
        }
    }
    /** @internal */
    get icon() {
        if (this.options.type === 'success') {
            return 'setdefault';
        }
        if (this.options.type === 'error') {
            return 'error-circle';
        }
        return this.options.type;
    }
    /** @internal */
    get sizeClass() {
        switch (this.options.size.toLowerCase()) {
            case 'small':
            case 's':
                return 'eui-alert-banner--small';
            case 'medium':
            case 'm':
                return 'eui-alert-banner--medium';
            default:
                return '';
        }
    }
    /** @internal */
    get typeClass() {
        return `eui-alert-banner-type--${this.options.type}`;
    }
    /** @internal */
    get classes() {
        return `${this.typeClass} ${this.sizeClass}`;
    }
    /** @internal */
    ngOnInit() {
        if (!this.options.type) {
            this.options.type = 'info';
        }
    }
    /** @internal */
    dismiss() {
        this.snackBarRef.dismissWithAction();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiAlertBannerComponent, deps: [{ token: i1.MatSnackBarRef }, { token: MAT_SNACK_BAR_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.2.1", type: EuiAlertBannerComponent, isStandalone: false, selector: "eui-alert-banner", ngImport: i0, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<div class=\"eui-alert-banner\" [ngClass]=\"classes\" [attr.role]=\"options.role\">\n  <eui-icon [icon]=\"icon\" class=\"eui-alert-banner-icon\" size=\"24px\"></eui-icon>\n  <span [innerHtml]=\"options.message\" class=\"eui-alert-banner-content\"></span>\n  @if (options.dismissable) {\n    <button\n      matIconButton\n      class=\"eui-alert-banner-close\"\n      (click)=\"dismiss()\"\n      [attr.aria-label]=\"options.closeAriaLabel\"\n      data-testid=\"eui-alert-banner-close\"\n      >\n      <eui-icon icon=\"close\" size=\"24px\"></eui-icon>\n    </button>\n  }\n</div>\n", styles: [".eui-dark-theme .mat-mdc-snack-bar-container.eui-alert-banner-panel .mdc-snackbar__surface{background:#444647}.eui-dark-theme .eui-alert-banner{color:#dfe4e6}.eui-dark-theme .eui-alert-banner.eui-alert-banner-type--success .eui-alert-banner-icon{color:#99c478}.eui-dark-theme .eui-alert-banner.eui-alert-banner-type--success{border-color:#99c478}.eui-dark-theme .eui-alert-banner.eui-alert-banner-type--info .eui-alert-banner-icon{color:#8acbe3}.eui-dark-theme .eui-alert-banner.eui-alert-banner-type--info{border-color:#8acbe3}.eui-dark-theme .eui-alert-banner.eui-alert-banner-type--warning .eui-alert-banner-icon{color:#edbe8e}.eui-dark-theme .eui-alert-banner.eui-alert-banner-type--warning{border-color:#edbe8e}.eui-dark-theme .eui-alert-banner.eui-alert-banner-type--error .eui-alert-banner-icon{color:#f29d99}.eui-dark-theme .eui-alert-banner.eui-alert-banner-type--error{border-color:#f29d99}.eui-contrast-theme .mat-mdc-snack-bar-container.eui-alert-banner-panel .mdc-snackbar__surface{background:#18191a}.eui-contrast-theme .eui-alert-banner{color:#dfe4e6}.eui-contrast-theme .eui-alert-banner.eui-alert-banner-type--success .eui-alert-banner-icon{color:#99c478}.eui-contrast-theme .eui-alert-banner.eui-alert-banner-type--success{border-color:#99c478}.eui-contrast-theme .eui-alert-banner.eui-alert-banner-type--info .eui-alert-banner-icon{color:#8acbe3}.eui-contrast-theme .eui-alert-banner.eui-alert-banner-type--info{border-color:#8acbe3}.eui-contrast-theme .eui-alert-banner.eui-alert-banner-type--warning .eui-alert-banner-icon{color:#edbe8e}.eui-contrast-theme .eui-alert-banner.eui-alert-banner-type--warning{border-color:#edbe8e}.eui-contrast-theme .eui-alert-banner.eui-alert-banner-type--error .eui-alert-banner-icon{color:#f29d99}.eui-contrast-theme .eui-alert-banner.eui-alert-banner-type--error{border-color:#f29d99}.eui-contrast-theme .eui-alert-banner{border-bottom:1px solid transparent}.mat-mdc-snack-bar-container.eui-alert-banner-panel .mdc-snackbar__surface{background:#fff}.eui-alert-banner{color:#2f3233}.eui-alert-banner.eui-alert-banner-type--success .eui-alert-banner-icon{color:#4ba803}.eui-alert-banner.eui-alert-banner-type--success{border-color:#4ba803}.eui-alert-banner.eui-alert-banner-type--info .eui-alert-banner-icon{color:#0a96d1}.eui-alert-banner.eui-alert-banner-type--info{border-color:#0a96d1}.eui-alert-banner.eui-alert-banner-type--warning .eui-alert-banner-icon{color:#e36a00}.eui-alert-banner.eui-alert-banner-type--warning{border-color:#e36a00}.eui-alert-banner.eui-alert-banner-type--error .eui-alert-banner-icon{color:#db2534}.eui-alert-banner.eui-alert-banner-type--error{border-color:#db2534}.eui-alert-banner{display:flex;justify-content:center;align-items:center;line-height:24px;opacity:1;font-size:20px;padding:22px 0}.eui-alert-banner.eui-alert-banner--small{font-size:16px;line-height:20px}.eui-alert-banner.eui-alert-banner--medium{font-size:18px;line-height:22px}.eui-alert-banner .eui-alert-banner-close{margin-left:20px;cursor:pointer}[dir=rtl] .eui-alert-banner .eui-alert-banner-close{margin-left:0;margin-right:20px}.eui-alert-banner .eui-alert-banner-icon{padding-right:15px}[dir=rtl] .eui-alert-banner .eui-alert-banner-icon{padding-right:0;padding-left:15px}@media only screen and (max-width: 768px){.eui-alert-banner .eui-alert-banner-content{font-size:16px}}@media only screen and (max-width: 480px){.eui-alert-banner .eui-alert-banner-icon{display:none}}.mat-mdc-snack-bar-container.eui-alert-banner-panel{width:100vw;margin:0}.mat-mdc-snack-bar-container.eui-alert-banner-panel .mdc-snackbar__surface{max-width:100%;margin:0 0 20px;padding:0;box-shadow:0 2px 10px #0000001a;position:absolute;top:64px;left:0;right:0}.mat-mdc-snack-bar-container.eui-alert-banner-panel .mdc-snackbar__label{padding:0}@media (max-width: 768px){.mat-mdc-snack-bar-container.eui-alert-banner-panel .mdc-snackbar__surface{top:56px}}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: EuiIconComponent, selector: "eui-icon", inputs: ["aria-hidden", "setLineHeight", "icon", "size"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiAlertBannerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-alert-banner', encapsulation: ViewEncapsulation.None, standalone: false, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<div class=\"eui-alert-banner\" [ngClass]=\"classes\" [attr.role]=\"options.role\">\n  <eui-icon [icon]=\"icon\" class=\"eui-alert-banner-icon\" size=\"24px\"></eui-icon>\n  <span [innerHtml]=\"options.message\" class=\"eui-alert-banner-content\"></span>\n  @if (options.dismissable) {\n    <button\n      matIconButton\n      class=\"eui-alert-banner-close\"\n      (click)=\"dismiss()\"\n      [attr.aria-label]=\"options.closeAriaLabel\"\n      data-testid=\"eui-alert-banner-close\"\n      >\n      <eui-icon icon=\"close\" size=\"24px\"></eui-icon>\n    </button>\n  }\n</div>\n", styles: [".eui-dark-theme .mat-mdc-snack-bar-container.eui-alert-banner-panel .mdc-snackbar__surface{background:#444647}.eui-dark-theme .eui-alert-banner{color:#dfe4e6}.eui-dark-theme .eui-alert-banner.eui-alert-banner-type--success .eui-alert-banner-icon{color:#99c478}.eui-dark-theme .eui-alert-banner.eui-alert-banner-type--success{border-color:#99c478}.eui-dark-theme .eui-alert-banner.eui-alert-banner-type--info .eui-alert-banner-icon{color:#8acbe3}.eui-dark-theme .eui-alert-banner.eui-alert-banner-type--info{border-color:#8acbe3}.eui-dark-theme .eui-alert-banner.eui-alert-banner-type--warning .eui-alert-banner-icon{color:#edbe8e}.eui-dark-theme .eui-alert-banner.eui-alert-banner-type--warning{border-color:#edbe8e}.eui-dark-theme .eui-alert-banner.eui-alert-banner-type--error .eui-alert-banner-icon{color:#f29d99}.eui-dark-theme .eui-alert-banner.eui-alert-banner-type--error{border-color:#f29d99}.eui-contrast-theme .mat-mdc-snack-bar-container.eui-alert-banner-panel .mdc-snackbar__surface{background:#18191a}.eui-contrast-theme .eui-alert-banner{color:#dfe4e6}.eui-contrast-theme .eui-alert-banner.eui-alert-banner-type--success .eui-alert-banner-icon{color:#99c478}.eui-contrast-theme .eui-alert-banner.eui-alert-banner-type--success{border-color:#99c478}.eui-contrast-theme .eui-alert-banner.eui-alert-banner-type--info .eui-alert-banner-icon{color:#8acbe3}.eui-contrast-theme .eui-alert-banner.eui-alert-banner-type--info{border-color:#8acbe3}.eui-contrast-theme .eui-alert-banner.eui-alert-banner-type--warning .eui-alert-banner-icon{color:#edbe8e}.eui-contrast-theme .eui-alert-banner.eui-alert-banner-type--warning{border-color:#edbe8e}.eui-contrast-theme .eui-alert-banner.eui-alert-banner-type--error .eui-alert-banner-icon{color:#f29d99}.eui-contrast-theme .eui-alert-banner.eui-alert-banner-type--error{border-color:#f29d99}.eui-contrast-theme .eui-alert-banner{border-bottom:1px solid transparent}.mat-mdc-snack-bar-container.eui-alert-banner-panel .mdc-snackbar__surface{background:#fff}.eui-alert-banner{color:#2f3233}.eui-alert-banner.eui-alert-banner-type--success .eui-alert-banner-icon{color:#4ba803}.eui-alert-banner.eui-alert-banner-type--success{border-color:#4ba803}.eui-alert-banner.eui-alert-banner-type--info .eui-alert-banner-icon{color:#0a96d1}.eui-alert-banner.eui-alert-banner-type--info{border-color:#0a96d1}.eui-alert-banner.eui-alert-banner-type--warning .eui-alert-banner-icon{color:#e36a00}.eui-alert-banner.eui-alert-banner-type--warning{border-color:#e36a00}.eui-alert-banner.eui-alert-banner-type--error .eui-alert-banner-icon{color:#db2534}.eui-alert-banner.eui-alert-banner-type--error{border-color:#db2534}.eui-alert-banner{display:flex;justify-content:center;align-items:center;line-height:24px;opacity:1;font-size:20px;padding:22px 0}.eui-alert-banner.eui-alert-banner--small{font-size:16px;line-height:20px}.eui-alert-banner.eui-alert-banner--medium{font-size:18px;line-height:22px}.eui-alert-banner .eui-alert-banner-close{margin-left:20px;cursor:pointer}[dir=rtl] .eui-alert-banner .eui-alert-banner-close{margin-left:0;margin-right:20px}.eui-alert-banner .eui-alert-banner-icon{padding-right:15px}[dir=rtl] .eui-alert-banner .eui-alert-banner-icon{padding-right:0;padding-left:15px}@media only screen and (max-width: 768px){.eui-alert-banner .eui-alert-banner-content{font-size:16px}}@media only screen and (max-width: 480px){.eui-alert-banner .eui-alert-banner-icon{display:none}}.mat-mdc-snack-bar-container.eui-alert-banner-panel{width:100vw;margin:0}.mat-mdc-snack-bar-container.eui-alert-banner-panel .mdc-snackbar__surface{max-width:100%;margin:0 0 20px;padding:0;box-shadow:0 2px 10px #0000001a;position:absolute;top:64px;left:0;right:0}.mat-mdc-snack-bar-container.eui-alert-banner-panel .mdc-snackbar__label{padding:0}@media (max-width: 768px){.mat-mdc-snack-bar-container.eui-alert-banner-panel .mdc-snackbar__surface{top:56px}}\n"] }]
        }], ctorParameters: () => [{ type: i1.MatSnackBarRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_SNACK_BAR_DATA]
                }] }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiAlertBannerService {
    constructor(snackbar) {
        this.snackbar = snackbar;
        /**
         * Emits an event when the alert banner is dismissed by the user
         */
        this.userDismissed = new Subject();
    }
    /**
     * Opens a new instance of an alert banner.
     *
     * @param options Configuration options for the alert banner (including snackbar config). See the [[EuiAlertBannerOptions]] interface for more information.
     */
    open(options) {
        // previous snackbar needs to be dismissed before opening new one to make sure that setting the top doesn't cause the banner to jump about
        if (this.snackbar._openedSnackBarRef) {
            this.afterDismissed = this.snackbar._openedSnackBarRef.afterDismissed().subscribe(() => this.openNewBanner(options));
            this.snackbar.dismiss();
        }
        else {
            this.openNewBanner(options);
        }
    }
    /**
     * Removes the alert banner from the page.
     */
    dismiss() {
        this.userDismissed.next(true);
    }
    openNewBanner(options) {
        if (this.afterDismissed && !this.afterDismissed.closed) {
            this.afterDismissed.unsubscribe();
        }
        const config = {
            verticalPosition: 'top',
            data: options,
            ...options,
        };
        const panelClass = ['eui-alert-banner-panel'];
        if (options.panelClass) {
            panelClass.push(options.panelClass);
        }
        config.panelClass = panelClass;
        const ref = this.snackbar.openFromComponent(EuiAlertBannerComponent, config);
        ref.onAction().subscribe(() => this.dismiss());
        if (options.top) {
            const panel = document.querySelectorAll('.eui-alert-banner-panel .mdc-snackbar__surface')[0];
            panel.style.top = options.top;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiAlertBannerService, deps: [{ token: i1.MatSnackBar }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiAlertBannerService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiAlertBannerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.MatSnackBar }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiAlertComponent {
    constructor() {
        /**
         * Value to be assigned to the aria-label attribute for close icon
         *
         * @category Input
         */
        this.closeAriaLabel = 'close';
        /**
         * Emits an event when the alert is dismissed
         *
         * @category Output
         * @event
         */
        this.dismissed = new EventEmitter();
        /**
         * Value to be used for the role attribute
         *
         * @category Input
         */
        this.role = 'alert';
        /** @internal */
        this.isDismissed = false;
        /** @internal */
        this.classList = [];
    }
    /** @internal */
    get icon() {
        if (this.type === 'success') {
            return 'setdefault';
        }
        if (this.type === 'error') {
            return 'error-circle';
        }
        return this.type;
    }
    /** @internal */
    ngOnInit() {
        this.setupComponent();
    }
    /** @internal */
    ngOnChanges() {
        this.setupComponent();
    }
    /** @internal */
    setupComponent() {
        if (!this.type) {
            this.type = 'info';
        }
        this.classList = [];
        if (this.condensed) {
            this.classList.push('eui-alert-condensed');
        }
        if (this.colored) {
            this.classList.push('eui-alert-colored');
        }
        if (this.custom) {
            this.classList.push(this.custom.className);
            this.type = this.custom.icon;
        }
        this.classList.push(`eui-alert-type--${this.type}`);
    }
    /** @internal */
    dismiss($event) {
        this.isDismissed = true;
        this.dismissed.emit($event);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiAlertComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.2.1", type: EuiAlertComponent, isStandalone: false, selector: "eui-alert", inputs: { colored: "colored", condensed: "condensed", type: "type", dismissable: "dismissable", closeAriaLabel: "closeAriaLabel", custom: "custom", role: "role" }, outputs: { dismissed: "dismissed" }, usesOnChanges: true, ngImport: i0, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n@if (!isDismissed) {\n  <div class=\"eui-alert\" [ngClass]=\"classList\" [attr.role]=\"role\">\n    <eui-icon class=\"eui-alert-icon\" [icon]=\"icon\" [size]=\"condensed ? '20px' : '24px'\"></eui-icon>\n    <div class=\"eui-alert-body\" [ngClass]=\"{ 'eui-alert-body--dismissable': dismissable }\">\n      @if (!header.innerHTML.trim()) {\n        <h5 class=\"eui-alert-header\">\n          <ng-content></ng-content>\n        </h5>\n      }\n      <h5 class=\"eui-alert-header\" #header [hidden]=\"!header.innerHTML.trim()\">\n        <ng-content select=\"eui-alert-header\"></ng-content>\n      </h5>\n      <p class=\"eui-alert-content\" #content [hidden]=\"!header.innerHTML.trim() || !content.innerHTML.trim()\">\n        <ng-content select=\"eui-alert-content\"></ng-content>\n      </p>\n    </div>\n    @if (dismissable) {\n      <button matIconButton class=\"eui-alert-close\" (click)=\"dismiss($event)\" [attr.aria-label]=\"closeAriaLabel\" data-testid=\"eui-alert-close\">\n        <eui-icon icon=\"close\" size=\"20px\"></eui-icon>\n      </button>\n    }\n  </div>\n}\n", styles: [".eui-dark-theme .eui-alert{background-color:#444647}.eui-dark-theme .eui-alert.eui-alert-type--warning{border-color:#edbe8e1a}.eui-dark-theme .eui-alert.eui-alert-type--warning:not(.eui-alert-colored){border-left:5px solid #edbe8e}[dir=rtl] .eui-dark-theme .eui-alert.eui-alert-type--warning:not(.eui-alert-colored){border-left:0;border-right:5px solid #edbe8e}.eui-dark-theme .eui-alert.eui-alert-type--warning .eui-alert-icon{color:#edbe8e}.eui-dark-theme .eui-alert.eui-alert-type--warning.eui-alert-colored{background-color:#592d00;border:1px solid rgba(237,190,142,.1)}.eui-dark-theme .eui-alert.eui-alert-type--error{border-color:#f29d991a}.eui-dark-theme .eui-alert.eui-alert-type--error:not(.eui-alert-colored){border-left:5px solid #f29d99}[dir=rtl] .eui-dark-theme .eui-alert.eui-alert-type--error:not(.eui-alert-colored){border-left:0;border-right:5px solid #f29d99}.eui-dark-theme .eui-alert.eui-alert-type--error .eui-alert-icon{color:#f29d99}.eui-dark-theme .eui-alert.eui-alert-type--error.eui-alert-colored{background-color:#570000;border:1px solid rgba(242,157,153,.1)}.eui-dark-theme .eui-alert.eui-alert-type--success{border-color:#99c4781a}.eui-dark-theme .eui-alert.eui-alert-type--success:not(.eui-alert-colored){border-left:5px solid #99c478}[dir=rtl] .eui-dark-theme .eui-alert.eui-alert-type--success:not(.eui-alert-colored){border-left:0;border-right:5px solid #99c478}.eui-dark-theme .eui-alert.eui-alert-type--success .eui-alert-icon{color:#99c478}.eui-dark-theme .eui-alert.eui-alert-type--success.eui-alert-colored{background-color:#1c4000;border:1px solid rgba(153,196,120,.1)}.eui-dark-theme .eui-alert.eui-alert-type--info{border-color:#8acbe31a}.eui-dark-theme .eui-alert.eui-alert-type--info:not(.eui-alert-colored){border-left:5px solid #8acbe3}[dir=rtl] .eui-dark-theme .eui-alert.eui-alert-type--info:not(.eui-alert-colored){border-left:0;border-right:5px solid #8acbe3}.eui-dark-theme .eui-alert.eui-alert-type--info .eui-alert-icon{color:#8acbe3}.eui-dark-theme .eui-alert.eui-alert-type--info.eui-alert-colored{background-color:#00384d;border:1px solid rgba(138,203,227,.1)}.eui-contrast-theme .eui-alert{background-color:#18191a;border:1px solid transparent}.eui-contrast-theme .eui-alert.eui-alert-type--warning{border-color:#edbe8e}.eui-contrast-theme .eui-alert.eui-alert-type--warning:not(.eui-alert-colored){border-left:5px solid #edbe8e}[dir=rtl] .eui-contrast-theme .eui-alert.eui-alert-type--warning:not(.eui-alert-colored){border-left:0;border-right:5px solid #edbe8e}.eui-contrast-theme .eui-alert.eui-alert-type--warning .eui-alert-icon{color:#edbe8e}.eui-contrast-theme .eui-alert.eui-alert-type--warning.eui-alert-colored{background-color:#592d00b3;border:1px solid #edbe8e}.eui-contrast-theme .eui-alert.eui-alert-type--error{border-color:#f29d99}.eui-contrast-theme .eui-alert.eui-alert-type--error:not(.eui-alert-colored){border-left:5px solid #f29d99}[dir=rtl] .eui-contrast-theme .eui-alert.eui-alert-type--error:not(.eui-alert-colored){border-left:0;border-right:5px solid #f29d99}.eui-contrast-theme .eui-alert.eui-alert-type--error .eui-alert-icon{color:#f29d99}.eui-contrast-theme .eui-alert.eui-alert-type--error.eui-alert-colored{background-color:#570000b3;border:1px solid #f29d99}.eui-contrast-theme .eui-alert.eui-alert-type--success{border-color:#99c478}.eui-contrast-theme .eui-alert.eui-alert-type--success:not(.eui-alert-colored){border-left:5px solid #99c478}[dir=rtl] .eui-contrast-theme .eui-alert.eui-alert-type--success:not(.eui-alert-colored){border-left:0;border-right:5px solid #99c478}.eui-contrast-theme .eui-alert.eui-alert-type--success .eui-alert-icon{color:#99c478}.eui-contrast-theme .eui-alert.eui-alert-type--success.eui-alert-colored{background-color:#1c4000b3;border:1px solid #99c478}.eui-contrast-theme .eui-alert.eui-alert-type--info{border-color:#8acbe3}.eui-contrast-theme .eui-alert.eui-alert-type--info:not(.eui-alert-colored){border-left:5px solid #8acbe3}[dir=rtl] .eui-contrast-theme .eui-alert.eui-alert-type--info:not(.eui-alert-colored){border-left:0;border-right:5px solid #8acbe3}.eui-contrast-theme .eui-alert.eui-alert-type--info .eui-alert-icon{color:#8acbe3}.eui-contrast-theme .eui-alert.eui-alert-type--info.eui-alert-colored{background-color:#00384db3;border:1px solid #8acbe3}.eui-alert{background-color:#fff;border-radius:1px;box-shadow:0 2px 4px -1px #0003,0 4px 5px #00000024,0 1px 10px #0000001f;padding:20px;display:flex;width:100%;position:relative}.eui-alert.eui-alert-colored{box-shadow:0 3px 1px -2px #0003,0 2px 2px #00000024,0 1px 5px #0000001f}.eui-alert .eui-alert-body{flex:1;display:flex;flex-direction:column;align-items:flex-start;padding-left:12px}[dir=rtl] .eui-alert .eui-alert-body{padding-left:0;padding-right:12px}.eui-alert .eui-alert-body.eui-alert-body--dismissable .eui-alert-header{padding-right:40px}[dir=rtl] .eui-alert .eui-alert-body.eui-alert-body--dismissable .eui-alert-header{padding-right:0;padding-left:40px}.eui-alert .eui-alert-bar{border-radius:1px 0 0 1px;height:100%;width:5px}.eui-alert .eui-alert-header{font-size:16px;font-weight:600;line-height:24px}.eui-alert .eui-alert-content{margin:10px 0 0}.eui-alert .eui-alert-close{height:24px;width:24px;line-height:20px;position:absolute;right:14px;top:14px}[dir=rtl] .eui-alert .eui-alert-close{right:auto;left:14px}.eui-alert.eui-alert-type--warning{border-color:#592d001a}.eui-alert.eui-alert-type--warning:not(.eui-alert-colored){border-left:5px solid #e36a00}[dir=rtl] .eui-alert.eui-alert-type--warning:not(.eui-alert-colored){border-left:0;border-right:5px solid #e36a00}.eui-alert.eui-alert-type--warning .eui-alert-icon{color:#e36a00}.eui-alert.eui-alert-type--warning.eui-alert-colored{background-color:#fbefe2;border:1px solid rgba(89,45,0,.1)}.eui-alert.eui-alert-type--error{border-color:#5700001a}.eui-alert.eui-alert-type--error:not(.eui-alert-colored){border-left:5px solid #db2534}[dir=rtl] .eui-alert.eui-alert-type--error:not(.eui-alert-colored){border-left:0;border-right:5px solid #db2534}.eui-alert.eui-alert-type--error .eui-alert-icon{color:#db2534}.eui-alert.eui-alert-type--error.eui-alert-colored{background-color:#fbe3e3;border:1px solid rgba(87,0,0,.1)}.eui-alert.eui-alert-type--success{border-color:#1c40001a}.eui-alert.eui-alert-type--success:not(.eui-alert-colored){border-left:5px solid #4ba803}[dir=rtl] .eui-alert.eui-alert-type--success:not(.eui-alert-colored){border-left:0;border-right:5px solid #4ba803}.eui-alert.eui-alert-type--success .eui-alert-icon{color:#4ba803}.eui-alert.eui-alert-type--success.eui-alert-colored{background-color:#e7f8db;border:1px solid rgba(28,64,0,.1)}.eui-alert.eui-alert-type--info{border-color:#00384d1a}.eui-alert.eui-alert-type--info:not(.eui-alert-colored){border-left:5px solid #0a96d1}[dir=rtl] .eui-alert.eui-alert-type--info:not(.eui-alert-colored){border-left:0;border-right:5px solid #0a96d1}.eui-alert.eui-alert-type--info .eui-alert-icon{color:#0a96d1}.eui-alert.eui-alert-type--info.eui-alert-colored{background-color:#e1f4fa;border:1px solid rgba(0,56,77,.1)}.eui-alert.eui-alert-condensed{padding:16px}.eui-alert.eui-alert-condensed .eui-alert-header{font-size:14px;line-height:20px}.eui-alert.eui-alert-condensed .eui-alert-content{font-size:14px}.eui-alert.eui-alert-condensed .eui-alert-close{top:8px;right:8px}[dir=rtl] .eui-alert.eui-alert-condensed .eui-alert-close{right:auto;left:8px}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: EuiIconComponent, selector: "eui-icon", inputs: ["aria-hidden", "setLineHeight", "icon", "size"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiAlertComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-alert', encapsulation: ViewEncapsulation.None, standalone: false, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n@if (!isDismissed) {\n  <div class=\"eui-alert\" [ngClass]=\"classList\" [attr.role]=\"role\">\n    <eui-icon class=\"eui-alert-icon\" [icon]=\"icon\" [size]=\"condensed ? '20px' : '24px'\"></eui-icon>\n    <div class=\"eui-alert-body\" [ngClass]=\"{ 'eui-alert-body--dismissable': dismissable }\">\n      @if (!header.innerHTML.trim()) {\n        <h5 class=\"eui-alert-header\">\n          <ng-content></ng-content>\n        </h5>\n      }\n      <h5 class=\"eui-alert-header\" #header [hidden]=\"!header.innerHTML.trim()\">\n        <ng-content select=\"eui-alert-header\"></ng-content>\n      </h5>\n      <p class=\"eui-alert-content\" #content [hidden]=\"!header.innerHTML.trim() || !content.innerHTML.trim()\">\n        <ng-content select=\"eui-alert-content\"></ng-content>\n      </p>\n    </div>\n    @if (dismissable) {\n      <button matIconButton class=\"eui-alert-close\" (click)=\"dismiss($event)\" [attr.aria-label]=\"closeAriaLabel\" data-testid=\"eui-alert-close\">\n        <eui-icon icon=\"close\" size=\"20px\"></eui-icon>\n      </button>\n    }\n  </div>\n}\n", styles: [".eui-dark-theme .eui-alert{background-color:#444647}.eui-dark-theme .eui-alert.eui-alert-type--warning{border-color:#edbe8e1a}.eui-dark-theme .eui-alert.eui-alert-type--warning:not(.eui-alert-colored){border-left:5px solid #edbe8e}[dir=rtl] .eui-dark-theme .eui-alert.eui-alert-type--warning:not(.eui-alert-colored){border-left:0;border-right:5px solid #edbe8e}.eui-dark-theme .eui-alert.eui-alert-type--warning .eui-alert-icon{color:#edbe8e}.eui-dark-theme .eui-alert.eui-alert-type--warning.eui-alert-colored{background-color:#592d00;border:1px solid rgba(237,190,142,.1)}.eui-dark-theme .eui-alert.eui-alert-type--error{border-color:#f29d991a}.eui-dark-theme .eui-alert.eui-alert-type--error:not(.eui-alert-colored){border-left:5px solid #f29d99}[dir=rtl] .eui-dark-theme .eui-alert.eui-alert-type--error:not(.eui-alert-colored){border-left:0;border-right:5px solid #f29d99}.eui-dark-theme .eui-alert.eui-alert-type--error .eui-alert-icon{color:#f29d99}.eui-dark-theme .eui-alert.eui-alert-type--error.eui-alert-colored{background-color:#570000;border:1px solid rgba(242,157,153,.1)}.eui-dark-theme .eui-alert.eui-alert-type--success{border-color:#99c4781a}.eui-dark-theme .eui-alert.eui-alert-type--success:not(.eui-alert-colored){border-left:5px solid #99c478}[dir=rtl] .eui-dark-theme .eui-alert.eui-alert-type--success:not(.eui-alert-colored){border-left:0;border-right:5px solid #99c478}.eui-dark-theme .eui-alert.eui-alert-type--success .eui-alert-icon{color:#99c478}.eui-dark-theme .eui-alert.eui-alert-type--success.eui-alert-colored{background-color:#1c4000;border:1px solid rgba(153,196,120,.1)}.eui-dark-theme .eui-alert.eui-alert-type--info{border-color:#8acbe31a}.eui-dark-theme .eui-alert.eui-alert-type--info:not(.eui-alert-colored){border-left:5px solid #8acbe3}[dir=rtl] .eui-dark-theme .eui-alert.eui-alert-type--info:not(.eui-alert-colored){border-left:0;border-right:5px solid #8acbe3}.eui-dark-theme .eui-alert.eui-alert-type--info .eui-alert-icon{color:#8acbe3}.eui-dark-theme .eui-alert.eui-alert-type--info.eui-alert-colored{background-color:#00384d;border:1px solid rgba(138,203,227,.1)}.eui-contrast-theme .eui-alert{background-color:#18191a;border:1px solid transparent}.eui-contrast-theme .eui-alert.eui-alert-type--warning{border-color:#edbe8e}.eui-contrast-theme .eui-alert.eui-alert-type--warning:not(.eui-alert-colored){border-left:5px solid #edbe8e}[dir=rtl] .eui-contrast-theme .eui-alert.eui-alert-type--warning:not(.eui-alert-colored){border-left:0;border-right:5px solid #edbe8e}.eui-contrast-theme .eui-alert.eui-alert-type--warning .eui-alert-icon{color:#edbe8e}.eui-contrast-theme .eui-alert.eui-alert-type--warning.eui-alert-colored{background-color:#592d00b3;border:1px solid #edbe8e}.eui-contrast-theme .eui-alert.eui-alert-type--error{border-color:#f29d99}.eui-contrast-theme .eui-alert.eui-alert-type--error:not(.eui-alert-colored){border-left:5px solid #f29d99}[dir=rtl] .eui-contrast-theme .eui-alert.eui-alert-type--error:not(.eui-alert-colored){border-left:0;border-right:5px solid #f29d99}.eui-contrast-theme .eui-alert.eui-alert-type--error .eui-alert-icon{color:#f29d99}.eui-contrast-theme .eui-alert.eui-alert-type--error.eui-alert-colored{background-color:#570000b3;border:1px solid #f29d99}.eui-contrast-theme .eui-alert.eui-alert-type--success{border-color:#99c478}.eui-contrast-theme .eui-alert.eui-alert-type--success:not(.eui-alert-colored){border-left:5px solid #99c478}[dir=rtl] .eui-contrast-theme .eui-alert.eui-alert-type--success:not(.eui-alert-colored){border-left:0;border-right:5px solid #99c478}.eui-contrast-theme .eui-alert.eui-alert-type--success .eui-alert-icon{color:#99c478}.eui-contrast-theme .eui-alert.eui-alert-type--success.eui-alert-colored{background-color:#1c4000b3;border:1px solid #99c478}.eui-contrast-theme .eui-alert.eui-alert-type--info{border-color:#8acbe3}.eui-contrast-theme .eui-alert.eui-alert-type--info:not(.eui-alert-colored){border-left:5px solid #8acbe3}[dir=rtl] .eui-contrast-theme .eui-alert.eui-alert-type--info:not(.eui-alert-colored){border-left:0;border-right:5px solid #8acbe3}.eui-contrast-theme .eui-alert.eui-alert-type--info .eui-alert-icon{color:#8acbe3}.eui-contrast-theme .eui-alert.eui-alert-type--info.eui-alert-colored{background-color:#00384db3;border:1px solid #8acbe3}.eui-alert{background-color:#fff;border-radius:1px;box-shadow:0 2px 4px -1px #0003,0 4px 5px #00000024,0 1px 10px #0000001f;padding:20px;display:flex;width:100%;position:relative}.eui-alert.eui-alert-colored{box-shadow:0 3px 1px -2px #0003,0 2px 2px #00000024,0 1px 5px #0000001f}.eui-alert .eui-alert-body{flex:1;display:flex;flex-direction:column;align-items:flex-start;padding-left:12px}[dir=rtl] .eui-alert .eui-alert-body{padding-left:0;padding-right:12px}.eui-alert .eui-alert-body.eui-alert-body--dismissable .eui-alert-header{padding-right:40px}[dir=rtl] .eui-alert .eui-alert-body.eui-alert-body--dismissable .eui-alert-header{padding-right:0;padding-left:40px}.eui-alert .eui-alert-bar{border-radius:1px 0 0 1px;height:100%;width:5px}.eui-alert .eui-alert-header{font-size:16px;font-weight:600;line-height:24px}.eui-alert .eui-alert-content{margin:10px 0 0}.eui-alert .eui-alert-close{height:24px;width:24px;line-height:20px;position:absolute;right:14px;top:14px}[dir=rtl] .eui-alert .eui-alert-close{right:auto;left:14px}.eui-alert.eui-alert-type--warning{border-color:#592d001a}.eui-alert.eui-alert-type--warning:not(.eui-alert-colored){border-left:5px solid #e36a00}[dir=rtl] .eui-alert.eui-alert-type--warning:not(.eui-alert-colored){border-left:0;border-right:5px solid #e36a00}.eui-alert.eui-alert-type--warning .eui-alert-icon{color:#e36a00}.eui-alert.eui-alert-type--warning.eui-alert-colored{background-color:#fbefe2;border:1px solid rgba(89,45,0,.1)}.eui-alert.eui-alert-type--error{border-color:#5700001a}.eui-alert.eui-alert-type--error:not(.eui-alert-colored){border-left:5px solid #db2534}[dir=rtl] .eui-alert.eui-alert-type--error:not(.eui-alert-colored){border-left:0;border-right:5px solid #db2534}.eui-alert.eui-alert-type--error .eui-alert-icon{color:#db2534}.eui-alert.eui-alert-type--error.eui-alert-colored{background-color:#fbe3e3;border:1px solid rgba(87,0,0,.1)}.eui-alert.eui-alert-type--success{border-color:#1c40001a}.eui-alert.eui-alert-type--success:not(.eui-alert-colored){border-left:5px solid #4ba803}[dir=rtl] .eui-alert.eui-alert-type--success:not(.eui-alert-colored){border-left:0;border-right:5px solid #4ba803}.eui-alert.eui-alert-type--success .eui-alert-icon{color:#4ba803}.eui-alert.eui-alert-type--success.eui-alert-colored{background-color:#e7f8db;border:1px solid rgba(28,64,0,.1)}.eui-alert.eui-alert-type--info{border-color:#00384d1a}.eui-alert.eui-alert-type--info:not(.eui-alert-colored){border-left:5px solid #0a96d1}[dir=rtl] .eui-alert.eui-alert-type--info:not(.eui-alert-colored){border-left:0;border-right:5px solid #0a96d1}.eui-alert.eui-alert-type--info .eui-alert-icon{color:#0a96d1}.eui-alert.eui-alert-type--info.eui-alert-colored{background-color:#e1f4fa;border:1px solid rgba(0,56,77,.1)}.eui-alert.eui-alert-condensed{padding:16px}.eui-alert.eui-alert-condensed .eui-alert-header{font-size:14px;line-height:20px}.eui-alert.eui-alert-condensed .eui-alert-content{font-size:14px}.eui-alert.eui-alert-condensed .eui-alert-close{top:8px;right:8px}[dir=rtl] .eui-alert.eui-alert-condensed .eui-alert-close{right:auto;left:8px}\n"] }]
        }], propDecorators: { colored: [{
                type: Input
            }], condensed: [{
                type: Input
            }], type: [{
                type: Input
            }], dismissable: [{
                type: Input
            }], closeAriaLabel: [{
                type: Input
            }], custom: [{
                type: Input
            }], dismissed: [{
                type: Output
            }], role: [{
                type: Input
            }] } });
// Directives required to use tags for ng-content selector
class EuiAlertHeaderDirective {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiAlertHeaderDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.2.1", type: EuiAlertHeaderDirective, isStandalone: false, selector: "eui-alert-header", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiAlertHeaderDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/directive-selector
                    selector: 'eui-alert-header',
                    standalone: false
                }]
        }] });
class EuiAlertContentDirective {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiAlertContentDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.2.1", type: EuiAlertContentDirective, isStandalone: false, selector: "eui-alert-content", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiAlertContentDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/directive-selector
                    selector: 'eui-alert-content',
                    standalone: false
                }]
        }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiBadgeComponent {
    constructor() {
        /** @internal */
        this.class = 'eui-badge';
        /**
         * Set the background color of the badge
         *
         * Can be set as a custom hex value or one of the following palette colors:
         * primary, accent, warn, blue, darkblue, red, orange, green, yellow, pink, white, gray, gunmetal, black, purple
         *
         * @category Input
         */
        this.color = 'primary';
        /**
         * Set the text color of the badge
         *
         * Can be set as a custom hex value or one of the following palette colors:
         * black, white
         *
         * @category Input
         */
        this.textColor = '';
        /**
         * Set the size of the badge
         *
         * Defauls to "small", but can be set as one of the following sizes:
         * small, medium, large
         *
         * @category Input
         */
        this.size = 'small';
        /** @internal */
        this.possibleBgColors = [
            'primary',
            'accent',
            'warn',
            'blue',
            'darkblue',
            'red',
            'orange',
            'green',
            'yellow',
            'pink',
            'white',
            'gray',
            'gunmetal',
            'black',
            'purple',
        ];
        /** @internal */
        this.possibleTextColors = ['black', 'white'];
    }
    /** @internal */
    get colorClass() {
        const colorClass = this.isCustomBg ? 'default' : this.color;
        return `eui-badge-color--${colorClass}`;
    }
    /** @internal */
    get textColorClass() {
        const colorClass = this.isCustomText ? 'default' : this.textColor;
        return `eui-badge-text--${colorClass}`;
    }
    /** @internal */
    get sizeClass() {
        return `eui-badge--${this.size}`;
    }
    /** @internal */
    get cssClasses() {
        return `eui-badge-content ${this.colorClass} ${this.textColorClass} ${this.sizeClass}`;
    }
    /** @internal */
    get isCustomBg() {
        const color = this.color.toLowerCase();
        return this.possibleBgColors.indexOf(color) === -1;
    }
    /** @internal */
    get isCustomText() {
        const color = this.textColor.toLowerCase();
        return this.possibleTextColors.indexOf(color) === -1;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiBadgeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.2.1", type: EuiBadgeComponent, isStandalone: false, selector: "eui-badge", inputs: { color: "color", textColor: "textColor", size: "size" }, host: { properties: { "class": "this.class" } }, ngImport: i0, template: "<!--\n    Copyright 2025 One Identity LLC.\n    ALL RIGHTS RESERVED.\n-->\n\n<div [className]=\"cssClasses\" [style.backgroundColor]=\"isCustomBg ? color : ''\" [style.color]=\"isCustomText ? textColor : ''\">\n  <div>\n    <ng-content></ng-content>\n  </div>\n</div>\n", styles: [".eui-dark-theme :host.eui-badge{color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-color--blue{background-color:#016b91;color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-color--black{background-color:#000;color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-color--white{background-color:#fff;color:#000}.eui-dark-theme :host.eui-badge .eui-badge-color--gray{background-color:#616566;color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-color--red{background-color:#900;color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-color--orange{background-color:#a65300;color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-color--green{background-color:#327301;color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-content{border-color:#000}.eui-dark-theme :host.eui-badge .eui-badge-color--yellow{background-color:#948500;color:#000}.eui-dark-theme :host.eui-badge .eui-badge-color--purple{background-color:#8200a6;color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-color--pink{background-color:#a8007b;color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-color--primary{background-color:#016b91;color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-color--accent{background-color:#a65300;color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-content{border-color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-color--warn{background-color:#900;color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-text--white{color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-text--black{color:#000}.eui-contrast-theme :host.eui-badge{color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-text--white{color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-text--black{color:#18191a}.eui-contrast-theme :host.eui-badge .eui-badge-color--blue{background-color:#00384d;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-color--black{background-color:#000;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-content{border-color:#2f3233}.eui-contrast-theme :host.eui-badge .eui-badge-color--white{background-color:#fff;color:#2f3233}.eui-contrast-theme :host.eui-badge .eui-badge-color--gray{background-color:#444647;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-color--red{background-color:#570000;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-color--orange{background-color:#592d00;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-color--green{background-color:#1c4000;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-color--yellow{background-color:#403900;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-color--purple{background-color:#460059;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-color--pink{background-color:#590041;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-color--primary{background-color:#016b91;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-color--accent{background-color:#a65300;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-content{border-color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-color--warn{background-color:#900;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-content{border:1px solid}:host.eui-badge{color:#fff}:host.eui-badge .eui-badge-color--blue{background-color:#0a96d1;color:#fff}:host.eui-badge .eui-badge-color--black{background-color:#000;color:#fff}:host.eui-badge .eui-badge-color--white{background-color:#fff;color:#000}:host.eui-badge .eui-badge-color--gray{background-color:#c4cacc;color:#000}:host.eui-badge .eui-badge-color--red{background-color:#db2534;color:#fff}:host.eui-badge .eui-badge-color--orange{background-color:#e36a00;color:#fff}:host.eui-badge .eui-badge-color--green{background-color:#4ba803;color:#fff}:host.eui-badge .eui-badge-content{border-color:#000}:host.eui-badge .eui-badge-color--yellow{background-color:#ead200;color:#000}:host.eui-badge .eui-badge-color--purple{background-color:#b400e5;color:#fff}:host.eui-badge .eui-badge-color--pink{background-color:#f800b6;color:#fff}:host.eui-badge .eui-badge-color--primary{background-color:#0a96d1;color:#fff}:host.eui-badge .eui-badge-color--accent{background-color:#e36a00;color:#fff}:host.eui-badge .eui-badge-content{border-color:#fff}:host.eui-badge .eui-badge-color--warn{background-color:#db2534;color:#fff}:host.eui-badge .eui-badge-text--white{color:#fff}:host.eui-badge .eui-badge-text--black{color:#000}:host.eui-badge{display:inline-block}:host.eui-badge .eui-badge-content{border-radius:4px;padding:4px 8px;box-shadow:0 1px 2px #0003;vertical-align:top;font-size:10px;line-height:9px}:host.eui-badge .eui-badge-content.eui-badge--medium{font-size:14px;line-height:14px}:host.eui-badge .eui-badge-content.eui-badge--large{font-size:18px;line-height:18px;padding:5px 8px}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiBadgeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-badge', standalone: false, template: "<!--\n    Copyright 2025 One Identity LLC.\n    ALL RIGHTS RESERVED.\n-->\n\n<div [className]=\"cssClasses\" [style.backgroundColor]=\"isCustomBg ? color : ''\" [style.color]=\"isCustomText ? textColor : ''\">\n  <div>\n    <ng-content></ng-content>\n  </div>\n</div>\n", styles: [".eui-dark-theme :host.eui-badge{color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-color--blue{background-color:#016b91;color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-color--black{background-color:#000;color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-color--white{background-color:#fff;color:#000}.eui-dark-theme :host.eui-badge .eui-badge-color--gray{background-color:#616566;color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-color--red{background-color:#900;color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-color--orange{background-color:#a65300;color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-color--green{background-color:#327301;color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-content{border-color:#000}.eui-dark-theme :host.eui-badge .eui-badge-color--yellow{background-color:#948500;color:#000}.eui-dark-theme :host.eui-badge .eui-badge-color--purple{background-color:#8200a6;color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-color--pink{background-color:#a8007b;color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-color--primary{background-color:#016b91;color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-color--accent{background-color:#a65300;color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-content{border-color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-color--warn{background-color:#900;color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-text--white{color:#fff}.eui-dark-theme :host.eui-badge .eui-badge-text--black{color:#000}.eui-contrast-theme :host.eui-badge{color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-text--white{color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-text--black{color:#18191a}.eui-contrast-theme :host.eui-badge .eui-badge-color--blue{background-color:#00384d;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-color--black{background-color:#000;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-content{border-color:#2f3233}.eui-contrast-theme :host.eui-badge .eui-badge-color--white{background-color:#fff;color:#2f3233}.eui-contrast-theme :host.eui-badge .eui-badge-color--gray{background-color:#444647;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-color--red{background-color:#570000;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-color--orange{background-color:#592d00;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-color--green{background-color:#1c4000;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-color--yellow{background-color:#403900;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-color--purple{background-color:#460059;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-color--pink{background-color:#590041;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-color--primary{background-color:#016b91;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-color--accent{background-color:#a65300;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-content{border-color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-color--warn{background-color:#900;color:#fff}.eui-contrast-theme :host.eui-badge .eui-badge-content{border:1px solid}:host.eui-badge{color:#fff}:host.eui-badge .eui-badge-color--blue{background-color:#0a96d1;color:#fff}:host.eui-badge .eui-badge-color--black{background-color:#000;color:#fff}:host.eui-badge .eui-badge-color--white{background-color:#fff;color:#000}:host.eui-badge .eui-badge-color--gray{background-color:#c4cacc;color:#000}:host.eui-badge .eui-badge-color--red{background-color:#db2534;color:#fff}:host.eui-badge .eui-badge-color--orange{background-color:#e36a00;color:#fff}:host.eui-badge .eui-badge-color--green{background-color:#4ba803;color:#fff}:host.eui-badge .eui-badge-content{border-color:#000}:host.eui-badge .eui-badge-color--yellow{background-color:#ead200;color:#000}:host.eui-badge .eui-badge-color--purple{background-color:#b400e5;color:#fff}:host.eui-badge .eui-badge-color--pink{background-color:#f800b6;color:#fff}:host.eui-badge .eui-badge-color--primary{background-color:#0a96d1;color:#fff}:host.eui-badge .eui-badge-color--accent{background-color:#e36a00;color:#fff}:host.eui-badge .eui-badge-content{border-color:#fff}:host.eui-badge .eui-badge-color--warn{background-color:#db2534;color:#fff}:host.eui-badge .eui-badge-text--white{color:#fff}:host.eui-badge .eui-badge-text--black{color:#000}:host.eui-badge{display:inline-block}:host.eui-badge .eui-badge-content{border-radius:4px;padding:4px 8px;box-shadow:0 1px 2px #0003;vertical-align:top;font-size:10px;line-height:9px}:host.eui-badge .eui-badge-content.eui-badge--medium{font-size:14px;line-height:14px}:host.eui-badge .eui-badge-content.eui-badge--large{font-size:18px;line-height:18px;padding:5px 8px}\n"] }]
        }], propDecorators: { class: [{
                type: HostBinding,
                args: ['class']
            }], color: [{
                type: Input
            }], textColor: [{
                type: Input
            }], size: [{
                type: Input
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
const EUI_THEME_DEFAULT = new InjectionToken('EUI_THEME_DEFAULT');
const EUI_THEME_AUTO_LIGHT = new InjectionToken('EUI_THEME_AUTO_LIGHT');
const EUI_THEME_STORAGE_KEY = new InjectionToken('EUI_THEME_STORAGE_KEY');
const EUI_THEME_SKIP_SAVE = new InjectionToken('EUI_THEME_SKIP_SAVE');
const EUI_THEME_SKIP_LOAD = new InjectionToken('EUI_THEME_SKIP_LOAD');
var EuiTheme;
(function (EuiTheme) {
    EuiTheme["DARK"] = "eui-dark-theme";
    EuiTheme["LIGHT"] = "eui-light-theme";
    EuiTheme["CONTRAST"] = "eui-contrast-theme";
    EuiTheme["AUTO"] = "eui-auto-theme";
})(EuiTheme || (EuiTheme = {}));

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
const DEFAULT_THEME = EuiTheme.LIGHT;
const DEFAULT_AUTO_LIGHT_THEME = EuiTheme.LIGHT;
const DEFAULT_STORAGE_KEY = 'eui-theme';
const DEFAULT_SKIP_SAVE = false;
const DEFAULT_SKIP_LOAD = false;
/**
 * Gives ability to change the global theme
 */
class EuiThemeService {
    constructor(highContrastModeDetector, document, defaultTheme, autoLightTheme, storageKey, skipSave, skipLoad) {
        this.highContrastModeDetector = highContrastModeDetector;
        this.document = document;
        this.actualTheme = new ReplaySubject(1);
        this.preferredColorScheme = new BehaviorSubject(null);
        this.themeSwitcherState = new BehaviorSubject(DEFAULT_THEME);
        this.autoLightTheme = DEFAULT_AUTO_LIGHT_THEME;
        this.defaultTheme = DEFAULT_THEME;
        this.storageKey = DEFAULT_STORAGE_KEY;
        this.skipSave = DEFAULT_SKIP_SAVE;
        this.skipLoad = DEFAULT_SKIP_LOAD;
        this.onAutomaticThemeChange = (event) => {
            this.preferredColorScheme.next(event.matches ? EuiTheme.DARK : this.autoLightTheme);
        };
        this.updateTheme = () => {
            const themeSwitcherState = this.themeSwitcherState.value;
            let chosenState = themeSwitcherState;
            if (themeSwitcherState === EuiTheme.AUTO)
                chosenState = this.isDarkMode() ? EuiTheme.DARK : this.autoLightTheme;
            this.actualTheme.subscribe((theme) => this.clearClasses(theme));
            this.actualTheme.next(chosenState);
            this.addClass(chosenState);
            this.saveTheme();
        };
        this.autoLightTheme = autoLightTheme ?? DEFAULT_AUTO_LIGHT_THEME;
        this.defaultTheme = defaultTheme ?? DEFAULT_THEME;
        this.storageKey = storageKey ?? DEFAULT_STORAGE_KEY;
        this.skipSave = skipSave ?? DEFAULT_SKIP_SAVE;
        this.skipLoad = skipLoad ?? DEFAULT_SKIP_LOAD;
        this.watchPrefersColorSchemeChanges();
        this.watchForcedColorsChange();
        this.resetToDefault();
        if (!this.skipLoad)
            this.loadTheme();
        combineLatest([this.themeSwitcherState, this.preferredColorScheme])
            .pipe(tap(() => {
            const highContrastMode = this.highContrastModeDetector.getHighContrastMode();
            if (highContrastMode !== HighContrastMode.NONE) {
                this.highContrastThemeSupport();
            }
            else {
                this.updateTheme();
            }
        }))
            .subscribe();
    }
    /**
     * Setting the actual theme
     *
     * @param theme This theme set
     */
    setTheme(theme) {
        this.themeSwitcherState.next(theme);
    }
    /**
     * Get notification from the theme changing, that contains the automatic switches too.
     */
    getActualTheme() {
        return this.actualTheme.asObservable();
    }
    /**
     * Get notification from the theme switcher state changing
     */
    getThemeSwitcherState() {
        return this.themeSwitcherState.asObservable();
    }
    /**
     * Reset the theme to the default
     */
    resetToDefault() {
        const defaultTheme = Object.values(EuiTheme).includes(this.defaultTheme) ? this.defaultTheme : DEFAULT_THEME;
        this.themeSwitcherState.next(defaultTheme);
    }
    highContrastThemeSupport() {
        const chosenState = EuiTheme.CONTRAST;
        this.actualTheme.subscribe((theme) => this.clearClasses(theme));
        this.addClass(chosenState);
    }
    watchPrefersColorSchemeChanges() {
        if (window?.matchMedia)
            window.matchMedia('(prefers-color-scheme: dark)').onchange = this.onAutomaticThemeChange;
    }
    watchForcedColorsChange() {
        if (window?.matchMedia)
            window.matchMedia('(forced-colors: active)').onchange = this.onAutomaticThemeChange;
    }
    isDarkMode() {
        return window?.matchMedia && window?.matchMedia('(prefers-color-scheme: dark)')?.matches;
    }
    saveTheme() {
        if (!this.skipSave)
            localStorage?.setItem(this.storageKey, this.themeSwitcherState.value);
    }
    loadTheme() {
        const theme = localStorage?.getItem(this.storageKey);
        if (theme) {
            this.themeSwitcherState.next(theme);
        }
        this.updateTheme();
    }
    clearClasses(previousTheme) {
        this.document?.body?.classList?.remove(...Object.values(EuiTheme));
        if (previousTheme) {
            // remove theme if it is a custom theme
            this.document?.body?.classList?.remove(previousTheme);
        }
    }
    addClass(classToAdd) {
        if (!classToAdd)
            return;
        this.document?.body?.classList?.add(classToAdd);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiThemeService, deps: [{ token: i1$1.HighContrastModeDetector }, { token: DOCUMENT }, { token: EUI_THEME_DEFAULT, optional: true }, { token: EUI_THEME_AUTO_LIGHT, optional: true }, { token: EUI_THEME_STORAGE_KEY, optional: true }, { token: EUI_THEME_SKIP_SAVE, optional: true }, { token: EUI_THEME_SKIP_LOAD, optional: true }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiThemeService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiThemeService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.HighContrastModeDetector }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: EuiTheme, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [EUI_THEME_DEFAULT]
                }] }, { type: EuiTheme, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [EUI_THEME_AUTO_LIGHT]
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [EUI_THEME_STORAGE_KEY]
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [EUI_THEME_SKIP_SAVE]
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [EUI_THEME_SKIP_LOAD]
                }] }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiBillboardService {
    constructor(ngZone) {
        this.ngZone = ngZone;
    }
    /**
     * Generate function which call original billboard generate function
     */
    generate(options) {
        return this.ngZone.run(() => bb.generate(options));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiBillboardService, deps: [{ token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiBillboardService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiBillboardService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i0.NgZone }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiBillboardComponent {
    /**
     * You can set billboard.js options with this input, more details see ChartOptions type
     *
     * @category Input
     */
    set options(options) {
        if (!options) {
            return;
        }
        this._options = options;
    }
    constructor(elementRef, euiThemeService, chartService) {
        this.elementRef = elementRef;
        this.euiThemeService = euiThemeService;
        this.chartService = chartService;
        /**
         * Emit the generated chart to use for advanced functionality
         *
         * @category Output
         * @event
         */
        this.chart = new EventEmitter();
        /**
         * Emit event before chart destroy
         *
         * @category Output
         * @event
         */
        this.beforeDestroy = new EventEmitter();
        this._chart = null;
    }
    /** @internal */
    ngOnInit() {
        this.euiThemeService
            .getActualTheme()
            .pipe(debounceTime(0), tap((theme) => {
            this._currentTheme = theme;
            this.setupChart();
        }))
            .subscribe();
    }
    /** @internal */
    ngOnDestroy() {
        this.beforeDestroy.emit(true);
        if (this._chart !== null) {
            this._chart.destroy();
        }
    }
    setupChart() {
        if (!this._options) {
            return;
        }
        this.updateColors();
        // If there is already a chart, try to clean it up before creating a new one.
        if (this._chart !== null) {
            try {
                this._chart.destroy();
            }
            catch (exception) {
                // There are times when trying to clean up a chart throws an error.
                // We'll just catch it and ignore it.
            }
        }
        this._chart = this.chartService.generate({
            bindto: this.elementRef.nativeElement.firstChild,
            ...this._options,
        });
        this.chart.emit(this._chart);
    }
    updateColors() {
        let colors = ['#0a96d1', '#db2534', '#4ba803', '#ead200', '#b400e5', '#f800b6', '#616566'];
        if (this._currentTheme === EuiTheme.DARK || this._currentTheme === EuiTheme.CONTRAST) {
            colors = ['#8acbe3', '#f29d99', '#99c478', '#f2e991', '#d98eed', '#fa96df', '#aab0b3'];
        }
        if (!this._options.color) {
            this._options.color = {};
        }
        if (!this._options.color.pattern) {
            this._options.color.pattern = colors;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiBillboardComponent, deps: [{ token: i0.ElementRef }, { token: EuiThemeService }, { token: EuiBillboardService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.2.1", type: EuiBillboardComponent, isStandalone: false, selector: "eui-billboard", inputs: { options: "options" }, outputs: { chart: "chart", beforeDestroy: "beforeDestroy" }, ngImport: i0, template: '<div></div>', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiBillboardComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'eui-billboard',
                    template: '<div></div>',
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    standalone: false
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: EuiThemeService }, { type: EuiBillboardService }], propDecorators: { options: [{
                type: Input
            }], chart: [{
                type: Output
            }], beforeDestroy: [{
                type: Output
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiClickableDirective {
    /**
     * Focus and hover color for the element
     *
     * @category Input
     */
    set color(color) {
        this._color = color;
        this.setupClasses();
    }
    /**
     * Focus and hover color for the element
     *
     * @category Input
     */
    set disabled(disabled) {
        this._forceDisabled = disabled;
        this.setupClasses();
    }
    constructor(el) {
        /** @internal */
        this.tabindex = 0;
        /** @internal */
        this.class = 'eui-clickable';
        this._color = '';
        this._disabled = false;
        this._forceDisabled = false;
        this.element = el;
        const nativeEl = this.element.nativeElement;
        if (nativeEl.nodeName?.toLowerCase() !== 'tr') {
            nativeEl.setAttribute('role', 'button');
        }
        this.clickSubscription = fromEvent(el.nativeElement, 'click', { capture: true })
            .pipe(tap$1((event) => {
            if (this._disabled) {
                event.stopPropagation();
            }
            if (event.target !== event.currentTarget) {
                event.stopPropagation();
                this.element.nativeElement.click();
            }
        }))
            .subscribe();
    }
    /** @internal */
    keyDown(event) {
        if (!this._disabled && (event.key === ' ' || event.key === 'Enter')) {
            this.element.nativeElement.click();
        }
    }
    ngOnDestroy() {
        if (this.clickSubscription) {
            this.clickSubscription.unsubscribe();
        }
    }
    setupClasses() {
        this._disabled = this._color === 'disabled' || this._forceDisabled;
        this.tabindex = this._disabled ? -1 : 0;
        this.element.nativeElement.classList.remove('eui-clickable--primary', 'eui-clickable--accent');
        if (this._color) {
            this.element.nativeElement.classList.add(`eui-clickable--${this._color}`);
        }
        if (this._disabled) {
            this.element.nativeElement.classList.add(`eui-clickable--off`);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiClickableDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.2.1", type: EuiClickableDirective, isStandalone: false, selector: "[euiClickable]", inputs: { color: ["euiClickable", "color"], disabled: ["euiClickableDisabled", "disabled"] }, host: { listeners: { "keydown": "keyDown($event)" }, properties: { "attr.tabindex": "this.tabindex", "class": "this.class" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiClickableDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[euiClickable]',
                    standalone: false
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { tabindex: [{
                type: HostBinding,
                args: ['attr.tabindex']
            }], class: [{
                type: HostBinding,
                args: ['class']
            }], color: [{
                type: Input,
                args: ['euiClickable']
            }], disabled: [{
                type: Input,
                args: ['euiClickableDisabled']
            }], keyDown: [{
                type: HostListener,
                args: ['keydown', ['$event']]
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiDateFormatPipe {
    /**
     * A method that transforms the given date value into a moment format
     *
     * @param value The date to be formatted
     * @param format The format to apply
     * @memberof EuiDateFormatPipe
     */
    transform(value, format) {
        if (!value) {
            return '';
        }
        if (!format) {
            format = '';
        }
        return moment(value).format(format);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiDateFormatPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "20.2.1", ngImport: i0, type: EuiDateFormatPipe, isStandalone: false, name: "euiDateFormat" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiDateFormatPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'euiDateFormat',
                    standalone: false
                }]
        }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiReadonlyLabelComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiReadonlyLabelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.2.1", type: EuiReadonlyLabelComponent, isStandalone: false, selector: "eui-readonly-label", ngImport: i0, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<ng-content></ng-content>\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiReadonlyLabelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-readonly-label', standalone: false, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<ng-content></ng-content>\n" }]
        }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiLabelComponent {
    constructor(cdRef) {
        this.cdRef = cdRef;
        /** @internal */
        this.class = 'eui-label';
        /**
         * Sets whether the required indicator should be shown
         *
         * @category Input
         */
        this.required = false;
        /**
         * Sets whether the label should be displayed in the error state
         *
         * @category Input
         */
        this.errorState = false;
        /**
         * Sets whether the label should be displayed in a disabled state
         *
         * @category Input
         */
        this.disabled = false;
    }
    /** @internal */
    checkChanges() {
        this.cdRef.detectChanges();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiLabelComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.2.1", type: EuiLabelComponent, isStandalone: false, selector: "eui-label", inputs: { for: "for", required: "required", errorState: "errorState", disabled: "disabled" }, host: { properties: { "class": "this.class" } }, ngImport: i0, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<label class=\"eui-label\" [for]=\"for\" [ngClass]=\"{ 'eui-label--error': errorState && !disabled, 'eui-label--disabled': disabled }\">\n  @if (errorState) {\n    <eui-icon icon=\"error-circle\" size=\"16px\"></eui-icon>\n  }\n  <span><ng-content></ng-content></span>\n  @if (required) {\n    <span class=\"eui-label-required-indicator\">*</span>\n  }\n  <ng-content select=\"[euiLabelSuffix]\"></ng-content>\n</label>\n", dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: EuiIconComponent, selector: "eui-icon", inputs: ["aria-hidden", "setLineHeight", "icon", "size"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiLabelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-label', changeDetection: ChangeDetectionStrategy.OnPush, standalone: false, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<label class=\"eui-label\" [for]=\"for\" [ngClass]=\"{ 'eui-label--error': errorState && !disabled, 'eui-label--disabled': disabled }\">\n  @if (errorState) {\n    <eui-icon icon=\"error-circle\" size=\"16px\"></eui-icon>\n  }\n  <span><ng-content></ng-content></span>\n  @if (required) {\n    <span class=\"eui-label-required-indicator\">*</span>\n  }\n  <ng-content select=\"[euiLabelSuffix]\"></ng-content>\n</label>\n" }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { class: [{
                type: HostBinding,
                args: ['class']
            }], for: [{
                type: Input
            }], required: [{
                type: Input
            }], errorState: [{
                type: Input
            }], disabled: [{
                type: Input
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiFormFieldComponent {
    /**
     * Sets the width of the component
     *
     * @category Input
     */
    set width(val) {
        if (val) {
            this.fieldStyles = { width: val };
            this.hostWidth = val;
        }
    }
    /**
     * Controls whether the form field should be displayed as readonly
     *
     * @category Input
     */
    get readonly() {
        return this._readonly;
    }
    set readonly(value) {
        this._readonly = value;
        this.updateLabel();
        this.cdRef.detectChanges();
    }
    /** @internal */
    get elementRef() {
        return this.ref;
    }
    /** @internal */
    get id() {
        return this.matFormControl?.id ?? this._id;
    }
    constructor(cdRef, ref) {
        this.cdRef = cdRef;
        this.ref = ref;
        /** @internal */
        this.class = 'eui-form-field';
        /**
         * Appearance mode of the mat-form-field element
         *
         * @category Input
         */
        this.appearance = 'outline';
        /**
         * When true the 'eui-input--no-margin' class will be applied to the mat-form-field
         * Note: this needs to be set to 'false' when showing validation errors in the <mat-error> section, so that they display correctly
         *
         * @category Input
         */
        this.hideMargins = false;
        /**
         * Controls whether the legacy floating label is displayed or a label above the form field
         *
         * @category Input
         */
        this.useLegacyFloatingLabel = false;
        /**
         * Contains style key-value pairs for mat-form-field element
         */
        /** @internal */
        this.fieldStyles = {};
        /** @internal */
        this.isBeforeViewInit$$ = new BehaviorSubject(true);
        /** @internal */
        this.showFormElements = {
            matPrefix: true,
            matTextPrefix: true,
            matSuffix: true,
            matTextSuffix: true,
        };
        /** @internal */
        this.destroy = new Subject();
        this._id = 'eui-form-field-' + Math.floor(Math.random() * Date.now());
        this._readonly = false;
    }
    /** @internal */
    ngAfterContentInit() {
        // need to set isInFormField if form control is input
        const input = this.matFormControl;
        this.overrideReadonlyProperty(input, '_isInFormField', true);
        if (this.euiLabel) {
            this.euiLabel.for = this.id;
            this.updateLabel();
            this.matFormControl.stateChanges
                .pipe(takeUntil(this.destroy), tap(() => this.updateLabel()))
                .subscribe();
            if (this.matFormControl?.controlType === 'mat-chip-grid') {
                if (this.matInput) {
                    this.overrideReadonlyProperty(this.matInput, '_isInFormField', true);
                    this.overrideReadonlyProperty(this.matInput, 'id', this.id);
                }
            }
            else {
                this.overrideReadonlyProperty(this.matFormControl, 'id', this.id);
            }
        }
        this._suffixChildren.changes.pipe(takeUntil(this.destroy)).subscribe(() => this.checkFormElements());
        this._prefixChildren.changes.pipe(takeUntil(this.destroy)).subscribe(() => this.checkFormElements());
        this.cdRef.detectChanges();
    }
    /** @internal */
    ngAfterViewInit() {
        if (!this.matFormControl) {
            return;
        }
        const select = this.matFormControl;
        this.overrideReadonlyProperty(select, '_parentFormField', this.matFormField);
        // replace the reference to the dummy control
        this.matFormField._control = this.matFormControl;
        // force the form field to rebind everything to the actual control
        this.matFormField.ngAfterContentInit();
        this.isBeforeViewInit$$.next(false);
        this.checkFormElements();
    }
    /** @internal */
    ngOnDestroy() {
        this.destroy.next(true);
    }
    checkFormElements() {
        this.showFormElements.matPrefix = !!this._prefixChildren.find((s) => !s._isText);
        this.showFormElements.matTextPrefix = !!this._prefixChildren.find((s) => s._isText);
        this.showFormElements.matSuffix = !!this._suffixChildren.find((s) => !s._isText);
        this.showFormElements.matTextSuffix = !!this._suffixChildren.find((s) => s._isText);
        this.cdRef.detectChanges();
    }
    overrideReadonlyProperty(object, property, value) {
        if (object) {
            object[property] = value;
        }
    }
    updateLabel() {
        if (!this.euiLabel) {
            return;
        }
        this.euiLabel.required = (this.matFormControl?.required ?? false) && !this.readonly;
        this.euiLabel.disabled = this.matFormControl?.disabled ?? false;
        this.euiLabel.errorState = this.matFormControl?.errorState ?? false;
        if (this.readonly && this.matFormControl?.ngControl?.control) {
            this.matFormControl.ngControl.control.markAsPristine();
            this.matFormControl.ngControl.control.markAsUntouched();
        }
        this.euiLabel.checkChanges();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiFormFieldComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.2.1", type: EuiFormFieldComponent, isStandalone: false, selector: "eui-form-field", inputs: { appearance: "appearance", hideMargins: "hideMargins", width: "width", useLegacyFloatingLabel: "useLegacyFloatingLabel", readonly: "readonly" }, host: { properties: { "class": "this.class", "style.width": "this.hostWidth" } }, queries: [{ propertyName: "matFormControl", first: true, predicate: MatFormFieldControl, descendants: true }, { propertyName: "matInput", first: true, predicate: MatInput, descendants: true }, { propertyName: "euiLabel", first: true, predicate: EuiLabelComponent, descendants: true }, { propertyName: "_prefixChildren", predicate: MAT_PREFIX, descendants: true }, { propertyName: "_suffixChildren", predicate: MAT_SUFFIX, descendants: true }], viewQueries: [{ propertyName: "matFormField", first: true, predicate: MatFormField, descendants: true }], ngImport: i0, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n@if (!useLegacyFloatingLabel || readonly) {\n  <ng-content select=\"eui-label\"></ng-content>\n}\n\n@if (readonly) {\n  <span class=\"eui-form-field--readonly\">\n    <span #readonlyProjectedContent>\n      <ng-content select=\"eui-readonly-label\"></ng-content>\n    </span>\n    @if (!readonlyProjectedContent.childElementCount) {\n      @if (matFormControl && matFormControl.value){\n        {{ matFormControl.value }}\n      }\n      @else {\n        &mdash;\n      }\n    }\n  </span>\n}\n\n<mat-form-field [appearance]=\"appearance\" [ngClass]=\"{ 'eui-input--no-margin': hideMargins, 'eui-hidden': readonly }\" [ngStyle]=\"fieldStyles\" color=\"primary\">\n  @if (useLegacyFloatingLabel) {\n    <mat-label>\n      <ng-content select=\"mat-label\"></ng-content>\n    </mat-label>\n  }\n\n  <ng-content></ng-content>\n  @if (isBeforeViewInit$$ | async) {\n    <input hidden matInput />\n  }\n\n  @if (showFormElements.matTextPrefix) {\n    <span matTextPrefix>\n      <ng-content select=\"[matTextPrefix]\"></ng-content>\n    </span>\n  }\n  @if (showFormElements.matPrefix) {\n    <span matPrefix>\n      <ng-content select=\"[matPrefix], [matIconPrefix]\"></ng-content>\n    </span>\n  }\n  @if (showFormElements.matTextSuffix) {\n    <span matTextSuffix>\n      <ng-content select=\"[matTextSuffix]\"></ng-content>\n    </span>\n  }\n\n  @if (showFormElements.matSuffix) {\n    <span matSuffix>\n      <ng-content select=\"[matSuffix], [matIconSuffix]\"></ng-content>\n    </span>\n  }\n\n  <mat-hint class=\"eui-form-field-subscript\">\n    <ng-content select=\"mat-hint\"></ng-content>\n  </mat-hint>\n  <mat-error class=\"eui-form-field-subscript\">\n    <ng-content select=\"mat-error\"></ng-content>\n  </mat-error>\n</mat-form-field>\n", styles: [".eui-form-field--readonly{white-space:pre-line;word-wrap:break-word;word-break:break-word}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: i2$1.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i2$1.MatLabel, selector: "mat-label" }, { kind: "directive", type: i2$1.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i2$1.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i2$1.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i2$1.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "pipe", type: i2.AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiFormFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-form-field', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, standalone: false, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n@if (!useLegacyFloatingLabel || readonly) {\n  <ng-content select=\"eui-label\"></ng-content>\n}\n\n@if (readonly) {\n  <span class=\"eui-form-field--readonly\">\n    <span #readonlyProjectedContent>\n      <ng-content select=\"eui-readonly-label\"></ng-content>\n    </span>\n    @if (!readonlyProjectedContent.childElementCount) {\n      @if (matFormControl && matFormControl.value){\n        {{ matFormControl.value }}\n      }\n      @else {\n        &mdash;\n      }\n    }\n  </span>\n}\n\n<mat-form-field [appearance]=\"appearance\" [ngClass]=\"{ 'eui-input--no-margin': hideMargins, 'eui-hidden': readonly }\" [ngStyle]=\"fieldStyles\" color=\"primary\">\n  @if (useLegacyFloatingLabel) {\n    <mat-label>\n      <ng-content select=\"mat-label\"></ng-content>\n    </mat-label>\n  }\n\n  <ng-content></ng-content>\n  @if (isBeforeViewInit$$ | async) {\n    <input hidden matInput />\n  }\n\n  @if (showFormElements.matTextPrefix) {\n    <span matTextPrefix>\n      <ng-content select=\"[matTextPrefix]\"></ng-content>\n    </span>\n  }\n  @if (showFormElements.matPrefix) {\n    <span matPrefix>\n      <ng-content select=\"[matPrefix], [matIconPrefix]\"></ng-content>\n    </span>\n  }\n  @if (showFormElements.matTextSuffix) {\n    <span matTextSuffix>\n      <ng-content select=\"[matTextSuffix]\"></ng-content>\n    </span>\n  }\n\n  @if (showFormElements.matSuffix) {\n    <span matSuffix>\n      <ng-content select=\"[matSuffix], [matIconSuffix]\"></ng-content>\n    </span>\n  }\n\n  <mat-hint class=\"eui-form-field-subscript\">\n    <ng-content select=\"mat-hint\"></ng-content>\n  </mat-hint>\n  <mat-error class=\"eui-form-field-subscript\">\n    <ng-content select=\"mat-error\"></ng-content>\n  </mat-error>\n</mat-form-field>\n", styles: [".eui-form-field--readonly{white-space:pre-line;word-wrap:break-word;word-break:break-word}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i0.ElementRef }], propDecorators: { class: [{
                type: HostBinding,
                args: ['class']
            }], hostWidth: [{
                type: HostBinding,
                args: ['style.width']
            }], matFormControl: [{
                type: ContentChild,
                args: [MatFormFieldControl]
            }], matInput: [{
                type: ContentChild,
                args: [MatInput]
            }], euiLabel: [{
                type: ContentChild,
                args: [EuiLabelComponent]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField]
            }], _prefixChildren: [{
                type: ContentChildren,
                args: [MAT_PREFIX, { descendants: true }]
            }], _suffixChildren: [{
                type: ContentChildren,
                args: [MAT_SUFFIX, { descendants: true }]
            }], appearance: [{
                type: Input
            }], hideMargins: [{
                type: Input
            }], width: [{
                type: Input
            }], useLegacyFloatingLabel: [{
                type: Input
            }], readonly: [{
                type: Input
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiDatePickerComponent {
    constructor() {
        /**
         * Controls whether the legacy floating label is displayed or a label above the form field
         *
         * @category Input
         */
        this.useLegacyFloatingLabel = false;
        /**
         * Appearance mode of the mat-form-field element
         *
         * @category Input
         */
        this.appearance = 'outline';
        /**
         * Sets whether the component is required or not
         *
         * @category Input
         */
        this.required = false;
        /**
         * Sets whether the component is read-only or not
         *
         * @category Input
         */
        this.readonly = false;
        /**
         * When true the 'eui-input--no-margin' class will be applied to the mat-form-field
         * Note: this needs to be set to 'false' when showing validation errors in the <mat-error> section, so that they display correctly
         *
         * @category Input
         */
        this.hideMargins = false;
        /**
         * Allow the touchUi mode to be set for the mat-datepicker
         *
         * @category Input
         */
        this.touchUi = false;
        /**
         * When set to false, allows user to trigger the date picker by clicking or moving focus to the input field
         *
         * @category Input
         */
        this.allowTextInput = true;
        /**
         * Replaces date picker with a clear button to allow the value to be cleared. Usually used when allowTextInput is set to false
         *
         * @category Input
         */
        this.useClearIcon = false;
        /**
         * When set to true, displays a red error icon, representing the error state if the control is required and has been touched
         *
         * @category Input
         */
        this.showErrorState = false;
        /** @internal */
        this._disabled = false;
    }
    /**
     * Sets the disabled state of the component
     *
     * @category Input
     */
    set disabled(disabled) {
        this._disabled = disabled;
        if (disabled) {
            this.dateControl.disable();
        }
        else {
            this.dateControl.enable();
        }
    }
    /**
     * Gets the disabled state of the component
     */
    /** @internal */
    get disabled() {
        return this._disabled;
    }
    /** @internal */
    get isRequired() {
        if (this.required) {
            return true;
        }
        return this.dateControl?.hasValidator(Validators.required) ?? false;
    }
    /**
     * Function called when the mat-datepicker is closed to prevent open/close loop
     *
     * @param dateInput: A reference to the input field
     */
    /** @internal */
    blurPicker(dateInput) {
        setTimeout(() => {
            dateInput.blur();
        }, 300);
    }
    /**
     * Function called when clear button is pressed. Clears value of dateControl FormControl
     *
     * @param dateInput: A reference to the input field
     * @param event: The mouse click / key press event
     */
    /** @internal */
    clearValue(dateInput, event) {
        event.stopPropagation();
        this.dateControl.reset();
        setTimeout(() => {
            dateInput.blur();
        }, 0);
    }
    /**
     * Returns whether the dateControl FormControl contains errors
     */
    /** @internal */
    hasErrors() {
        return this.dateControl.errors != null;
    }
    /**
     * Returns all errors associated with the dateControl FormControl
     */
    /** @internal */
    getErrors() {
        return this.dateControl.errors || {};
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiDatePickerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.2.1", type: EuiDatePickerComponent, isStandalone: false, selector: "eui-date-picker", inputs: { dateControl: "dateControl", useLegacyFloatingLabel: "useLegacyFloatingLabel", label: "label", placeholder: "placeholder", appearance: "appearance", required: "required", readonly: "readonly", hideMargins: "hideMargins", min: "min", max: "max", width: "width", dateFilter: "dateFilter", touchUi: "touchUi", allowTextInput: "allowTextInput", useClearIcon: "useClearIcon", showErrorState: "showErrorState", disabled: "disabled" }, ngImport: i0, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n<eui-form-field\n  class=\"eui-date-picker\"\n  [width]=\"width\"\n  [appearance]=\"appearance\"\n  [readonly]=\"readonly\"\n  [hideMargins]=\"hideMargins\"\n  [useLegacyFloatingLabel]=\"useLegacyFloatingLabel\"\n  [ngClass]=\"{ 'eui-date-picker-no-text-input': !allowTextInput }\"\n  >\n  @if (label && !useLegacyFloatingLabel) {\n    <eui-label>{{ label }}</eui-label>\n  }\n\n  @if (label && useLegacyFloatingLabel) {\n    <mat-label>{{ label }}</mat-label>\n  }\n  \n  <eui-readonly-label>\n    <span #readonlyProjectedContent>\n      <ng-content select=\"eui-readonly-label\"></ng-content>\n    </span>\n    @if (!readonlyProjectedContent.childElementCount) {\n        @if (dateControl.value) {\n          {{ dateControl.value | euiDateFormat:'LL' }}\n        }\n        @else {\n          &mdash;\n        }\n    }\n  </eui-readonly-label>\n\n  @if(showErrorState && isRequired && dateControl.touched && !dateControl.disabled && !dateControl.value) {\n    <eui-icon class=\"error-circle\" matPrefix icon=\"error-circle\"/>\n  }\n\n  <input\n    matInput\n    #dateInput\n    [attr.aria-label]=\"label || placeholder\"\n    [matDatepicker]=\"euiDatePicker\"\n    [min]=\"min\"\n    [max]=\"max\"\n    [required]=\"isRequired\"\n    [placeholder]=\"placeholder\"\n    [formControl]=\"dateControl\"\n    [matDatepickerFilter]=\"dateFilter\"\n    (focus)=\"!allowTextInput && euiDatePicker.open()\"\n    data-testid=\"eui-date-picker-input\"\n    />\n    @if (!useClearIcon || !dateControl.value) {\n      <button\n        class=\"iconButton\"\n        matIconButton\n        [disabled]=\"disabled\"\n        matSuffix\n        (click)=\"euiDatePicker.open()\"\n        data-testid=\"eui-date-picker-open\"\n        >\n        <eui-icon icon=\"date\"></eui-icon>\n      </button>\n    }\n    @if (useClearIcon && dateControl.value) {\n      <button\n        class=\"closeButton\"\n        matIconButton\n        [disabled]=\"disabled\"\n        matSuffix\n        (click)=\"clearValue(dateInput, $event)\"\n        data-testid=\"eui-date-picker-clear\"\n        >\n        <eui-icon icon=\"close\"></eui-icon>\n      </button>\n    }\n    <mat-datepicker #euiDatePicker (closed)=\"blurPicker(dateInput)\" [touchUi]=\"touchUi\"></mat-datepicker>\n    <mat-error class=\"eui-form-field-subscript\">\n      <ng-content select=\"mat-error\"></ng-content>\n    </mat-error>\n  </eui-form-field>\n", styles: [".eui-date-picker.eui-date-picker-no-text-input input:hover,.eui-date-picker.eui-date-picker-no-text-input:hover{cursor:pointer}.eui-date-picker .error-circle{color:#db2534}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i3$1.MatDatepicker, selector: "mat-datepicker", exportAs: ["matDatepicker"] }, { kind: "directive", type: i3$1.MatDatepickerInput, selector: "input[matDatepicker]", inputs: ["matDatepicker", "min", "max", "matDatepickerFilter"], exportAs: ["matDatepickerInput"] }, { kind: "directive", type: i2$1.MatLabel, selector: "mat-label" }, { kind: "directive", type: i2$1.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i2$1.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i2$1.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "directive", type: i6.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i6.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i6.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i6.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "component", type: EuiIconComponent, selector: "eui-icon", inputs: ["aria-hidden", "setLineHeight", "icon", "size"] }, { kind: "component", type: EuiReadonlyLabelComponent, selector: "eui-readonly-label" }, { kind: "component", type: EuiFormFieldComponent, selector: "eui-form-field", inputs: ["appearance", "hideMargins", "width", "useLegacyFloatingLabel", "readonly"] }, { kind: "component", type: EuiLabelComponent, selector: "eui-label", inputs: ["for", "required", "errorState", "disabled"] }, { kind: "pipe", type: EuiDateFormatPipe, name: "euiDateFormat" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiDatePickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-date-picker', encapsulation: ViewEncapsulation.None, standalone: false, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n<eui-form-field\n  class=\"eui-date-picker\"\n  [width]=\"width\"\n  [appearance]=\"appearance\"\n  [readonly]=\"readonly\"\n  [hideMargins]=\"hideMargins\"\n  [useLegacyFloatingLabel]=\"useLegacyFloatingLabel\"\n  [ngClass]=\"{ 'eui-date-picker-no-text-input': !allowTextInput }\"\n  >\n  @if (label && !useLegacyFloatingLabel) {\n    <eui-label>{{ label }}</eui-label>\n  }\n\n  @if (label && useLegacyFloatingLabel) {\n    <mat-label>{{ label }}</mat-label>\n  }\n  \n  <eui-readonly-label>\n    <span #readonlyProjectedContent>\n      <ng-content select=\"eui-readonly-label\"></ng-content>\n    </span>\n    @if (!readonlyProjectedContent.childElementCount) {\n        @if (dateControl.value) {\n          {{ dateControl.value | euiDateFormat:'LL' }}\n        }\n        @else {\n          &mdash;\n        }\n    }\n  </eui-readonly-label>\n\n  @if(showErrorState && isRequired && dateControl.touched && !dateControl.disabled && !dateControl.value) {\n    <eui-icon class=\"error-circle\" matPrefix icon=\"error-circle\"/>\n  }\n\n  <input\n    matInput\n    #dateInput\n    [attr.aria-label]=\"label || placeholder\"\n    [matDatepicker]=\"euiDatePicker\"\n    [min]=\"min\"\n    [max]=\"max\"\n    [required]=\"isRequired\"\n    [placeholder]=\"placeholder\"\n    [formControl]=\"dateControl\"\n    [matDatepickerFilter]=\"dateFilter\"\n    (focus)=\"!allowTextInput && euiDatePicker.open()\"\n    data-testid=\"eui-date-picker-input\"\n    />\n    @if (!useClearIcon || !dateControl.value) {\n      <button\n        class=\"iconButton\"\n        matIconButton\n        [disabled]=\"disabled\"\n        matSuffix\n        (click)=\"euiDatePicker.open()\"\n        data-testid=\"eui-date-picker-open\"\n        >\n        <eui-icon icon=\"date\"></eui-icon>\n      </button>\n    }\n    @if (useClearIcon && dateControl.value) {\n      <button\n        class=\"closeButton\"\n        matIconButton\n        [disabled]=\"disabled\"\n        matSuffix\n        (click)=\"clearValue(dateInput, $event)\"\n        data-testid=\"eui-date-picker-clear\"\n        >\n        <eui-icon icon=\"close\"></eui-icon>\n      </button>\n    }\n    <mat-datepicker #euiDatePicker (closed)=\"blurPicker(dateInput)\" [touchUi]=\"touchUi\"></mat-datepicker>\n    <mat-error class=\"eui-form-field-subscript\">\n      <ng-content select=\"mat-error\"></ng-content>\n    </mat-error>\n  </eui-form-field>\n", styles: [".eui-date-picker.eui-date-picker-no-text-input input:hover,.eui-date-picker.eui-date-picker-no-text-input:hover{cursor:pointer}.eui-date-picker .error-circle{color:#db2534}\n"] }]
        }], propDecorators: { dateControl: [{
                type: Input
            }], useLegacyFloatingLabel: [{
                type: Input
            }], label: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], appearance: [{
                type: Input
            }], required: [{
                type: Input
            }], readonly: [{
                type: Input
            }], hideMargins: [{
                type: Input
            }], min: [{
                type: Input
            }], max: [{
                type: Input
            }], width: [{
                type: Input
            }], dateFilter: [{
                type: Input
            }], touchUi: [{
                type: Input
            }], allowTextInput: [{
                type: Input
            }], useClearIcon: [{
                type: Input
            }], showErrorState: [{
                type: Input
            }], disabled: [{
                type: Input
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
/** @internal */
const DOWNLOAD_REQUEST_SUBSCRIPTION = new InjectionToken('DOWNLOAD_REQUEST_SUBSCRIPTION');
/** @internal */
const DOWNLOAD_LOADER_CONFIG = new InjectionToken('DOWNLOAD_LOADER_CONFIG');

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiDownloadLoaderComponent {
    constructor(requestSubscription, config) {
        this.requestSubscription = requestSubscription;
        this.config = config;
        this.progress = 0;
    }
    ngAfterContentInit() {
        this.setCancelBtnFocus();
    }
    /** @internal */
    cancelDownload() {
        if (this.requestSubscription) {
            this.requestSubscription.unsubscribe();
        }
    }
    setCancelBtnFocus() {
        if (!this.config.disableCancel && this.cancelBtn) {
            this.cancelBtn.focus();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiDownloadLoaderComponent, deps: [{ token: DOWNLOAD_REQUEST_SUBSCRIPTION }, { token: DOWNLOAD_LOADER_CONFIG }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.2.1", type: EuiDownloadLoaderComponent, isStandalone: false, selector: "eui-download-loader", viewQueries: [{ propertyName: "cancelBtn", first: true, predicate: ["cancelBtn"], descendants: true }], ngImport: i0, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<div class=\"eui-download-loader\" cdkTrapFocus data-testid=\"eui-download-loader\">\n  @if (progress > 0) {\n    <h2>{{ progress }}%</h2>\n    <mat-progress-bar [mode]=\"progress === 0 ? 'indeterminate' : 'determinate'\" [value]=\"progress\" [attr.aria-label]=\"config.spinnerAriaLabel || 'Loading'\"></mat-progress-bar>\n  }\n  @if (progress === 0) {\n    <mat-spinner [attr.aria-label]=\"config.spinnerAriaLabel || 'Loading'\"></mat-spinner>\n  }\n  <p>{{ config.helperText || 'File download in progress' }}</p>\n  @if (!config.disableCancel) {\n    <button mat-stroked-button (click)=\"cancelDownload()\" #cancelBtn>\n      {{ config.buttonText || 'Cancel Download' }}\n    </button>\n  }\n</div>\n", styles: [":host-context(.eui-dark-theme) .eui-download-loader{background-color:#444647}:host-context(.eui-contrast-theme) .eui-download-loader{border:1px solid #ffffff;background-color:#2f3233!important}.eui-download-loader{display:flex;flex-direction:column;justify-content:center;align-items:center;background-color:#fff;padding:30px;border-radius:5px}.eui-download-loader h2{margin-bottom:16px;font-size:32px;font-weight:600}.eui-download-loader p{margin-top:30px;margin-bottom:0;font-size:18px}.eui-download-loader .mat-mdc-outlined-button{margin-top:30px}\n"], dependencies: [{ kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i1$2.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "component", type: i3$2.MatProgressBar, selector: "mat-progress-bar", inputs: ["color", "value", "bufferValue", "mode"], outputs: ["animationEnd"], exportAs: ["matProgressBar"] }, { kind: "directive", type: i1$1.CdkTrapFocus, selector: "[cdkTrapFocus]", inputs: ["cdkTrapFocus", "cdkTrapFocusAutoCapture"], exportAs: ["cdkTrapFocus"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiDownloadLoaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-download-loader', standalone: false, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<div class=\"eui-download-loader\" cdkTrapFocus data-testid=\"eui-download-loader\">\n  @if (progress > 0) {\n    <h2>{{ progress }}%</h2>\n    <mat-progress-bar [mode]=\"progress === 0 ? 'indeterminate' : 'determinate'\" [value]=\"progress\" [attr.aria-label]=\"config.spinnerAriaLabel || 'Loading'\"></mat-progress-bar>\n  }\n  @if (progress === 0) {\n    <mat-spinner [attr.aria-label]=\"config.spinnerAriaLabel || 'Loading'\"></mat-spinner>\n  }\n  <p>{{ config.helperText || 'File download in progress' }}</p>\n  @if (!config.disableCancel) {\n    <button mat-stroked-button (click)=\"cancelDownload()\" #cancelBtn>\n      {{ config.buttonText || 'Cancel Download' }}\n    </button>\n  }\n</div>\n", styles: [":host-context(.eui-dark-theme) .eui-download-loader{background-color:#444647}:host-context(.eui-contrast-theme) .eui-download-loader{border:1px solid #ffffff;background-color:#2f3233!important}.eui-download-loader{display:flex;flex-direction:column;justify-content:center;align-items:center;background-color:#fff;padding:30px;border-radius:5px}.eui-download-loader h2{margin-bottom:16px;font-size:32px;font-weight:600}.eui-download-loader p{margin-top:30px;margin-bottom:0;font-size:18px}.eui-download-loader .mat-mdc-outlined-button{margin-top:30px}\n"] }]
        }], ctorParameters: () => [{ type: i5.Subscription, decorators: [{
                    type: Inject,
                    args: [DOWNLOAD_REQUEST_SUBSCRIPTION]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOWNLOAD_LOADER_CONFIG]
                }] }], propDecorators: { cancelBtn: [{
                type: ViewChild,
                args: ['cancelBtn']
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
/** @internal */
class EuiDownloadService {
    constructor() {
        /** @internal */
        this.helpers = { saveAs };
    }
    /** @internal */
    saveAs(data, filename, options) {
        this.helpers.saveAs(data, filename, options);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiDownloadService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiDownloadService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiDownloadService, decorators: [{
            type: Injectable
        }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiDownloadDirective {
    constructor(el, http, overlay, injector, downloadSvc) {
        this.http = http;
        this.overlay = overlay;
        this.injector = injector;
        this.downloadSvc = downloadSvc;
        /**
         * Emits an event when the download completes
         *
         * @category Output
         * @event
         */
        this.downloadComplete = new EventEmitter();
        /**
         * Emits an event when the download starts. Returns the Subscription associated with the HTTP request. This can be used to cancel the download by calling unsubscribe().
         *
         * @category Output
         * @event
         */
        this.downloadStarted = new EventEmitter();
        /**
         * Emits an event if the download fails
         *
         * @category Output
         * @event
         */
        this.downloadError = new EventEmitter();
        this.element = el;
    }
    /**
     * Configuration options for the download directive. See the [[EuiDownloadOptions]] interface for more information.
     *
     * @category Input
     */
    set downloadOptions(options) {
        this.options = {
            url: '',
            method: 'GET',
            showLoader: true,
            disableElement: true,
            ...options,
        };
    }
    /** @internal */
    onClick() {
        this.download();
    }
    download() {
        if (!this.options?.url) {
            throw new Error('URL must be provided in EuiDownloadOptions to use EuiDownload directive');
        }
        const req = new HttpRequest(this.options.method, this.options.url, this.options.body, {
            observe: 'events',
            reportProgress: true,
            responseType: 'arraybuffer',
            ...this.options.requestOptions,
        });
        const requestSubscription = this.http
            .request(req)
            .pipe(tap((event) => this.handleEvents(event)), catchError((error) => this.handleError(error)), finalize(() => this.afterDownload(this.loaderRef)))
            .subscribe();
        this.loaderRef = this.beforeDownload(requestSubscription);
    }
    handleEvents(event) {
        if (event.type === HttpEventType.DownloadProgress) {
            const total = event.total ?? this.options.contentLength;
            const percentDone = total ? Math.round((100 * event.loaded) / total) : 0;
            this.componentRef.instance.progress = percentDone;
        }
        else if (event.type === HttpEventType.Response) {
            const meta = this.handleResponse(event);
            this.downloadSvc.saveAs(meta.data, meta.fileName);
        }
    }
    handleResponse(response) {
        const filename = this.options.fileName || this.getFilenameFromHeaders(response.headers);
        const blob = new Blob([response.body], {
            type: this.options.fileMimeType || response.headers.get('responseType') || response.headers.get('Content-Type'),
        });
        return { data: blob, fileName: filename };
    }
    handleError(response) {
        this.downloadError.emit(response);
        return throwError(() => response);
    }
    getFilenameFromHeaders(headers) {
        try {
            const contentDispositionHeader = headers.get('Content-Disposition');
            // Get just the filename value part from the header
            const cdParts = contentDispositionHeader.split(';');
            let fileName = cdParts.find((p) => p.indexOf('filename*=') > -1);
            if (!fileName) {
                fileName = cdParts.find((p) => p.indexOf('filename=') > -1);
            }
            let result = fileName.trim().split('=')[1];
            result = result.replace(/UTF-8''/i, '');
            // Remove the wrapping quotes and return the decoded name
            // Quotation marks need to be removed to prevent Edge outputting the filename as a guid
            return decodeURIComponent(result).replace(/"/g, '');
        }
        catch (error) {
            return 'download';
        }
    }
    beforeDownload(requestSubscription) {
        this.downloadStarted.emit(requestSubscription);
        if (this.options.disableElement) {
            this.element.nativeElement.setAttribute('disabled', true);
        }
        if (this.options.showLoader) {
            return this.openLoader(requestSubscription);
        }
    }
    afterDownload(loaderRef) {
        if (this.options.showLoader) {
            this.hideLoader(loaderRef);
        }
        if (this.options.disableElement) {
            this.element.nativeElement.removeAttribute('disabled');
            this.element.nativeElement.focus();
        }
        this.downloadComplete.emit();
    }
    openLoader(requestSubscription) {
        const config = new OverlayConfig({
            positionStrategy: this.overlay.position().global().centerHorizontally().centerVertically(),
            hasBackdrop: true,
        });
        const overlayRef = this.overlay.create(config);
        const staticProviders = [
            { provide: DOWNLOAD_REQUEST_SUBSCRIPTION, useValue: requestSubscription },
            { provide: DOWNLOAD_LOADER_CONFIG, useValue: this.options.loaderConfig || {} },
        ];
        const injector = Injector.create({ providers: staticProviders, parent: this.injector });
        this.componentRef = overlayRef.attach(new ComponentPortal(EuiDownloadLoaderComponent, null, injector));
        return overlayRef;
    }
    hideLoader(loaderRef) {
        if (loaderRef) {
            loaderRef.dispose();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiDownloadDirective, deps: [{ token: i0.ElementRef }, { token: i1$3.HttpClient }, { token: i1$4.Overlay }, { token: i0.Injector }, { token: EuiDownloadService }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.2.1", type: EuiDownloadDirective, isStandalone: false, selector: "[euiDownload]", inputs: { downloadOptions: ["euiDownload", "downloadOptions"] }, outputs: { downloadComplete: "downloadComplete", downloadStarted: "downloadStarted", downloadError: "downloadError" }, host: { listeners: { "click": "onClick()" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiDownloadDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[euiDownload]',
                    standalone: false
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1$3.HttpClient }, { type: i1$4.Overlay }, { type: i0.Injector }, { type: EuiDownloadService }], propDecorators: { downloadComplete: [{
                type: Output
            }], downloadStarted: [{
                type: Output
            }], downloadError: [{
                type: Output
            }], downloadOptions: [{
                type: Input,
                args: ['euiDownload']
            }], onClick: [{
                type: HostListener,
                args: ['click']
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiFlyoutComponent {
    constructor() {
        /**
         * Emits an event when the flyout opens.
         *
         * @category Output
         * @event
         */
        this.opened = new EventEmitter();
        /**
         * Emits an event when the flyout is closed.
         *
         * @category Output
         * @event
         */
        this.closed = new EventEmitter();
        this.loaded = new EventEmitter();
    }
    /**
     * Open the flyout.
     */
    open() {
        this.trigger.open();
    }
    /**
     * Close the flyout.
     */
    close() {
        this.trigger.close();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiFlyoutComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.2.1", type: EuiFlyoutComponent, isStandalone: false, selector: "eui-flyout", inputs: { options: "options" }, outputs: { opened: "opened", closed: "closed", loaded: "loaded" }, viewQueries: [{ propertyName: "templateRef", first: true, predicate: TemplateRef, descendants: true }], exportAs: ["euiFlyout"], ngImport: i0, template: "<!--\n    Copyright 2025 One Identity LLC.\n    ALL RIGHTS RESERVED.\n-->\n<ng-template>\n  <div class=\"eui-flyout\" [ngClass]=\"options?.panelClass\" cdkTrapFocus>\n    <ng-content></ng-content>\n  </div>\n</ng-template>\n", styles: [".eui-flyout{border-radius:4px;padding:16px;box-shadow:0 3px 3px -2px #0003,0 3px 4px #00000024,0 1px 8px #0000001f;position:relative}.eui-flyout--start-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--end-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--center-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--start-top:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--end-top:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--center-top:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--end-center:not(.eui-flyout--no-pointer) .eui-flyout:after{content:\"\";position:absolute}.eui-flyout--start-center:not(.eui-flyout--no-pointer) .eui-flyout:before{content:\"\";position:absolute;left:-20px;border-top:10px solid transparent;border-bottom:10px solid transparent;border-left:10px solid transparent;border-right:10px solid;filter:drop-shadow(-2px 0px 1px rgba(0,0,0,.12))}.eui-flyout--end-center:not(.eui-flyout--no-pointer) .eui-flyout:after{border-top:10px solid transparent;border-bottom:10px solid transparent;border-right:10px solid transparent;border-left:10px solid;right:-20px;filter:drop-shadow(2px 0px 1px rgba(0,0,0,.12))}.eui-flyout--end-center .eui-flyout:after,.eui-flyout--start-center .eui-flyout:before{top:calc(50% - 10px)}.eui-flyout--start-top:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--end-top:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--center-top:not(.eui-flyout--no-pointer) .eui-flyout:after{top:-20px;filter:drop-shadow(0px -2px 1px rgba(0,0,0,.12));border-top:10px solid transparent;border-bottom:10px solid;border-left:10px solid transparent;border-right:10px solid transparent}.eui-flyout--start-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--end-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--center-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after{bottom:-20px;filter:drop-shadow(0px 2px 1px rgba(0,0,0,.12));border-top:10px solid;border-bottom:10px solid transparent;border-left:10px solid transparent;border-right:10px solid transparent}.eui-flyout--start-top .eui-flyout:after,.eui-flyout--start-bottom .eui-flyout:after{left:var(--eui-flyout-arrow-offset, 0)}[dir=rtl] .eui-flyout--start-top .eui-flyout:after,[dir=rtl] .eui-flyout--start-bottom .eui-flyout:after{left:initial;right:var(--eui-flyout-arrow-offset, 0)}.eui-flyout--end-top .eui-flyout:after,.eui-flyout--end-bottom .eui-flyout:after{right:var(--eui-flyout-arrow-offset, 0)}[dir=rtl] .eui-flyout--end-top .eui-flyout:after,[dir=rtl] .eui-flyout--end-bottom .eui-flyout:after{right:initial;left:var(--eui-flyout-arrow-offset, 0)}.eui-flyout--center-top .eui-flyout:after,.eui-flyout--center-bottom .eui-flyout:after{left:calc(50% - 10px)}.eui-dark-theme .eui-flyout{background-color:#444647}.eui-dark-theme .eui-flyout--start-center:not(.eui-flyout--no-pointer) .eui-flyout:before{border-right-color:#444647}.eui-dark-theme .eui-flyout--end-center:not(.eui-flyout--no-pointer) .eui-flyout:after{border-left-color:#444647}.eui-dark-theme .eui-flyout--start-top:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-dark-theme .eui-flyout--end-top:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-dark-theme .eui-flyout--center-top:not(.eui-flyout--no-pointer) .eui-flyout:after{border-bottom-color:#444647}.eui-dark-theme .eui-flyout--start-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-dark-theme .eui-flyout--end-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-dark-theme .eui-flyout--center-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after{border-top-color:#444647}.eui-contrast-theme .eui-flyout{background-color:#18191a}.eui-contrast-theme .eui-flyout--start-center:not(.eui-flyout--no-pointer) .eui-flyout:before{border-right-color:#fffc}.eui-contrast-theme .eui-flyout--end-center:not(.eui-flyout--no-pointer) .eui-flyout:after{border-left-color:#fffc}.eui-contrast-theme .eui-flyout--start-top:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-contrast-theme .eui-flyout--end-top:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-contrast-theme .eui-flyout--center-top:not(.eui-flyout--no-pointer) .eui-flyout:after{border-bottom-color:#fffc}.eui-contrast-theme .eui-flyout--start-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-contrast-theme .eui-flyout--end-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-contrast-theme .eui-flyout--center-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after{border-top-color:#fffc}.eui-contrast-theme .eui-flyout{border:1px solid rgba(255,255,255,.8)}.eui-flyout{background-color:#fff}.eui-flyout--start-center:not(.eui-flyout--no-pointer) .eui-flyout:before{border-right-color:#fff}.eui-flyout--end-center:not(.eui-flyout--no-pointer) .eui-flyout:after{border-left-color:#fff}.eui-flyout--start-top:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--end-top:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--center-top:not(.eui-flyout--no-pointer) .eui-flyout:after{border-bottom-color:#fff}.eui-flyout--start-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--end-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--center-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after{border-top-color:#fff}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1$1.CdkTrapFocus, selector: "[cdkTrapFocus]", inputs: ["cdkTrapFocus", "cdkTrapFocusAutoCapture"], exportAs: ["cdkTrapFocus"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiFlyoutComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-flyout', exportAs: 'euiFlyout', encapsulation: ViewEncapsulation.None, standalone: false, template: "<!--\n    Copyright 2025 One Identity LLC.\n    ALL RIGHTS RESERVED.\n-->\n<ng-template>\n  <div class=\"eui-flyout\" [ngClass]=\"options?.panelClass\" cdkTrapFocus>\n    <ng-content></ng-content>\n  </div>\n</ng-template>\n", styles: [".eui-flyout{border-radius:4px;padding:16px;box-shadow:0 3px 3px -2px #0003,0 3px 4px #00000024,0 1px 8px #0000001f;position:relative}.eui-flyout--start-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--end-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--center-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--start-top:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--end-top:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--center-top:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--end-center:not(.eui-flyout--no-pointer) .eui-flyout:after{content:\"\";position:absolute}.eui-flyout--start-center:not(.eui-flyout--no-pointer) .eui-flyout:before{content:\"\";position:absolute;left:-20px;border-top:10px solid transparent;border-bottom:10px solid transparent;border-left:10px solid transparent;border-right:10px solid;filter:drop-shadow(-2px 0px 1px rgba(0,0,0,.12))}.eui-flyout--end-center:not(.eui-flyout--no-pointer) .eui-flyout:after{border-top:10px solid transparent;border-bottom:10px solid transparent;border-right:10px solid transparent;border-left:10px solid;right:-20px;filter:drop-shadow(2px 0px 1px rgba(0,0,0,.12))}.eui-flyout--end-center .eui-flyout:after,.eui-flyout--start-center .eui-flyout:before{top:calc(50% - 10px)}.eui-flyout--start-top:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--end-top:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--center-top:not(.eui-flyout--no-pointer) .eui-flyout:after{top:-20px;filter:drop-shadow(0px -2px 1px rgba(0,0,0,.12));border-top:10px solid transparent;border-bottom:10px solid;border-left:10px solid transparent;border-right:10px solid transparent}.eui-flyout--start-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--end-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--center-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after{bottom:-20px;filter:drop-shadow(0px 2px 1px rgba(0,0,0,.12));border-top:10px solid;border-bottom:10px solid transparent;border-left:10px solid transparent;border-right:10px solid transparent}.eui-flyout--start-top .eui-flyout:after,.eui-flyout--start-bottom .eui-flyout:after{left:var(--eui-flyout-arrow-offset, 0)}[dir=rtl] .eui-flyout--start-top .eui-flyout:after,[dir=rtl] .eui-flyout--start-bottom .eui-flyout:after{left:initial;right:var(--eui-flyout-arrow-offset, 0)}.eui-flyout--end-top .eui-flyout:after,.eui-flyout--end-bottom .eui-flyout:after{right:var(--eui-flyout-arrow-offset, 0)}[dir=rtl] .eui-flyout--end-top .eui-flyout:after,[dir=rtl] .eui-flyout--end-bottom .eui-flyout:after{right:initial;left:var(--eui-flyout-arrow-offset, 0)}.eui-flyout--center-top .eui-flyout:after,.eui-flyout--center-bottom .eui-flyout:after{left:calc(50% - 10px)}.eui-dark-theme .eui-flyout{background-color:#444647}.eui-dark-theme .eui-flyout--start-center:not(.eui-flyout--no-pointer) .eui-flyout:before{border-right-color:#444647}.eui-dark-theme .eui-flyout--end-center:not(.eui-flyout--no-pointer) .eui-flyout:after{border-left-color:#444647}.eui-dark-theme .eui-flyout--start-top:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-dark-theme .eui-flyout--end-top:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-dark-theme .eui-flyout--center-top:not(.eui-flyout--no-pointer) .eui-flyout:after{border-bottom-color:#444647}.eui-dark-theme .eui-flyout--start-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-dark-theme .eui-flyout--end-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-dark-theme .eui-flyout--center-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after{border-top-color:#444647}.eui-contrast-theme .eui-flyout{background-color:#18191a}.eui-contrast-theme .eui-flyout--start-center:not(.eui-flyout--no-pointer) .eui-flyout:before{border-right-color:#fffc}.eui-contrast-theme .eui-flyout--end-center:not(.eui-flyout--no-pointer) .eui-flyout:after{border-left-color:#fffc}.eui-contrast-theme .eui-flyout--start-top:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-contrast-theme .eui-flyout--end-top:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-contrast-theme .eui-flyout--center-top:not(.eui-flyout--no-pointer) .eui-flyout:after{border-bottom-color:#fffc}.eui-contrast-theme .eui-flyout--start-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-contrast-theme .eui-flyout--end-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-contrast-theme .eui-flyout--center-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after{border-top-color:#fffc}.eui-contrast-theme .eui-flyout{border:1px solid rgba(255,255,255,.8)}.eui-flyout{background-color:#fff}.eui-flyout--start-center:not(.eui-flyout--no-pointer) .eui-flyout:before{border-right-color:#fff}.eui-flyout--end-center:not(.eui-flyout--no-pointer) .eui-flyout:after{border-left-color:#fff}.eui-flyout--start-top:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--end-top:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--center-top:not(.eui-flyout--no-pointer) .eui-flyout:after{border-bottom-color:#fff}.eui-flyout--start-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--end-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after,.eui-flyout--center-bottom:not(.eui-flyout--no-pointer) .eui-flyout:after{border-top-color:#fff}\n"] }]
        }], propDecorators: { templateRef: [{
                type: ViewChild,
                args: [TemplateRef]
            }], options: [{
                type: Input
            }], opened: [{
                type: Output
            }], closed: [{
                type: Output
            }], loaded: [{
                type: Output
            }] } });

class EuiFlyoutPositionsService {
    constructor() {
        this.offset = 12;
    }
    positionChanged(elementRef, overlayElement, change) {
        if (change.connectionPair.overlayX === 'center' || change.connectionPair.overlayY === 'center') {
            return;
        }
        const arrowOffset = elementRef.nativeElement.offsetWidth / 2;
        const flyout = overlayElement.querySelector('.eui-flyout');
        flyout.style.setProperty('--eui-flyout-arrow-offset', `${arrowOffset - 10}px`);
    }
    getPositions(elementRef, options) {
        const offset = options?.hidePointer ? 0 : this.offset;
        const xPosition = options?.xPosition ?? 'center';
        let yPosition = options?.yPosition ?? 'below';
        if (xPosition === 'center' && yPosition === 'center') {
            yPosition = 'below';
        }
        let [originX, originFallbackX] = ['center', 'center'];
        let [overlayY, overlayFallbackY] = ['center', 'center'];
        const offsetWidth = elementRef.nativeElement.offsetWidth + offset;
        let offsetX = xPosition === 'before' ? -offsetWidth : offsetWidth;
        let offsetY = 0;
        if (xPosition !== 'center') {
            [originX, originFallbackX] = xPosition === 'before' ? ['end', 'start'] : ['start', 'end'];
        }
        if (yPosition !== 'center') {
            [overlayY, overlayFallbackY] = yPosition === 'above' ? ['bottom', 'top'] : ['top', 'bottom'];
            offsetY = yPosition === 'above' ? -offset : offset;
            offsetX = 0;
        }
        let [originY, originFallbackY] = [overlayY, overlayFallbackY];
        const [overlayX, overlayFallbackX] = [originX, originFallbackX];
        if (overlayY !== 'center') {
            originY = overlayY === 'top' ? 'bottom' : 'top';
            originFallbackY = overlayFallbackY === 'top' ? 'bottom' : 'top';
        }
        return this.generatePositions(elementRef, offset, xPosition, yPosition, { originY, overlayY, offsetY, originX, overlayX, offsetX }, { originY: originFallbackY, overlayY: overlayFallbackY, originX: originFallbackX, overlayX: overlayFallbackX });
    }
    generatePositions(elementRef, offset, xPosition, yPosition, position, fallbackPosition) {
        return [
            ...this.getBasePositions(position, fallbackPosition),
            ...this.getExtraPositions(elementRef, offset, xPosition, yPosition, position, fallbackPosition),
        ];
    }
    getBasePositions(position, fallbackPosition) {
        return [
            {
                originX: position.originX,
                originY: position.originY,
                overlayX: position.overlayX,
                overlayY: position.overlayY,
                offsetY: position.offsetY,
                offsetX: position.offsetX,
                panelClass: [`eui-flyout--${position.overlayX}-${position.overlayY}`],
            },
            {
                originX: fallbackPosition.originX,
                originY: position.originY,
                overlayX: fallbackPosition.overlayX,
                overlayY: position.overlayY,
                offsetY: position.offsetY,
                offsetX: -position.offsetX,
                panelClass: [`eui-flyout--${fallbackPosition.overlayX}-${position.overlayY}`],
            },
            {
                originX: position.originX,
                originY: fallbackPosition.originY,
                overlayX: position.overlayX,
                overlayY: fallbackPosition.overlayY,
                offsetY: -position.offsetY,
                offsetX: position.offsetX,
                panelClass: [`eui-flyout--${position.overlayX}-${fallbackPosition.overlayY}`],
            },
            {
                originX: fallbackPosition.originX,
                originY: fallbackPosition.originY,
                overlayX: fallbackPosition.overlayX,
                overlayY: fallbackPosition.overlayY,
                offsetY: -position.offsetY,
                offsetX: -position.offsetX,
                panelClass: [`eui-flyout--${fallbackPosition.overlayX}-${fallbackPosition.overlayY}`],
            },
        ];
    }
    getExtraPositions(elementRef, offset, xPosition, yPosition, position, fallbackPosition) {
        if (xPosition !== 'center' && yPosition !== 'center') {
            return [];
        }
        if (xPosition === 'center') {
            return [
                {
                    originX: 'start',
                    overlayX: 'start',
                    originY: position.originY,
                    overlayY: position.overlayY,
                    offsetY: position.offsetY,
                    panelClass: [`eui-flyout--start-${position.overlayY}`],
                },
                {
                    originX: 'start',
                    overlayX: 'start',
                    originY: fallbackPosition.originY,
                    overlayY: fallbackPosition.overlayY,
                    offsetY: -position.offsetY,
                    panelClass: [`eui-flyout--start-${fallbackPosition.overlayY}`],
                },
                {
                    originX: 'end',
                    overlayX: 'end',
                    originY: position.originY,
                    overlayY: position.overlayY,
                    offsetY: position.offsetY,
                    panelClass: [`eui-flyout--end-${position.overlayY}`],
                },
                {
                    originX: 'end',
                    overlayX: 'end',
                    originY: fallbackPosition.originY,
                    overlayY: fallbackPosition.overlayY,
                    offsetY: -position.offsetY,
                    panelClass: [`eui-flyout--end-${fallbackPosition.overlayY}`],
                },
            ];
        }
        const offsetY = elementRef.nativeElement.offsetHeight + offset;
        return [
            {
                originY: 'top',
                overlayY: 'top',
                originX: position.originX,
                overlayX: position.overlayX,
                offsetX: 0,
                offsetY,
                panelClass: [`eui-flyout--${position.overlayX}-top`],
            },
            {
                originY: 'top',
                overlayY: 'top',
                originX: fallbackPosition.originX,
                overlayX: fallbackPosition.overlayX,
                offsetX: 0,
                offsetY,
                panelClass: [`eui-flyout--${fallbackPosition.overlayX}-top`],
            },
            {
                originY: 'top',
                overlayY: 'top',
                originX: 'center',
                overlayX: 'center',
                offsetX: 0,
                offsetY,
                panelClass: [`eui-flyout--center-top`],
            },
            {
                originY: 'bottom',
                overlayY: 'bottom',
                originX: position.originX,
                overlayX: position.overlayX,
                offsetX: 0,
                offsetY: -offsetY,
                panelClass: [`eui-flyout--${position.overlayX}-bottom`],
            },
            {
                originY: 'bottom',
                overlayY: 'bottom',
                originX: fallbackPosition.originX,
                overlayX: fallbackPosition.overlayX,
                offsetX: 0,
                offsetY: -offsetY,
                panelClass: [`eui-flyout--${fallbackPosition.overlayX}-bottom`],
            },
            {
                originY: 'bottom',
                overlayY: 'bottom',
                originX: 'center',
                overlayX: 'center',
                offsetX: 0,
                offsetY: -offsetY,
                panelClass: [`eui-flyout--center-bottom`],
            },
        ];
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiFlyoutPositionsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiFlyoutPositionsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiFlyoutPositionsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiFlyoutTriggerDirective {
    /**
     * Reference to the EUI flyout component that should be opened by the trigger.
     */
    set flyout(flyout) {
        this._flyout = flyout;
        this.flyout.trigger = this;
    }
    get flyout() {
        return this._flyout;
    }
    constructor(overlay, elementRef, viewContainerRef, renderer2, positions) {
        this.overlay = overlay;
        this.elementRef = elementRef;
        this.viewContainerRef = viewContainerRef;
        this.renderer2 = renderer2;
        this.positions = positions;
        this.isOpen = false;
        const renderer = this.renderer2.createRenderer(null, null);
        renderer.listen('document', 'click', (event) => this.handleBackgroundClick(event));
    }
    /** @internal */
    onClick() {
        this.open();
    }
    /** @internal */
    onKeydown(event) {
        if (event.key === ' ' || event.key === 'Enter') {
            this.open();
        }
    }
    /**
     * Open the flyout.
     */
    open() {
        if (this.isOpen || !this.flyout) {
            return;
        }
        this.isOpen = true;
        const positionStrategy = this.overlay
            .position()
            .flexibleConnectedTo(this.elementRef)
            .withPositions(this.positions.getPositions(this.elementRef, this.flyout.options))
            .withFlexibleDimensions(false)
            .withTransformOriginOn('.eui-flyout')
            .withPush(false);
        const overlayConfig = this.getOverlayConfig(positionStrategy);
        this.overlayRef = this.overlay.create(overlayConfig);
        const containerPortal = new TemplatePortal(this.flyout.templateRef, this.viewContainerRef);
        this.overlayRef.attach(containerPortal);
        this.overlayRef.keydownEvents().subscribe((event) => this.onOverlayKeydown(event));
        positionStrategy.positionChanges.subscribe((change) => this.positions.positionChanged(this.elementRef, this.overlayRef.overlayElement, change));
        setTimeout(() => this.setFocusFirstElement(this.overlayRef.hostElement));
    }
    /**
     * Close the flyout.
     */
    close() {
        if (this.isOpen) {
            this.overlayRef.dispose();
            this.flyout.closed.emit(true);
            this.isOpen = false;
            this.elementRef.nativeElement.focus();
        }
    }
    getOverlayConfig(positionStrategy) {
        const panelClasses = [];
        if (this.flyout.options?.hidePointer) {
            panelClasses.push('eui-flyout--no-pointer');
        }
        if (this.flyout.options?.panelClass) {
            panelClasses.push(this.flyout.options?.panelClass);
        }
        const overlayConfig = new OverlayConfig({
            hasBackdrop: false,
            panelClass: panelClasses,
            direction: this.flyout.options?.direction,
            scrollStrategy: this.overlay.scrollStrategies.reposition(),
            positionStrategy,
        });
        return overlayConfig;
    }
    setFocusFirstElement(element) {
        this.flyout.opened.emit(true);
        if (this.flyout.options && this.flyout.options.autoFocus === false) {
            return;
        }
        const clickable = [];
        const elements = element.querySelectorAll('a[href], button, input, textarea, select,[tabindex]:not([tabindex="-1"])');
        elements.forEach((el) => {
            if (!el.hasAttribute('disabled') && !el.getAttribute('aria-hidden')) {
                clickable.push(el);
            }
        });
        if (clickable.length > 0) {
            clickable[0].focus();
        }
    }
    onOverlayKeydown(event) {
        if (event.key === 'Escape') {
            if (this.isOpen) {
                event.stopImmediatePropagation();
            }
            this.close();
        }
    }
    handleBackgroundClick(event) {
        if (!this.isOpen) {
            return;
        }
        const target = event.target;
        if (document.contains(target) && !this.elementRef.nativeElement.contains(target) && !this.overlayRef.overlayElement.contains(target)) {
            this.close();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiFlyoutTriggerDirective, deps: [{ token: i1$4.Overlay }, { token: i0.ElementRef }, { token: i0.ViewContainerRef }, { token: i0.RendererFactory2 }, { token: EuiFlyoutPositionsService }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.2.1", type: EuiFlyoutTriggerDirective, isStandalone: false, selector: "[euiFlyoutTriggerFor]", inputs: { flyout: ["euiFlyoutTriggerFor", "flyout"] }, host: { listeners: { "click": "onClick()", "keydown": "onKeydown($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiFlyoutTriggerDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[euiFlyoutTriggerFor]',
                    standalone: false
                }]
        }], ctorParameters: () => [{ type: i1$4.Overlay }, { type: i0.ElementRef }, { type: i0.ViewContainerRef }, { type: i0.RendererFactory2 }, { type: EuiFlyoutPositionsService }], propDecorators: { flyout: [{
                type: Input,
                args: ['euiFlyoutTriggerFor']
            }], onClick: [{
                type: HostListener,
                args: ['click']
            }], onKeydown: [{
                type: HostListener,
                args: ['keydown', ['$event']]
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiJoinPipe {
    /**
     * A method that joins the array elements using the provided separator.
     *
     * @param value The array to be joined
     * @param separator The separator to apply
     * @memberof EuiJoinPipe
     */
    transform(value, separator = ', ') {
        if (!value) {
            return '';
        }
        if (!Array.isArray(value)) {
            return value;
        }
        if (!separator) {
            separator = ', ';
        }
        return value.map(v => v.toString()).join(separator);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiJoinPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "20.2.1", ngImport: i0, type: EuiJoinPipe, isStandalone: false, name: "euiJoin" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiJoinPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'euiJoin',
                    standalone: false
                }]
        }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
const LOADING_ARIA_LABEL = new InjectionToken('LOADING_ARIA_LABEL');

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiLoadingComponent {
    constructor(ariaLabel) {
        this.ariaLabel = ariaLabel;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiLoadingComponent, deps: [{ token: LOADING_ARIA_LABEL }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.2.1", type: EuiLoadingComponent, isStandalone: false, selector: "eui-loading", ngImport: i0, template: "<!--\n    Copyright 2025 One Identity LLC.\n    ALL RIGHTS RESERVED.\n-->\n\n<div class=\"eui-loading-progress\" data-testid=\"eui-loading-progress\">\n  <mat-spinner [attr.aria-label]=\"ariaLabel\"></mat-spinner>\n</div>\n", styles: [":host-context(.eui-dark-theme) .eui-loading-progress{background-color:#444647}:host-context(.eui-contrast-theme) .eui-loading-progress{background-color:#18191a;border:1px solid #ffffff}.eui-loading-progress{background-color:#fff;padding:30px;border-radius:4px}\n"], dependencies: [{ kind: "component", type: i1$2.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiLoadingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-loading', standalone: false, template: "<!--\n    Copyright 2025 One Identity LLC.\n    ALL RIGHTS RESERVED.\n-->\n\n<div class=\"eui-loading-progress\" data-testid=\"eui-loading-progress\">\n  <mat-spinner [attr.aria-label]=\"ariaLabel\"></mat-spinner>\n</div>\n", styles: [":host-context(.eui-dark-theme) .eui-loading-progress{background-color:#444647}:host-context(.eui-contrast-theme) .eui-loading-progress{background-color:#18191a;border:1px solid #ffffff}.eui-loading-progress{background-color:#fff;padding:30px;border-radius:4px}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [LOADING_ARIA_LABEL]
                }] }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiLoadingService {
    get overlayRefs() {
        return this._overlayRefs;
    }
    constructor(overlay, injector) {
        this.overlay = overlay;
        this.injector = injector;
        this._overlayRefs = [];
    }
    /**
     * Displays the loading component within an overlay
     *
     * @param debounce Optional parameter to add delay before loader is shown. Loader will not be shown if it is hidden before then end of the delay.
     */
    show(debounce = 0, ariaLabel = 'loading') {
        const config = new OverlayConfig({
            positionStrategy: this.overlay.position().global().centerHorizontally().centerVertically(),
            hasBackdrop: true,
        });
        const overlayRef = this.overlay.create(config);
        this._overlayRefs.push(overlayRef);
        setTimeout(() => {
            if (this._overlayRefs.indexOf(overlayRef) > -1) {
                const injector = this.createInjector(ariaLabel);
                overlayRef.attach(new ComponentPortal(EuiLoadingComponent, null, injector));
            }
        }, debounce);
        return overlayRef;
    }
    /**
     * Hides visible loader overlays
     *
     * @param overlayRef: Optional parameter to hide only a specific loader overlay
     */
    hide(overlayRef) {
        if (overlayRef) {
            this.disposeOverlayRef(overlayRef);
        }
        else {
            this._overlayRefs.forEach((oRef) => {
                setTimeout(() => this.disposeOverlayRef(oRef));
            });
        }
    }
    createInjector(ariaLabel) {
        const staticProviders = [{ provide: LOADING_ARIA_LABEL, useValue: ariaLabel }];
        return Injector.create({ providers: staticProviders, parent: this.injector });
    }
    disposeOverlayRef(overlayRef) {
        if (overlayRef && overlayRef.hasAttached()) {
            overlayRef.dispose();
        }
        this.removeOverlayRef(overlayRef);
    }
    removeOverlayRef(overlayRef) {
        const index = this._overlayRefs.indexOf(overlayRef);
        if (index > -1) {
            this._overlayRefs.splice(index, 1);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiLoadingService, deps: [{ token: i1$4.Overlay }, { token: i0.Injector }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiLoadingService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiLoadingService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1$4.Overlay }, { type: i0.Injector }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiLogoComponent {
    constructor() {
        /** @internal */
        this.height = null;
        /** @internal */
        this._size = 16;
    }
    /**
     * Sets the logo's height in pixel
     *
     * @category Input
     */
    set size(val) {
        if (!val) {
            return;
        }
        this._size = val;
        this.height = val + 'px';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiLogoComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.2.1", type: EuiLogoComponent, isStandalone: false, selector: "eui-logo", inputs: { size: "size" }, host: { properties: { "style.height": "this.height" } }, ngImport: i0, template: "<!--\n    Copyright 2025 One Identity LLC.\n    ALL RIGHTS RESERVED.\n-->\n\n<svg viewBox=\"0 0 1205 215\" xmlns=\"http://www.w3.org/2000/svg\" [attr.height]=\"_size + 'px'\">\n  <path d=\"M178.2,148A80,80,0,0,1,39.64,68l8.66,5a70,70,0,1,0,121.24,70\" />\n  <path d=\"M108.92,28A80,80,0,0,1,178.2,68l-8.66,5a70,70,0,0,0-60.62-35Z\" />\n  <path d=\"M158.92,194.6a100,100,0,1,1,0-173.2l-5,8.66a90,90,0,1,0,0,155.88Z\" />\n  <path d=\"M108.92,48a60,60,0,1,1-60,60A60,60,0,0,1,108.92,48Zm-35,60a35,35,0,1,0,35-35A35,35,0,0,0,73.92,108Z\" />\n  <path\n    d=\"M188,56.06a3,3,0,0,1,3-2.88h2.4c1.59,0,2.71,1.12,4,2.4l61.3,58.91h.16V57.81a3,3,0,0,1,3-3H281a3.15,3.15,0,0,1,3,3V165.25a2.81,2.81,0,0,1-3,2.88h-1.59a5.1,5.1,0,0,1-4-1.76L213.34,104h-.16V163.5a3,3,0,0,1-3,3h-19a3.14,3.14,0,0,1-3-3L188,56.06\"\n  />\n  <path\n    d=\"M303.38,57.81a3,3,0,0,1,3-3h66.09a3,3,0,0,1,3,3v17.4a3,3,0,0,1-3,3H328.29V98h36.4a3.15,3.15,0,0,1,3,3v17.4a3,3,0,0,1-3,3h-36.4v21.55h44.22a3,3,0,0,1,3,3v17.4a3,3,0,0,1-3,3H306.42a3,3,0,0,1-3-3V57.81\"\n  />\n  <path d=\"M455.05,57.42a3.13,3.13,0,0,1,3-3h19.16a3.14,3.14,0,0,1,3,3V163.11a3.14,3.14,0,0,1-3,3H458.08a3.14,3.14,0,0,1-3-3V57.42\" />\n  <path\n    d=\"M500.58,57.42a3,3,0,0,1,2.87-3h39c30.81,0,56,25.06,56,55.71a56.11,56.11,0,0,1-56,56h-39a3,3,0,0,1-2.87-3V57.42m41.67,85.09c18,0,29.69-14.21,29.69-32.41,0-18-11.65-32.25-29.69-32.25H525.48v64.66Z\"\n  />\n  <path\n    d=\"M615.5,57.42a3,3,0,0,1,3-3h66.09a3,3,0,0,1,3,3v17.4a3,3,0,0,1-3,3H640.41v19.8h36.4a3.14,3.14,0,0,1,3,3v17.4a3,3,0,0,1-3,3h-36.4v21.55h44.22a3,3,0,0,1,3,3v17.41a3,3,0,0,1-3,3H618.54a3,3,0,0,1-3-3V57.42\"\n  />\n  <path\n    d=\"M704.69,55.66a3,3,0,0,1,3-2.87h2.39c1.6,0,2.72,1.12,4,2.39l61.31,58.91h.16V57.42a3,3,0,0,1,3-3h19.17a3.14,3.14,0,0,1,3,3V164.86a2.81,2.81,0,0,1-3,2.88h-1.6a5.1,5.1,0,0,1-4-1.76l-62.11-62.42h-.16v59.55a3,3,0,0,1-3,3h-19a3.14,3.14,0,0,1-3-3l-.16-107.45\"\n  />\n  <path d=\"M847.44,77.85H824.61a3,3,0,0,1-3-3V57.42a3,3,0,0,1,3-3h70.88a3,3,0,0,1,3,3v17.4a3,3,0,0,1-3,3H872.66v85.26a3.14,3.14,0,0,1-3,3H850.47a3.14,3.14,0,0,1-3-3V77.85\" />\n  <path d=\"M919.3,57.42a3.14,3.14,0,0,1,3-3h19.15a3.14,3.14,0,0,1,3,3V163.11a3.15,3.15,0,0,1-3,3H922.34a3.15,3.15,0,0,1-3-3V57.42\" />\n  <path d=\"M990.17,77.85H967.35a3,3,0,0,1-3-3V57.42a3,3,0,0,1,3-3h70.88a3,3,0,0,1,3,3v17.4a3,3,0,0,1-3,3H1015.4v85.26a3.15,3.15,0,0,1-3,3H993.21a3.15,3.15,0,0,1-3-3V77.85\" />\n  <path\n    d=\"M1090.82,113.33,1055.54,60a3,3,0,0,1,2.56-4.63h20.75a3.16,3.16,0,0,1,2.55,1.43l22.2,32.73,22.19-32.73a2.94,2.94,0,0,1,2.55-1.43h20.75a3,3,0,0,1,2.56,4.63l-35.76,53.16V164.1a3.14,3.14,0,0,1-3,3h-19a3,3,0,0,1-3-3V113.33\"\n  />\n  <path\n    d=\"M1168.09,58.45h-3.91a.48.48,0,0,1-.48-.49v-2.1a.48.48,0,0,1,.48-.48h11.17a.49.49,0,0,1,.49.48V58a.49.49,0,0,1-.49.49h-3.91V73a.5.5,0,0,1-.48.48h-2.38a.5.5,0,0,1-.49-.48Z\"\n  />\n  <path\n    d=\"M1180.06,55.76a.43.43,0,0,1,.46-.38h.41a.46.46,0,0,1,.43.25L1187,67.7h.07l5.63-12.07a.43.43,0,0,1,.43-.25h.41a.44.44,0,0,1,.46.38l3,17.18a.45.45,0,0,1-.46.59h-2.33a.58.58,0,0,1-.49-.39l-1.5-9.68h-.08l-4.47,10a.45.45,0,0,1-.44.28h-.46a.45.45,0,0,1-.43-.28l-4.53-10h-.08l-1.48,9.68a.49.49,0,0,1-.46.39h-2.3a.47.47,0,0,1-.48-.59Z\"\n  />\n</svg>\n", styles: [":host{vertical-align:middle}svg{fill:currentColor;display:inline-block}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiLogoComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-logo', standalone: false, template: "<!--\n    Copyright 2025 One Identity LLC.\n    ALL RIGHTS RESERVED.\n-->\n\n<svg viewBox=\"0 0 1205 215\" xmlns=\"http://www.w3.org/2000/svg\" [attr.height]=\"_size + 'px'\">\n  <path d=\"M178.2,148A80,80,0,0,1,39.64,68l8.66,5a70,70,0,1,0,121.24,70\" />\n  <path d=\"M108.92,28A80,80,0,0,1,178.2,68l-8.66,5a70,70,0,0,0-60.62-35Z\" />\n  <path d=\"M158.92,194.6a100,100,0,1,1,0-173.2l-5,8.66a90,90,0,1,0,0,155.88Z\" />\n  <path d=\"M108.92,48a60,60,0,1,1-60,60A60,60,0,0,1,108.92,48Zm-35,60a35,35,0,1,0,35-35A35,35,0,0,0,73.92,108Z\" />\n  <path\n    d=\"M188,56.06a3,3,0,0,1,3-2.88h2.4c1.59,0,2.71,1.12,4,2.4l61.3,58.91h.16V57.81a3,3,0,0,1,3-3H281a3.15,3.15,0,0,1,3,3V165.25a2.81,2.81,0,0,1-3,2.88h-1.59a5.1,5.1,0,0,1-4-1.76L213.34,104h-.16V163.5a3,3,0,0,1-3,3h-19a3.14,3.14,0,0,1-3-3L188,56.06\"\n  />\n  <path\n    d=\"M303.38,57.81a3,3,0,0,1,3-3h66.09a3,3,0,0,1,3,3v17.4a3,3,0,0,1-3,3H328.29V98h36.4a3.15,3.15,0,0,1,3,3v17.4a3,3,0,0,1-3,3h-36.4v21.55h44.22a3,3,0,0,1,3,3v17.4a3,3,0,0,1-3,3H306.42a3,3,0,0,1-3-3V57.81\"\n  />\n  <path d=\"M455.05,57.42a3.13,3.13,0,0,1,3-3h19.16a3.14,3.14,0,0,1,3,3V163.11a3.14,3.14,0,0,1-3,3H458.08a3.14,3.14,0,0,1-3-3V57.42\" />\n  <path\n    d=\"M500.58,57.42a3,3,0,0,1,2.87-3h39c30.81,0,56,25.06,56,55.71a56.11,56.11,0,0,1-56,56h-39a3,3,0,0,1-2.87-3V57.42m41.67,85.09c18,0,29.69-14.21,29.69-32.41,0-18-11.65-32.25-29.69-32.25H525.48v64.66Z\"\n  />\n  <path\n    d=\"M615.5,57.42a3,3,0,0,1,3-3h66.09a3,3,0,0,1,3,3v17.4a3,3,0,0,1-3,3H640.41v19.8h36.4a3.14,3.14,0,0,1,3,3v17.4a3,3,0,0,1-3,3h-36.4v21.55h44.22a3,3,0,0,1,3,3v17.41a3,3,0,0,1-3,3H618.54a3,3,0,0,1-3-3V57.42\"\n  />\n  <path\n    d=\"M704.69,55.66a3,3,0,0,1,3-2.87h2.39c1.6,0,2.72,1.12,4,2.39l61.31,58.91h.16V57.42a3,3,0,0,1,3-3h19.17a3.14,3.14,0,0,1,3,3V164.86a2.81,2.81,0,0,1-3,2.88h-1.6a5.1,5.1,0,0,1-4-1.76l-62.11-62.42h-.16v59.55a3,3,0,0,1-3,3h-19a3.14,3.14,0,0,1-3-3l-.16-107.45\"\n  />\n  <path d=\"M847.44,77.85H824.61a3,3,0,0,1-3-3V57.42a3,3,0,0,1,3-3h70.88a3,3,0,0,1,3,3v17.4a3,3,0,0,1-3,3H872.66v85.26a3.14,3.14,0,0,1-3,3H850.47a3.14,3.14,0,0,1-3-3V77.85\" />\n  <path d=\"M919.3,57.42a3.14,3.14,0,0,1,3-3h19.15a3.14,3.14,0,0,1,3,3V163.11a3.15,3.15,0,0,1-3,3H922.34a3.15,3.15,0,0,1-3-3V57.42\" />\n  <path d=\"M990.17,77.85H967.35a3,3,0,0,1-3-3V57.42a3,3,0,0,1,3-3h70.88a3,3,0,0,1,3,3v17.4a3,3,0,0,1-3,3H1015.4v85.26a3.15,3.15,0,0,1-3,3H993.21a3.15,3.15,0,0,1-3-3V77.85\" />\n  <path\n    d=\"M1090.82,113.33,1055.54,60a3,3,0,0,1,2.56-4.63h20.75a3.16,3.16,0,0,1,2.55,1.43l22.2,32.73,22.19-32.73a2.94,2.94,0,0,1,2.55-1.43h20.75a3,3,0,0,1,2.56,4.63l-35.76,53.16V164.1a3.14,3.14,0,0,1-3,3h-19a3,3,0,0,1-3-3V113.33\"\n  />\n  <path\n    d=\"M1168.09,58.45h-3.91a.48.48,0,0,1-.48-.49v-2.1a.48.48,0,0,1,.48-.48h11.17a.49.49,0,0,1,.49.48V58a.49.49,0,0,1-.49.49h-3.91V73a.5.5,0,0,1-.48.48h-2.38a.5.5,0,0,1-.49-.48Z\"\n  />\n  <path\n    d=\"M1180.06,55.76a.43.43,0,0,1,.46-.38h.41a.46.46,0,0,1,.43.25L1187,67.7h.07l5.63-12.07a.43.43,0,0,1,.43-.25h.41a.44.44,0,0,1,.46.38l3,17.18a.45.45,0,0,1-.46.59h-2.33a.58.58,0,0,1-.49-.39l-1.5-9.68h-.08l-4.47,10a.45.45,0,0,1-.44.28h-.46a.45.45,0,0,1-.43-.28l-4.53-10h-.08l-1.48,9.68a.49.49,0,0,1-.46.39h-2.3a.47.47,0,0,1-.48-.59Z\"\n  />\n</svg>\n", styles: [":host{vertical-align:middle}svg{fill:currentColor;display:inline-block}\n"] }]
        }], propDecorators: { height: [{
                type: HostBinding,
                args: ['style.height']
            }], size: [{
                type: Input
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiMastheadComponent {
    constructor() {
        /**
         * Emits a MouseEvent when the logo is clicked.
         *
         * @category Output
         * @event
         */
        this.logoClicked = new EventEmitter();
    }
    /** @internal */
    get logoClickObserved() {
        return this.logoClicked.observed;
    }
    /** @internal */
    onLogoClick(event) {
        this.logoClicked.emit(event);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiMastheadComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.2.1", type: EuiMastheadComponent, isStandalone: false, selector: "eui-masthead", inputs: { icon: "icon", centeredMasthead: "centeredMasthead" }, outputs: { logoClicked: "logoClicked" }, ngImport: i0, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<header class=\"eui-masthead\">\n  <div class=\"eui-masthead-inner\" [ngClass]=\"{ 'eui-masthead-centered': centeredMasthead }\">\n    @if (icon === 'oi-horizontal' || !icon) {\n      <eui-logo\n        [style.cursor]=\"logoClickObserved ? 'pointer' : 'default'\"\n        [size]=\"28\"\n        tabindex=\"0\"\n        (keydown.enter)=\"onLogoClick($event)\"\n        (click)=\"onLogoClick($event)\"\n      ></eui-logo>\n    }\n    @if (icon && icon !== 'oi-horizontal' && icon !== 'custom') {\n      <eui-icon\n        [icon]=\"icon\"\n        [style.cursor]=\"logoClickObserved ? 'pointer' : 'default'\"\n        size=\"28px\"\n        tabindex=\"0\"\n        (keydown.enter)=\"onLogoClick($event)\"\n        (click)=\"onLogoClick($event)\"\n      ></eui-icon>\n    }\n    <ng-content></ng-content>\n  </div>\n</header>\n", styles: [".eui-dark-theme .eui-masthead{background-color:#016b91;color:#f2f6f7}.eui-dark-theme .eui-masthead .mat-mdc-button.mat-unthemed{color:#f2f6f7}.eui-contrast-theme .eui-masthead{background-color:#00384d;color:#f9fbfc}.eui-contrast-theme .eui-masthead .mat-mdc-button.mat-unthemed{color:#f9fbfc}.eui-contrast-theme .eui-masthead{border-bottom:1px solid #f2fcff}.eui-masthead{background-color:#0a96d1;color:#f2f6f7}.eui-masthead .mat-mdc-button.mat-unthemed{color:#f2f6f7}.eui-masthead-inner{font-size:20px;height:64px;display:flex;align-items:center;padding:10px 24px 10px 32px;line-height:20px;align-content:space-between}[dir=rtl] .eui-masthead-inner{padding:10px 32px 10px 24px}.eui-masthead-inner .masthead-custom-icon{max-height:40px}.eui-masthead-inner .masthead-title{font-size:20px;font-weight:400;padding-left:20px;line-height:20px;flex-grow:1}[dir=rtl] .eui-masthead-inner .masthead-title{padding-left:0;padding-right:20px}.eui-masthead-inner .masthead-actions .mat-mdc-button{margin-right:8px}[dir=rtl] .eui-masthead-inner .masthead-actions .mat-mdc-button{margin-right:initial;margin-left:8px}.eui-masthead-inner .masthead-actions .mat-mdc-button:last-of-type{margin-right:0}[dir=rtl] .eui-masthead-inner .masthead-actions .mat-mdc-button:last-of-type{margin-left:0}.eui-masthead-inner .masthead-actions .mat-mdc-button:not(.eui-masthead--icon-button){max-width:250px;overflow:hidden;text-overflow:ellipsis}.eui-masthead-inner .masthead-actions .mat-mdc-button.eui-masthead--icon-button{min-width:44px}.eui-masthead-inner .masthead-actions .mat-mdc-button.eui-masthead--icon-button .mdc-button__label span{display:none}.eui-masthead-centered{max-width:1180px;margin:0 auto}.eui-masthead-fixed{position:fixed;left:0;right:0;top:0;z-index:950}@media screen and (min-width: 769px) and (max-width: 1200px){.eui-masthead-inner .masthead-actions .mat-mdc-button:not(.eui-masthead--icon-button){max-width:150px!important}}@media screen and (min-width: 769px) and (max-width: 992px){.eui-masthead-inner .masthead-title{font-size:18px}.eui-masthead-inner .masthead-actions .mat-mdc-button:not(.eui-masthead--icon-button){min-width:44px}.eui-masthead-inner .masthead-actions .mat-mdc-button:not(.eui-masthead--icon-button) .mat-icon+span,.eui-masthead-inner .masthead-actions .mat-mdc-button:not(.eui-masthead--icon-button) .eui-icon+span{display:none}}@media screen and (max-width: 768px){.eui-masthead-menu{width:242px}.eui-masthead-menu .mat-mdc-menu-item{text-align:center}.eui-masthead-inner{padding:10px 16px;justify-content:center;height:56px}.eui-masthead-inner .masthead-title{text-align:center;padding-left:0;padding-right:0}.eui-masthead-inner>eui-logo,.eui-masthead-inner>.eui-icon,.eui-masthead-inner>.masthead-actions,.eui-masthead-inner>.masthead-custom-icon{display:none}}@media screen and (max-width: 480px){.eui-masthead .eui-masthead-inner .masthead-title{font-size:16px;max-width:calc(100% - 75px)}}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: EuiIconComponent, selector: "eui-icon", inputs: ["aria-hidden", "setLineHeight", "icon", "size"] }, { kind: "component", type: EuiLogoComponent, selector: "eui-logo", inputs: ["size"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiMastheadComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-masthead', encapsulation: ViewEncapsulation.None, standalone: false, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<header class=\"eui-masthead\">\n  <div class=\"eui-masthead-inner\" [ngClass]=\"{ 'eui-masthead-centered': centeredMasthead }\">\n    @if (icon === 'oi-horizontal' || !icon) {\n      <eui-logo\n        [style.cursor]=\"logoClickObserved ? 'pointer' : 'default'\"\n        [size]=\"28\"\n        tabindex=\"0\"\n        (keydown.enter)=\"onLogoClick($event)\"\n        (click)=\"onLogoClick($event)\"\n      ></eui-logo>\n    }\n    @if (icon && icon !== 'oi-horizontal' && icon !== 'custom') {\n      <eui-icon\n        [icon]=\"icon\"\n        [style.cursor]=\"logoClickObserved ? 'pointer' : 'default'\"\n        size=\"28px\"\n        tabindex=\"0\"\n        (keydown.enter)=\"onLogoClick($event)\"\n        (click)=\"onLogoClick($event)\"\n      ></eui-icon>\n    }\n    <ng-content></ng-content>\n  </div>\n</header>\n", styles: [".eui-dark-theme .eui-masthead{background-color:#016b91;color:#f2f6f7}.eui-dark-theme .eui-masthead .mat-mdc-button.mat-unthemed{color:#f2f6f7}.eui-contrast-theme .eui-masthead{background-color:#00384d;color:#f9fbfc}.eui-contrast-theme .eui-masthead .mat-mdc-button.mat-unthemed{color:#f9fbfc}.eui-contrast-theme .eui-masthead{border-bottom:1px solid #f2fcff}.eui-masthead{background-color:#0a96d1;color:#f2f6f7}.eui-masthead .mat-mdc-button.mat-unthemed{color:#f2f6f7}.eui-masthead-inner{font-size:20px;height:64px;display:flex;align-items:center;padding:10px 24px 10px 32px;line-height:20px;align-content:space-between}[dir=rtl] .eui-masthead-inner{padding:10px 32px 10px 24px}.eui-masthead-inner .masthead-custom-icon{max-height:40px}.eui-masthead-inner .masthead-title{font-size:20px;font-weight:400;padding-left:20px;line-height:20px;flex-grow:1}[dir=rtl] .eui-masthead-inner .masthead-title{padding-left:0;padding-right:20px}.eui-masthead-inner .masthead-actions .mat-mdc-button{margin-right:8px}[dir=rtl] .eui-masthead-inner .masthead-actions .mat-mdc-button{margin-right:initial;margin-left:8px}.eui-masthead-inner .masthead-actions .mat-mdc-button:last-of-type{margin-right:0}[dir=rtl] .eui-masthead-inner .masthead-actions .mat-mdc-button:last-of-type{margin-left:0}.eui-masthead-inner .masthead-actions .mat-mdc-button:not(.eui-masthead--icon-button){max-width:250px;overflow:hidden;text-overflow:ellipsis}.eui-masthead-inner .masthead-actions .mat-mdc-button.eui-masthead--icon-button{min-width:44px}.eui-masthead-inner .masthead-actions .mat-mdc-button.eui-masthead--icon-button .mdc-button__label span{display:none}.eui-masthead-centered{max-width:1180px;margin:0 auto}.eui-masthead-fixed{position:fixed;left:0;right:0;top:0;z-index:950}@media screen and (min-width: 769px) and (max-width: 1200px){.eui-masthead-inner .masthead-actions .mat-mdc-button:not(.eui-masthead--icon-button){max-width:150px!important}}@media screen and (min-width: 769px) and (max-width: 992px){.eui-masthead-inner .masthead-title{font-size:18px}.eui-masthead-inner .masthead-actions .mat-mdc-button:not(.eui-masthead--icon-button){min-width:44px}.eui-masthead-inner .masthead-actions .mat-mdc-button:not(.eui-masthead--icon-button) .mat-icon+span,.eui-masthead-inner .masthead-actions .mat-mdc-button:not(.eui-masthead--icon-button) .eui-icon+span{display:none}}@media screen and (max-width: 768px){.eui-masthead-menu{width:242px}.eui-masthead-menu .mat-mdc-menu-item{text-align:center}.eui-masthead-inner{padding:10px 16px;justify-content:center;height:56px}.eui-masthead-inner .masthead-title{text-align:center;padding-left:0;padding-right:0}.eui-masthead-inner>eui-logo,.eui-masthead-inner>.eui-icon,.eui-masthead-inner>.masthead-actions,.eui-masthead-inner>.masthead-custom-icon{display:none}}@media screen and (max-width: 480px){.eui-masthead .eui-masthead-inner .masthead-title{font-size:16px;max-width:calc(100% - 75px)}}\n"] }]
        }], propDecorators: { icon: [{
                type: Input
            }], centeredMasthead: [{
                type: Input
            }], logoClicked: [{
                type: Output
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiNumberComponent {
    constructor() {
        /**
         * Sets whether the component is required or not
         *
         * @category Input
         */
        this.required = false;
        /**
         * Sets whether the component is read-only or not
         *
         * @category Input
         */
        this.readonly = false;
        /**
         * Sets the native 'step' attribute
         *
         * @category Input
         */
        this.step = 1;
        /**
         * Controls whether the legacy floating label is displayed or a label above the form field
         *
         * @category Input
         */
        this.useLegacyFloatingLabel = false;
        /**
         * When true the 'eui-input--no-margin' class won't be applied to the mat-form-field
         * Note: this needs to be set to 'false' when showing no validation errors in the <mat-error> section, so that they display correctly
         *
         * @category Input
         */
        this.enableFormFieldMargin = true;
        /**
         * Allows a FormControl to be passed to the component so that state and value changes can be viewed
         *
         * @category Input
         */
        this.numberControl = new FormControl(null);
        this._disabled = false;
    }
    /**
     * Sets the disabled state of the component
     *
     * @category Input
     */
    set disabled(value) {
        this._disabled = value;
        this.setDisabled();
    }
    /**
     * Gets the disabled state of the component
     */
    /** @internal */
    get disabled() {
        return this._disabled;
    }
    /** @internal */
    get canIncrease() {
        if (typeof this.max === 'undefined' || this.isValueEmpty) {
            return true;
        }
        const increasedVal = this.numberControl.value + this.step;
        return increasedVal <= this.max;
    }
    /** @internal */
    get canDecrease() {
        if (typeof this.min === 'undefined' || this.isValueEmpty) {
            return true;
        }
        const decreasedVal = this.numberControl.value - this.step;
        return decreasedVal >= this.min;
    }
    /** @internal */
    get isRequired() {
        if (this.required) {
            return true;
        }
        return this.numberControl?.hasValidator(Validators.required) ?? false;
    }
    get isValueEmpty() {
        return !this.numberControl || this.numberControl.value === null || this.numberControl.value === undefined;
    }
    /** @internal */
    ngOnInit() {
        this.setDisabled();
    }
    /** @internal */
    subtractButtonClicked() {
        if (this.numberControl) {
            let newValue = this.numberControl.value - this.step;
            newValue = this.validateValueUpdate(newValue);
            this.updateValue(newValue);
        }
    }
    /** @internal */
    addButtonClicked() {
        if (this.numberControl) {
            let newValue = this.numberControl.value + this.step;
            newValue = this.validateValueUpdate(newValue);
            this.updateValue(newValue);
        }
    }
    validateValueUpdate(newValue) {
        if (typeof this.max !== 'undefined' && newValue > this.max) {
            newValue = this.max;
        }
        if (typeof this.min !== 'undefined' && newValue < this.min) {
            newValue = this.min;
        }
        return newValue;
    }
    setDisabled() {
        if (this.disabled) {
            this.numberControl.disable();
        }
        else {
            this.numberControl.enable();
        }
    }
    updateValue(value) {
        this.numberControl.setValue(value);
        this.numberControl.markAsTouched();
        this.numberControl.markAsDirty();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiNumberComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.2.1", type: EuiNumberComponent, isStandalone: false, selector: "eui-number", inputs: { required: "required", readonly: "readonly", min: "min", max: "max", step: "step", placeholder: "placeholder", label: "label", useLegacyFloatingLabel: "useLegacyFloatingLabel", enableFormFieldMargin: "enableFormFieldMargin", numberControl: "numberControl", width: "width", suffix: "suffix", disabled: "disabled" }, viewQueries: [{ propertyName: "inputElementRef", first: true, predicate: ["inputElement"], descendants: true }], ngImport: i0, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<eui-form-field [width]=\"width\" class=\"eui-number\" [useLegacyFloatingLabel]=\"useLegacyFloatingLabel\" [hideMargins]=\"!enableFormFieldMargin\" [readonly]=\"readonly\">\n  @if (label && !useLegacyFloatingLabel) {\n    <eui-label>{{ label }}</eui-label>\n  }\n  @if (label && useLegacyFloatingLabel) {\n    <mat-label> {{ label }}</mat-label>\n  }\n  \n  <eui-readonly-label>\n    <span #readonlyProjectedContent>\n      <ng-content select=\"eui-readonly-label\"></ng-content>\n    </span>\n    @if (!readonlyProjectedContent.childElementCount) {\n        @if (numberControl.value) {\n          {{ numberControl.value }}\n        }\n        @else {\n          &mdash;\n        }\n    }\n  </eui-readonly-label>\n  \n  <input\n    class=\"eui-number-input\"\n    type=\"number\"\n    data-testid=\"eui-number-input\"\n    matInput\n    #inputElement\n    [formControl]=\"numberControl\"\n    [placeholder]=\"placeholder\"\n    [attr.aria-label]=\"placeholder\"\n    autocomplete=\"off\"\n    [attr.min]=\"min\"\n    [attr.max]=\"max\"\n    [attr.step]=\"step\"\n    [required]=\"isRequired\"\n    />\n    @if (suffix) {\n      <div matTextSuffix>\n        <div class=\"suffix\">{{ suffix }}</div>\n      </div>\n    }\n    <div class=\"buttonWrapper\" matSuffix>\n      <button (click)=\"addButtonClicked()\" class=\"eui-icon--up\" [disabled]=\"disabled || !canIncrease\" tabindex=\"-1\">\n        <eui-icon class=\"eui-scrollup\" icon=\"scrollup\" data-testid=\"eui-number-up\"></eui-icon>\n      </button>\n      <button (click)=\"subtractButtonClicked()\" class=\"eui-icon--down\" [disabled]=\"disabled || !canDecrease\" tabindex=\"-1\">\n        <eui-icon class=\"eui-scrolldown\" icon=\"scrolldown\" data-testid=\"eui-number-down\"></eui-icon>\n      </button>\n    </div>\n    <mat-error class=\"eui-form-field-subscript\">\n      <ng-content select=\"mat-error\"></ng-content>\n    </mat-error>\n    <mat-hint class=\"eui-form-field-subscript\">\n      <ng-content select=\"mat-hint\"></ng-content>\n    </mat-hint>\n  </eui-form-field>\n", styles: [":host-context(.eui-dark-theme) .eui-number:hover .eui-icon--up,:host-context(.eui-dark-theme) .eui-number:hover .eui-icon--down,:host-context(.eui-dark-theme) .eui-number:focus-within .eui-icon--up,:host-context(.eui-dark-theme) .eui-number:focus-within .eui-icon--down{background:#2f3233;color:#f2f6f7}:host-context(.eui-dark-theme) .eui-number .eui-icon--up,:host-context(.eui-dark-theme) .eui-number .eui-icon--down{background:transparent;color:#616566}:host-context(.eui-dark-theme) .eui-number .eui-icon--up:hover,:host-context(.eui-dark-theme) .eui-number .eui-icon--up:focus,:host-context(.eui-dark-theme) .eui-number .eui-icon--down:hover,:host-context(.eui-dark-theme) .eui-number .eui-icon--down:focus{background:#444647;color:#f2f6f7;outline:none}:host-context(.eui-dark-theme) .eui-number .eui-icon--up:disabled,:host-context(.eui-dark-theme) .eui-number .eui-icon--down:disabled{background:transparent;color:#616566;cursor:default}:host-context(.eui-contrast-theme) .eui-number:hover .eui-icon--up,:host-context(.eui-contrast-theme) .eui-number:hover .eui-icon--down,:host-context(.eui-contrast-theme) .eui-number:focus-within .eui-icon--up,:host-context(.eui-contrast-theme) .eui-number:focus-within .eui-icon--down{background:#2f3233;color:#f9fbfc}:host-context(.eui-contrast-theme) .eui-number .eui-icon--up,:host-context(.eui-contrast-theme) .eui-number .eui-icon--down{background:transparent;color:#dfe4e6}:host-context(.eui-contrast-theme) .eui-number .eui-icon--up:hover,:host-context(.eui-contrast-theme) .eui-number .eui-icon--up:focus,:host-context(.eui-contrast-theme) .eui-number .eui-icon--down:hover,:host-context(.eui-contrast-theme) .eui-number .eui-icon--down:focus{background:#444647;color:#f9fbfc;outline:none}:host-context(.eui-contrast-theme) .eui-number .eui-icon--up:disabled,:host-context(.eui-contrast-theme) .eui-number .eui-icon--down:disabled{background:transparent;color:#dfe4e6;cursor:default}:host-context(.eui-contrast-theme) .eui-number .eui-icon--up,:host-context(.eui-contrast-theme) .eui-number .eui-icon--down{box-shadow:0 0 1px 1px #616566 inset}:host-context(.eui-contrast-theme) .eui-number .eui-icon--up:hover:not(:disabled),:host-context(.eui-contrast-theme) .eui-number .eui-icon--down:hover:not(:disabled){box-shadow:0 0 1px 1px #f2f6f7 inset}.eui-number:hover .eui-icon--up,.eui-number:hover .eui-icon--down,.eui-number:focus-within .eui-icon--up,.eui-number:focus-within .eui-icon--down{background:#f2f6f7;color:#444647}.eui-number .eui-icon--up,.eui-number .eui-icon--down{background:transparent;color:#dfe4e6}.eui-number .eui-icon--up:hover,.eui-number .eui-icon--up:focus,.eui-number .eui-icon--down:hover,.eui-number .eui-icon--down:focus{background:#c4cacc;color:#444647;outline:none}.eui-number .eui-icon--up:disabled,.eui-number .eui-icon--down:disabled{background:transparent;color:#dfe4e6;cursor:default}input[type=number]{appearance:textfield}input[type=number]::-webkit-inner-spin-button,input[type=number]::-webkit-outer-spin-button{-webkit-appearance:none}:host ::ng-deep .mat-mdc-form-field-icon-suffix{z-index:auto}.eui-number .suffix{margin-right:24px}.eui-number .buttonWrapper{position:relative}.eui-number .eui-icon--up,.eui-number .eui-icon--down{position:absolute;cursor:pointer;padding:2px;border:0;height:17px;width:18px}.eui-number .eui-icon--up .eui-icon,.eui-number .eui-icon--down .eui-icon{font-size:8px;line-height:12px}.eui-number .eui-icon--up{border-top-right-radius:3px;top:-17px;right:0}.eui-number .eui-icon--down{border-bottom-right-radius:3px;bottom:-17px;right:0}\n"], dependencies: [{ kind: "directive", type: i2$1.MatLabel, selector: "mat-label" }, { kind: "directive", type: i2$1.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i2$1.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i2$1.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "directive", type: i6.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i6.NumberValueAccessor, selector: "input[type=number][formControlName],input[type=number][formControl],input[type=number][ngModel]" }, { kind: "directive", type: i6.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i6.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i6.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "component", type: EuiIconComponent, selector: "eui-icon", inputs: ["aria-hidden", "setLineHeight", "icon", "size"] }, { kind: "component", type: EuiReadonlyLabelComponent, selector: "eui-readonly-label" }, { kind: "component", type: EuiFormFieldComponent, selector: "eui-form-field", inputs: ["appearance", "hideMargins", "width", "useLegacyFloatingLabel", "readonly"] }, { kind: "component", type: EuiLabelComponent, selector: "eui-label", inputs: ["for", "required", "errorState", "disabled"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiNumberComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-number', standalone: false, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<eui-form-field [width]=\"width\" class=\"eui-number\" [useLegacyFloatingLabel]=\"useLegacyFloatingLabel\" [hideMargins]=\"!enableFormFieldMargin\" [readonly]=\"readonly\">\n  @if (label && !useLegacyFloatingLabel) {\n    <eui-label>{{ label }}</eui-label>\n  }\n  @if (label && useLegacyFloatingLabel) {\n    <mat-label> {{ label }}</mat-label>\n  }\n  \n  <eui-readonly-label>\n    <span #readonlyProjectedContent>\n      <ng-content select=\"eui-readonly-label\"></ng-content>\n    </span>\n    @if (!readonlyProjectedContent.childElementCount) {\n        @if (numberControl.value) {\n          {{ numberControl.value }}\n        }\n        @else {\n          &mdash;\n        }\n    }\n  </eui-readonly-label>\n  \n  <input\n    class=\"eui-number-input\"\n    type=\"number\"\n    data-testid=\"eui-number-input\"\n    matInput\n    #inputElement\n    [formControl]=\"numberControl\"\n    [placeholder]=\"placeholder\"\n    [attr.aria-label]=\"placeholder\"\n    autocomplete=\"off\"\n    [attr.min]=\"min\"\n    [attr.max]=\"max\"\n    [attr.step]=\"step\"\n    [required]=\"isRequired\"\n    />\n    @if (suffix) {\n      <div matTextSuffix>\n        <div class=\"suffix\">{{ suffix }}</div>\n      </div>\n    }\n    <div class=\"buttonWrapper\" matSuffix>\n      <button (click)=\"addButtonClicked()\" class=\"eui-icon--up\" [disabled]=\"disabled || !canIncrease\" tabindex=\"-1\">\n        <eui-icon class=\"eui-scrollup\" icon=\"scrollup\" data-testid=\"eui-number-up\"></eui-icon>\n      </button>\n      <button (click)=\"subtractButtonClicked()\" class=\"eui-icon--down\" [disabled]=\"disabled || !canDecrease\" tabindex=\"-1\">\n        <eui-icon class=\"eui-scrolldown\" icon=\"scrolldown\" data-testid=\"eui-number-down\"></eui-icon>\n      </button>\n    </div>\n    <mat-error class=\"eui-form-field-subscript\">\n      <ng-content select=\"mat-error\"></ng-content>\n    </mat-error>\n    <mat-hint class=\"eui-form-field-subscript\">\n      <ng-content select=\"mat-hint\"></ng-content>\n    </mat-hint>\n  </eui-form-field>\n", styles: [":host-context(.eui-dark-theme) .eui-number:hover .eui-icon--up,:host-context(.eui-dark-theme) .eui-number:hover .eui-icon--down,:host-context(.eui-dark-theme) .eui-number:focus-within .eui-icon--up,:host-context(.eui-dark-theme) .eui-number:focus-within .eui-icon--down{background:#2f3233;color:#f2f6f7}:host-context(.eui-dark-theme) .eui-number .eui-icon--up,:host-context(.eui-dark-theme) .eui-number .eui-icon--down{background:transparent;color:#616566}:host-context(.eui-dark-theme) .eui-number .eui-icon--up:hover,:host-context(.eui-dark-theme) .eui-number .eui-icon--up:focus,:host-context(.eui-dark-theme) .eui-number .eui-icon--down:hover,:host-context(.eui-dark-theme) .eui-number .eui-icon--down:focus{background:#444647;color:#f2f6f7;outline:none}:host-context(.eui-dark-theme) .eui-number .eui-icon--up:disabled,:host-context(.eui-dark-theme) .eui-number .eui-icon--down:disabled{background:transparent;color:#616566;cursor:default}:host-context(.eui-contrast-theme) .eui-number:hover .eui-icon--up,:host-context(.eui-contrast-theme) .eui-number:hover .eui-icon--down,:host-context(.eui-contrast-theme) .eui-number:focus-within .eui-icon--up,:host-context(.eui-contrast-theme) .eui-number:focus-within .eui-icon--down{background:#2f3233;color:#f9fbfc}:host-context(.eui-contrast-theme) .eui-number .eui-icon--up,:host-context(.eui-contrast-theme) .eui-number .eui-icon--down{background:transparent;color:#dfe4e6}:host-context(.eui-contrast-theme) .eui-number .eui-icon--up:hover,:host-context(.eui-contrast-theme) .eui-number .eui-icon--up:focus,:host-context(.eui-contrast-theme) .eui-number .eui-icon--down:hover,:host-context(.eui-contrast-theme) .eui-number .eui-icon--down:focus{background:#444647;color:#f9fbfc;outline:none}:host-context(.eui-contrast-theme) .eui-number .eui-icon--up:disabled,:host-context(.eui-contrast-theme) .eui-number .eui-icon--down:disabled{background:transparent;color:#dfe4e6;cursor:default}:host-context(.eui-contrast-theme) .eui-number .eui-icon--up,:host-context(.eui-contrast-theme) .eui-number .eui-icon--down{box-shadow:0 0 1px 1px #616566 inset}:host-context(.eui-contrast-theme) .eui-number .eui-icon--up:hover:not(:disabled),:host-context(.eui-contrast-theme) .eui-number .eui-icon--down:hover:not(:disabled){box-shadow:0 0 1px 1px #f2f6f7 inset}.eui-number:hover .eui-icon--up,.eui-number:hover .eui-icon--down,.eui-number:focus-within .eui-icon--up,.eui-number:focus-within .eui-icon--down{background:#f2f6f7;color:#444647}.eui-number .eui-icon--up,.eui-number .eui-icon--down{background:transparent;color:#dfe4e6}.eui-number .eui-icon--up:hover,.eui-number .eui-icon--up:focus,.eui-number .eui-icon--down:hover,.eui-number .eui-icon--down:focus{background:#c4cacc;color:#444647;outline:none}.eui-number .eui-icon--up:disabled,.eui-number .eui-icon--down:disabled{background:transparent;color:#dfe4e6;cursor:default}input[type=number]{appearance:textfield}input[type=number]::-webkit-inner-spin-button,input[type=number]::-webkit-outer-spin-button{-webkit-appearance:none}:host ::ng-deep .mat-mdc-form-field-icon-suffix{z-index:auto}.eui-number .suffix{margin-right:24px}.eui-number .buttonWrapper{position:relative}.eui-number .eui-icon--up,.eui-number .eui-icon--down{position:absolute;cursor:pointer;padding:2px;border:0;height:17px;width:18px}.eui-number .eui-icon--up .eui-icon,.eui-number .eui-icon--down .eui-icon{font-size:8px;line-height:12px}.eui-number .eui-icon--up{border-top-right-radius:3px;top:-17px;right:0}.eui-number .eui-icon--down{border-bottom-right-radius:3px;bottom:-17px;right:0}\n"] }]
        }], propDecorators: { inputElementRef: [{
                type: ViewChild,
                args: ['inputElement']
            }], required: [{
                type: Input
            }], readonly: [{
                type: Input
            }], min: [{
                type: Input
            }], max: [{
                type: Input
            }], step: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], label: [{
                type: Input
            }], useLegacyFloatingLabel: [{
                type: Input
            }], enableFormFieldMargin: [{
                type: Input
            }], numberControl: [{
                type: Input
            }], width: [{
                type: Input
            }], suffix: [{
                type: Input
            }], disabled: [{
                type: Input
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
var EuiOperator;
(function (EuiOperator) {
    EuiOperator["AND"] = "AND";
    EuiOperator["NOT"] = "NOT";
    EuiOperator["OR"] = "OR";
})(EuiOperator || (EuiOperator = {}));

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiPermissionService {
    constructor() {
        this.splitSeparator = '.';
        this.permissionInitialized = new BehaviorSubject(false);
        this.permissionChanged = new Subject();
        this.unsupportedOperatorMessage = 'Unsupported permission operator';
    }
    /**
     * Set the user permissions.
     * This method rewrites the previous settings.
     * If you would like to reset permissions, you enough to set empty array eg.: []
     *
     * You are able to use two styles. Object and Array.:
     *
     * - Object style: \{'profile': \{'get': \{\}, 'delete': \{\}\}\}
     * Object style better for hierarchical permission (like REST API endpoint and method pairs).
     *
     * - Array style: ['search', 'configuration']
     * Array style better for simple list permission.
     *
     * @param userPermission - "EuiPermission" interface.
     */
    setPermission(userPermission) {
        if (Array.isArray(userPermission))
            this.setPermissionArray(userPermission);
        else
            this.setPermissionObject(userPermission);
        if (this.permissionInitialized.value === false)
            this.permissionInitialized.next(true);
        this.permissionChanged.next(true);
    }
    /**
     * Check user permission.
     * This method is able to check user permission (one or more).
     *
     * @example
     * .hasPermission(['profile'])
     * .hasPermission(['search', 'configuration'], EuiOperator.OR)
     * @param expectedPermission - "EuiPermission" interface.
     * @param operator - "EuiOperator" enum (default EuiOperator.AND).
     */
    hasPermission(expectedPermission, operator = EuiOperator.AND) {
        if (expectedPermission === null)
            return true;
        if (operator === null)
            operator = EuiOperator.AND;
        if (this.permissionInitialized.value) {
            return Array.isArray(expectedPermission)
                ? this.hasPermissionArray(expectedPermission, operator)
                : this.hasPermissionObject(expectedPermission, operator);
        }
        return false;
    }
    setPermissionArray(userPermission) {
        const filteredPermission = {};
        for (const permission of userPermission) {
            const keys = permission.split(this.splitSeparator);
            let currentNode = filteredPermission;
            for (const key of keys) {
                if (!currentNode.hasOwnProperty(key))
                    currentNode[key] = {};
                currentNode = currentNode[key];
            }
        }
        this.userPermission = filteredPermission;
    }
    setPermissionObject(userPermission) {
        this.userPermission = userPermission;
    }
    hasPermissionArray(expectedPermission, operator) {
        if (operator === EuiOperator.AND)
            return this.hasPermissionArrayAND(expectedPermission);
        if (operator === EuiOperator.OR)
            return this.hasPermissionArrayOR(expectedPermission);
        if (operator === EuiOperator.NOT)
            return !this.hasPermissionArrayOR(expectedPermission);
        throw new Error(this.unsupportedOperatorMessage);
    }
    hasPermissionArrayAND(expectedPermission) {
        for (const permission of expectedPermission) {
            const keys = permission.split(this.splitSeparator);
            let currentNode = this.userPermission;
            for (const key of keys) {
                if (currentNode.hasOwnProperty(key))
                    currentNode = currentNode[key];
                else
                    return false;
            }
        }
        return true;
    }
    hasPermissionArrayOR(expectedPermission) {
        for (const permission of expectedPermission) {
            const keys = permission.split(this.splitSeparator);
            let currentNode = this.userPermission;
            let result = true;
            for (const key of keys) {
                if (currentNode.hasOwnProperty(key)) {
                    currentNode = currentNode[key];
                }
                else {
                    result = false;
                    break;
                }
            }
            if (result === true)
                return true;
        }
        return false;
    }
    hasPermissionObject(expectedPermission, operator) {
        if (operator === EuiOperator.AND)
            return this.hasPermissionObjectAND(expectedPermission, this.userPermission);
        if (operator === EuiOperator.OR)
            return this.hasPermissionObjectOR(expectedPermission, this.userPermission);
        if (operator === EuiOperator.NOT)
            return !this.hasPermissionObjectOR(expectedPermission, this.userPermission);
        throw new Error(this.unsupportedOperatorMessage);
    }
    hasPermissionObjectAND(expectedPermission, currentNode) {
        for (const key of Object.keys(expectedPermission)) {
            if (currentNode.hasOwnProperty(key)) {
                if (!this.hasPermissionObjectAND(expectedPermission[key], currentNode[key]))
                    return false;
            }
            else {
                return false;
            }
        }
        return true;
    }
    hasPermissionObjectOR(expectedPermission, currentNode, root = true, tmp = { path: [] }) {
        for (const key of Object.keys(expectedPermission)) {
            if (!currentNode.hasOwnProperty(key))
                continue;
            if (root)
                tmp.path = [];
            tmp.path.push(key);
            const result = this.hasPermissionObjectOR(expectedPermission[key], currentNode[key], false, tmp);
            if (result)
                return true;
            if (Object.keys(expectedPermission[key]).length === 0)
                return true;
            tmp.path.pop();
        }
        return false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiPermissionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiPermissionService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiPermissionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
/**
 * This directive can handle the permission sensitive template contents.
 * It depends on EuiPermissionService.
 *
 * @example
 *   <ng-container *euiPermission="{permission: ['admin']}">
 *     "Admin" only content
 *   </ng-container>
 *
 *   <ng-container *euiPermission="{permission: ['admin', 'general-user'], operator: 'OR'}">
 *     "Admin" OR "General user" only content
 *   </ng-container>
 */
class EuiPermissionDirective {
    /**
     * Set the expected permissions and operator.
     *
     * @category Input
     * @param params - \{ permission: EuiPermission, operator?: EuiOperator | string | null \}
     */
    set permission(params) {
        this.expectedPermission = params.permission || null;
        this.operator = params.operator || null;
        this.checkPermission();
    }
    constructor(changeDetectorRef, permissionService, templateRef, viewContainerRef) {
        this.changeDetectorRef = changeDetectorRef;
        this.permissionService = permissionService;
        this.templateRef = templateRef;
        this.viewContainerRef = viewContainerRef;
        this.checkPermission = () => {
            this.viewContainerRef.clear();
            if (this.expectedPermission && this.permissionService.hasPermission(this.expectedPermission, this.operator)) {
                this.viewContainerRef.createEmbeddedView(this.templateRef);
            }
        };
        this.subscription = this.permissionService.permissionChanged.subscribe(() => {
            this.checkPermission();
            this.changeDetectorRef.markForCheck();
        });
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiPermissionDirective, deps: [{ token: i0.ChangeDetectorRef }, { token: EuiPermissionService }, { token: i0.TemplateRef }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.2.1", type: EuiPermissionDirective, isStandalone: false, selector: "[euiPermission]", inputs: { permission: ["euiPermission", "permission"] }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiPermissionDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[euiPermission]',
                    standalone: false
                }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: EuiPermissionService }, { type: i0.TemplateRef }, { type: i0.ViewContainerRef }], propDecorators: { permission: [{
                type: Input,
                args: ['euiPermission']
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiPermissionGuard {
    static canActivate(route, state) {
        const permissionService = inject(EuiPermissionService);
        const router = inject(Router);
        return new Promise((resolve) => {
            const permission = route.data.permission || null;
            const permissionOperator = route.data.permissionOperator || null;
            if (permissionService.hasPermission(permission, permissionOperator))
                resolve(true);
            else
                resolve(router.parseUrl('permission-denied'));
        });
    }
    static canActivateChild(route, state) {
        return EuiPermissionGuard.canActivate(route, state);
    }
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
/**
 * Smooth Scrollbar wrapper
 *
 * @see https://www.npmjs.com/package/smooth-scrollbar
 * @see https://idiotwu.github.io/smooth-scrollbar
 * @see https://github.com/idiotWu/smooth-scrollbar
 */
class EuiScrollComponent {
    /**
     * Smooth scrollbar options
     *
     * @category Input
     * @see https://github.com/idiotWu/smooth-scrollbar/blob/develop/docs/README.md#available-options-for-scrollbar
     */
    set options(options) {
        this.init(options);
    }
    /** @internal */
    set scrollStatus(scrollStatus) {
        this._scrollStatus.next(scrollStatus);
        if (this.dispatchEvent)
            document.dispatchEvent(new Event('scroll'));
    }
    constructor(zone) {
        this.zone = zone;
        /** @internal */
        this.class = 'eui-scroll';
        /**
         * Turns the scroll bar real event dispatching on document.
         *
         * @category Input
         */
        this.dispatchEvent = false;
        this._scrollStatus = new BehaviorSubject(null);
        this.defaultSettings = {
            alwaysShowTracks: true,
            continuousScrolling: true,
            damping: 0.1,
            renderByPixels: true,
            thumbMinSize: 20,
        };
    }
    /** @internal */
    ngOnInit() {
        if (!this.settings)
            this.init(this.defaultSettings);
    }
    /** @internal */
    ngAfterViewInit() {
        this.update();
    }
    /** @internal */
    ngAfterViewChecked() {
        this.update();
    }
    /** @internal */
    ngOnDestroy() {
        this.destroyInstance();
    }
    /**
     * Forces scrollbar to update geometry information.
     *
     * @see https://github.com/idiotWu/smooth-scrollbar/blob/develop/docs/api.md#scrollbarupdate
     * @internal */
    update() {
        this.zone.runOutsideAngular(() => {
            this.instance.update();
        });
    }
    /**
     * Scrolls to given position with easing function.
     *
     * @see https://github.com/idiotWu/smooth-scrollbar/blob/develop/docs/api.md#scrollbarscrollto
     *
     * @param x - Scrolling offset in x-axis.
     * @param y - Scrolling offset in y-axis.
     * @param duration - Easing duration, default is 0 (non-easing).
     * @param options - Smooth Scrollbar ScrollToOptions.
     * @internal */
    scrollTo(x, y, duration = 0, options = {}) {
        this.zone.runOutsideAngular(() => {
            this.instance.scrollTo(x, y, duration, options);
        });
    }
    /**
     * Scrolls the target element into visible area of scrollbar, likes DOM method element.scrollIntoView().
     * This method will be helpful when you want to create some anchors.
     *
     * @see https://github.com/idiotWu/smooth-scrollbar/blob/develop/docs/api.md#scrollbarscrollintoview
     *
     * @param elem - Target element.
     * @param options - Smooth Scrollbar ScrollIntoViewOptions.
     * @internal */
    scrollIntoView(elem, options = {}) {
        this.zone.runOutsideAngular(() => {
            this.instance.scrollIntoView(elem, options);
        });
    }
    /**
     * Returns scrolling status observable
     *
     * @internal
     */
    getScrollStatus() {
        return this._scrollStatus;
    }
    init(options) {
        this.settings = { ...this.defaultSettings, ...options };
        this.destroyInstance();
        this.createInstance();
    }
    createInstance() {
        this.zone.runOutsideAngular(() => {
            this.instance = Scrollbar.init(this.scrollContainer.nativeElement, this.settings);
            this.instance.addListener((scrollStatus) => (this.scrollStatus = scrollStatus));
        });
    }
    destroyInstance() {
        if (Scrollbar.has(this.scrollContainer.nativeElement)) {
            this.zone.runOutsideAngular(() => {
                Scrollbar.destroy(this.scrollContainer.nativeElement);
            });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiScrollComponent, deps: [{ token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.2.1", type: EuiScrollComponent, isStandalone: false, selector: "eui-scroll", inputs: { dispatchEvent: "dispatchEvent", options: "options" }, host: { properties: { "class": "this.class" } }, viewQueries: [{ propertyName: "scrollContainer", first: true, predicate: ["scrollContainer"], descendants: true, static: true }], ngImport: i0, template: "<!--\n    Copyright 2025 One Identity LLC.\n    ALL RIGHTS RESERVED.\n-->\n\n<div class=\"eui-scroll-container\" #scrollContainer>\n  <ng-content></ng-content>\n</div>\n", styles: [":host.eui-scroll{display:inline-block;position:relative;width:100%;height:100%}:host.eui-scroll .eui-scroll-container{display:inline-block;position:relative;overflow:hidden;max-width:100%;max-height:100%;width:100%}:host.eui-scroll .eui-scroll-container .scrollbar-track{background:#0000001a}:host.eui-scroll .eui-scroll-container .scrollbar-thumb{background:#0006}:host.eui-scroll:hover ::ng-deep .scrollbar-track,:host.eui-scroll:focus ::ng-deep .scrollbar-track{opacity:1}:host.eui-scroll ::ng-deep .scroll-content{transform:translateZ(0);will-change:transform}:host.eui-scroll ::ng-deep .scrollbar-track{transition:none;border-radius:4px}:host.eui-scroll ::ng-deep .scrollbar-thumb{border-radius:4px}:host.eui-scroll ::ng-deep .scrollbar-thumb-x{margin:1px 0;height:6px}:host.eui-scroll ::ng-deep .scrollbar-thumb-y{margin:0 1px;width:6px}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiScrollComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-scroll', changeDetection: ChangeDetectionStrategy.OnPush, standalone: false, template: "<!--\n    Copyright 2025 One Identity LLC.\n    ALL RIGHTS RESERVED.\n-->\n\n<div class=\"eui-scroll-container\" #scrollContainer>\n  <ng-content></ng-content>\n</div>\n", styles: [":host.eui-scroll{display:inline-block;position:relative;width:100%;height:100%}:host.eui-scroll .eui-scroll-container{display:inline-block;position:relative;overflow:hidden;max-width:100%;max-height:100%;width:100%}:host.eui-scroll .eui-scroll-container .scrollbar-track{background:#0000001a}:host.eui-scroll .eui-scroll-container .scrollbar-thumb{background:#0006}:host.eui-scroll:hover ::ng-deep .scrollbar-track,:host.eui-scroll:focus ::ng-deep .scrollbar-track{opacity:1}:host.eui-scroll ::ng-deep .scroll-content{transform:translateZ(0);will-change:transform}:host.eui-scroll ::ng-deep .scrollbar-track{transition:none;border-radius:4px}:host.eui-scroll ::ng-deep .scrollbar-thumb{border-radius:4px}:host.eui-scroll ::ng-deep .scrollbar-thumb-x{margin:1px 0;height:6px}:host.eui-scroll ::ng-deep .scrollbar-thumb-y{margin:0 1px;width:6px}\n"] }]
        }], ctorParameters: () => [{ type: i0.NgZone }], propDecorators: { class: [{
                type: HostBinding,
                args: ['class']
            }], scrollContainer: [{
                type: ViewChild,
                args: ['scrollContainer', { static: true }]
            }], dispatchEvent: [{
                type: Input
            }], options: [{
                type: Input
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/** @internal */
const SIDESHEET_TITLE = new InjectionToken('SIDESHEET_TITLE');
/** @internal */
const SIDESHEET_SUB_TITLE = new InjectionToken('SIDESHEET_SUB_TITLE');
/** @internal */
const SIDESHEET_HEADER_COLOUR = new InjectionToken('SIDESHEET_HEADER_COLOUR');
/** @internal */
const SIDESHEET_ICON = new InjectionToken('SIDESHEET_ICON');
/** @internal */
const SIDESHEET_WIDTH = new InjectionToken('SIDESHEET_WIDTH');
/** @internal */
const SIDESHEET_PADDING = new InjectionToken('SIDESHEET_PADDING');
/** @internal */
const SIDESHEET_TEXT_DIRECTION = new InjectionToken('SIDESHEET_TEXT_DIRECTION');
/** @internal */
const SIDESHEET_CLOSE_ARIA_LABEL = new InjectionToken('SIDESHEET_CLOSE_ARIA_LABEL');
/** @internal */
const SIDESHEET_DISABLE_CLOSE = new InjectionToken('SIDESHEET_DISABLE_CLOSE');
/** @internal */
const EUI_SIDESHEET_TEST_ID = new InjectionToken('EUI_SIDESHEET_TEST_ID');
/** @internal */
const EUI_SIDESHEET_REF = new InjectionToken('EUI_SIDESHEET_REF');
/** @internal */
const SIDESHEET_INTERNAL_CLOSE_ID = 'eui_sidesheet_internal_close_click';
/**
 * Injection token used to inject sidesheet data into component.
 */
const EUI_SIDESHEET_DATA = new InjectionToken('EUI_SIDESHEET_DATA');
/**
 * Configuration options for a sidesheet opened through EuiSidesheetService.
 */
class EuiSidesheetConfig {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSidesheetConfig, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSidesheetConfig }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSidesheetConfig, decorators: [{
            type: Injectable
        }] });
/** @internal */
const DEFAULT_CONFIG = {
    title: '',
    headerColour: '',
    icon: '',
    width: '95%',
    padding: '20px',
    textDirection: 'ltr',
    hasBackdrop: true,
    closeAriaLabel: 'close',
    data: '',
    testId: 'eui-sidesheet',
    disableClose: false,
    autoFocus: true,
    headerComponent: null,
};
/**
 * The action taken when the escape key is pressed
 */
var EuiSidesheetEscapeKeyAction;
(function (EuiSidesheetEscapeKeyAction) {
    EuiSidesheetEscapeKeyAction["None"] = "None";
    EuiSidesheetEscapeKeyAction["CloseTop"] = "CloseTop";
    EuiSidesheetEscapeKeyAction["CloseAll"] = "CloseAll";
})(EuiSidesheetEscapeKeyAction || (EuiSidesheetEscapeKeyAction = {}));

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
/**
 * A reference to a sidesheet component.
 */
class EuiSidesheetRef {
    constructor(overlayRef) {
        this.overlayRef = overlayRef;
        this._beforeClose = new Subject();
        this._afterClosed = new Subject();
        this._closeClicked = new Subject();
    }
    /**
     * A method to get an observable that triggers after the sidesheet is closed.
     */
    afterClosed() {
        return this._afterClosed.asObservable();
    }
    /**
     * A method to get an observable that triggers before the sidesheet is closed.
     */
    beforeClose() {
        return this._beforeClose.asObservable();
    }
    /**
     * A method to get an observable that triggers when the sidesheet is closed via the header close button, escape key or backdrop.
     */
    closeClicked() {
        return this._closeClicked.asObservable();
    }
    /**
     * Closes the sidesheet.
     */
    close(data) {
        let closeDisabled = false;
        if (data === SIDESHEET_INTERNAL_CLOSE_ID) {
            closeDisabled = this.componentInstance.disableClose;
            data = undefined;
            this._closeClicked.next(true);
        }
        if (closeDisabled) {
            return;
        }
        this.closeSidesheet(data);
    }
    closeSidesheet(data) {
        if (this.componentInstance) {
            // setup a subscribe to the start animationStateChanged stream on the sidesheet component
            this.componentInstance.animationStateChanged
                .pipe(filter((event) => event.phaseName === 'start'), take(1))
                .subscribe(() => {
                this._beforeClose.next(data);
                this._beforeClose.complete();
                this.overlayRef.detachBackdrop();
            });
            // Also setup a subscribe to listen for the done state, so we know when to actually close the overlay
            this.componentInstance.animationStateChanged
                .pipe(filter((event) => event.phaseName === 'done' && event.toState === 'leave'), take(1))
                .subscribe(() => {
                this.overlayRef.dispose();
                this._afterClosed.next(data);
                this._afterClosed.complete();
                this.componentInstance = undefined;
            });
            // On close trigger, start sequence to begin closing overlay
            this.componentInstance.startExitAnimation();
        }
    }
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiSidesheetHeaderDirective {
    constructor(viewContainerRef) {
        this.viewContainerRef = viewContainerRef;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSidesheetHeaderDirective, deps: [{ token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.2.1", type: EuiSidesheetHeaderDirective, isStandalone: false, selector: "[euiSidesheetHeader]", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSidesheetHeaderDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[euiSidesheetHeader]',
                    standalone: false
                }]
        }], ctorParameters: () => [{ type: i0.ViewContainerRef }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiSidesheetDirective {
    constructor(viewContainerRef) {
        this.viewContainerRef = viewContainerRef;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSidesheetDirective, deps: [{ token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.2.1", type: EuiSidesheetDirective, isStandalone: false, selector: "[euiSidesheet]", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSidesheetDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[euiSidesheet]',
                    standalone: false
                }]
        }], ctorParameters: () => [{ type: i0.ViewContainerRef }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiSidesheetContentService {
    get contentComponent() {
        return this._contentComponent;
    }
    set contentComponent(comp) {
        this._contentComponent = comp;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSidesheetContentService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSidesheetContentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSidesheetContentService, decorators: [{
            type: Injectable
        }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
const ANIMATION_TIMINGS = '0.25s';
/**
 * This component is not meant to be instantiated directly in your application's code.
 * Call EuiSidesheetService.open() instead.
 */
class EuiSidesheetComponent {
    /**
     * Checks the screen width to see if it is 'mobile' size
     *
     * @internal */
    get isMobile() {
        return document.body.offsetWidth <= 768;
    }
    /**
     * Gets the desired sidesheet width, overriding to 100% if the screen width is 'mobile' size
     *
     * @internal
     */
    get sidesheetWidth() {
        let displayWidth = this.width;
        if (this.isMobile) {
            // Override the display width if on mobile
            displayWidth = '100%';
        }
        return displayWidth;
    }
    get contentWidth() {
        let displayWidth = this.config.width;
        if (this.isMobile) {
            // Override the display width if on mobile
            displayWidth = '100%';
        }
        return displayWidth;
    }
    get translateXDirection() {
        return this.direction === 'rtl' ? '-100%' : '100%';
    }
    constructor(sidesheetRef, config, sidesheetContent, renderer, injector, cdr, title, subTitle, headerBackground, icon, width, padding, direction, closeAriaLabel, disableClose, data, testId) {
        this.sidesheetRef = sidesheetRef;
        this.config = config;
        this.sidesheetContent = sidesheetContent;
        this.renderer = renderer;
        this.injector = injector;
        this.cdr = cdr;
        this.title = title;
        this.subTitle = subTitle;
        this.headerBackground = headerBackground;
        this.icon = icon;
        this.width = width;
        this.padding = padding;
        this.direction = direction;
        this.closeAriaLabel = closeAriaLabel;
        this.disableClose = disableClose;
        this.data = data;
        this.testId = testId;
        /** @internal */
        this.animationState = 'enter';
        /** @internal */
        this.animationStateChanged = new EventEmitter();
        /** @internal */
        this.onOpenSubject = new ReplaySubject(1);
        /** @internal */
        this.titleTooltip = null;
        /** @internal */
        this.subtitleTooltip = null;
        this.titleTextElementChecked = false;
    }
    /** @ignore */
    ngOnInit() {
        this.renderer.addClass(document.body, 'eui-sidesheet-open');
        this.loadComponents();
    }
    /** @ignore */
    ngOnDestroy() {
        this.renderer.removeClass(document.body, 'eui-sidesheet-open');
    }
    /** @ignore */
    ngAfterContentChecked() {
        // After a fight with "expression changed after checked" when trying to set the matTooltip
        // on an overflowed title or subtitle, this both stops the error AND pleases the unit tests.
        // While AfterContentChecked gets called lot, once we find what we're looking for this
        // will be skipped.
        if (this.titleTextElement && !this.titleTextElementChecked) {
            this.titleTooltip = this.titleTextElement.nativeElement.scrollWidth > this.titleTextElement.nativeElement.offsetWidth ? this.title : null;
            // If present, subtitle will "appear" at the same time
            if (this.subTitleTextElement) {
                this.subtitleTooltip = this.subTitleTextElement.nativeElement.scrollWidth > this.subTitleTextElement.nativeElement.offsetWidth ? this.subTitle : null;
            }
            this.titleTextElementChecked = true;
            this.cdr.detectChanges();
        }
    }
    /**
     * Gets the CSS background class based on the passed in colour name.
     *
     * @param colour Valid values: 'black', 'blue', 'gray', 'green', 'orange', 'pink', 'purple', 'red', 'white', 'yellow', 'primary', 'accent', 'warn'
     *
     *    Deprecated values: 'gunmetal', 'iris-blue', 'iris-tint', 'iris-shade', 'iris-pastel', 'asher-gray', 'phoenix-red', 'phoenix-tint', 'phoenix-shade', 'phoenix-pastel',
     *    'corbin-orange', 'corbin-tint', 'corbin-shade', 'corbin-pastel', 'aspen-green', 'aspen-tint', 'aspen-shade', 'aspen-pastel',
     *    'tiki-sunrise', 'tiki-tint', 'tiki-shade', 'tiki-pastel', 'maui-sunset', 'maui-tint', 'maui-shade', 'maui-pastel',
     *    'azalea-pink', 'azalea-tint', 'azalea-shade', 'azalea-pastel', 'black-3', 'black-4', 'black-6', 'black-7', 'black-9', 'black-b', 'black-c'
     * @internal
     */
    getBackgroundClass(colour) {
        let sanitisedColour = colour.toLowerCase();
        // Add modifier to account for the variations of spelling
        if (sanitisedColour === 'grey') {
            sanitisedColour = 'gray';
        }
        return `background--${sanitisedColour}`;
    }
    /** @ignore */
    onAnimationStart(event) {
        this.animationStateChanged.emit(event);
    }
    /** @ignore */
    onAnimationDone(event) {
        this.animationStateChanged.emit(event);
        if (this.animationState === 'enter') {
            this.setFocus();
            this.onOpenSubject.next();
            this.onOpenSubject.complete();
        }
    }
    /**
     * An observable that fires when the sheet has been opened and the slide animation has completed.
     *
     * @internal */
    onOpen() {
        return this.onOpenSubject;
    }
    /** @ignore */
    startExitAnimation() {
        this.animationState = 'leave';
    }
    /**
     * Loads the components that were passed to the sidesheet.
     *
     * @internal */
    loadComponents() {
        const injector = this.buildInjector();
        // Main Component
        this.createComponent(this.sidesheetContent.contentComponent, this.sheetDirective?.viewContainerRef, injector);
        // Header Component
        this.createComponent(this.config.headerComponent, this.sheetHeaderDirective?.viewContainerRef, injector);
    }
    /**
     * Closes the sidesheet.
     *
     * @internal */
    close() {
        this.sidesheetRef.close(SIDESHEET_INTERNAL_CLOSE_ID);
    }
    /**
     * Sets focus within the sidesheet
     *
     * @internal */
    setFocus() {
        if (!this.config.autoFocus) {
            return;
        }
        setTimeout(() => {
            if (this.sidesheetclose) {
                this.sidesheetclose.nativeElement.focus();
            }
        });
    }
    /**
     * Creates a component and assigns it to the view container.
     */
    createComponent(component, viewContainerRef, injector) {
        if (component && viewContainerRef) {
            viewContainerRef.clear();
            viewContainerRef.createComponent(component, { injector });
        }
    }
    /**
     * Builds an injector to pass to the content and header components
     */
    buildInjector() {
        const staticProviders = [
            { provide: EUI_SIDESHEET_REF, useValue: this.sidesheetRef },
            { provide: EuiSidesheetConfig, useValue: this.config },
        ];
        if (this.data) {
            staticProviders.push({ provide: EUI_SIDESHEET_DATA, useValue: this.data });
        }
        return Injector.create({ providers: staticProviders, parent: this.injector });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSidesheetComponent, deps: [{ token: EuiSidesheetRef }, { token: EuiSidesheetConfig }, { token: EuiSidesheetContentService }, { token: i0.Renderer2 }, { token: i0.Injector }, { token: i0.ChangeDetectorRef }, { token: SIDESHEET_TITLE }, { token: SIDESHEET_SUB_TITLE }, { token: SIDESHEET_HEADER_COLOUR }, { token: SIDESHEET_ICON }, { token: SIDESHEET_WIDTH }, { token: SIDESHEET_PADDING }, { token: SIDESHEET_TEXT_DIRECTION }, { token: SIDESHEET_CLOSE_ARIA_LABEL }, { token: SIDESHEET_DISABLE_CLOSE }, { token: EUI_SIDESHEET_DATA }, { token: EUI_SIDESHEET_TEST_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.2.1", type: EuiSidesheetComponent, isStandalone: false, selector: "eui-sidesheet", viewQueries: [{ propertyName: "sheetDirective", first: true, predicate: EuiSidesheetDirective, descendants: true, static: true }, { propertyName: "sheetHeaderDirective", first: true, predicate: EuiSidesheetHeaderDirective, descendants: true, static: true }, { propertyName: "sidesheetclose", first: true, predicate: ["sidesheetclose"], descendants: true, read: ElementRef, static: true }, { propertyName: "sidesheetWrapper", first: true, predicate: ["wrapper"], descendants: true }, { propertyName: "titleTextElement", first: true, predicate: ["titleTextElement"], descendants: true }, { propertyName: "subTitleTextElement", first: true, predicate: ["subTitleTextElement"], descendants: true }], ngImport: i0, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<div\n  [@slideContent]=\"{ value: animationState, params: { translate: translateXDirection } }\"\n  (@slideContent.start)=\"onAnimationStart($event)\"\n  (@slideContent.done)=\"onAnimationDone($event)\"\n  class=\"eui-sidesheet\"\n  [style.width]=\"sidesheetWidth\"\n  [dir]=\"direction\"\n  [attr.data-testid]=\"testId + '-container'\"\n  cdkTrapFocus\n  #wrapper\n  >\n  <mat-toolbar [ngClass]=\"getBackgroundClass(headerBackground)\" [attr.data-testid]=\"testId + '-toolbar'\">\n    @if (icon) {\n      <span class=\"eui-sidesheet__icon\">\n        <eui-icon [icon]=\"icon\" size=\"32px\"></eui-icon>\n      </span>\n    }\n    <span class=\"eui-sidesheet__heading-text\">\n      <span class=\"eui-sidesheet__heading\" [attr.data-testid]=\"testId + '-title'\" [matTooltip]=\"titleTooltip\" [matTooltipShowDelay]=\"500\" #titleTextElement>{{ title }}</span>\n      @if (subTitle) {\n        <span class=\"eui-sidesheet__subheading\" [attr.data-testid]=\"testId + '-subtitle'\" [matTooltip]=\"subtitleTooltip\" [matTooltipShowDelay]=\"500\" #subTitleTextElement>{{ subTitle }}</span>\n      }\n    </span>\n    <span class=\"eui-sidesheet__header-component\" [attr.data-testid]=\"testId + '-header-component'\"><ng-template euiSidesheetHeader></ng-template></span>\n    <button class=\"eui-sidesheet-close\" (click)=\"close()\" matIconButton [attr.aria-label]=\"closeAriaLabel\" [attr.data-testid]=\"testId + '-close'\" #sidesheetclose>\n      <eui-icon icon=\"close\" size=\"24px\"></eui-icon>\n    </button>\n  </mat-toolbar>\n\n  <div\n    class=\"eui-sidesheet__content\"\n    [ngClass]=\"{ 'eui-sidesheet__content--alt': config.useAltBodyColor }\"\n    [style.padding]=\"padding\"\n    [attr.data-testid]=\"testId + '-content'\"\n    [style.width]=\"contentWidth\"\n    >\n    <ng-template euiSidesheet></ng-template>\n  </div>\n</div>\n", styles: [".eui-dark-theme .eui-sidesheet{background:#2f3233;color:#f9fbfc}.eui-dark-theme .eui-sidesheet .mat-toolbar{background-color:#00384d;color:#f9fbfc}.eui-dark-theme .eui-sidesheet__content--alt{background-color:#000}.eui-dark-theme .eui-sidesheet-actions{background-color:#444647;border-top:1px solid #616566}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--black,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--black{background-color:#000;color:#fff}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--white,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--white{background-color:#fff;color:#000}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--gray,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--gray{background-color:#616566;color:#fff}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--blue,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--blue{background-color:#016b91;color:#fff}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--red,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--red{background-color:#900;color:#fff}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--orange,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--orange{background-color:#a65300;color:#fff}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--green,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--green{background-color:#327301;color:#fff}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--yellow,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--yellow{background-color:#948500;color:#f9fbfc}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--purple,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--purple{background-color:#8200a6;color:#fff}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--pink,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--pink{background-color:#a8007b;color:#fff}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--primary,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--primary{background-color:#016b91;color:#fff}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--accent,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--accent{background-color:#a65300;color:#fff}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--warn,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--warn{background-color:#900;color:#fff}.eui-contrast-theme .eui-sidesheet{background:#18191a;color:#f9fbfc}.eui-contrast-theme .eui-sidesheet .mat-toolbar{background-color:#00384d;color:#f9fbfc}.eui-contrast-theme .eui-sidesheet__content--alt{background-color:#000}.eui-contrast-theme .eui-sidesheet-actions{background-color:#2f3233;border-top:1px solid #444647}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--black,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--black{background-color:#000;color:#fff}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--white,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--white{background-color:#fff;color:#000}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--gray,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--gray{background-color:#444647;color:#fff}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--blue,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--blue{background-color:#00384d;color:#fff}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--red,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--red{background-color:#570000;color:#fff}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--orange,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--orange{background-color:#592d00;color:#fff}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--green,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--green{background-color:#1c4000;color:#fff}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--yellow,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--yellow{background-color:#403900;color:#f9fbfc}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--purple,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--purple{background-color:#460059;color:#fff}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--pink,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--pink{background-color:#590041;color:#fff}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--primary,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--primary{background-color:#00384d;color:#fff}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--accent,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--accent{background-color:#592d00;color:#fff}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--warn,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--warn{background-color:#570000;color:#fff}.eui-sidesheet{transition:width .25s;max-width:100%;position:absolute;top:0;right:0;height:100%;box-shadow:0 2px 4px -1px #0003,0 4px 5px #00000024,0 1px 10px #0000001f;translate:100%}.eui-sidesheet[dir=rtl]{translate:-100%}.eui-sidesheet .mat-toolbar{height:64px;padding:0 20px;flex-shrink:0;justify-content:space-between;align-items:center}.eui-sidesheet .mat-toolbar .eui-sidesheet__icon{margin-right:16px;display:flex;align-items:center}[dir=rtl] .eui-sidesheet .mat-toolbar .eui-sidesheet__icon{margin-left:16px;margin-right:0}.eui-sidesheet .mat-toolbar .eui-sidesheet__heading-text{max-width:calc(100% - 88px);flex:0 1 100%;display:flex;flex-direction:column}.eui-sidesheet .mat-toolbar .eui-sidesheet__heading{font-size:20px;line-height:normal;overflow:hidden;text-overflow:ellipsis}.eui-sidesheet .mat-toolbar .eui-sidesheet__subheading{font-size:14px;line-height:normal;opacity:.6;overflow:hidden;text-overflow:ellipsis;margin-top:-2px;margin-bottom:2px}.eui-sidesheet .mat-toolbar .eui-sidesheet__header-component{flex:0 1 auto}.eui-sidesheet__content{padding:20px;height:calc(100% - 64px);overflow:auto;max-width:100%}.eui-sidesheet__content>*{height:100%;display:flex;flex-direction:column}.eui-sidesheet{background:#f9fbfc;color:#2f3233}.eui-sidesheet .mat-toolbar{background-color:#00384d;color:#f9fbfc}.eui-sidesheet__content--alt{background-color:#fff}.eui-sidesheet-actions{background-color:#fff;border-top:1px solid #dfe4e6}.eui-sidesheet .mat-toolbar.background--black,.eui-sidesheet .eui-sidesheet__content.background--black{background-color:#000;color:#fff}.eui-sidesheet .mat-toolbar.background--white,.eui-sidesheet .eui-sidesheet__content.background--white{background-color:#fff;color:#000}.eui-sidesheet .mat-toolbar.background--gray,.eui-sidesheet .eui-sidesheet__content.background--gray{background-color:#797e80;color:#fff}.eui-sidesheet .mat-toolbar.background--blue,.eui-sidesheet .eui-sidesheet__content.background--blue{background-color:#0a96d1;color:#fff}.eui-sidesheet .mat-toolbar.background--red,.eui-sidesheet .eui-sidesheet__content.background--red{background-color:#db2534;color:#fff}.eui-sidesheet .mat-toolbar.background--orange,.eui-sidesheet .eui-sidesheet__content.background--orange{background-color:#e36a00;color:#fff}.eui-sidesheet .mat-toolbar.background--green,.eui-sidesheet .eui-sidesheet__content.background--green{background-color:#4ba803;color:#fff}.eui-sidesheet .mat-toolbar.background--yellow,.eui-sidesheet .eui-sidesheet__content.background--yellow{background-color:#ead200;color:#000}.eui-sidesheet .mat-toolbar.background--purple,.eui-sidesheet .eui-sidesheet__content.background--purple{background-color:#b400e5;color:#fff}.eui-sidesheet .mat-toolbar.background--pink,.eui-sidesheet .eui-sidesheet__content.background--pink{background-color:#f800b6;color:#fff}.eui-sidesheet .mat-toolbar.background--primary,.eui-sidesheet .eui-sidesheet__content.background--primary{background-color:#0a96d1;color:#fff}.eui-sidesheet .mat-toolbar.background--accent,.eui-sidesheet .eui-sidesheet__content.background--accent{background-color:#e36a00;color:#fff}.eui-sidesheet .mat-toolbar.background--warn,.eui-sidesheet .eui-sidesheet__content.background--warn{background-color:#db2534;color:#fff}.eui-sidesheet .mat-toolbar.background--iris-blue,.eui-sidesheet .eui-sidesheet__content.background--iris-blue{background-color:#0a96d1;color:#fff}.eui-sidesheet .mat-toolbar.background--iris-tint,.eui-sidesheet .eui-sidesheet__content.background--iris-tint{background-color:#8acbe3;color:#000}.eui-sidesheet .mat-toolbar.background--iris-shade,.eui-sidesheet .eui-sidesheet__content.background--iris-shade{background-color:#016b91;color:#fff}.eui-sidesheet .mat-toolbar.background--iris-pastel,.eui-sidesheet .eui-sidesheet__content.background--iris-pastel{background-color:#cbe8f2;color:#000}.eui-sidesheet .mat-toolbar.background--asher-gray,.eui-sidesheet .eui-sidesheet__content.background--asher-gray{background-color:#f9fbfc;color:#000}.eui-sidesheet .mat-toolbar.background--gunmetal,.eui-sidesheet .eui-sidesheet__content.background--gunmetal,.eui-sidesheet .mat-toolbar.background--black-3,.eui-sidesheet .eui-sidesheet__content.background--black-3{background-color:#2f3233;color:#fff}.eui-sidesheet .mat-toolbar.background--black-4,.eui-sidesheet .eui-sidesheet__content.background--black-4{background-color:#444647;color:#fff}.eui-sidesheet .mat-toolbar.background--black-6,.eui-sidesheet .eui-sidesheet__content.background--black-6{background-color:#616566;color:#fff}.eui-sidesheet .mat-toolbar.background--black-7,.eui-sidesheet .eui-sidesheet__content.background--black-7{background-color:#797e80;color:#fff}.eui-sidesheet .mat-toolbar.background--black-b,.eui-sidesheet .eui-sidesheet__content.background--black-b{background-color:#aab0b3;color:#000}.eui-sidesheet .mat-toolbar.background--black-c,.eui-sidesheet .eui-sidesheet__content.background--black-c{background-color:#c4cacc;color:#000}.eui-sidesheet .mat-toolbar.background--phoenix-red,.eui-sidesheet .eui-sidesheet__content.background--phoenix-red{background-color:#db2534;color:#fff}.eui-sidesheet .mat-toolbar.background--phoenix-tint,.eui-sidesheet .eui-sidesheet__content.background--phoenix-tint{background-color:#f29d99;color:#000}.eui-sidesheet .mat-toolbar.background--phoenix-shade,.eui-sidesheet .eui-sidesheet__content.background--phoenix-shade{background-color:#570000;color:#fff}.eui-sidesheet .mat-toolbar.background--phoenix-pastel,.eui-sidesheet .eui-sidesheet__content.background--phoenix-pastel{background-color:#f3c8c8;color:#000}.eui-sidesheet .mat-toolbar.background--corbin-orange,.eui-sidesheet .eui-sidesheet__content.background--corbin-orange{background-color:#e36a00;color:#fff}.eui-sidesheet .mat-toolbar.background--corbin-tint,.eui-sidesheet .eui-sidesheet__content.background--corbin-tint{background-color:#edbe8e;color:#000}.eui-sidesheet .mat-toolbar.background--corbin-shade,.eui-sidesheet .eui-sidesheet__content.background--corbin-shade{background-color:#592d00;color:#fff}.eui-sidesheet .mat-toolbar.background--corbin-pastel,.eui-sidesheet .eui-sidesheet__content.background--corbin-pastel{background-color:#f7e4d0;color:#000}.eui-sidesheet .mat-toolbar.background--aspen-green,.eui-sidesheet .eui-sidesheet__content.background--aspen-green{background-color:#4ba803;color:#fff}.eui-sidesheet .mat-toolbar.background--aspen-tint,.eui-sidesheet .eui-sidesheet__content.background--aspen-tint{background-color:#99c478;color:#000}.eui-sidesheet .mat-toolbar.background--aspen-shade,.eui-sidesheet .eui-sidesheet__content.background--aspen-shade{background-color:#1c4000;color:#fff}.eui-sidesheet .mat-toolbar.background--aspen-pastel,.eui-sidesheet .eui-sidesheet__content.background--aspen-pastel{background-color:#cee3bf;color:#000}.eui-sidesheet .mat-toolbar.background--tiki-sunrise,.eui-sidesheet .eui-sidesheet__content.background--tiki-sunrise{background-color:#ead200;color:#000}.eui-sidesheet .mat-toolbar.background--tiki-tint,.eui-sidesheet .eui-sidesheet__content.background--tiki-tint{background-color:#f2e991;color:#000}.eui-sidesheet .mat-toolbar.background--tiki-shade,.eui-sidesheet .eui-sidesheet__content.background--tiki-shade{background-color:#948500;color:#fff}.eui-sidesheet .mat-toolbar.background--tiki-pastel,.eui-sidesheet .eui-sidesheet__content.background--tiki-pastel{background-color:#f7f3d0;color:#000}.eui-sidesheet .mat-toolbar.background--maui-sunset,.eui-sidesheet .eui-sidesheet__content.background--maui-sunset{background-color:#b400e5;color:#fff}.eui-sidesheet .mat-toolbar.background--maui-tint,.eui-sidesheet .eui-sidesheet__content.background--maui-tint{background-color:#d98eed;color:#000}.eui-sidesheet .mat-toolbar.background--maui-shade,.eui-sidesheet .eui-sidesheet__content.background--maui-shade{background-color:#460059;color:#fff}.eui-sidesheet .mat-toolbar.background--maui-pastel,.eui-sidesheet .eui-sidesheet__content.background--maui-pastel{background-color:#efd0f7;color:#000}.eui-sidesheet .mat-toolbar.background--azalea-pink,.eui-sidesheet .eui-sidesheet__content.background--azalea-pink{background-color:#f800b6;color:#fff}.eui-sidesheet .mat-toolbar.background--azalea-tint,.eui-sidesheet .eui-sidesheet__content.background--azalea-tint{background-color:#fa96df;color:#000}.eui-sidesheet .mat-toolbar.background--azalea-shade,.eui-sidesheet .eui-sidesheet__content.background--azalea-shade{background-color:#590041;color:#fff}.eui-sidesheet .mat-toolbar.background--azalea-pastel,.eui-sidesheet .eui-sidesheet__content.background--azalea-pastel{background-color:#fcd4f2;color:#000}.eui-sidesheet-open{overflow:hidden}.eui-sidesheet[dir=rtl]{right:auto;left:0}.eui-sidesheet-content{padding:20px;overflow:auto;height:100%;flex:1}.eui-sidesheet-actions{padding:16px 20px;display:flex;justify-content:flex-end;z-index:2}.eui-sidesheet-actions .mat-mdc-button-base+.mat-mdc-button-base{margin-left:16px}@media (max-width: 768px){.eui-sidesheet .mat-toolbar{height:56px}.eui-sidesheet__content{height:calc(100% - 56px)}}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1$5.Dir, selector: "[dir]", inputs: ["dir"], outputs: ["dirChange"], exportAs: ["dir"] }, { kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i7.MatToolbar, selector: "mat-toolbar", inputs: ["color"], exportAs: ["matToolbar"] }, { kind: "directive", type: i1$6.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "directive", type: i1$1.CdkTrapFocus, selector: "[cdkTrapFocus]", inputs: ["cdkTrapFocus", "cdkTrapFocusAutoCapture"], exportAs: ["cdkTrapFocus"] }, { kind: "component", type: EuiIconComponent, selector: "eui-icon", inputs: ["aria-hidden", "setLineHeight", "icon", "size"] }, { kind: "directive", type: EuiSidesheetDirective, selector: "[euiSidesheet]" }, { kind: "directive", type: EuiSidesheetHeaderDirective, selector: "[euiSidesheetHeader]" }], animations: [
            trigger('slideContent', [
                state('enter', style({ translate: '0' })),
                state('leave', style({ translate: '{{translate}}', opacity: 0 }), { params: { translate: 0 } }),
                transition('* => *', animate(ANIMATION_TIMINGS)),
            ]),
        ], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSidesheetComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-sidesheet', encapsulation: ViewEncapsulation.None, animations: [
                        trigger('slideContent', [
                            state('enter', style({ translate: '0' })),
                            state('leave', style({ translate: '{{translate}}', opacity: 0 }), { params: { translate: 0 } }),
                            transition('* => *', animate(ANIMATION_TIMINGS)),
                        ]),
                    ], standalone: false, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<div\n  [@slideContent]=\"{ value: animationState, params: { translate: translateXDirection } }\"\n  (@slideContent.start)=\"onAnimationStart($event)\"\n  (@slideContent.done)=\"onAnimationDone($event)\"\n  class=\"eui-sidesheet\"\n  [style.width]=\"sidesheetWidth\"\n  [dir]=\"direction\"\n  [attr.data-testid]=\"testId + '-container'\"\n  cdkTrapFocus\n  #wrapper\n  >\n  <mat-toolbar [ngClass]=\"getBackgroundClass(headerBackground)\" [attr.data-testid]=\"testId + '-toolbar'\">\n    @if (icon) {\n      <span class=\"eui-sidesheet__icon\">\n        <eui-icon [icon]=\"icon\" size=\"32px\"></eui-icon>\n      </span>\n    }\n    <span class=\"eui-sidesheet__heading-text\">\n      <span class=\"eui-sidesheet__heading\" [attr.data-testid]=\"testId + '-title'\" [matTooltip]=\"titleTooltip\" [matTooltipShowDelay]=\"500\" #titleTextElement>{{ title }}</span>\n      @if (subTitle) {\n        <span class=\"eui-sidesheet__subheading\" [attr.data-testid]=\"testId + '-subtitle'\" [matTooltip]=\"subtitleTooltip\" [matTooltipShowDelay]=\"500\" #subTitleTextElement>{{ subTitle }}</span>\n      }\n    </span>\n    <span class=\"eui-sidesheet__header-component\" [attr.data-testid]=\"testId + '-header-component'\"><ng-template euiSidesheetHeader></ng-template></span>\n    <button class=\"eui-sidesheet-close\" (click)=\"close()\" matIconButton [attr.aria-label]=\"closeAriaLabel\" [attr.data-testid]=\"testId + '-close'\" #sidesheetclose>\n      <eui-icon icon=\"close\" size=\"24px\"></eui-icon>\n    </button>\n  </mat-toolbar>\n\n  <div\n    class=\"eui-sidesheet__content\"\n    [ngClass]=\"{ 'eui-sidesheet__content--alt': config.useAltBodyColor }\"\n    [style.padding]=\"padding\"\n    [attr.data-testid]=\"testId + '-content'\"\n    [style.width]=\"contentWidth\"\n    >\n    <ng-template euiSidesheet></ng-template>\n  </div>\n</div>\n", styles: [".eui-dark-theme .eui-sidesheet{background:#2f3233;color:#f9fbfc}.eui-dark-theme .eui-sidesheet .mat-toolbar{background-color:#00384d;color:#f9fbfc}.eui-dark-theme .eui-sidesheet__content--alt{background-color:#000}.eui-dark-theme .eui-sidesheet-actions{background-color:#444647;border-top:1px solid #616566}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--black,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--black{background-color:#000;color:#fff}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--white,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--white{background-color:#fff;color:#000}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--gray,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--gray{background-color:#616566;color:#fff}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--blue,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--blue{background-color:#016b91;color:#fff}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--red,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--red{background-color:#900;color:#fff}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--orange,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--orange{background-color:#a65300;color:#fff}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--green,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--green{background-color:#327301;color:#fff}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--yellow,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--yellow{background-color:#948500;color:#f9fbfc}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--purple,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--purple{background-color:#8200a6;color:#fff}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--pink,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--pink{background-color:#a8007b;color:#fff}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--primary,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--primary{background-color:#016b91;color:#fff}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--accent,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--accent{background-color:#a65300;color:#fff}.eui-dark-theme .eui-sidesheet .mat-toolbar.background--warn,.eui-dark-theme .eui-sidesheet .eui-sidesheet__content.background--warn{background-color:#900;color:#fff}.eui-contrast-theme .eui-sidesheet{background:#18191a;color:#f9fbfc}.eui-contrast-theme .eui-sidesheet .mat-toolbar{background-color:#00384d;color:#f9fbfc}.eui-contrast-theme .eui-sidesheet__content--alt{background-color:#000}.eui-contrast-theme .eui-sidesheet-actions{background-color:#2f3233;border-top:1px solid #444647}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--black,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--black{background-color:#000;color:#fff}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--white,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--white{background-color:#fff;color:#000}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--gray,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--gray{background-color:#444647;color:#fff}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--blue,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--blue{background-color:#00384d;color:#fff}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--red,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--red{background-color:#570000;color:#fff}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--orange,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--orange{background-color:#592d00;color:#fff}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--green,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--green{background-color:#1c4000;color:#fff}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--yellow,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--yellow{background-color:#403900;color:#f9fbfc}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--purple,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--purple{background-color:#460059;color:#fff}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--pink,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--pink{background-color:#590041;color:#fff}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--primary,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--primary{background-color:#00384d;color:#fff}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--accent,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--accent{background-color:#592d00;color:#fff}.eui-contrast-theme .eui-sidesheet .mat-toolbar.background--warn,.eui-contrast-theme .eui-sidesheet .eui-sidesheet__content.background--warn{background-color:#570000;color:#fff}.eui-sidesheet{transition:width .25s;max-width:100%;position:absolute;top:0;right:0;height:100%;box-shadow:0 2px 4px -1px #0003,0 4px 5px #00000024,0 1px 10px #0000001f;translate:100%}.eui-sidesheet[dir=rtl]{translate:-100%}.eui-sidesheet .mat-toolbar{height:64px;padding:0 20px;flex-shrink:0;justify-content:space-between;align-items:center}.eui-sidesheet .mat-toolbar .eui-sidesheet__icon{margin-right:16px;display:flex;align-items:center}[dir=rtl] .eui-sidesheet .mat-toolbar .eui-sidesheet__icon{margin-left:16px;margin-right:0}.eui-sidesheet .mat-toolbar .eui-sidesheet__heading-text{max-width:calc(100% - 88px);flex:0 1 100%;display:flex;flex-direction:column}.eui-sidesheet .mat-toolbar .eui-sidesheet__heading{font-size:20px;line-height:normal;overflow:hidden;text-overflow:ellipsis}.eui-sidesheet .mat-toolbar .eui-sidesheet__subheading{font-size:14px;line-height:normal;opacity:.6;overflow:hidden;text-overflow:ellipsis;margin-top:-2px;margin-bottom:2px}.eui-sidesheet .mat-toolbar .eui-sidesheet__header-component{flex:0 1 auto}.eui-sidesheet__content{padding:20px;height:calc(100% - 64px);overflow:auto;max-width:100%}.eui-sidesheet__content>*{height:100%;display:flex;flex-direction:column}.eui-sidesheet{background:#f9fbfc;color:#2f3233}.eui-sidesheet .mat-toolbar{background-color:#00384d;color:#f9fbfc}.eui-sidesheet__content--alt{background-color:#fff}.eui-sidesheet-actions{background-color:#fff;border-top:1px solid #dfe4e6}.eui-sidesheet .mat-toolbar.background--black,.eui-sidesheet .eui-sidesheet__content.background--black{background-color:#000;color:#fff}.eui-sidesheet .mat-toolbar.background--white,.eui-sidesheet .eui-sidesheet__content.background--white{background-color:#fff;color:#000}.eui-sidesheet .mat-toolbar.background--gray,.eui-sidesheet .eui-sidesheet__content.background--gray{background-color:#797e80;color:#fff}.eui-sidesheet .mat-toolbar.background--blue,.eui-sidesheet .eui-sidesheet__content.background--blue{background-color:#0a96d1;color:#fff}.eui-sidesheet .mat-toolbar.background--red,.eui-sidesheet .eui-sidesheet__content.background--red{background-color:#db2534;color:#fff}.eui-sidesheet .mat-toolbar.background--orange,.eui-sidesheet .eui-sidesheet__content.background--orange{background-color:#e36a00;color:#fff}.eui-sidesheet .mat-toolbar.background--green,.eui-sidesheet .eui-sidesheet__content.background--green{background-color:#4ba803;color:#fff}.eui-sidesheet .mat-toolbar.background--yellow,.eui-sidesheet .eui-sidesheet__content.background--yellow{background-color:#ead200;color:#000}.eui-sidesheet .mat-toolbar.background--purple,.eui-sidesheet .eui-sidesheet__content.background--purple{background-color:#b400e5;color:#fff}.eui-sidesheet .mat-toolbar.background--pink,.eui-sidesheet .eui-sidesheet__content.background--pink{background-color:#f800b6;color:#fff}.eui-sidesheet .mat-toolbar.background--primary,.eui-sidesheet .eui-sidesheet__content.background--primary{background-color:#0a96d1;color:#fff}.eui-sidesheet .mat-toolbar.background--accent,.eui-sidesheet .eui-sidesheet__content.background--accent{background-color:#e36a00;color:#fff}.eui-sidesheet .mat-toolbar.background--warn,.eui-sidesheet .eui-sidesheet__content.background--warn{background-color:#db2534;color:#fff}.eui-sidesheet .mat-toolbar.background--iris-blue,.eui-sidesheet .eui-sidesheet__content.background--iris-blue{background-color:#0a96d1;color:#fff}.eui-sidesheet .mat-toolbar.background--iris-tint,.eui-sidesheet .eui-sidesheet__content.background--iris-tint{background-color:#8acbe3;color:#000}.eui-sidesheet .mat-toolbar.background--iris-shade,.eui-sidesheet .eui-sidesheet__content.background--iris-shade{background-color:#016b91;color:#fff}.eui-sidesheet .mat-toolbar.background--iris-pastel,.eui-sidesheet .eui-sidesheet__content.background--iris-pastel{background-color:#cbe8f2;color:#000}.eui-sidesheet .mat-toolbar.background--asher-gray,.eui-sidesheet .eui-sidesheet__content.background--asher-gray{background-color:#f9fbfc;color:#000}.eui-sidesheet .mat-toolbar.background--gunmetal,.eui-sidesheet .eui-sidesheet__content.background--gunmetal,.eui-sidesheet .mat-toolbar.background--black-3,.eui-sidesheet .eui-sidesheet__content.background--black-3{background-color:#2f3233;color:#fff}.eui-sidesheet .mat-toolbar.background--black-4,.eui-sidesheet .eui-sidesheet__content.background--black-4{background-color:#444647;color:#fff}.eui-sidesheet .mat-toolbar.background--black-6,.eui-sidesheet .eui-sidesheet__content.background--black-6{background-color:#616566;color:#fff}.eui-sidesheet .mat-toolbar.background--black-7,.eui-sidesheet .eui-sidesheet__content.background--black-7{background-color:#797e80;color:#fff}.eui-sidesheet .mat-toolbar.background--black-b,.eui-sidesheet .eui-sidesheet__content.background--black-b{background-color:#aab0b3;color:#000}.eui-sidesheet .mat-toolbar.background--black-c,.eui-sidesheet .eui-sidesheet__content.background--black-c{background-color:#c4cacc;color:#000}.eui-sidesheet .mat-toolbar.background--phoenix-red,.eui-sidesheet .eui-sidesheet__content.background--phoenix-red{background-color:#db2534;color:#fff}.eui-sidesheet .mat-toolbar.background--phoenix-tint,.eui-sidesheet .eui-sidesheet__content.background--phoenix-tint{background-color:#f29d99;color:#000}.eui-sidesheet .mat-toolbar.background--phoenix-shade,.eui-sidesheet .eui-sidesheet__content.background--phoenix-shade{background-color:#570000;color:#fff}.eui-sidesheet .mat-toolbar.background--phoenix-pastel,.eui-sidesheet .eui-sidesheet__content.background--phoenix-pastel{background-color:#f3c8c8;color:#000}.eui-sidesheet .mat-toolbar.background--corbin-orange,.eui-sidesheet .eui-sidesheet__content.background--corbin-orange{background-color:#e36a00;color:#fff}.eui-sidesheet .mat-toolbar.background--corbin-tint,.eui-sidesheet .eui-sidesheet__content.background--corbin-tint{background-color:#edbe8e;color:#000}.eui-sidesheet .mat-toolbar.background--corbin-shade,.eui-sidesheet .eui-sidesheet__content.background--corbin-shade{background-color:#592d00;color:#fff}.eui-sidesheet .mat-toolbar.background--corbin-pastel,.eui-sidesheet .eui-sidesheet__content.background--corbin-pastel{background-color:#f7e4d0;color:#000}.eui-sidesheet .mat-toolbar.background--aspen-green,.eui-sidesheet .eui-sidesheet__content.background--aspen-green{background-color:#4ba803;color:#fff}.eui-sidesheet .mat-toolbar.background--aspen-tint,.eui-sidesheet .eui-sidesheet__content.background--aspen-tint{background-color:#99c478;color:#000}.eui-sidesheet .mat-toolbar.background--aspen-shade,.eui-sidesheet .eui-sidesheet__content.background--aspen-shade{background-color:#1c4000;color:#fff}.eui-sidesheet .mat-toolbar.background--aspen-pastel,.eui-sidesheet .eui-sidesheet__content.background--aspen-pastel{background-color:#cee3bf;color:#000}.eui-sidesheet .mat-toolbar.background--tiki-sunrise,.eui-sidesheet .eui-sidesheet__content.background--tiki-sunrise{background-color:#ead200;color:#000}.eui-sidesheet .mat-toolbar.background--tiki-tint,.eui-sidesheet .eui-sidesheet__content.background--tiki-tint{background-color:#f2e991;color:#000}.eui-sidesheet .mat-toolbar.background--tiki-shade,.eui-sidesheet .eui-sidesheet__content.background--tiki-shade{background-color:#948500;color:#fff}.eui-sidesheet .mat-toolbar.background--tiki-pastel,.eui-sidesheet .eui-sidesheet__content.background--tiki-pastel{background-color:#f7f3d0;color:#000}.eui-sidesheet .mat-toolbar.background--maui-sunset,.eui-sidesheet .eui-sidesheet__content.background--maui-sunset{background-color:#b400e5;color:#fff}.eui-sidesheet .mat-toolbar.background--maui-tint,.eui-sidesheet .eui-sidesheet__content.background--maui-tint{background-color:#d98eed;color:#000}.eui-sidesheet .mat-toolbar.background--maui-shade,.eui-sidesheet .eui-sidesheet__content.background--maui-shade{background-color:#460059;color:#fff}.eui-sidesheet .mat-toolbar.background--maui-pastel,.eui-sidesheet .eui-sidesheet__content.background--maui-pastel{background-color:#efd0f7;color:#000}.eui-sidesheet .mat-toolbar.background--azalea-pink,.eui-sidesheet .eui-sidesheet__content.background--azalea-pink{background-color:#f800b6;color:#fff}.eui-sidesheet .mat-toolbar.background--azalea-tint,.eui-sidesheet .eui-sidesheet__content.background--azalea-tint{background-color:#fa96df;color:#000}.eui-sidesheet .mat-toolbar.background--azalea-shade,.eui-sidesheet .eui-sidesheet__content.background--azalea-shade{background-color:#590041;color:#fff}.eui-sidesheet .mat-toolbar.background--azalea-pastel,.eui-sidesheet .eui-sidesheet__content.background--azalea-pastel{background-color:#fcd4f2;color:#000}.eui-sidesheet-open{overflow:hidden}.eui-sidesheet[dir=rtl]{right:auto;left:0}.eui-sidesheet-content{padding:20px;overflow:auto;height:100%;flex:1}.eui-sidesheet-actions{padding:16px 20px;display:flex;justify-content:flex-end;z-index:2}.eui-sidesheet-actions .mat-mdc-button-base+.mat-mdc-button-base{margin-left:16px}@media (max-width: 768px){.eui-sidesheet .mat-toolbar{height:56px}.eui-sidesheet__content{height:calc(100% - 56px)}}\n"] }]
        }], ctorParameters: () => [{ type: EuiSidesheetRef }, { type: EuiSidesheetConfig }, { type: EuiSidesheetContentService }, { type: i0.Renderer2 }, { type: i0.Injector }, { type: i0.ChangeDetectorRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [SIDESHEET_TITLE]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [SIDESHEET_SUB_TITLE]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [SIDESHEET_HEADER_COLOUR]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [SIDESHEET_ICON]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [SIDESHEET_WIDTH]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [SIDESHEET_PADDING]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [SIDESHEET_TEXT_DIRECTION]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [SIDESHEET_CLOSE_ARIA_LABEL]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [SIDESHEET_DISABLE_CLOSE]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [EUI_SIDESHEET_DATA]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [EUI_SIDESHEET_TEST_ID]
                }] }], propDecorators: { sheetDirective: [{
                type: ViewChild,
                args: [EuiSidesheetDirective, { static: true }]
            }], sheetHeaderDirective: [{
                type: ViewChild,
                args: [EuiSidesheetHeaderDirective, { static: true }]
            }], sidesheetclose: [{
                type: ViewChild,
                args: ['sidesheetclose', { static: true, read: ElementRef }]
            }], sidesheetWrapper: [{
                type: ViewChild,
                args: ['wrapper']
            }], titleTextElement: [{
                type: ViewChild,
                args: ['titleTextElement']
            }], subTitleTextElement: [{
                type: ViewChild,
                args: ['subTitleTextElement']
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
const ESCAPE_KEY = 'Escape';
const ESCAPE_KEY_IE = 'Esc';
/**
 * A service that opens sidesheets (with optional background overlays).
 */
class EuiSidesheetService {
    /** @ignore */
    get contentComponent() {
        return this._contentComponent;
    }
    /** @ignore */
    set contentComponent(comp) {
        this._contentComponent = comp;
    }
    /**
     * Returns the sidesheet that is currently displayed
     */
    get topSidesheet() {
        if (this._sidesheetRefs.length === 0) {
            return undefined;
        }
        return this._sidesheetRefs[this._sidesheetRefs.length - 1];
    }
    constructor(injector, overlay, sidesheetContent) {
        this.injector = injector;
        this.overlay = overlay;
        this.sidesheetContent = sidesheetContent;
        this._sidesheetRefs = [];
        this._escapeKeyAction = EuiSidesheetEscapeKeyAction.CloseTop;
    }
    /**
     * Opens a new instance of a sidesheet, sliding out from the side of the screen.
     *
     * @param component The component to show in the sidesheet.
     * @param config Configuration options for the sidesheet. See the [[EuiSidesheetConfig]] interface for more information.
     */
    open(component, config) {
        if (this._sidesheetRefs.length === 0) {
            this._triggerElement = document.activeElement;
        }
        this.sidesheetContent.contentComponent = component;
        const sidesheetConfig = { ...DEFAULT_CONFIG, ...config };
        const overlayConfig = this.getOverlayConfig(sidesheetConfig);
        const overlayRef = this.overlay.create(overlayConfig);
        // Remote control for the sidesheet overlay ref
        const sidesheetRef = new EuiSidesheetRef(overlayRef);
        if (sidesheetConfig.width.endsWith('%')) {
            sidesheetConfig.width = `${this.getStartingWidthNum(sidesheetConfig.width)}px`;
        }
        this._sidesheetRefs.push(sidesheetRef);
        const sidesheetComponent = this.attachDialogContainer(overlayRef, sidesheetConfig, sidesheetRef);
        sidesheetRef.componentInstance = sidesheetComponent;
        if (this._sidesheetRefs.length > 1) {
            this.setSidesheetWidths();
        }
        overlayRef.backdropClick().subscribe(() => sidesheetRef.close(SIDESHEET_INTERNAL_CLOSE_ID));
        overlayRef.keydownEvents().subscribe((event) => this.handleKeyDown(event));
        sidesheetRef.beforeClose().subscribe(() => this.removeSidesheetRef(sidesheetRef));
        return sidesheetRef;
    }
    /**
     *  Closes the last opened sidesheet (top of the stack).
     *
     *  @param data Data that can be passed to the parent component via the EuiSidesheetRef beforeClose and afterClosed observables
     */
    close(data) {
        const sidesheetRef = this.getTopSidesheetRef();
        if (sidesheetRef) {
            sidesheetRef.close(data);
        }
    }
    /**
     *  Closes all open sidesheets.
     *
     *  @param data Data that can be passed to the parent component via the EuiSidesheetRef beforeClose and afterClosed observables
     */
    closeAll(data) {
        this._sidesheetRefs.forEach((ref) => ref.close(data));
    }
    /**
     *  Sets what should happen when the escape key is pressed.
     */
    setEscapeKeyAction(escapeKeyAction) {
        this._escapeKeyAction = escapeKeyAction;
    }
    // Removes the sidesheetRef from the _sidesheetRefs array, if found
    removeSidesheetRef(sidesheetRef) {
        for (let i = 0; i < this._sidesheetRefs.length; i++) {
            if (this._sidesheetRefs[i] === sidesheetRef) {
                this._sidesheetRefs.splice(i, 1);
                this.setTopSidesheetFocus();
                this.setSidesheetWidths(true);
                break;
            }
        }
    }
    getOverlayConfig(config) {
        const positionStrategy = this.overlay.position().global().centerHorizontally().centerVertically();
        const overlayConfig = new OverlayConfig({
            hasBackdrop: config.hasBackdrop,
            backdropClass: config.backdropClass,
            panelClass: config.panelClass,
            direction: config.textDirection,
            scrollStrategy: this.overlay.scrollStrategies.block(),
            positionStrategy,
        });
        return overlayConfig;
    }
    createInjector(config, sidesheetRef) {
        const staticProviders = [];
        config.textDirection = config.textDirection || 'ltr';
        staticProviders.push({ provide: EuiSidesheetRef, useValue: sidesheetRef });
        staticProviders.push({ provide: EuiSidesheetConfig, useValue: config });
        staticProviders.push({ provide: SIDESHEET_TITLE, useValue: config.title });
        staticProviders.push({ provide: SIDESHEET_SUB_TITLE, useValue: config.subTitle });
        staticProviders.push({ provide: SIDESHEET_HEADER_COLOUR, useValue: config.headerColour });
        staticProviders.push({ provide: SIDESHEET_ICON, useValue: config.icon });
        staticProviders.push({ provide: SIDESHEET_WIDTH, useValue: config.width });
        staticProviders.push({ provide: SIDESHEET_PADDING, useValue: config.padding });
        staticProviders.push({ provide: SIDESHEET_TEXT_DIRECTION, useValue: config.textDirection });
        staticProviders.push({ provide: SIDESHEET_CLOSE_ARIA_LABEL, useValue: config.closeAriaLabel });
        staticProviders.push({ provide: SIDESHEET_DISABLE_CLOSE, useValue: config.disableClose });
        staticProviders.push({ provide: EUI_SIDESHEET_DATA, useValue: config.data });
        staticProviders.push({ provide: EUI_SIDESHEET_TEST_ID, useValue: config.testId });
        if (config.data?.extraProviders?.length) {
            config.data.extraProviders.forEach((extraProvider) => {
                staticProviders.push(extraProvider);
            });
        }
        return Injector.create({ providers: staticProviders, parent: this.injector });
    }
    attachDialogContainer(overlayRef, config, sidesheetRef) {
        const injector = this.createInjector(config, sidesheetRef);
        const containerPortal = new ComponentPortal(EuiSidesheetComponent, null, injector);
        const containerRef = overlayRef.attach(containerPortal);
        return containerRef.instance;
    }
    handleKeyDown(event) {
        if (event.key === ESCAPE_KEY || event.key === ESCAPE_KEY_IE) {
            // check if esc came from inside sidesheet
            // esc should not close sidesheet if it is pressed on a different overlay (e.g. data picker)
            const ref = this.getTopSidesheetRef();
            if (!ref) {
                return;
            }
            const wrapperElem = ref.componentInstance.sidesheetWrapper.nativeElement;
            const target = event.target;
            if (target && !wrapperElem.contains(target) && target.tagName !== 'BODY') {
                return;
            }
            if (this._escapeKeyAction === EuiSidesheetEscapeKeyAction.CloseTop) {
                this.close(SIDESHEET_INTERNAL_CLOSE_ID);
            }
            else if (this._escapeKeyAction === EuiSidesheetEscapeKeyAction.CloseAll) {
                this.closeAll(SIDESHEET_INTERNAL_CLOSE_ID);
            }
        }
    }
    getTopSidesheetRef() {
        if (this._sidesheetRefs.length === 0) {
            return undefined;
        }
        return this._sidesheetRefs[this._sidesheetRefs.length - 1];
    }
    setTopSidesheetFocus() {
        if (this._sidesheetRefs.length > 0) {
            this._sidesheetRefs[this._sidesheetRefs.length - 1].componentInstance.setFocus();
        }
        else {
            this._triggerElement.focus();
        }
    }
    setSidesheetWidths(removing = false) {
        if (this._sidesheetRefs.length === 0) {
            return;
        }
        const firstParent = this._sidesheetRefs[0];
        const startingWidth = firstParent.componentInstance.config.width;
        const startingWidthNum = this.getStartingWidthNum(startingWidth);
        let currentWidth = startingWidthNum - 75;
        const refs = [...this._sidesheetRefs].reverse();
        refs.forEach((ref, index) => {
            currentWidth += 75;
            const value = this.getStartingWidthNum(ref.componentInstance.width);
            const isTop = index === 0;
            if (!removing && (isTop || (value > currentWidth && !isTop))) {
                currentWidth = value;
            }
            else if (removing) {
                const result = this.getWidthUpdateRemoving(ref, isTop, value, currentWidth);
                currentWidth = result.currentWidth;
                if (result.break) {
                    return;
                }
            }
            ref.componentInstance.width = `${currentWidth}px`;
        });
    }
    getWidthUpdateRemoving(ref, isTop, value, currentWidth) {
        const originalValue = this.getStartingWidthNum(ref.componentInstance.config.width);
        currentWidth = originalValue > currentWidth ? originalValue : currentWidth;
        const topSmallOriginal = isTop && originalValue < currentWidth;
        if (topSmallOriginal || value === originalValue) {
            ref.componentInstance.width = `${originalValue}px`;
            if (topSmallOriginal) {
                currentWidth = originalValue;
            }
            return { currentWidth, break: true };
        }
        if (!isTop && value - 75 < originalValue && value !== currentWidth) {
            return { currentWidth: originalValue, break: false };
        }
        if (!isTop && value < currentWidth) {
            ref.componentInstance.width = `${value - 75}px`;
            return { currentWidth, break: true };
        }
        return { currentWidth, break: false };
    }
    getStartingWidthNum(startingWidth) {
        if (!startingWidth) {
            return 0;
        }
        const suffix = startingWidth.endsWith('px') ? 'px' : '%';
        let value = this.getNumVal(startingWidth, suffix);
        if (suffix === '%') {
            const percent = value / 100;
            value = Math.round(document.body.offsetWidth * percent);
        }
        return value;
    }
    getNumVal(numString, suffix) {
        const val = numString.replace(suffix, '');
        return Number(val);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSidesheetService, deps: [{ token: i0.Injector }, { token: i1$4.Overlay }, { token: EuiSidesheetContentService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSidesheetService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSidesheetService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i0.Injector }, { type: i1$4.Overlay }, { type: EuiSidesheetContentService }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
const FILTER_OPERATORS = {
    string: [
        {
            key: 'contains',
            expression: '{FIELD_NAME} co \'{VALUE}\''
        },
        {
            key: 'doesNotContain',
            expression: 'not ({FIELD_NAME} co \'{VALUE}\')'
        },
        {
            key: 'equals',
            expression: '{FIELD_NAME} eq \'{VALUE}\''
        },
        {
            key: 'doesNotEqual',
            expression: '{FIELD_NAME} ne \'{VALUE}\''
        },
        {
            key: 'beginsWith',
            expression: '{FIELD_NAME} sw \'{VALUE}\''
        },
        {
            key: 'doesNotBeginWith',
            expression: 'not ({FIELD_NAME} sw \'{VALUE}\')'
        },
        {
            key: 'endsWith',
            expression: '{FIELD_NAME} ew \'{VALUE}\''
        },
        {
            key: 'doesNotEndWith',
            expression: 'not ({FIELD_NAME} ew \'{VALUE}\')'
        }
    ],
    number: [
        {
            key: 'equals',
            expression: '{FIELD_NAME} eq {VALUE}'
        },
        {
            key: 'doesNotEqual',
            expression: '{FIELD_NAME} ne {VALUE}'
        },
        {
            key: 'isGreaterThan',
            expression: '{FIELD_NAME} gt {VALUE}'
        },
        {
            key: 'isGreaterThanOrEqualTo',
            expression: '{FIELD_NAME} ge {VALUE}'
        },
        {
            key: 'isLessThan',
            expression: '{FIELD_NAME} lt {VALUE}'
        },
        {
            'key': 'isLessThanOrEqualTo',
            expression: '{FIELD_NAME} le {VALUE}'
        }
    ],
    date: [
        {
            key: 'equals',
            expression: '({FIELD_NAME} ge \'{SELECTED_DATE}\') and ({FIELD_NAME} lt \'{NEXT_DAY}\')'
        },
        {
            key: 'doesNotEqual',
            expression: '({FIELD_NAME} lt \'{SELECTED_DATE}\') or ({FIELD_NAME} ge \'{NEXT_DAY}\')'
        },
        {
            key: 'isAfter',
            expression: '{FIELD_NAME} ge \'{NEXT_DAY}\''
        },
        {
            key: 'isOnOrAfter',
            expression: '{FIELD_NAME} ge \'{SELECTED_DATE}\''
        },
        {
            key: 'isBefore',
            expression: '{FIELD_NAME} lt \'{SELECTED_DATE}\''
        },
        {
            key: 'isOnOrBefore',
            expression: '{FIELD_NAME} lt \'{NEXT_DAY}\''
        }
    ]
};

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiCustomFilterService {
    constructor(_sidesheetService) {
        this._sidesheetService = _sidesheetService;
        this.INITIAL_STATE = {
            matchSelection: 'and',
            conditionsAndGroups: [{}]
        };
        this.activeFilters = new BehaviorSubject(this.INITIAL_STATE);
        // eslint-disable-next-line @typescript-eslint/member-ordering
        this.activeFilters$ = this.activeFilters.asObservable();
        // eslint-disable-next-line @typescript-eslint/member-ordering
        this.activeFiltersCount$ = this.activeFilters$.pipe(map((activeFilters) => this.getActiveFiltersCountRecursively(activeFilters)));
        // store moment in property so that it can be mocked in unit test
        this.moment = moment$1;
    }
    openSideSheet$({ fields, labelTranslations }, component) {
        this.fields = fields;
        const sidesheetRef = this._sidesheetService.open(component, {
            title: labelTranslations.sidesheetTitle,
            icon: 'filter',
            width: '769px',
            padding: '0',
            data: {
                rootFilterGroup: structuredClone(this.activeFilters.value),
                extraProviders: [{ provide: EuiCustomFilterService, useValue: this }],
                labelTranslations: labelTranslations.sidesheet
            }
        });
        return sidesheetRef.afterClosed().pipe(filter((data) => !!data), tap((filterGroup) => this.activeFilters.next(filterGroup)), map((filterGroup) => {
            const filterExpression = this.mapToFilterExpression(filterGroup);
            return filterExpression.length ? `(${filterExpression})` : '';
        }));
    }
    clearFilters() {
        this.activeFilters.next(structuredClone(this.INITIAL_STATE));
    }
    resetFilters(rootFilterGroup) {
        rootFilterGroup.matchSelection = this.INITIAL_STATE.matchSelection;
        rootFilterGroup.conditionsAndGroups = structuredClone(this.INITIAL_STATE.conditionsAndGroups);
    }
    cancel() {
        this._sidesheetService.close();
    }
    apply(rootFilterGroup) {
        this._sidesheetService.close(rootFilterGroup);
    }
    addCondition(filterGroup) {
        filterGroup.conditionsAndGroups.push({});
    }
    addGroup(filterGroup) {
        filterGroup.conditionsAndGroups.push({
            matchSelection: 'and',
            conditionsAndGroups: [{}]
        });
    }
    duplicateConditionOrGroup(parent, conditionOrGroup) {
        const idx = parent.conditionsAndGroups.indexOf(conditionOrGroup);
        parent.conditionsAndGroups.splice(idx, 0, structuredClone(conditionOrGroup));
    }
    clearGroup(parent, filterGroup) {
        const idx = parent.conditionsAndGroups.indexOf(filterGroup);
        parent.conditionsAndGroups.splice(idx, 1);
        const wasTheLastObjectAtCurrentLevel = parent.conditionsAndGroups.length === 0;
        if (wasTheLastObjectAtCurrentLevel) {
            parent.conditionsAndGroups.splice(idx, 0, {});
        }
    }
    clearCondition(parent, condition) {
        const idx = parent.conditionsAndGroups.indexOf(condition);
        const isLastObjectAtCurrentLevel = parent.conditionsAndGroups.length === 1;
        if (isLastObjectAtCurrentLevel) {
            condition.fieldName = null;
            condition.operator = null;
            condition.value = null;
        }
        else {
            parent.conditionsAndGroups.splice(idx, 1);
        }
    }
    hasInvalidCondition(filterGroup) {
        return filterGroup.conditionsAndGroups.some(conditionOrGroup => {
            if (!this.isFilterGroup(conditionOrGroup)) {
                if (this.isConditionEmpty(conditionOrGroup)) {
                    return true;
                }
            }
            else {
                const hasInvalidCondition = this.hasInvalidCondition(conditionOrGroup);
                if (hasInvalidCondition) {
                    return true;
                }
            }
        });
    }
    haveActiveFiltersNotChanged(rootFilterGroup) {
        const currentActiveFilters = this.activeFilters.value;
        if (Object.keys(currentActiveFilters).length !== Object.keys(rootFilterGroup).length) {
            return false;
        }
        return isEqual(currentActiveFilters, rootFilterGroup);
    }
    isConditionEmpty(condition) {
        return condition.value === null || condition.value === undefined || condition.value === '';
    }
    getActiveFiltersCountRecursively(activeFilters) {
        let count = 0;
        if (!activeFilters.conditionsAndGroups?.length) {
            return count;
        }
        const { conditions, filterGroups } = this.getConditionsAndGroupsSeparately(activeFilters);
        count += conditions.filter((condition) => !this.isConditionEmpty(condition)).length;
        filterGroups.forEach((filterGroup) => {
            count += this.getActiveFiltersCountRecursively(filterGroup);
        });
        return count;
    }
    isFilterGroup(conditionOrFilterGroup) {
        // @ts-ignore
        return !!conditionOrFilterGroup['matchSelection'];
    }
    getConditionsAndGroupsSeparately(activeFilters) {
        const conditions = [];
        const filterGroups = [];
        // separate conditions from groups to count conditions
        activeFilters.conditionsAndGroups.forEach((conditionOrGroup) => {
            if (this.isFilterGroup(conditionOrGroup)) {
                filterGroups.push(conditionOrGroup);
            }
            else {
                conditions.push(conditionOrGroup);
            }
        });
        return {
            conditions,
            filterGroups
        };
    }
    mapToFilterExpression(filterGroup) {
        let filterExpr = '';
        filterGroup.conditionsAndGroups.forEach((conditionOrGroup, index) => {
            if (this.isFilterGroup(conditionOrGroup)) {
                filterExpr += `(${this.mapToFilterExpression(conditionOrGroup)})`;
            }
            else if (conditionOrGroup.fieldName) {
                const dataType = this.fields.find((field) => conditionOrGroup.fieldName === field.name).type;
                if (dataType === 'boolean') {
                    filterExpr += `(${conditionOrGroup.fieldName} eq ${conditionOrGroup.value})`;
                }
                else {
                    const expression = FILTER_OPERATORS[dataType].find((operator) => operator.key === conditionOrGroup.operator).expression;
                    const fieldNameReplaced = expression.replace(/{FIELD_NAME}/g, conditionOrGroup.fieldName);
                    if (dataType === 'date') {
                        const nextDay = this.moment(conditionOrGroup.value.toString()).add(1, 'day');
                        const selectedDateReplaced = fieldNameReplaced.replace(/{SELECTED_DATE}/g, conditionOrGroup.value.toString());
                        const nextDayReplaced = selectedDateReplaced.replace(/{NEXT_DAY}/g, nextDay.format());
                        filterExpr += `(${nextDayReplaced})`;
                    }
                    else {
                        filterExpr += `(${fieldNameReplaced.replace(/{VALUE}/g, conditionOrGroup.value.toString())})`;
                    }
                }
            }
            if (index < filterGroup.conditionsAndGroups.length - 1) {
                filterExpr += ` ${filterGroup.matchSelection} `;
            }
        });
        return filterExpr;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiCustomFilterService, deps: [{ token: EuiSidesheetService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiCustomFilterService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiCustomFilterService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: EuiSidesheetService }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiSearchCustomFiltersIndividualActionsComponent {
    constructor() {
        this.byDuplicate = new EventEmitter();
        this.byClear = new EventEmitter();
    }
    onDuplicateClick() {
        this.byDuplicate.emit();
    }
    onClearClick() {
        this.byClear.emit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSearchCustomFiltersIndividualActionsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.2.1", type: EuiSearchCustomFiltersIndividualActionsComponent, isStandalone: false, selector: "eui-search-custom-filters-individual-actions", inputs: { isClearDisabled: "isClearDisabled", labelTranslations: "labelTranslations", path: "path" }, outputs: { byDuplicate: "byDuplicate", byClear: "byClear" }, ngImport: i0, template: "<button\n  matIconButton\n  color=\"primary\"\n  (click)=\"onDuplicateClick()\"\n  [attr.aria-label]=\"labelTranslations.duplicateTooltip\"\n  [matTooltip]=\"labelTranslations.duplicateTooltip\"\n  [matTooltipShowDelay]=\"500\"\n  [attr.data-testid]=\"'eui-search-custom-filters-individual-actions-' + path + '-duplicate-btn'\"\n>\n  <eui-icon icon=\"copy\"/>\n</button>\n\n<button\n  matIconButton\n  (click)=\"onClearClick()\"\n  [attr.aria-label]=\"labelTranslations.clearTooltip\"\n  [matTooltip]=\"labelTranslations.clearTooltip\"\n  [matTooltipShowDelay]=\"500\"\n  [attr.data-testid]=\"'eui-search-custom-filters-individual-actions-' + path + '-clear-btn'\"\n  [disabled]=\"isClearDisabled\"\n>\n  <eui-icon icon=\"close\"/>\n</button>\n", styles: [":host{display:grid;grid-template-columns:repeat(2,1fr);column-gap:8px}\n"], dependencies: [{ kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: i1$6.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "component", type: EuiIconComponent, selector: "eui-icon", inputs: ["aria-hidden", "setLineHeight", "icon", "size"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSearchCustomFiltersIndividualActionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-search-custom-filters-individual-actions', standalone: false, template: "<button\n  matIconButton\n  color=\"primary\"\n  (click)=\"onDuplicateClick()\"\n  [attr.aria-label]=\"labelTranslations.duplicateTooltip\"\n  [matTooltip]=\"labelTranslations.duplicateTooltip\"\n  [matTooltipShowDelay]=\"500\"\n  [attr.data-testid]=\"'eui-search-custom-filters-individual-actions-' + path + '-duplicate-btn'\"\n>\n  <eui-icon icon=\"copy\"/>\n</button>\n\n<button\n  matIconButton\n  (click)=\"onClearClick()\"\n  [attr.aria-label]=\"labelTranslations.clearTooltip\"\n  [matTooltip]=\"labelTranslations.clearTooltip\"\n  [matTooltipShowDelay]=\"500\"\n  [attr.data-testid]=\"'eui-search-custom-filters-individual-actions-' + path + '-clear-btn'\"\n  [disabled]=\"isClearDisabled\"\n>\n  <eui-icon icon=\"close\"/>\n</button>\n", styles: [":host{display:grid;grid-template-columns:repeat(2,1fr);column-gap:8px}\n"] }]
        }], propDecorators: { byDuplicate: [{
                type: Output
            }], byClear: [{
                type: Output
            }], isClearDisabled: [{
                type: Input
            }], labelTranslations: [{
                type: Input,
                args: [{ required: true }]
            }], path: [{
                type: Input,
                args: [{ required: true }]
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiOrderByPipe {
    transform(array, orderByKey, order = 'asc') {
        if (!array || array.length <= 1 || !orderByKey) {
            return array;
        }
        const arrayCopy = structuredClone(array);
        arrayCopy.sort((a, b) => {
            const valueA = a[orderByKey];
            const valueB = b[orderByKey];
            if (valueA < valueB) {
                return order === 'asc' ? -1 : 1;
            }
            else if (valueA > valueB) {
                return order === 'asc' ? 1 : -1;
            }
            else {
                return 0;
            }
        });
        return arrayCopy;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiOrderByPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "20.2.1", ngImport: i0, type: EuiOrderByPipe, isStandalone: false, name: "euiOrderBy" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiOrderByPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'euiOrderBy',
                    standalone: false
                }]
        }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiSearchCustomFiltersConditionComponent {
    constructor(_destroyRef) {
        this._destroyRef = _destroyRef;
        this.byConditionDuplicated = new EventEmitter();
        this.byConditionCleared = new EventEmitter();
        this.dateControl = new FormControl(null, Validators.required);
        this.booleanValues = ['true', 'false'];
    }
    ngOnInit() {
        if (this.condition.fieldName) {
            this.dataType = this.fields.find((field) => this.condition.fieldName === field.name).type;
            if (this.dataType === 'boolean') {
                this.operators = null;
            }
            else {
                this.operators = FILTER_OPERATORS[this.dataType];
            }
            if (this.dataType === 'date' && typeof this.condition.value === 'string') {
                this.dateControl.setValue(moment$1(this.condition.value));
            }
        }
        this.dateControl.valueChanges.pipe(filter((selectedDate) => !!selectedDate), takeUntilDestroyed(this._destroyRef)).subscribe((selectedDate) => {
            this.condition.value = selectedDate.format();
        });
    }
    onDuplicate() {
        this.byConditionDuplicated.emit({ parent: this.parent, conditionOrFilterGroup: this.condition });
    }
    onClear() {
        this.operators = undefined;
        this.dataType = null;
        this.resetControls();
        this.byConditionCleared.emit({ parent: this.parent, condition: this.condition });
    }
    onFieldSelectionChange() {
        this.resetControls();
        this.dataType = this.fields.find((field) => this.condition.fieldName === field.name).type;
        if (this.dataType === 'boolean') {
            this.condition.value = 'true';
            this.operators = null;
            this.condition.operator = null;
        }
        else {
            this.condition.value = null;
            this.operators = FILTER_OPERATORS[this.dataType];
            // set default operator
            this.condition.operator = this.operators[0].key;
        }
    }
    resetControls() {
        if (this.inputModel) {
            this.inputModel.reset();
        }
        this.dateControl.reset();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSearchCustomFiltersConditionComponent, deps: [{ token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.2.1", type: EuiSearchCustomFiltersConditionComponent, isStandalone: false, selector: "eui-search-custom-filters-condition", inputs: { condition: "condition", isLastObject: "isLastObject", fields: "fields", labelTranslations: "labelTranslations", parent: "parent", outerIdx: "outerIdx", loopIdx: "loopIdx", path: "path" }, outputs: { byConditionDuplicated: "byConditionDuplicated", byConditionCleared: "byConditionCleared" }, viewQueries: [{ propertyName: "inputModel", first: true, predicate: ["inputModel"], descendants: true, read: NgModel }], ngImport: i0, template: "<div class=\"fields\">\n  <eui-form-field [hideMargins]=\"true\">\n    <mat-select\n      [(value)]=\"condition.fieldName\"\n      [placeholder]=\"labelTranslations.condition.selectField\"\n      (selectionChange)=\"onFieldSelectionChange()\"\n      [attr.data-testid]=\"'eui-search-custom-filters-condition-' + path + '-fieldName-select'\"\n    >\n      @for (field of fields | euiOrderBy: 'label'; track field) {\n        <mat-option\n          [value]=\"field.name\"\n          [attr.data-testid]=\"'eui-search-custom-filters-condition-' + path + '-fieldName-select-option-' + field.name\"\n        >\n          {{ field.label }}\n        </mat-option>\n      }\n    </mat-select>\n  </eui-form-field>\n\n  @if (operators !== null) {\n    <eui-form-field [hideMargins]=\"true\">\n      <mat-select\n        [(value)]=\"condition.operator\"\n        [placeholder]=\"labelTranslations.condition.operator.description\"\n        [disabled]=\"!condition.fieldName\"\n        [attr.data-testid]=\"'eui-search-custom-filters-condition-' + path + '-operator-select'\"\n      >\n        @for (operator of operators; track operator) {\n          <mat-option\n            [value]=\"operator.key\"\n            [attr.data-testid]=\"'eui-search-custom-filters-condition-' + path + '-operator-select-option-' + operator.key\"\n          >\n            {{ $any(labelTranslations.condition.operator.selectableValue)[dataType]?.[operator.key] }}\n          </mat-option>\n        }\n      </mat-select>\n    </eui-form-field>\n\n    @if (dataType === 'date') {\n      <eui-date-picker\n        [hideMargins]=\"true\"\n        [allowTextInput]=\"false\"\n        [dateControl]=\"dateControl\"\n        [placeholder]=\"labelTranslations.condition.input.date\"\n        [disabled]=\"!condition.operator\"\n        [showErrorState]=\"true\"\n        [attr.data-testid]=\"'eui-search-custom-filters-condition-' + path + '-date-input'\"\n      />\n    } @else {\n      <eui-form-field [hideMargins]=\"true\">\n        @if (inputModel.touched && !inputModel.disabled && (condition.value === null || condition.value === undefined || condition.value === '')) {\n          <eui-icon matPrefix icon=\"error-circle\"/>\n        }\n        <input\n          [(ngModel)]=\"condition.value\"\n          #inputModel=\"ngModel\"\n          matInput\n          [placeholder]=\"!condition.operator ? labelTranslations.condition.input.value : dataType === 'string' ? labelTranslations.condition.input.string : labelTranslations.condition.input.number\"\n          [attr.aria-label]=\"!condition.operator ? labelTranslations.condition.input.value : dataType === 'string' ? labelTranslations.condition.input.string : labelTranslations.condition.input.number\"\n          [attr.data-testid]=\"'eui-search-custom-filters-condition-' + path + '-value'\"\n          autocomplete=\"off\"\n          [type]=\"dataType === 'string' ? 'text' : 'number'\"\n          [disabled]=\"!condition.operator\"\n          required\n        />\n      </eui-form-field>\n    }\n  } @else {\n    <mat-radio-group\n      [(ngModel)]=\"condition.value\"\n      [attr.aria-label]=\"labelTranslations.condition.input.boolean.ariaLabel\"\n      [attr.data-testid]=\"'eui-search-custom-filters-condition-' + path + '-boolean-radio-group'\"\n    >\n      @for (booleanValue of booleanValues; track booleanValue) {\n        <mat-radio-button\n          [value]=\"booleanValue\"\n          [attr.data-testid]=\"'eui-search-custom-filters-condition-' + path + '-boolean-radio-button-' + booleanValue\"\n        >\n          {{ labelTranslations.condition.input.boolean[booleanValue] }}\n        </mat-radio-button>\n      }\n    </mat-radio-group>\n  }\n</div>\n\n<eui-search-custom-filters-individual-actions\n  [path]=\"path\"\n  [labelTranslations]=\"labelTranslations.individualActions\"\n  [isClearDisabled]=\"isLastObject && (!condition.fieldName && !condition.operator && (condition.value === null || condition.value === undefined || condition.value === ''))\"\n  (byDuplicate)=\"onDuplicate()\"\n  (byClear)=\"onClear()\"\n/>\n", styles: [":host{display:grid;grid-template-columns:1fr auto;column-gap:16px}:host .fields{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}@media screen and (max-width: 768px){:host .fields{grid-template-columns:1fr}}:host .fields eui-icon{color:#db2534}\n"], dependencies: [{ kind: "component", type: i2$2.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "directive", type: i2$1.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "directive", type: i4$1.MatRadioGroup, selector: "mat-radio-group", inputs: ["color", "name", "labelPosition", "value", "selected", "disabled", "required", "disabledInteractive"], outputs: ["change"], exportAs: ["matRadioGroup"] }, { kind: "component", type: i4$1.MatRadioButton, selector: "mat-radio-button", inputs: ["id", "name", "aria-label", "aria-labelledby", "aria-describedby", "disableRipple", "tabIndex", "checked", "value", "labelPosition", "disabled", "required", "color", "disabledInteractive"], outputs: ["change"], exportAs: ["matRadioButton"] }, { kind: "component", type: i8.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "directive", type: i6.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i6.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i6.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i6.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: EuiDatePickerComponent, selector: "eui-date-picker", inputs: ["dateControl", "useLegacyFloatingLabel", "label", "placeholder", "appearance", "required", "readonly", "hideMargins", "min", "max", "width", "dateFilter", "touchUi", "allowTextInput", "useClearIcon", "showErrorState", "disabled"] }, { kind: "component", type: EuiIconComponent, selector: "eui-icon", inputs: ["aria-hidden", "setLineHeight", "icon", "size"] }, { kind: "component", type: EuiSearchCustomFiltersIndividualActionsComponent, selector: "eui-search-custom-filters-individual-actions", inputs: ["isClearDisabled", "labelTranslations", "path"], outputs: ["byDuplicate", "byClear"] }, { kind: "component", type: EuiFormFieldComponent, selector: "eui-form-field", inputs: ["appearance", "hideMargins", "width", "useLegacyFloatingLabel", "readonly"] }, { kind: "pipe", type: EuiOrderByPipe, name: "euiOrderBy" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSearchCustomFiltersConditionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-search-custom-filters-condition', standalone: false, template: "<div class=\"fields\">\n  <eui-form-field [hideMargins]=\"true\">\n    <mat-select\n      [(value)]=\"condition.fieldName\"\n      [placeholder]=\"labelTranslations.condition.selectField\"\n      (selectionChange)=\"onFieldSelectionChange()\"\n      [attr.data-testid]=\"'eui-search-custom-filters-condition-' + path + '-fieldName-select'\"\n    >\n      @for (field of fields | euiOrderBy: 'label'; track field) {\n        <mat-option\n          [value]=\"field.name\"\n          [attr.data-testid]=\"'eui-search-custom-filters-condition-' + path + '-fieldName-select-option-' + field.name\"\n        >\n          {{ field.label }}\n        </mat-option>\n      }\n    </mat-select>\n  </eui-form-field>\n\n  @if (operators !== null) {\n    <eui-form-field [hideMargins]=\"true\">\n      <mat-select\n        [(value)]=\"condition.operator\"\n        [placeholder]=\"labelTranslations.condition.operator.description\"\n        [disabled]=\"!condition.fieldName\"\n        [attr.data-testid]=\"'eui-search-custom-filters-condition-' + path + '-operator-select'\"\n      >\n        @for (operator of operators; track operator) {\n          <mat-option\n            [value]=\"operator.key\"\n            [attr.data-testid]=\"'eui-search-custom-filters-condition-' + path + '-operator-select-option-' + operator.key\"\n          >\n            {{ $any(labelTranslations.condition.operator.selectableValue)[dataType]?.[operator.key] }}\n          </mat-option>\n        }\n      </mat-select>\n    </eui-form-field>\n\n    @if (dataType === 'date') {\n      <eui-date-picker\n        [hideMargins]=\"true\"\n        [allowTextInput]=\"false\"\n        [dateControl]=\"dateControl\"\n        [placeholder]=\"labelTranslations.condition.input.date\"\n        [disabled]=\"!condition.operator\"\n        [showErrorState]=\"true\"\n        [attr.data-testid]=\"'eui-search-custom-filters-condition-' + path + '-date-input'\"\n      />\n    } @else {\n      <eui-form-field [hideMargins]=\"true\">\n        @if (inputModel.touched && !inputModel.disabled && (condition.value === null || condition.value === undefined || condition.value === '')) {\n          <eui-icon matPrefix icon=\"error-circle\"/>\n        }\n        <input\n          [(ngModel)]=\"condition.value\"\n          #inputModel=\"ngModel\"\n          matInput\n          [placeholder]=\"!condition.operator ? labelTranslations.condition.input.value : dataType === 'string' ? labelTranslations.condition.input.string : labelTranslations.condition.input.number\"\n          [attr.aria-label]=\"!condition.operator ? labelTranslations.condition.input.value : dataType === 'string' ? labelTranslations.condition.input.string : labelTranslations.condition.input.number\"\n          [attr.data-testid]=\"'eui-search-custom-filters-condition-' + path + '-value'\"\n          autocomplete=\"off\"\n          [type]=\"dataType === 'string' ? 'text' : 'number'\"\n          [disabled]=\"!condition.operator\"\n          required\n        />\n      </eui-form-field>\n    }\n  } @else {\n    <mat-radio-group\n      [(ngModel)]=\"condition.value\"\n      [attr.aria-label]=\"labelTranslations.condition.input.boolean.ariaLabel\"\n      [attr.data-testid]=\"'eui-search-custom-filters-condition-' + path + '-boolean-radio-group'\"\n    >\n      @for (booleanValue of booleanValues; track booleanValue) {\n        <mat-radio-button\n          [value]=\"booleanValue\"\n          [attr.data-testid]=\"'eui-search-custom-filters-condition-' + path + '-boolean-radio-button-' + booleanValue\"\n        >\n          {{ labelTranslations.condition.input.boolean[booleanValue] }}\n        </mat-radio-button>\n      }\n    </mat-radio-group>\n  }\n</div>\n\n<eui-search-custom-filters-individual-actions\n  [path]=\"path\"\n  [labelTranslations]=\"labelTranslations.individualActions\"\n  [isClearDisabled]=\"isLastObject && (!condition.fieldName && !condition.operator && (condition.value === null || condition.value === undefined || condition.value === ''))\"\n  (byDuplicate)=\"onDuplicate()\"\n  (byClear)=\"onClear()\"\n/>\n", styles: [":host{display:grid;grid-template-columns:1fr auto;column-gap:16px}:host .fields{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}@media screen and (max-width: 768px){:host .fields{grid-template-columns:1fr}}:host .fields eui-icon{color:#db2534}\n"] }]
        }], ctorParameters: () => [{ type: i0.DestroyRef }], propDecorators: { byConditionDuplicated: [{
                type: Output
            }], byConditionCleared: [{
                type: Output
            }], inputModel: [{
                type: ViewChild,
                args: ['inputModel', { read: NgModel }]
            }], condition: [{
                type: Input,
                args: [{ required: true }]
            }], isLastObject: [{
                type: Input,
                args: [{ required: true }]
            }], fields: [{
                type: Input,
                args: [{ required: true }]
            }], labelTranslations: [{
                type: Input,
                args: [{ required: true }]
            }], parent: [{
                type: Input,
                args: [{ required: true }]
            }], outerIdx: [{
                type: Input,
                args: [{ required: true }]
            }], loopIdx: [{
                type: Input,
                args: [{ required: true }]
            }], path: [{
                type: Input,
                args: [{ required: true }]
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiSearchCustomFiltersGroupComponent {
    constructor() {
        this.byConditionAdded = new EventEmitter();
        this.byGroupAdded = new EventEmitter();
        this.byConditionOrGroupDuplicated = new EventEmitter();
        this.byGroupCleared = new EventEmitter();
        this.byConditionClearedInGroup = new EventEmitter();
        this.outerIdx = 0;
        this.loopIdx = 0;
        this.parentCount = 0;
    }
    set parentCounter(parentCount) {
        this.parentCount = parentCount;
    }
    onAddConditionClick(filterGroup) {
        this.byConditionAdded.emit(filterGroup);
    }
    onAddGroupClick(filterGroup) {
        this.byGroupAdded.emit(filterGroup);
    }
    onDuplicate(filterGroupOrConditionDuplicateData) {
        this.byConditionOrGroupDuplicated.emit(filterGroupOrConditionDuplicateData);
    }
    onClear(filterGroupClearData) {
        this.byGroupCleared.emit(filterGroupClearData);
    }
    onConditionCleared(filterConditionClearData) {
        this.byConditionClearedInGroup.emit(filterConditionClearData);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSearchCustomFiltersGroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.2.1", type: EuiSearchCustomFiltersGroupComponent, isStandalone: false, selector: "eui-search-custom-filters-group", inputs: { filterGroup: "filterGroup", hideActions: "hideActions", fields: "fields", labelTranslations: "labelTranslations", parent: "parent", outerIdx: "outerIdx", loopIdx: "loopIdx", path: "path", parentCounter: "parentCounter" }, outputs: { byConditionAdded: "byConditionAdded", byGroupAdded: "byGroupAdded", byConditionOrGroupDuplicated: "byConditionOrGroupDuplicated", byGroupCleared: "byGroupCleared", byConditionClearedInGroup: "byConditionClearedInGroup" }, host: { classAttribute: "eui-search-custom-filters-group" }, ngImport: i0, template: "<header class=\"header\">\n  <div class=\"header__match\">\n    <mat-radio-group\n      [(ngModel)]=\"filterGroup.matchSelection\"\n      [attr.aria-label]=\"labelTranslations.matchSelection.ariaLabel\"\n      [attr.data-testid]=\"path + '-matchSelection-radio-group'\"\n    >\n      <mat-radio-button\n        value=\"and\"\n        [aria-label]=\"labelTranslations.matchSelection.radio.and\"\n        [attr.data-testid]=\"path + '-matchSelection-radio-button-and'\"\n      >\n        {{ labelTranslations.matchSelection.radio.and }}\n      </mat-radio-button>\n      <mat-radio-button\n        value=\"or\"\n        [aria-label]=\"labelTranslations.matchSelection.radio.or\"\n        [attr.data-testid]=\"path + '-matchSelection-radio-button-or'\"\n      >\n        {{ labelTranslations.matchSelection.radio.or }}\n      </mat-radio-button>\n    </mat-radio-group>\n  </div>\n\n  <div class=\"actions\">\n    <div class=\"actions__add-buttons\">\n      <button\n        mat-button\n        color=\"primary\"\n        (click)=\"onAddConditionClick(filterGroup)\"\n        [attr.data-testid]=\"path + '-add-condition-btn'\"\n      >\n        <eui-icon icon=\"add\" size=\"16px\"/>\n        <span>{{ labelTranslations.actions.addConditionBtn }}</span>\n      </button>\n\n      @if (parentCount < 2) {\n        <button\n          mat-button\n          color=\"primary\"\n          (click)=\"onAddGroupClick(filterGroup)\"\n          [attr.data-testid]=\"path + '-add-group-btn'\"\n        >\n          <eui-icon icon=\"add\" size=\"16px\"/>\n          <span>{{ labelTranslations.actions.addGroupBtn }}</span>\n        </button>\n      }\n    </div>\n\n    @if (!hideActions) {\n      <eui-search-custom-filters-individual-actions\n        [path]=\"path\"\n        [labelTranslations]=\"labelTranslations.individualActions\"\n        (byDuplicate)=\"onDuplicate({ parent, conditionOrFilterGroup: filterGroup })\"\n        (byClear)=\"onClear({ parent, filterGroup })\"\n      />\n    }\n  </div>\n</header>\n<mat-divider/>\n\n<div class=\"conditions-and-groups\">\n  @for (conditionOrGroup of filterGroup.conditionsAndGroups; track conditionOrGroup; let i = $index) {\n    @if ($any(conditionOrGroup).matchSelection) {\n      <eui-search-custom-filters-group\n        [parent]=\"filterGroup\"\n        [parentCounter]=\"parentCount + 1\"\n        [outerIdx]=\"loopIdx\"\n        [loopIdx]=\"i\"\n        [labelTranslations]=\"labelTranslations\"\n        [fields]=\"fields\"\n        [filterGroup]=\"conditionOrGroup\"\n        [path]=\"path + '-filterGroup-outerIdx-' + outerIdx + '-index-' + i\"\n        (byConditionAdded)=\"onAddConditionClick($event)\"\n        (byGroupAdded)=\"onAddGroupClick($event)\"\n        (byGroupCleared)=\"onClear($event)\"\n        (byConditionOrGroupDuplicated)=\"onDuplicate($event)\"\n        (byConditionClearedInGroup)=\"onConditionCleared($event)\"\n      />\n    } @else {\n      <eui-search-custom-filters-condition\n        [parent]=\"filterGroup\"\n        [outerIdx]=\"loopIdx\"\n        [loopIdx]=\"i\"\n        [labelTranslations]=\"labelTranslations\"\n        [fields]=\"fields\"\n        [isLastObject]=\"filterGroup.conditionsAndGroups.length === 1\"\n        [condition]=\"conditionOrGroup\"\n        [path]=\"path + '-filterGroup-outerIdx-' + outerIdx + '-index-' + i\"\n        (byConditionDuplicated)=\"onDuplicate($event)\"\n        (byConditionCleared)=\"onConditionCleared($event)\"\n      />\n    }\n  }\n</div>\n", styles: [".eui-search-custom-filters-group .mat-mdc-form-field-infix{width:100%}.eui-search-custom-filters-group .mat-mdc-radio-group{display:flex;gap:8px}.eui-search-custom-filters-group .header{display:flex;justify-content:space-between}.eui-search-custom-filters-group .header__match{display:flex;align-items:center;column-gap:8px}.eui-search-custom-filters-group .header .actions,.eui-search-custom-filters-group .header .actions__add-buttons{display:flex}.eui-search-custom-filters-group .header .actions__add-buttons>button{padding-inline:16px;padding-block:10px}@media screen and (max-width: 768px){.eui-search-custom-filters-group .header{display:grid;grid-template-columns:1fr;grid-template-rows:1fr 1fr}.eui-search-custom-filters-group .header .actions{justify-content:space-between}.eui-search-custom-filters-group .header .actions__add-buttons{display:flex}.eui-search-custom-filters-group .header .actions__add-buttons>button{padding-inline:8px}}.eui-search-custom-filters-group .conditions-and-groups{display:flex;flex-direction:column;gap:24px;padding-block-start:16px;height:calc(100vh - 190px);overflow-y:auto}@media screen and (max-width: 768px){.eui-search-custom-filters-group .conditions-and-groups{height:calc(100vh - 218px)}}.eui-search-custom-filters-group .conditions-and-groups>:last-child{margin-bottom:20px}.eui-search-custom-filters-group .eui-search-custom-filters-group .eui-search-custom-filters-group{background:#f2f6f7;box-shadow:none}.eui-search-custom-filters-group .eui-search-custom-filters-group{background:#fff}.eui-search-custom-filters-group .eui-search-custom-filters-group .header{background-color:#dfe4e6}.eui-search-custom-filters-group .eui-search-custom-filters-group .header__match{padding-inline-start:8px}.eui-search-custom-filters-group .eui-search-custom-filters-group .conditions-and-groups{padding-inline-start:8px;padding-block-end:24px;height:auto;overflow-y:visible}.eui-search-custom-filters-group .eui-search-custom-filters-group .conditions-and-groups>:last-child{margin-bottom:0}.eui-search-custom-filters-group .eui-search-custom-filters-group{border-left:4px solid #c4cacc;border-radius:4px;box-shadow:0 2px 1px -1px #0003,0 1px 1px #00000024,0 1px 3px #0000001f}\n"], dependencies: [{ kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i2$3.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "directive", type: i4$1.MatRadioGroup, selector: "mat-radio-group", inputs: ["color", "name", "labelPosition", "value", "selected", "disabled", "required", "disabledInteractive"], outputs: ["change"], exportAs: ["matRadioGroup"] }, { kind: "component", type: i4$1.MatRadioButton, selector: "mat-radio-button", inputs: ["id", "name", "aria-label", "aria-labelledby", "aria-describedby", "disableRipple", "tabIndex", "checked", "value", "labelPosition", "disabled", "required", "color", "disabledInteractive"], outputs: ["change"], exportAs: ["matRadioButton"] }, { kind: "directive", type: i6.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i6.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: EuiIconComponent, selector: "eui-icon", inputs: ["aria-hidden", "setLineHeight", "icon", "size"] }, { kind: "component", type: EuiSearchCustomFiltersGroupComponent, selector: "eui-search-custom-filters-group", inputs: ["filterGroup", "hideActions", "fields", "labelTranslations", "parent", "outerIdx", "loopIdx", "path", "parentCounter"], outputs: ["byConditionAdded", "byGroupAdded", "byConditionOrGroupDuplicated", "byGroupCleared", "byConditionClearedInGroup"] }, { kind: "component", type: EuiSearchCustomFiltersConditionComponent, selector: "eui-search-custom-filters-condition", inputs: ["condition", "isLastObject", "fields", "labelTranslations", "parent", "outerIdx", "loopIdx", "path"], outputs: ["byConditionDuplicated", "byConditionCleared"] }, { kind: "component", type: EuiSearchCustomFiltersIndividualActionsComponent, selector: "eui-search-custom-filters-individual-actions", inputs: ["isClearDisabled", "labelTranslations", "path"], outputs: ["byDuplicate", "byClear"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSearchCustomFiltersGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-search-custom-filters-group', standalone: false, host: {
                        'class': 'eui-search-custom-filters-group'
                    }, encapsulation: ViewEncapsulation.None, template: "<header class=\"header\">\n  <div class=\"header__match\">\n    <mat-radio-group\n      [(ngModel)]=\"filterGroup.matchSelection\"\n      [attr.aria-label]=\"labelTranslations.matchSelection.ariaLabel\"\n      [attr.data-testid]=\"path + '-matchSelection-radio-group'\"\n    >\n      <mat-radio-button\n        value=\"and\"\n        [aria-label]=\"labelTranslations.matchSelection.radio.and\"\n        [attr.data-testid]=\"path + '-matchSelection-radio-button-and'\"\n      >\n        {{ labelTranslations.matchSelection.radio.and }}\n      </mat-radio-button>\n      <mat-radio-button\n        value=\"or\"\n        [aria-label]=\"labelTranslations.matchSelection.radio.or\"\n        [attr.data-testid]=\"path + '-matchSelection-radio-button-or'\"\n      >\n        {{ labelTranslations.matchSelection.radio.or }}\n      </mat-radio-button>\n    </mat-radio-group>\n  </div>\n\n  <div class=\"actions\">\n    <div class=\"actions__add-buttons\">\n      <button\n        mat-button\n        color=\"primary\"\n        (click)=\"onAddConditionClick(filterGroup)\"\n        [attr.data-testid]=\"path + '-add-condition-btn'\"\n      >\n        <eui-icon icon=\"add\" size=\"16px\"/>\n        <span>{{ labelTranslations.actions.addConditionBtn }}</span>\n      </button>\n\n      @if (parentCount < 2) {\n        <button\n          mat-button\n          color=\"primary\"\n          (click)=\"onAddGroupClick(filterGroup)\"\n          [attr.data-testid]=\"path + '-add-group-btn'\"\n        >\n          <eui-icon icon=\"add\" size=\"16px\"/>\n          <span>{{ labelTranslations.actions.addGroupBtn }}</span>\n        </button>\n      }\n    </div>\n\n    @if (!hideActions) {\n      <eui-search-custom-filters-individual-actions\n        [path]=\"path\"\n        [labelTranslations]=\"labelTranslations.individualActions\"\n        (byDuplicate)=\"onDuplicate({ parent, conditionOrFilterGroup: filterGroup })\"\n        (byClear)=\"onClear({ parent, filterGroup })\"\n      />\n    }\n  </div>\n</header>\n<mat-divider/>\n\n<div class=\"conditions-and-groups\">\n  @for (conditionOrGroup of filterGroup.conditionsAndGroups; track conditionOrGroup; let i = $index) {\n    @if ($any(conditionOrGroup).matchSelection) {\n      <eui-search-custom-filters-group\n        [parent]=\"filterGroup\"\n        [parentCounter]=\"parentCount + 1\"\n        [outerIdx]=\"loopIdx\"\n        [loopIdx]=\"i\"\n        [labelTranslations]=\"labelTranslations\"\n        [fields]=\"fields\"\n        [filterGroup]=\"conditionOrGroup\"\n        [path]=\"path + '-filterGroup-outerIdx-' + outerIdx + '-index-' + i\"\n        (byConditionAdded)=\"onAddConditionClick($event)\"\n        (byGroupAdded)=\"onAddGroupClick($event)\"\n        (byGroupCleared)=\"onClear($event)\"\n        (byConditionOrGroupDuplicated)=\"onDuplicate($event)\"\n        (byConditionClearedInGroup)=\"onConditionCleared($event)\"\n      />\n    } @else {\n      <eui-search-custom-filters-condition\n        [parent]=\"filterGroup\"\n        [outerIdx]=\"loopIdx\"\n        [loopIdx]=\"i\"\n        [labelTranslations]=\"labelTranslations\"\n        [fields]=\"fields\"\n        [isLastObject]=\"filterGroup.conditionsAndGroups.length === 1\"\n        [condition]=\"conditionOrGroup\"\n        [path]=\"path + '-filterGroup-outerIdx-' + outerIdx + '-index-' + i\"\n        (byConditionDuplicated)=\"onDuplicate($event)\"\n        (byConditionCleared)=\"onConditionCleared($event)\"\n      />\n    }\n  }\n</div>\n", styles: [".eui-search-custom-filters-group .mat-mdc-form-field-infix{width:100%}.eui-search-custom-filters-group .mat-mdc-radio-group{display:flex;gap:8px}.eui-search-custom-filters-group .header{display:flex;justify-content:space-between}.eui-search-custom-filters-group .header__match{display:flex;align-items:center;column-gap:8px}.eui-search-custom-filters-group .header .actions,.eui-search-custom-filters-group .header .actions__add-buttons{display:flex}.eui-search-custom-filters-group .header .actions__add-buttons>button{padding-inline:16px;padding-block:10px}@media screen and (max-width: 768px){.eui-search-custom-filters-group .header{display:grid;grid-template-columns:1fr;grid-template-rows:1fr 1fr}.eui-search-custom-filters-group .header .actions{justify-content:space-between}.eui-search-custom-filters-group .header .actions__add-buttons{display:flex}.eui-search-custom-filters-group .header .actions__add-buttons>button{padding-inline:8px}}.eui-search-custom-filters-group .conditions-and-groups{display:flex;flex-direction:column;gap:24px;padding-block-start:16px;height:calc(100vh - 190px);overflow-y:auto}@media screen and (max-width: 768px){.eui-search-custom-filters-group .conditions-and-groups{height:calc(100vh - 218px)}}.eui-search-custom-filters-group .conditions-and-groups>:last-child{margin-bottom:20px}.eui-search-custom-filters-group .eui-search-custom-filters-group .eui-search-custom-filters-group{background:#f2f6f7;box-shadow:none}.eui-search-custom-filters-group .eui-search-custom-filters-group{background:#fff}.eui-search-custom-filters-group .eui-search-custom-filters-group .header{background-color:#dfe4e6}.eui-search-custom-filters-group .eui-search-custom-filters-group .header__match{padding-inline-start:8px}.eui-search-custom-filters-group .eui-search-custom-filters-group .conditions-and-groups{padding-inline-start:8px;padding-block-end:24px;height:auto;overflow-y:visible}.eui-search-custom-filters-group .eui-search-custom-filters-group .conditions-and-groups>:last-child{margin-bottom:0}.eui-search-custom-filters-group .eui-search-custom-filters-group{border-left:4px solid #c4cacc;border-radius:4px;box-shadow:0 2px 1px -1px #0003,0 1px 1px #00000024,0 1px 3px #0000001f}\n"] }]
        }], propDecorators: { byConditionAdded: [{
                type: Output
            }], byGroupAdded: [{
                type: Output
            }], byConditionOrGroupDuplicated: [{
                type: Output
            }], byGroupCleared: [{
                type: Output
            }], byConditionClearedInGroup: [{
                type: Output
            }], filterGroup: [{
                type: Input,
                args: [{ required: true }]
            }], hideActions: [{
                type: Input
            }], fields: [{
                type: Input,
                args: [{ required: true }]
            }], labelTranslations: [{
                type: Input,
                args: [{ required: true }]
            }], parent: [{
                type: Input
            }], outerIdx: [{
                type: Input
            }], loopIdx: [{
                type: Input
            }], path: [{
                type: Input,
                args: [{ required: true }]
            }], parentCounter: [{
                type: Input,
                args: [{ required: true }]
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiSidesheetContentDirective {
    constructor() {
        this.class = 'eui-sidesheet-content';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSidesheetContentDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.2.1", type: EuiSidesheetContentDirective, isStandalone: false, selector: "[eui-sidesheet-content], eui-sidesheet-content, [euiSidesheetContent]", host: { properties: { "class": "this.class" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSidesheetContentDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[eui-sidesheet-content], eui-sidesheet-content, [euiSidesheetContent]',
                    standalone: false
                }]
        }], propDecorators: { class: [{
                type: HostBinding,
                args: ['class']
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiSidesheetActionsDirective {
    constructor() {
        this.class = 'eui-sidesheet-actions';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSidesheetActionsDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.2.1", type: EuiSidesheetActionsDirective, isStandalone: false, selector: "[eui-sidesheet-actions], eui-sidesheet-actions, [euiSidesheetActions]", host: { properties: { "class": "this.class" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSidesheetActionsDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[eui-sidesheet-actions], eui-sidesheet-actions, [euiSidesheetActions]',
                    standalone: false
                }]
        }], propDecorators: { class: [{
                type: HostBinding,
                args: ['class']
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiSearchCustomFiltersComponent {
    constructor(data, _customFilterService) {
        this._customFilterService = _customFilterService;
        this.fields = this._customFilterService.fields;
        this.rootFilterGroup = data.rootFilterGroup;
        this.labelTranslations = data.labelTranslations;
    }
    onResetClick() {
        this._customFilterService.resetFilters(this.rootFilterGroup);
    }
    onCancelClick() {
        this._customFilterService.cancel();
    }
    onApplyClick() {
        this._customFilterService.apply(this.rootFilterGroup);
    }
    onConditionAdded(filterGroup) {
        this._customFilterService.addCondition(filterGroup);
    }
    onGroupAdded(filterGroup) {
        this._customFilterService.addGroup(filterGroup);
    }
    onConditionOrGroupDuplicated({ parent, conditionOrFilterGroup }) {
        this._customFilterService.duplicateConditionOrGroup(parent, conditionOrFilterGroup);
    }
    onGroupCleared({ parent, filterGroup }) {
        this._customFilterService.clearGroup(parent, filterGroup);
    }
    onConditionCleared({ parent, condition }) {
        this._customFilterService.clearCondition(parent, condition);
    }
    hasInvalidCondition() {
        return this._customFilterService.hasInvalidCondition(this.rootFilterGroup);
    }
    haveActiveFiltersNotChanged() {
        return this._customFilterService.haveActiveFiltersNotChanged(this.rootFilterGroup);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSearchCustomFiltersComponent, deps: [{ token: EUI_SIDESHEET_DATA }, { token: EuiCustomFilterService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.2.1", type: EuiSearchCustomFiltersComponent, isStandalone: false, selector: "eui-search-custom-filters", ngImport: i0, template: "<div eui-sidesheet-content>\n  <eui-search-custom-filters-group\n    path=\"eui-search-rootFilterGroup\"\n    [parentCounter]=\"0\"\n    [labelTranslations]=\"labelTranslations.filterGroup\"\n    [fields]=\"fields\"\n    [hideActions]=\"true\"\n    [filterGroup]=\"rootFilterGroup\"\n    (byConditionAdded)=\"onConditionAdded($event)\"\n    (byGroupAdded)=\"onGroupAdded($event)\"\n    (byGroupCleared)=\"onGroupCleared($event)\"\n    (byConditionOrGroupDuplicated)=\"onConditionOrGroupDuplicated($event)\"\n    (byConditionClearedInGroup)=\"onConditionCleared($event)\"\n  />\n</div>\n<div eui-sidesheet-actions>\n  <div class=\"actions\">\n    <button\n      mat-stroked-button\n      color=\"primary\"\n      (click)=\"onResetClick()\"\n      [attr.aria-label]=\"labelTranslations.actions.resetBtn\"\n      data-testid=\"eui-search-custom-filters-reset-filters-btn\"\n    >\n      <eui-icon icon=\"refresh\" size=\"16px\"/>\n      <span>{{ labelTranslations.actions.resetBtn }}</span>\n    </button>\n\n    <div>\n      <button\n        mat-stroked-button\n        (click)=\"onCancelClick()\"\n        data-testid=\"eui-search-custom-filters-cancel-btn\"\n      >\n        {{ labelTranslations.actions.cancelBtn }}\n      </button>\n\n      <button\n        mat-flat-button\n        color=\"primary\"\n        (click)=\"onApplyClick()\"\n        data-testid=\"eui-search-custom-filters-apply-btn\"\n        [disabled]=\"haveActiveFiltersNotChanged() || hasInvalidCondition()\"\n      >\n        {{ labelTranslations.actions.applyBtn }}\n      </button>\n    </div>\n  </div>\n</div>\n", styles: [".eui-sidesheet-content{padding-bottom:0}.actions{display:flex;justify-content:space-between;flex-grow:1}\n"], dependencies: [{ kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: EuiIconComponent, selector: "eui-icon", inputs: ["aria-hidden", "setLineHeight", "icon", "size"] }, { kind: "component", type: EuiSearchCustomFiltersGroupComponent, selector: "eui-search-custom-filters-group", inputs: ["filterGroup", "hideActions", "fields", "labelTranslations", "parent", "outerIdx", "loopIdx", "path", "parentCounter"], outputs: ["byConditionAdded", "byGroupAdded", "byConditionOrGroupDuplicated", "byGroupCleared", "byConditionClearedInGroup"] }, { kind: "directive", type: EuiSidesheetContentDirective, selector: "[eui-sidesheet-content], eui-sidesheet-content, [euiSidesheetContent]" }, { kind: "directive", type: EuiSidesheetActionsDirective, selector: "[eui-sidesheet-actions], eui-sidesheet-actions, [euiSidesheetActions]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSearchCustomFiltersComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-search-custom-filters', standalone: false, template: "<div eui-sidesheet-content>\n  <eui-search-custom-filters-group\n    path=\"eui-search-rootFilterGroup\"\n    [parentCounter]=\"0\"\n    [labelTranslations]=\"labelTranslations.filterGroup\"\n    [fields]=\"fields\"\n    [hideActions]=\"true\"\n    [filterGroup]=\"rootFilterGroup\"\n    (byConditionAdded)=\"onConditionAdded($event)\"\n    (byGroupAdded)=\"onGroupAdded($event)\"\n    (byGroupCleared)=\"onGroupCleared($event)\"\n    (byConditionOrGroupDuplicated)=\"onConditionOrGroupDuplicated($event)\"\n    (byConditionClearedInGroup)=\"onConditionCleared($event)\"\n  />\n</div>\n<div eui-sidesheet-actions>\n  <div class=\"actions\">\n    <button\n      mat-stroked-button\n      color=\"primary\"\n      (click)=\"onResetClick()\"\n      [attr.aria-label]=\"labelTranslations.actions.resetBtn\"\n      data-testid=\"eui-search-custom-filters-reset-filters-btn\"\n    >\n      <eui-icon icon=\"refresh\" size=\"16px\"/>\n      <span>{{ labelTranslations.actions.resetBtn }}</span>\n    </button>\n\n    <div>\n      <button\n        mat-stroked-button\n        (click)=\"onCancelClick()\"\n        data-testid=\"eui-search-custom-filters-cancel-btn\"\n      >\n        {{ labelTranslations.actions.cancelBtn }}\n      </button>\n\n      <button\n        mat-flat-button\n        color=\"primary\"\n        (click)=\"onApplyClick()\"\n        data-testid=\"eui-search-custom-filters-apply-btn\"\n        [disabled]=\"haveActiveFiltersNotChanged() || hasInvalidCondition()\"\n      >\n        {{ labelTranslations.actions.applyBtn }}\n      </button>\n    </div>\n  </div>\n</div>\n", styles: [".eui-sidesheet-content{padding-bottom:0}.actions{display:flex;justify-content:space-between;flex-grow:1}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [EUI_SIDESHEET_DATA]
                }] }, { type: EuiCustomFilterService }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiSearchComponent {
    /**
     * Sets the disabled state of the component
     *
     * @category Input
     */
    set disabled(value) {
        this._disabled = value;
        this.setDisabled();
    }
    /**
     * Gets the disabled state of the component
     */
    /** @internal */
    get disabled() {
        return this._disabled;
    }
    constructor(_customFilterService, _destroyRef) {
        this._customFilterService = _customFilterService;
        this._destroyRef = _destroyRef;
        /**
         * Emits an event when the search icon is clicked
         *
         * @category Output
         * @event
         */
        this.searchIconClick = new EventEmitter();
        /**
         * Emits an event when the custom filters changed.
         *
         * This event provides the newly parsed filter expression as a string.
         * The filter expression adheres to a specific syntax (e.g., `((not (user_name co 'a')))`).
         *
         * @category Output
         * @type {string}
         * @description The emitted string represents the parsed filter expression.
         * @example
         * ```html
         *  <eui-search (customFiltersChanged)="onCustomFiltersChanged($event)" />
         * ```
         * ```typescript
         * // Example callback to the event:
         * onCustomFiltersChanged(filterExpression: string): void {
         *  console.log(filterExpression);
         * }
         * ```
         */
        this.customFiltersChanged = new EventEmitter();
        /** @internal */
        this.hasSearchIconClickHandler = false;
        this.activeFiltersCount$ = this._customFilterService.activeFiltersCount$;
    }
    /** @internal */
    ngOnInit() {
        this.hasSearchIconClickHandler = this.searchIconClick.observed;
        this.setDisabled();
    }
    /**
     * Clears the input field when the close icon is clicked
     *
     * @internal */
    clearSearch() {
        this.searchControl.setValue('');
    }
    /**
     * Emits an event when the search icon is clicked
     *
     * @internal */
    searchIconClicked($event) {
        this.searchIconClick.emit($event);
    }
    openCustomFiltersSidesheet() {
        this._customFilterService.openSideSheet$(this.customFiltersConfig, EuiSearchCustomFiltersComponent)
            .pipe(takeUntilDestroyed(this._destroyRef))
            .subscribe((filterExpression) => this.customFiltersChanged.emit(filterExpression));
    }
    onClearFiltersClick() {
        this._customFilterService.clearFilters();
        this.customFiltersChanged.emit('');
    }
    setDisabled() {
        if (this.disabled === undefined)
            return;
        if (this.disabled) {
            this.searchControl.disable();
        }
        else {
            this.searchControl.enable();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSearchComponent, deps: [{ token: EuiCustomFilterService, self: true }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.2.1", type: EuiSearchComponent, isStandalone: false, selector: "eui-search", inputs: { customFiltersConfig: "customFiltersConfig", placeholder: "placeholder", searchControl: "searchControl", width: "width", disabled: "disabled" }, outputs: { searchIconClick: "searchIconClick", customFiltersChanged: "customFiltersChanged" }, providers: [EuiCustomFilterService], viewQueries: [{ propertyName: "inputElementRef", first: true, predicate: ["inputElement"], descendants: true }], ngImport: i0, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n@if ({activeFiltersCount: activeFiltersCount$ | async}; as vm) {\n  <div class=\"search\" [ngClass]=\"{'search__gap': customFiltersConfig && vm.activeFiltersCount}\">\n    <mat-form-field\n      appearance=\"outline\"\n      class=\"eui-search eui-input--no-margin\"\n      [ngClass]=\"{ 'has-custom-filters': customFiltersConfig }\"\n      [style.width]=\"width\"\n      >\n      @if (!hasSearchIconClickHandler) {\n        <eui-icon\n          class=\"eui-search-icon\"\n          [ngClass]=\"{ 'eui-search-icon-disabled': disabled || searchControl?.disabled }\"\n          matPrefix\n          icon=\"search\"\n          (click)=\"searchIconClicked($event)\"\n          data-testid=\"eui-search-icon\"\n        ></eui-icon>\n      }\n\n      @if (hasSearchIconClickHandler) {\n        <button\n          matIconButton\n          [disabled]=\"disabled || searchControl?.disabled\"\n          (click)=\"searchIconClicked($event)\"\n          data-testid=\"eui-search-icon\"\n          matPrefix\n          class=\"eui-search-icon\"\n          >\n          <eui-icon icon=\"search\"></eui-icon>\n        </button>\n      }\n      <input\n        class=\"eui-search-input\"\n        matInput\n        [formControl]=\"searchControl\"\n        [placeholder]=\"placeholder\"\n        type=\"text\"\n        #inputElement\n        [attr.aria-label]=\"placeholder\"\n        data-testid=\"eui-search-input\"\n        autocomplete=\"off\"\n        />\n        @if (searchControl.value || customFiltersConfig) {\n          <div class=\"icons\" matSuffix>\n            <button\n              matIconButton\n              class=\"eui-search-close\"\n              (click)=\"clearSearch()\"\n              data-testid=\"eui-search-close\"\n              [ngClass]=\"{ 'visibility-hidden': !searchControl.value }\"\n              >\n              <eui-icon icon=\"close\"></eui-icon>\n            </button>\n            @if (customFiltersConfig) {\n              <button\n                matIconButton\n                (click)=\"openCustomFiltersSidesheet()\"\n                data-testid=\"eui-search-custom-filters-opener-btn\"\n                [matTooltip]=\"customFiltersConfig.labelTranslations.customFilterIcon.tooltip\"\n                [matTooltipShowDelay]=\"500\"\n                [matBadge]=\"vm.activeFiltersCount\"\n                [matBadgeHidden]=\"vm.activeFiltersCount === 0\"\n                matBadgeSize=\"medium\"\n                matBadgeColor=\"accent\"\n                [matBadgeDescription]=\"customFiltersConfig.labelTranslations.customFilterIcon.badgeDescription.replace('{numberOfActiveFilters}', vm.activeFiltersCount?.toString())\"\n                [attr.aria-label]=\"customFiltersConfig.labelTranslations.customFilterIcon.tooltip\"\n                >\n                <eui-icon icon=\"filter\"/>\n              </button>\n            }\n          </div>\n        }\n      </mat-form-field>\n\n      @if (customFiltersConfig && vm.activeFiltersCount) {\n        <button class=\"clear-filters\" mat-button color=\"accent\" (click)=\"onClearFiltersClick()\">\n          <eui-icon icon=\"close\" size=\"16px\"/>\n          <span class=\"clear-filters__label\">{{ customFiltersConfig.labelTranslations.clearFiltersBtn }}</span>\n        </button>\n      }\n    </div>\n  }\n", styles: [".eui-dark-theme .eui-search.mat-mdc-form-field.mat-form-field-appearance-outline .mat-mdc-form-field-icon-prefix,.eui-contrast-theme .eui-search.mat-mdc-form-field.mat-form-field-appearance-outline .mat-mdc-form-field-icon-prefix{color:#919799}.eui-dark-theme .eui-search.mat-mdc-form-field.mat-form-field-appearance-outline .mat-mdc-form-field-icon-prefix .eui-search-icon-disabled,.eui-contrast-theme .eui-search.mat-mdc-form-field.mat-form-field-appearance-outline .mat-mdc-form-field-icon-prefix .eui-search-icon-disabled{color:#f2f6f780}.eui-search.mat-mdc-form-field.mat-form-field-appearance-outline .mat-mdc-form-field-icon-prefix{color:#919799}.eui-search.mat-mdc-form-field.mat-form-field-appearance-outline .mat-mdc-form-field-icon-prefix .eui-search-icon-disabled{color:#00000061}.eui-search.mat-mdc-form-field.mat-form-field-appearance-outline:not(.has-custom-filters){min-width:280px}.icons{display:flex}.icons .visibility-hidden{visibility:hidden}.search{display:grid;grid-template-columns:1fr auto}.search .clear-filters__label{white-space:nowrap}.search__gap{grid-column-gap:8px}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3$3.MatBadge, selector: "[matBadge]", inputs: ["matBadgeColor", "matBadgeOverlap", "matBadgeDisabled", "matBadgePosition", "matBadge", "matBadgeDescription", "matBadgeSize", "matBadgeHidden"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i2$1.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i2$1.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i2$1.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "directive", type: i1$6.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "directive", type: i6.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i6.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i6.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "component", type: EuiIconComponent, selector: "eui-icon", inputs: ["aria-hidden", "setLineHeight", "icon", "size"] }, { kind: "pipe", type: i2.AsyncPipe, name: "async" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSearchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-search', encapsulation: ViewEncapsulation.None, providers: [EuiCustomFilterService], standalone: false, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n@if ({activeFiltersCount: activeFiltersCount$ | async}; as vm) {\n  <div class=\"search\" [ngClass]=\"{'search__gap': customFiltersConfig && vm.activeFiltersCount}\">\n    <mat-form-field\n      appearance=\"outline\"\n      class=\"eui-search eui-input--no-margin\"\n      [ngClass]=\"{ 'has-custom-filters': customFiltersConfig }\"\n      [style.width]=\"width\"\n      >\n      @if (!hasSearchIconClickHandler) {\n        <eui-icon\n          class=\"eui-search-icon\"\n          [ngClass]=\"{ 'eui-search-icon-disabled': disabled || searchControl?.disabled }\"\n          matPrefix\n          icon=\"search\"\n          (click)=\"searchIconClicked($event)\"\n          data-testid=\"eui-search-icon\"\n        ></eui-icon>\n      }\n\n      @if (hasSearchIconClickHandler) {\n        <button\n          matIconButton\n          [disabled]=\"disabled || searchControl?.disabled\"\n          (click)=\"searchIconClicked($event)\"\n          data-testid=\"eui-search-icon\"\n          matPrefix\n          class=\"eui-search-icon\"\n          >\n          <eui-icon icon=\"search\"></eui-icon>\n        </button>\n      }\n      <input\n        class=\"eui-search-input\"\n        matInput\n        [formControl]=\"searchControl\"\n        [placeholder]=\"placeholder\"\n        type=\"text\"\n        #inputElement\n        [attr.aria-label]=\"placeholder\"\n        data-testid=\"eui-search-input\"\n        autocomplete=\"off\"\n        />\n        @if (searchControl.value || customFiltersConfig) {\n          <div class=\"icons\" matSuffix>\n            <button\n              matIconButton\n              class=\"eui-search-close\"\n              (click)=\"clearSearch()\"\n              data-testid=\"eui-search-close\"\n              [ngClass]=\"{ 'visibility-hidden': !searchControl.value }\"\n              >\n              <eui-icon icon=\"close\"></eui-icon>\n            </button>\n            @if (customFiltersConfig) {\n              <button\n                matIconButton\n                (click)=\"openCustomFiltersSidesheet()\"\n                data-testid=\"eui-search-custom-filters-opener-btn\"\n                [matTooltip]=\"customFiltersConfig.labelTranslations.customFilterIcon.tooltip\"\n                [matTooltipShowDelay]=\"500\"\n                [matBadge]=\"vm.activeFiltersCount\"\n                [matBadgeHidden]=\"vm.activeFiltersCount === 0\"\n                matBadgeSize=\"medium\"\n                matBadgeColor=\"accent\"\n                [matBadgeDescription]=\"customFiltersConfig.labelTranslations.customFilterIcon.badgeDescription.replace('{numberOfActiveFilters}', vm.activeFiltersCount?.toString())\"\n                [attr.aria-label]=\"customFiltersConfig.labelTranslations.customFilterIcon.tooltip\"\n                >\n                <eui-icon icon=\"filter\"/>\n              </button>\n            }\n          </div>\n        }\n      </mat-form-field>\n\n      @if (customFiltersConfig && vm.activeFiltersCount) {\n        <button class=\"clear-filters\" mat-button color=\"accent\" (click)=\"onClearFiltersClick()\">\n          <eui-icon icon=\"close\" size=\"16px\"/>\n          <span class=\"clear-filters__label\">{{ customFiltersConfig.labelTranslations.clearFiltersBtn }}</span>\n        </button>\n      }\n    </div>\n  }\n", styles: [".eui-dark-theme .eui-search.mat-mdc-form-field.mat-form-field-appearance-outline .mat-mdc-form-field-icon-prefix,.eui-contrast-theme .eui-search.mat-mdc-form-field.mat-form-field-appearance-outline .mat-mdc-form-field-icon-prefix{color:#919799}.eui-dark-theme .eui-search.mat-mdc-form-field.mat-form-field-appearance-outline .mat-mdc-form-field-icon-prefix .eui-search-icon-disabled,.eui-contrast-theme .eui-search.mat-mdc-form-field.mat-form-field-appearance-outline .mat-mdc-form-field-icon-prefix .eui-search-icon-disabled{color:#f2f6f780}.eui-search.mat-mdc-form-field.mat-form-field-appearance-outline .mat-mdc-form-field-icon-prefix{color:#919799}.eui-search.mat-mdc-form-field.mat-form-field-appearance-outline .mat-mdc-form-field-icon-prefix .eui-search-icon-disabled{color:#00000061}.eui-search.mat-mdc-form-field.mat-form-field-appearance-outline:not(.has-custom-filters){min-width:280px}.icons{display:flex}.icons .visibility-hidden{visibility:hidden}.search{display:grid;grid-template-columns:1fr auto}.search .clear-filters__label{white-space:nowrap}.search__gap{grid-column-gap:8px}\n"] }]
        }], ctorParameters: () => [{ type: EuiCustomFilterService, decorators: [{
                    type: Self
                }] }, { type: i0.DestroyRef }], propDecorators: { inputElementRef: [{
                type: ViewChild,
                args: ['inputElement']
            }], customFiltersConfig: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], searchControl: [{
                type: Input
            }], searchIconClick: [{
                type: Output
            }], customFiltersChanged: [{
                type: Output
            }], width: [{
                type: Input
            }], disabled: [{
                type: Input
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
const EUI_TOOLTIP_DEFAULTS = new InjectionToken('EUI_TOOLTIP_DEFAULTS');

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
/**
 * Tooltip directive that wraps Angular Material's MatTooltip with simplified input and optional configuration.
 *
 * This directive allows developers to display tooltips with default show delay,
 * while inheriting all behavior from MatTooltip via hostDirectives.
 *
 * Configuration:
 * - Accepts optional injection of EUI_TOOLTIP_DEFAULTS to override default value for mat tooltip show delay.
 *
 * Host Directives:
 * - MatTooltip: Inherits tooltip behavior and inputs from Angular Material.
 */
class EuiTooltipDirective {
    /**
     * Tooltip message to display. If not provided, the element's text content is used.
     *
     * @category Input
     */
    set euiTooltip(value) {
        this._euiTooltip = value;
        this.updateTooltip();
    }
    get euiTooltip() {
        return this._euiTooltip;
    }
    /** @internal */
    constructor(config) {
        /**
         * Delay in milliseconds before showing the tooltip (default is 500ms).
         *
         * @category Input
         */
        this.matTooltipShowDelay = 500;
        /** @internal */
        this.matTooltip = inject(MatTooltip);
        /** @internal */
        this.elementRef = inject(ElementRef);
        /** @internal */
        this.cdr = inject(ChangeDetectorRef);
        this._euiTooltip = '';
        this.matTooltipShowDelay = config?.matTooltipShowDelay ?? 500;
    }
    /** @internal */
    ngAfterViewInit() {
        this.updateTooltip();
        this.cdr.detectChanges();
    }
    /** @internal */
    updateTooltip() {
        this.matTooltip.showDelay = this.matTooltipShowDelay;
        // If explicitly set to null, empty tooltip
        if (this._euiTooltip === null) {
            this.matTooltip.message = '';
        }
        else {
            const element = this.elementRef.nativeElement;
            const message = this._euiTooltip || element.textContent || '';
            this.matTooltip.message = message.trim();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTooltipDirective, deps: [{ token: EUI_TOOLTIP_DEFAULTS, optional: true }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.2.1", type: EuiTooltipDirective, isStandalone: false, selector: "[euiTooltip]", inputs: { euiTooltip: "euiTooltip", matTooltipShowDelay: "matTooltipShowDelay" }, hostDirectives: [{ directive: i1$6.MatTooltip, inputs: ["matTooltipPosition", "matTooltipPosition", "matTooltipDisabled", "matTooltipDisabled", "matTooltipHideDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltipTouchGestures", "matTooltipClass", "matTooltipClass"] }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTooltipDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[euiTooltip]',
                    standalone: false,
                    hostDirectives: [
                        {
                            directive: MatTooltip,
                            inputs: [
                                'matTooltipPosition: matTooltipPosition',
                                'matTooltipDisabled: matTooltipDisabled',
                                'matTooltipHideDelay: matTooltipHideDelay',
                                'matTooltipTouchGestures: matTooltipTouchGestures',
                                'matTooltipClass: matTooltipClass',
                            ]
                        }
                    ],
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [EUI_TOOLTIP_DEFAULTS]
                }] }], propDecorators: { euiTooltip: [{
                type: Input
            }], matTooltipShowDelay: [{
                type: Input
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiSelectComponent {
    /**
     * Disable select input
     *
     * @category Input
     */
    set disabled(value) {
        this._disabled = value;
        if (value) {
            this.inputControl.disable();
        }
        else {
            this.inputControl.enable();
        }
    }
    /** @internal */
    get showAllSelectedText() {
        return this.multiple && this.allOptionsSelected && this.allSelectedText !== '';
    }
    /** @internal
     * Default feedback messages in English.
     * If new properties are added to EuiSelectFeedbackMessages they should be
     * marked as nullable and default values added here.
    */
    get defaultFeedbackMessages() {
        return {
            selected: '{{value}} selected',
            clear: 'Clear',
            search: 'Search',
            plusOther: '+1 other',
            plusOtherPlural: '+{{value}} others',
            unsupportedCharacter: 'Unsupported character',
            noResults: 'No results',
            clearAll: 'Clear all',
            selectAll: 'Select all',
            ok: 'OK',
            keyboardOptionsListAria: 'Use the arrow keys to navigate the options',
        };
    }
    /**
     * Set options
     *
     * @category Input
     */
    set options(options) {
        this._options = options || [];
        this.filterOptions();
    }
    /** @internal */
    get showPrefixIcon() {
        return !!this.findOptionByValue(this.inputControl.value)?.icon && !this.showAllSelectedText;
    }
    /**
     * Set sort function to specify search input filter operation
     *
     * @category Input
     * @default not sorting
     */
    set sortFunction(value) {
        this._sortFunction = value;
        this.filterOptions();
    }
    /** @internal */
    get plusOthersText() {
        const value = this.inputControl.value ? this.inputControl.value.length : 0;
        let textToShow = this.feedbackMessages.plusOther;
        if (value > 1) {
            textToShow = this.feedbackMessages.plusOtherPlural.replace('{{value}}', (value - 1).toString());
        }
        return `(${textToShow})`;
    }
    /** @internal */
    get selectedText() {
        const value = this.inputControl.value ? this.inputControl.value.length : 0;
        const text = this.feedbackMessages.selected.replace('{{value}}', value.toString());
        return `(${text})`;
    }
    /** @internal */
    get showLabel() {
        return !!(this.label !== null && (this.label || (this.inputControl.value?.length && this.multiple)));
    }
    /** @internal */
    get isRequired() {
        if (this.required) {
            return true;
        }
        return this.inputControl?.hasValidator(Validators.required) ?? false;
    }
    /** @internal */
    get enabledOptions() {
        return this._options.filter((v) => !v.disabled);
    }
    /** @internal */
    get allOptionsSelected() {
        return this.multiple && this._options.length === this.inputControl.value?.length;
    }
    constructor(cdRef, directionality, sidesheetDirection) {
        this.cdRef = cdRef;
        this.directionality = directionality;
        this.sidesheetDirection = sidesheetDirection;
        /** @internal */
        this.class = 'eui-select';
        /**
         * Sets whether the component is required or not
         *
         * @category Input
         */
        this.required = false;
        /**
         * Sets whether the component is read-only or not
         *
         * @category Input
         */
        this.readonly = false;
        /**
         * Sets whether the component's read-only label is abbreviated or not
         *
         * @category Input
         */
        this.readonlyAbbr = false;
        /**
         * Toggle pending state
         *
         * @category Input
         */
        this.isPending = false;
        /**
         * Set select Form Control.
         *
         * Possible application areas: Set default selected values
         *
         * @category Input
         */
        this.inputControl = new FormControl(null);
        /**
         * Specify Form Control to filter input, that allows to add validators.
         *
         * @category Input
         */
        this.searchFormControl = new FormControl('');
        /**
         * Input placeholder
         *
         * @category Input
         */
        this.placeholder = '';
        /**
         * Title of the select. Set to null to omit label (this will also override the multi-select "(X selected)" addition to a blank label).
         *
         * @category Input
         */
        this.label = '';
        /**
         * Controls whether the legacy floating label is displayed or a label above the form field. Overridden by setting label = null.
         *
         * @category Input
         */
        this.useLegacyFloatingLabel = false;
        /**
         * Toggle multiple chooser<br/>
         * <br/>
         * <strong>Note:</strong> When using a multi-select and setting width it is up to the developer to keep the control from
         * getting too narrow to display the options footer buttons.
         *
         * @category Input
         */
        this.multiple = false;
        /**
         * When true the 'eui-input--no-margin' class won't be applied to the mat-form-field<br/>
         * <br/>
         * <strong>Note:</strong> this needs to be set to 'true' when showing validation errors in the <mat-error> section, so that they display correctly
         *
         * @category Input
         */
        this.enableFormFieldMargin = false;
        /**
         * When true the clear selection button in the title container will not be shown
         *
         * @category Input
         */
        this.hideClearButton = false;
        /**
         * When true the footer at the bottom of the options panel will not be shown
         *
         * @category Input
         */
        this.hidePanelFooter = false;
        /**
         * When true, the search bar at the top of the options panel will not be shown
         *
         * @category Input
         */
        this.hideSearch = false;
        /**
         * Optional text to display when all options are selected instead of "X (+5 others)"
         *
         * @category Input
         */
        this.allSelectedText = '';
        /**
         * Provide text to override the default text used within the component
         *
         * @category Input
         */
        this.feedbackMessages = { ...this.defaultFeedbackMessages };
        /**
         * Triggered when search input changed
         *
         * @category Output
         * @event
         */
        this.searchFieldChange = new EventEmitter();
        /**
         * Triggered when selected options changed
         *
         * @category Output
         * @event
         */
        this.selectionChange = new EventEmitter();
        /**
         * Trigger when open state changed
         *
         * @category Output
         * @event
         */
        this.openChange = new EventEmitter();
        /**
         * Trigger when select clicked
         *
         * @category Output
         * @event
         */
        this.triggerClick = new EventEmitter();
        /**
         * Trigger when options cleared
         *
         * @category Output
         * @event
         */
        this.optionsClear = new EventEmitter();
        /** @internal */
        this._disabled = false;
        /** @internal */
        this._options = [];
        /** @internal */
        this._sortFunction = null;
        /** @internal */
        this.error = new BehaviorSubject(null);
        /** @internal */
        this.filteredOptions = new BehaviorSubject([]);
        /** @internal */
        this.hasResults = false;
        /** @internal */
        this.showFormElements = {
            matPrefix: true,
            matTextPrefix: true,
            matSuffix: true,
            matTextSuffix: true,
        };
        /**
         * When greater than 0, if the number of options is less than or equal to the value, the search bar will be hidden.
         * If the 'hideSearch' input is set to true, the search bar will be hidden regardless of this value.
         */
        /** @internal */
        this.autoHideSearchLimit = 5;
        this.destroy = new Subject();
        /** @internal */
        this.defaultFilter = (option, searchInputValue) => option.display.toString().toUpperCase().trim().includes(searchInputValue.toUpperCase().trim());
        /** @internal */
        this.filterValueChange = () => {
            if (this.searchFormControl.valid) {
                this.searchFieldChange.emit(this.searchFormControl.value);
                this.filterOptions();
            }
        };
        /** @internal */
        this.validate = () => {
            if (this.searchFormControl.valid) {
                this.error.next(null);
                return true;
            }
            else {
                this.error.next(this.searchFormControl.errors);
                return false;
            }
        };
        this.filterFunction = this.defaultFilter;
        this.direction = sidesheetDirection ?? directionality.value;
    }
    /** @internal */
    ngAfterViewInit() {
        const el = this.formField.elementRef.nativeElement;
        const textFieldWrapper = el.querySelector('.mat-mdc-text-field-wrapper');
        this.select._preferredOverlayOrigin = new ElementRef(textFieldWrapper);
        this._prefixChildren.changes.pipe(takeUntil(this.destroy)).subscribe(() => this.checkFormElements());
        this._suffixChildren.changes.pipe(takeUntil(this.destroy)).subscribe(() => this.checkFormElements());
        this.checkFormElements();
    }
    /** @internal */
    ngOnInit() {
        this.searchFormControl.valueChanges
            .pipe(takeUntil(this.destroy), filter(this.validate), debounceTime(500))
            .subscribe(this.filterValueChange);
        this.directionality.change
            .pipe(takeUntil(this.destroy))
            .subscribe(dir => this.direction = dir);
    }
    /** @internal */
    ngOnDestroy() {
        this.destroy.next(true);
    }
    /** @internal */
    checkFormElements() {
        this.showFormElements.matPrefix = !!this._prefixChildren.find((s) => !s._isText);
        this.showFormElements.matTextPrefix = !!this._prefixChildren.find((s) => s._isText);
        this.showFormElements.matSuffix = !!this._suffixChildren.find((s) => !s._isText);
        this.showFormElements.matTextSuffix = !!this._suffixChildren.find((s) => s._isText);
        this.cdRef.detectChanges();
    }
    /** @internal */
    filterOptions() {
        this.hasResults = false;
        const searchText = this.searchFormControl.value ? this.searchFormControl.value : '';
        const options = this._options.map((option) => {
            const visible = searchText ? this.filterFunction(option, searchText) : true;
            this.hasResults = this.hasResults || visible;
            return { ...option, visible };
        });
        if (this._sortFunction)
            options.sort(this._sortFunction);
        this.filteredOptions.next(options);
    }
    /** @internal */
    scrollActiveOptionIntoView() {
        const elems = document.querySelectorAll('.eui-select-options .eui-option-active');
        setTimeout(() => elems.forEach((e) => e.classList.remove('eui-option-active')));
        let elem = document.querySelector('.eui-select-options .mat-mdc-option-active:not(.hidden-option)');
        if (!elem) {
            elem = document.querySelector('.eui-select-options .mat-mdc-option:not(.hidden-option)');
            elem.classList.add('eui-option-active');
        }
        if (elem) {
            this.optionsScroll.scrollIntoView(elem, { alignToTop: true, offsetTop: 50 });
        }
    }
    /** @internal */
    onOptionFocus(event) {
        event.preventDefault();
        const previousFocus = event.relatedTarget;
        const keyboardHelperNext = previousFocus.classList && previousFocus.nodeName
            ? previousFocus.classList.contains('cdk-focus-trap-anchor') || previousFocus.nodeName.toLowerCase() === 'button'
            : false;
        if ((!this.multiple || this.hidePanelFooter) && !keyboardHelperNext) {
            this.searchInput?.inputElementRef.nativeElement.focus();
            return;
        }
        if (keyboardHelperNext) {
            this.keyboardHelper?.nativeElement.focus();
            return;
        }
        if (this.inputControl.value?.length > 0) {
            this.multiSubmitClear._elementRef.nativeElement.focus();
        }
        else {
            this.multiSubmitOk._elementRef.nativeElement.focus();
        }
    }
    /** @internal */
    keyboardHelperKeyDown(event) {
        if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
            this.scrollActiveOptionIntoView();
        }
        if (event.key === 'Tab') {
            event.stopPropagation();
        }
        if (this.multiple && (event.key === 'Enter' || event.key === ' ')) {
            setTimeout(() => this.keyboardHelper?.nativeElement.focus());
        }
    }
    /** @internal */
    submitButtonsKeyDown(event) {
        if (event.key === 'Tab') {
            event.stopPropagation();
        }
        if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
            event.preventDefault();
        }
        if (event.key === 'Enter' || event.key === ' ') {
            event.stopPropagation();
        }
    }
    /** @internal */
    onOptionChange(event) {
        const selectedItems = this.multiple
            ? this._options.filter((v) => event.value.includes(v.value))
            : this._options.find((v) => event.value === v.value);
        this.selectionChange.emit(selectedItems);
        this.searchInput?.inputElementRef.nativeElement.focus();
    }
    /** @internal */
    findOptionByValue(value) {
        if (value === null || value === undefined) {
            return null;
        }
        // When a formControlName is supplied and multiple==true, one of the
        // passes through here hands in that control rather than the value,
        // so we need to dig the value out of there instead. This does *not*
        // seem to happen when inputControl is supplied. Go figure.
        if (value instanceof FormControl) {
            value = value.value;
        }
        const findval = Array.isArray(value) ? value[0] : value;
        const opt = this._options.find((option) => option.value === findval);
        return opt ? opt : null;
    }
    /** @internal */
    onDropdownOpen() {
        setTimeout(() => this.searchInput?.inputElementRef.nativeElement.focus(), 0);
    }
    /** @internal */
    clearSelectionsOutside() {
        this.clearSelectionsInside(true);
        this.optionsClear.emit([]);
        this.select?.focus();
    }
    /** @internal */
    clearSelectionsInside(isFromOutside = false) {
        this.inputControl.setValue(this.multiple ? [] : '');
        this.selectionChange.emit([]);
        if (!isFromOutside) {
            this.searchInput?.inputElementRef.nativeElement.focus();
        }
    }
    /** @internal */
    selectAllInside(isFromOutside = false) {
        if (this.multiple) {
            const selectedItems = this.enabledOptions;
            this.select.value = selectedItems.map((v) => v.value);
            this.selectionChange.emit(selectedItems);
            if (!isFromOutside) {
                this.searchInput?.inputElementRef.nativeElement.focus();
            }
        }
    }
    /** @internal */
    close() {
        this.select.close();
        this.select.focus();
    }
    /** @internal */
    onTouched() { }
    /** @internal */
    registerOnChange(onChange) {
        this.inputControl.valueChanges.subscribe(onChange);
    }
    /** @internal */
    registerOnTouched(onTouched) {
        this.onTouched = onTouched;
    }
    /** @internal */
    setDisabledState(isDisabled) {
        if (isDisabled) {
            this.inputControl.disable();
        }
        else {
            this.inputControl.enable();
        }
    }
    /** @internal */
    writeValue(value) {
        this.inputControl.setValue(value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSelectComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i1$5.Directionality }, { token: SIDESHEET_TEXT_DIRECTION, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.2.1", type: EuiSelectComponent, isStandalone: false, selector: "eui-select", inputs: { required: "required", readonly: "readonly", readonlyAbbr: "readonlyAbbr", width: "width", isPending: "isPending", inputControl: "inputControl", searchFormControl: "searchFormControl", filterFunction: "filterFunction", placeholder: "placeholder", label: "label", useLegacyFloatingLabel: "useLegacyFloatingLabel", multiple: "multiple", enableFormFieldMargin: "enableFormFieldMargin", hideClearButton: "hideClearButton", hidePanelFooter: "hidePanelFooter", hideSearch: "hideSearch", disabled: "disabled", allSelectedText: "allSelectedText", feedbackMessages: "feedbackMessages", options: "options", sortFunction: "sortFunction" }, outputs: { searchFieldChange: "searchFieldChange", selectionChange: "selectionChange", openChange: "openChange", triggerClick: "triggerClick", optionsClear: "optionsClear" }, host: { properties: { "class": "this.class" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => EuiSelectComponent),
                multi: true,
            },
        ], queries: [{ propertyName: "_prefixChildren", predicate: MAT_PREFIX, descendants: true }, { propertyName: "_suffixChildren", predicate: MAT_SUFFIX, descendants: true }], viewQueries: [{ propertyName: "searchInput", first: true, predicate: ["searchInput"], descendants: true }, { propertyName: "select", first: true, predicate: ["select"], descendants: true }, { propertyName: "formField", first: true, predicate: ["formField"], descendants: true }, { propertyName: "optionsScroll", first: true, predicate: ["optionsScroll"], descendants: true }, { propertyName: "multiSubmitClear", first: true, predicate: ["multiSubmitClear"], descendants: true }, { propertyName: "multiSubmitOk", first: true, predicate: ["multiSubmitOk"], descendants: true }, { propertyName: "keyboardHelper", first: true, predicate: ["keyboardHelper"], descendants: true }], ngImport: i0, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<ng-template #selectDisplay>\n  @if (showAllSelectedText) {\n    {{ allSelectedText }}\n  }\n  @else if (multiple) {\n    {{ findOptionByValue(inputControl)?.display ?? '' }}\n    @if (inputControl.value?.length > 1) {\n      <span> {{ plusOthersText }} </span>\n    }\n  } @else {\n    {{ findOptionByValue(inputControl.value)?.display ?? '' }}\n  }\n</ng-template>\n\n<eui-form-field\n  [hideMargins]=\"!enableFormFieldMargin\"\n  [ngClass]=\"{ 'eui-select--with-icon': !!findOptionByValue(inputControl.value)?.icon }\"\n  (click)=\"triggerClick.emit($event)\"\n  data-testid=\"eui-select-form\"\n  [width]=\"width\"\n  [readonly]=\"readonly\"\n  [useLegacyFloatingLabel]=\"useLegacyFloatingLabel && label !== null\"\n  #formField\n  >\n  @if (!useLegacyFloatingLabel && showLabel) {\n    <eui-label>\n       {{ label }}\n       @if (inputControl.value?.length && multiple && !readonly) {\n         <span> {{ selectedText }} </span>\n       }\n    </eui-label>\n    }\n  @if (useLegacyFloatingLabel && showLabel) {\n    <mat-label>\n      {{ label }}\n      @if (inputControl.value?.length && multiple && !readonly) {\n        <span> {{ selectedText }} </span>\n      }\n    </mat-label>\n  }\n  \n  <eui-readonly-label>\n    <span #readonlyProjectedContent>\n      <ng-content select=\"eui-readonly-label\"></ng-content>\n    </span>\n    @if (!readonlyProjectedContent.childElementCount) {\n        @if (inputControl.value) {\n          @if (readonlyAbbr) {\n            <span [euiTooltip]=\"inputControl.value | euiJoin\">\n              @if (showPrefixIcon) {\n                <eui-icon class=\"eui-select--icon-readonly\" [icon]=\"findOptionByValue(inputControl.value)?.icon\"></eui-icon>\n              }\n              <ng-container *ngTemplateOutlet=\"selectDisplay\"></ng-container>\n            </span>\n          }\n          @else if (!multiple) {\n            @if (showPrefixIcon) {\n              <eui-icon class=\"eui-select--icon-readonly\" [icon]=\"findOptionByValue(inputControl.value)?.icon\"></eui-icon>\n            }\n            {{ inputControl.value }}\n          }\n          @else {\n            @for (v of inputControl.value; track v) {\n              @if (showPrefixIcon) {\n                <eui-icon class=\"eui-select--icon-readonly\" [icon]=\"findOptionByValue(v)?.icon\"></eui-icon>\n              }\n              {{ v }}@if ($index < inputControl.value.length-1) {,&nbsp;}\n            }\n          }\n        }\n        @else {\n          &mdash;\n        }\n    }\n  </eui-readonly-label>\n\n  @if (showFormElements.matTextPrefix) {\n    <span class=\"eui-select--text-prefix\" matTextPrefix>\n      <ng-content select=\"[matTextPrefix]\"></ng-content>\n    </span>\n  }\n\n  @if (showFormElements.matPrefix) {\n    <span class=\"eui-select--prefix\" matPrefix>\n      <ng-content select=\"[matPrefix], [matIconPrefix]\"></ng-content>\n    </span>\n  }\n\n  @if (showFormElements.matTextSuffix) {\n    <span class=\"eui-select--text-suffix\" matTextSuffix>\n      <ng-content select=\"[matTextSuffix]\"></ng-content>\n    </span>\n  }\n\n  @if (showFormElements.matSuffix) {\n    <span class=\"eui-select--suffix\" matSuffix>\n      <ng-content select=\"[matSuffix], [matIconSuffix]\"></ng-content>\n    </span>\n  }\n\n  @if (showPrefixIcon) {\n    <eui-icon class=\"eui-select--icon\" matPrefix [icon]=\"findOptionByValue(inputControl.value)?.icon\"></eui-icon>\n  }\n\n  <mat-select\n    #select\n    [multiple]=\"multiple\"\n    disableOptionCentering\n    placeholder=\"{{ placeholder }}\"\n    panelClass=\"multi-select-dropdown\"\n    [formControl]=\"inputControl\"\n    (selectionChange)=\"onOptionChange($event)\"\n    (openedChange)=\"openChange.emit($event)\"\n    (closed)=\"onTouched()\"\n    (opened)=\"onDropdownOpen()\"\n    [required]=\"isRequired\"\n    >\n    <mat-select-trigger>\n      <ng-container *ngTemplateOutlet=\"selectDisplay\"></ng-container>\n    </mat-select-trigger>\n    <div (keydown.esc)=\"$event.stopPropagation()\" (keyup.esc)=\"select.close(); select.focus()\" [dir]=\"direction\">\n      <div class=\"grid-container\" cdkTrapFocus>\n        @if (!hideSearch && (autoHideSearchLimit <= 0 || _options.length > autoHideSearchLimit)) {\n          <div class=\"search-input-area\">\n            <eui-search\n              #searchInput\n              [placeholder]=\"feedbackMessages.search\"\n              width=\"100%\"\n              size=\"m\"\n              [searchControl]=\"searchFormControl\"\n              data-testid=\"eui-select-search\"\n              (keydown)=\"$event.stopPropagation()\"\n            ></eui-search>\n            <div\n              #keyboardHelper\n              tabindex=\"0\"\n              (keydown)=\"keyboardHelperKeyDown($event)\"\n              (focus)=\"scrollActiveOptionIntoView()\"\n              [attr.aria-label]=\"feedbackMessages.keyboardOptionsListAria\"\n            ></div>\n            <div class=\"divider\">\n              <mat-divider></mat-divider>\n            </div>\n          </div>\n        }\n\n        <div class=\"error-area\">\n          @if (error | async) {\n            <div class=\"error-message\">\n              <eui-icon icon=\"error-circle\" size=\"s\"></eui-icon>\n              <span class=\"error-message-spacer\">{{ feedbackMessages.unsupportedCharacter }}</span>\n            </div>\n          }\n        </div>\n        <div class=\"eui-select-options options-area\">\n          <eui-scroll #optionsScroll>\n            @if (!hasResults) {\n              <div class=\"no-results\">{{ feedbackMessages.noResults }}</div>\n            }\n            @for (item of filteredOptions | async; track item) {\n              <mat-option\n                [value]=\"item.value\"\n                [ngClass]=\"{ 'hidden-option': !item.visible }\"\n                [disabled]=\"!!item.disabled || !item.visible\"\n                [attr.data-testid]=\"'eui-select-option-' + item.value\"\n                (focus)=\"onOptionFocus($event)\"\n                >\n                <div class=\"option-content\">\n                  @if (item.icon) {\n                    <eui-icon class=\"eui-select--icon\" [icon]=\"item.icon\"></eui-icon>\n                  }\n                  <div class=\"option-content-text\">\n                    <div>{{ item.display }}</div>\n                    @if (item.displayDetail) {\n                      <div class=\"display-details-text\">{{ item.displayDetail }}</div>\n                    }\n                  </div>\n                </div>\n              </mat-option>\n            }\n          </eui-scroll>\n          @if (isPending) {\n            <div class=\"disable-layer\"></div>\n          }\n        </div>\n        @if (multiple && !hidePanelFooter) {\n          <div class=\"submit-area\">\n            <button\n              class=\"button-small select-all-button\"\n              mat-stroked-button\n              [disabled]=\"enabledOptions.length === 0 || allOptionsSelected\"\n              (click)=\"selectAllInside()\"\n              color=\"primary\"\n              data-testid=\"eui-select-select-all\"\n              #multiSubmitSelectAll\n              (keydown)=\"submitButtonsKeyDown($event)\"\n              >\n              {{ feedbackMessages.selectAll ?? defaultFeedbackMessages.selectAll }}\n            </button>\n            <button\n              class=\"button-small clear-all-button\"\n              mat-stroked-button\n              [disabled]=\"!inputControl.value?.length\"\n              (click)=\"clearSelectionsInside()\"\n              color=\"primary\"\n              data-testid=\"eui-select-clear-all\"\n              #multiSubmitClear\n              (keydown)=\"submitButtonsKeyDown($event)\"\n              >\n              {{ feedbackMessages.clearAll }}\n            </button>\n            <button class=\"button-small\" mat-flat-button color=\"primary\" (click)=\"close()\" data-testid=\"eui-select-ok\" #multiSubmitOk (keydown)=\"submitButtonsKeyDown($event)\">\n              {{ feedbackMessages.ok }}\n            </button>\n            @if (isPending) {\n              <div class=\"disable-layer\"></div>\n            }\n          </div>\n        }\n        <div class=\"progress-area\">\n          @if (isPending) {\n            <mat-progress-bar mode=\"indeterminate\"></mat-progress-bar>\n          }\n        </div>\n      </div>\n    </div>\n  </mat-select>\n  @if (!hideClearButton && inputControl.value?.length && !select.panelOpen) {\n    <button\n      class=\"closeButton\"\n      matIconButton\n      [disabled]=\"disabled\"\n      matSuffix\n      (click)=\"clearSelectionsOutside()\"\n      data-testid=\"eui-select-clear\"\n      [attr.aria-label]=\"feedbackMessages.clear\"\n      [euiTooltip]=\"feedbackMessages.clear\"\n      >\n      <eui-icon icon=\"close\"></eui-icon>\n    </button>\n  }\n  <mat-error class=\"eui-form-field-subscript\">\n    <ng-content select=\"mat-error\"></ng-content>\n  </mat-error>\n  <mat-hint class=\"eui-form-field-subscript\">\n    <ng-content select=\"mat-hint\"></ng-content>\n  </mat-hint>\n</eui-form-field>\n", styles: [".eui-dark-theme .error-area .error-message{color:#f29d99}.eui-dark-theme .options-area .eui-option-active:not(.mat-mdc-selected){background:#f9fbfc0a}.eui-dark-theme .eui-select--suffix,.eui-dark-theme .eui-select--text-suffix,.eui-dark-theme .eui-select--prefix,.eui-dark-theme .eui-select--text-prefix{color:#dfe4e6}.error-area .error-message{color:#db2534}.options-area .eui-option-active:not(.mat-mdc-selected){background:#4446470a}.eui-select--suffix,.eui-select--text-suffix,.eui-select--prefix,.eui-select--text-prefix{color:#616566}.grid-container{display:grid;grid-template-columns:1fr;grid-template-rows:auto auto 1fr auto auto;grid-template-areas:\"search-input-area\" \"error-area\" \"options-area\" \"submit-area\" \"progress-area\";height:100%;max-height:256px}.search-input-area{grid-area:search-input-area;min-width:0px}.search-input-area ::ng-deep .mdc-text-field--outlined:not(.mdc-text-field--disabled) .mdc-notched-outline__leading,.search-input-area ::ng-deep .mdc-text-field--outlined:not(.mdc-text-field--disabled) .mdc-notched-outline__notch,.search-input-area ::ng-deep .mdc-text-field--outlined:not(.mdc-text-field--disabled) .mdc-notched-outline__trailing{border-color:transparent}.search-input-area ::ng-deep .eui-search.mat-mdc-form-field.mat-form-field-appearance-outline{min-width:0}.search-input-area .divider{width:100%;padding:0 4px 4px}.error-area{grid-area:error-area}.error-area .error-message{height:3em;display:flex;align-items:center;padding:0 16px}.error-area .error-message .error-message-spacer{margin:0 8px}.eui-select--icon{font-size:20px;margin-inline-end:10px;opacity:.6;display:inline-block;vertical-align:middle}.eui-select--icon-readonly{font-size:16px;margin-inline-end:3px;opacity:.6;display:inline-block;vertical-align:middle}.eui-select--prefix{display:inline-block;vertical-align:middle;margin-inline-end:4px;margin-inline-start:12px;text-wrap-mode:nowrap}.eui-select--text-prefix{margin-inline-end:8px;margin-inline-start:-4px;text-wrap-mode:nowrap}.eui-select--suffix{display:inline-block;vertical-align:middle;margin-inline-start:4px;margin-inline-end:16px;text-wrap-mode:nowrap}.eui-select--text-suffix{margin-inline-start:8px;margin-inline-end:0;text-wrap-mode:nowrap}.closeButton{vertical-align:middle}.options-area{grid-area:options-area;overflow:hidden;position:relative}.options-area .no-results{height:3em;display:flex;align-items:center;padding:0 16px;font-size:100%}.options-area .hidden-option{display:none;visibility:hidden}.options-area .option-content{display:flex;align-items:center}.options-area .option-content .option-content-text>div{line-height:initial}.options-area .option-content .option-content-text .display-details-text{font-size:75%;opacity:.6}.submit-area{grid-area:submit-area;padding:4px;position:relative;display:flex;flex-direction:row;justify-content:flex-end;gap:8px}.submit-area .select-all-button,.submit-area .clear-all-button{font-weight:400;text-wrap-mode:nowrap}.submit-area .button-small{line-height:28px}.progress-area{grid-area:progress-area;z-index:1000}:host{position:relative}.disable-layer{position:absolute;top:0;left:0;width:100%;height:100%;background-color:#fff9}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: i2$2.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "directive", type: i1$5.Dir, selector: "[dir]", inputs: ["dir"], outputs: ["dirChange"], exportAs: ["dir"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i2$3.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "directive", type: i2$1.MatLabel, selector: "mat-label" }, { kind: "directive", type: i2$1.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i2$1.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i2$1.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i2$1.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "component", type: i3$2.MatProgressBar, selector: "mat-progress-bar", inputs: ["color", "value", "bufferValue", "mode"], outputs: ["animationEnd"], exportAs: ["matProgressBar"] }, { kind: "component", type: i8.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "directive", type: i8.MatSelectTrigger, selector: "mat-select-trigger" }, { kind: "directive", type: i1$1.CdkTrapFocus, selector: "[cdkTrapFocus]", inputs: ["cdkTrapFocus", "cdkTrapFocusAutoCapture"], exportAs: ["cdkTrapFocus"] }, { kind: "directive", type: i6.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i6.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i6.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "component", type: EuiIconComponent, selector: "eui-icon", inputs: ["aria-hidden", "setLineHeight", "icon", "size"] }, { kind: "component", type: EuiReadonlyLabelComponent, selector: "eui-readonly-label" }, { kind: "component", type: EuiScrollComponent, selector: "eui-scroll", inputs: ["dispatchEvent", "options"] }, { kind: "component", type: EuiSearchComponent, selector: "eui-search", inputs: ["customFiltersConfig", "placeholder", "searchControl", "width", "disabled"], outputs: ["searchIconClick", "customFiltersChanged"] }, { kind: "component", type: EuiFormFieldComponent, selector: "eui-form-field", inputs: ["appearance", "hideMargins", "width", "useLegacyFloatingLabel", "readonly"] }, { kind: "component", type: EuiLabelComponent, selector: "eui-label", inputs: ["for", "required", "errorState", "disabled"] }, { kind: "directive", type: EuiTooltipDirective, selector: "[euiTooltip]", inputs: ["euiTooltip", "matTooltipShowDelay"] }, { kind: "pipe", type: i2.AsyncPipe, name: "async" }, { kind: "pipe", type: EuiJoinPipe, name: "euiJoin" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-select', providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => EuiSelectComponent),
                            multi: true,
                        },
                    ], changeDetection: ChangeDetectionStrategy.OnPush, standalone: false, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<ng-template #selectDisplay>\n  @if (showAllSelectedText) {\n    {{ allSelectedText }}\n  }\n  @else if (multiple) {\n    {{ findOptionByValue(inputControl)?.display ?? '' }}\n    @if (inputControl.value?.length > 1) {\n      <span> {{ plusOthersText }} </span>\n    }\n  } @else {\n    {{ findOptionByValue(inputControl.value)?.display ?? '' }}\n  }\n</ng-template>\n\n<eui-form-field\n  [hideMargins]=\"!enableFormFieldMargin\"\n  [ngClass]=\"{ 'eui-select--with-icon': !!findOptionByValue(inputControl.value)?.icon }\"\n  (click)=\"triggerClick.emit($event)\"\n  data-testid=\"eui-select-form\"\n  [width]=\"width\"\n  [readonly]=\"readonly\"\n  [useLegacyFloatingLabel]=\"useLegacyFloatingLabel && label !== null\"\n  #formField\n  >\n  @if (!useLegacyFloatingLabel && showLabel) {\n    <eui-label>\n       {{ label }}\n       @if (inputControl.value?.length && multiple && !readonly) {\n         <span> {{ selectedText }} </span>\n       }\n    </eui-label>\n    }\n  @if (useLegacyFloatingLabel && showLabel) {\n    <mat-label>\n      {{ label }}\n      @if (inputControl.value?.length && multiple && !readonly) {\n        <span> {{ selectedText }} </span>\n      }\n    </mat-label>\n  }\n  \n  <eui-readonly-label>\n    <span #readonlyProjectedContent>\n      <ng-content select=\"eui-readonly-label\"></ng-content>\n    </span>\n    @if (!readonlyProjectedContent.childElementCount) {\n        @if (inputControl.value) {\n          @if (readonlyAbbr) {\n            <span [euiTooltip]=\"inputControl.value | euiJoin\">\n              @if (showPrefixIcon) {\n                <eui-icon class=\"eui-select--icon-readonly\" [icon]=\"findOptionByValue(inputControl.value)?.icon\"></eui-icon>\n              }\n              <ng-container *ngTemplateOutlet=\"selectDisplay\"></ng-container>\n            </span>\n          }\n          @else if (!multiple) {\n            @if (showPrefixIcon) {\n              <eui-icon class=\"eui-select--icon-readonly\" [icon]=\"findOptionByValue(inputControl.value)?.icon\"></eui-icon>\n            }\n            {{ inputControl.value }}\n          }\n          @else {\n            @for (v of inputControl.value; track v) {\n              @if (showPrefixIcon) {\n                <eui-icon class=\"eui-select--icon-readonly\" [icon]=\"findOptionByValue(v)?.icon\"></eui-icon>\n              }\n              {{ v }}@if ($index < inputControl.value.length-1) {,&nbsp;}\n            }\n          }\n        }\n        @else {\n          &mdash;\n        }\n    }\n  </eui-readonly-label>\n\n  @if (showFormElements.matTextPrefix) {\n    <span class=\"eui-select--text-prefix\" matTextPrefix>\n      <ng-content select=\"[matTextPrefix]\"></ng-content>\n    </span>\n  }\n\n  @if (showFormElements.matPrefix) {\n    <span class=\"eui-select--prefix\" matPrefix>\n      <ng-content select=\"[matPrefix], [matIconPrefix]\"></ng-content>\n    </span>\n  }\n\n  @if (showFormElements.matTextSuffix) {\n    <span class=\"eui-select--text-suffix\" matTextSuffix>\n      <ng-content select=\"[matTextSuffix]\"></ng-content>\n    </span>\n  }\n\n  @if (showFormElements.matSuffix) {\n    <span class=\"eui-select--suffix\" matSuffix>\n      <ng-content select=\"[matSuffix], [matIconSuffix]\"></ng-content>\n    </span>\n  }\n\n  @if (showPrefixIcon) {\n    <eui-icon class=\"eui-select--icon\" matPrefix [icon]=\"findOptionByValue(inputControl.value)?.icon\"></eui-icon>\n  }\n\n  <mat-select\n    #select\n    [multiple]=\"multiple\"\n    disableOptionCentering\n    placeholder=\"{{ placeholder }}\"\n    panelClass=\"multi-select-dropdown\"\n    [formControl]=\"inputControl\"\n    (selectionChange)=\"onOptionChange($event)\"\n    (openedChange)=\"openChange.emit($event)\"\n    (closed)=\"onTouched()\"\n    (opened)=\"onDropdownOpen()\"\n    [required]=\"isRequired\"\n    >\n    <mat-select-trigger>\n      <ng-container *ngTemplateOutlet=\"selectDisplay\"></ng-container>\n    </mat-select-trigger>\n    <div (keydown.esc)=\"$event.stopPropagation()\" (keyup.esc)=\"select.close(); select.focus()\" [dir]=\"direction\">\n      <div class=\"grid-container\" cdkTrapFocus>\n        @if (!hideSearch && (autoHideSearchLimit <= 0 || _options.length > autoHideSearchLimit)) {\n          <div class=\"search-input-area\">\n            <eui-search\n              #searchInput\n              [placeholder]=\"feedbackMessages.search\"\n              width=\"100%\"\n              size=\"m\"\n              [searchControl]=\"searchFormControl\"\n              data-testid=\"eui-select-search\"\n              (keydown)=\"$event.stopPropagation()\"\n            ></eui-search>\n            <div\n              #keyboardHelper\n              tabindex=\"0\"\n              (keydown)=\"keyboardHelperKeyDown($event)\"\n              (focus)=\"scrollActiveOptionIntoView()\"\n              [attr.aria-label]=\"feedbackMessages.keyboardOptionsListAria\"\n            ></div>\n            <div class=\"divider\">\n              <mat-divider></mat-divider>\n            </div>\n          </div>\n        }\n\n        <div class=\"error-area\">\n          @if (error | async) {\n            <div class=\"error-message\">\n              <eui-icon icon=\"error-circle\" size=\"s\"></eui-icon>\n              <span class=\"error-message-spacer\">{{ feedbackMessages.unsupportedCharacter }}</span>\n            </div>\n          }\n        </div>\n        <div class=\"eui-select-options options-area\">\n          <eui-scroll #optionsScroll>\n            @if (!hasResults) {\n              <div class=\"no-results\">{{ feedbackMessages.noResults }}</div>\n            }\n            @for (item of filteredOptions | async; track item) {\n              <mat-option\n                [value]=\"item.value\"\n                [ngClass]=\"{ 'hidden-option': !item.visible }\"\n                [disabled]=\"!!item.disabled || !item.visible\"\n                [attr.data-testid]=\"'eui-select-option-' + item.value\"\n                (focus)=\"onOptionFocus($event)\"\n                >\n                <div class=\"option-content\">\n                  @if (item.icon) {\n                    <eui-icon class=\"eui-select--icon\" [icon]=\"item.icon\"></eui-icon>\n                  }\n                  <div class=\"option-content-text\">\n                    <div>{{ item.display }}</div>\n                    @if (item.displayDetail) {\n                      <div class=\"display-details-text\">{{ item.displayDetail }}</div>\n                    }\n                  </div>\n                </div>\n              </mat-option>\n            }\n          </eui-scroll>\n          @if (isPending) {\n            <div class=\"disable-layer\"></div>\n          }\n        </div>\n        @if (multiple && !hidePanelFooter) {\n          <div class=\"submit-area\">\n            <button\n              class=\"button-small select-all-button\"\n              mat-stroked-button\n              [disabled]=\"enabledOptions.length === 0 || allOptionsSelected\"\n              (click)=\"selectAllInside()\"\n              color=\"primary\"\n              data-testid=\"eui-select-select-all\"\n              #multiSubmitSelectAll\n              (keydown)=\"submitButtonsKeyDown($event)\"\n              >\n              {{ feedbackMessages.selectAll ?? defaultFeedbackMessages.selectAll }}\n            </button>\n            <button\n              class=\"button-small clear-all-button\"\n              mat-stroked-button\n              [disabled]=\"!inputControl.value?.length\"\n              (click)=\"clearSelectionsInside()\"\n              color=\"primary\"\n              data-testid=\"eui-select-clear-all\"\n              #multiSubmitClear\n              (keydown)=\"submitButtonsKeyDown($event)\"\n              >\n              {{ feedbackMessages.clearAll }}\n            </button>\n            <button class=\"button-small\" mat-flat-button color=\"primary\" (click)=\"close()\" data-testid=\"eui-select-ok\" #multiSubmitOk (keydown)=\"submitButtonsKeyDown($event)\">\n              {{ feedbackMessages.ok }}\n            </button>\n            @if (isPending) {\n              <div class=\"disable-layer\"></div>\n            }\n          </div>\n        }\n        <div class=\"progress-area\">\n          @if (isPending) {\n            <mat-progress-bar mode=\"indeterminate\"></mat-progress-bar>\n          }\n        </div>\n      </div>\n    </div>\n  </mat-select>\n  @if (!hideClearButton && inputControl.value?.length && !select.panelOpen) {\n    <button\n      class=\"closeButton\"\n      matIconButton\n      [disabled]=\"disabled\"\n      matSuffix\n      (click)=\"clearSelectionsOutside()\"\n      data-testid=\"eui-select-clear\"\n      [attr.aria-label]=\"feedbackMessages.clear\"\n      [euiTooltip]=\"feedbackMessages.clear\"\n      >\n      <eui-icon icon=\"close\"></eui-icon>\n    </button>\n  }\n  <mat-error class=\"eui-form-field-subscript\">\n    <ng-content select=\"mat-error\"></ng-content>\n  </mat-error>\n  <mat-hint class=\"eui-form-field-subscript\">\n    <ng-content select=\"mat-hint\"></ng-content>\n  </mat-hint>\n</eui-form-field>\n", styles: [".eui-dark-theme .error-area .error-message{color:#f29d99}.eui-dark-theme .options-area .eui-option-active:not(.mat-mdc-selected){background:#f9fbfc0a}.eui-dark-theme .eui-select--suffix,.eui-dark-theme .eui-select--text-suffix,.eui-dark-theme .eui-select--prefix,.eui-dark-theme .eui-select--text-prefix{color:#dfe4e6}.error-area .error-message{color:#db2534}.options-area .eui-option-active:not(.mat-mdc-selected){background:#4446470a}.eui-select--suffix,.eui-select--text-suffix,.eui-select--prefix,.eui-select--text-prefix{color:#616566}.grid-container{display:grid;grid-template-columns:1fr;grid-template-rows:auto auto 1fr auto auto;grid-template-areas:\"search-input-area\" \"error-area\" \"options-area\" \"submit-area\" \"progress-area\";height:100%;max-height:256px}.search-input-area{grid-area:search-input-area;min-width:0px}.search-input-area ::ng-deep .mdc-text-field--outlined:not(.mdc-text-field--disabled) .mdc-notched-outline__leading,.search-input-area ::ng-deep .mdc-text-field--outlined:not(.mdc-text-field--disabled) .mdc-notched-outline__notch,.search-input-area ::ng-deep .mdc-text-field--outlined:not(.mdc-text-field--disabled) .mdc-notched-outline__trailing{border-color:transparent}.search-input-area ::ng-deep .eui-search.mat-mdc-form-field.mat-form-field-appearance-outline{min-width:0}.search-input-area .divider{width:100%;padding:0 4px 4px}.error-area{grid-area:error-area}.error-area .error-message{height:3em;display:flex;align-items:center;padding:0 16px}.error-area .error-message .error-message-spacer{margin:0 8px}.eui-select--icon{font-size:20px;margin-inline-end:10px;opacity:.6;display:inline-block;vertical-align:middle}.eui-select--icon-readonly{font-size:16px;margin-inline-end:3px;opacity:.6;display:inline-block;vertical-align:middle}.eui-select--prefix{display:inline-block;vertical-align:middle;margin-inline-end:4px;margin-inline-start:12px;text-wrap-mode:nowrap}.eui-select--text-prefix{margin-inline-end:8px;margin-inline-start:-4px;text-wrap-mode:nowrap}.eui-select--suffix{display:inline-block;vertical-align:middle;margin-inline-start:4px;margin-inline-end:16px;text-wrap-mode:nowrap}.eui-select--text-suffix{margin-inline-start:8px;margin-inline-end:0;text-wrap-mode:nowrap}.closeButton{vertical-align:middle}.options-area{grid-area:options-area;overflow:hidden;position:relative}.options-area .no-results{height:3em;display:flex;align-items:center;padding:0 16px;font-size:100%}.options-area .hidden-option{display:none;visibility:hidden}.options-area .option-content{display:flex;align-items:center}.options-area .option-content .option-content-text>div{line-height:initial}.options-area .option-content .option-content-text .display-details-text{font-size:75%;opacity:.6}.submit-area{grid-area:submit-area;padding:4px;position:relative;display:flex;flex-direction:row;justify-content:flex-end;gap:8px}.submit-area .select-all-button,.submit-area .clear-all-button{font-weight:400;text-wrap-mode:nowrap}.submit-area .button-small{line-height:28px}.progress-area{grid-area:progress-area;z-index:1000}:host{position:relative}.disable-layer{position:absolute;top:0;left:0;width:100%;height:100%;background-color:#fff9}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i1$5.Directionality }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [SIDESHEET_TEXT_DIRECTION]
                }] }], propDecorators: { class: [{
                type: HostBinding,
                args: ['class']
            }], searchInput: [{
                type: ViewChild,
                args: ['searchInput']
            }], select: [{
                type: ViewChild,
                args: ['select']
            }], formField: [{
                type: ViewChild,
                args: ['formField']
            }], optionsScroll: [{
                type: ViewChild,
                args: ['optionsScroll']
            }], multiSubmitClear: [{
                type: ViewChild,
                args: ['multiSubmitClear']
            }], multiSubmitOk: [{
                type: ViewChild,
                args: ['multiSubmitOk']
            }], keyboardHelper: [{
                type: ViewChild,
                args: ['keyboardHelper']
            }], _prefixChildren: [{
                type: ContentChildren,
                args: [MAT_PREFIX, { descendants: true }]
            }], _suffixChildren: [{
                type: ContentChildren,
                args: [MAT_SUFFIX, { descendants: true }]
            }], required: [{
                type: Input
            }], readonly: [{
                type: Input
            }], readonlyAbbr: [{
                type: Input
            }], width: [{
                type: Input
            }], isPending: [{
                type: Input
            }], inputControl: [{
                type: Input
            }], searchFormControl: [{
                type: Input
            }], filterFunction: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], label: [{
                type: Input
            }], useLegacyFloatingLabel: [{
                type: Input
            }], multiple: [{
                type: Input
            }], enableFormFieldMargin: [{
                type: Input
            }], hideClearButton: [{
                type: Input
            }], hidePanelFooter: [{
                type: Input
            }], hideSearch: [{
                type: Input
            }], disabled: [{
                type: Input
            }], allSelectedText: [{
                type: Input
            }], feedbackMessages: [{
                type: Input
            }], searchFieldChange: [{
                type: Output
            }], selectionChange: [{
                type: Output
            }], openChange: [{
                type: Output
            }], triggerClick: [{
                type: Output
            }], optionsClear: [{
                type: Output
            }], options: [{
                type: Input
            }], sortFunction: [{
                type: Input
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
var EuiSidebarEnum;
(function (EuiSidebarEnum) {
    EuiSidebarEnum["COLLAPSE_START"] = "COLLAPSE_START";
    EuiSidebarEnum["COLLAPSE_END"] = "COLLAPSE_END";
    EuiSidebarEnum["EXPAND_START"] = "EXPAND_START";
    EuiSidebarEnum["EXPAND_END"] = "EXPAND_END";
})(EuiSidebarEnum || (EuiSidebarEnum = {}));

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
const sidebarToggleAnimation = trigger('sidebarToggle', [
    state('true', style({ overflow: 'hidden', width: '48px' })),
    state('false', style({ overflow: 'hidden', width: '*' })),
    transition('true <=> false', animate('150ms ease-in-out')),
]);
/** @internal */
const DUE_TIME = 30;
/** @internal */
const USER_EVENT_DUE_TIME = 100;
/**
 * Simple sidebar with three optional content area.:
 * <eui-sidebar>
 *   <div data-content-area="header">Header content</div>
 *   Main content
 *   <div data-content-area="footer">Footer content</div>
 * </eui-sidebar>
 */
class EuiSidebarComponent {
    constructor(hostElementRef, dir) {
        this.hostElementRef = hostElementRef;
        this.dir = dir;
        /**
         * Sets the height of the sidebar component when minimized.
         *
         * @category Input
         * @default '100%'
         */
        this.minimizedHeight = '100%';
        /**
         * This affects which side the menu opens on when minimized.
         *
         * @category Input
         */
        this.direction = this.dir.value;
        /**
         * Collapse/Toggle Start/Stop events.
         * It's a useful event if you would like to control of sidebar content elements.
         *
         * Use EuiSidebarEnum:
         * - COLLAPSE_START
         * - COLLAPSE_END
         * - EXPAND_START
         * - EXPAND_END
         *
         * @internal */
        this.event = new BehaviorSubject(null);
        /**
         * Sidebar minimized/maximized state.
         *
         * @internal */
        this.minimized = new BehaviorSubject(false);
        /** @internal */
        this._collapse = new BehaviorSubject(false);
        this.debounce = new Subject();
        this.debounceUserEvent = new Subject();
        this.destroy = new Subject();
        this.debounce.pipe(takeUntil(this.destroy), debounceTime(DUE_TIME)).subscribe((callback) => callback());
        this.debounceUserEvent.pipe(takeUntil(this.destroy), debounceTime(USER_EVENT_DUE_TIME)).subscribe((callback) => callback());
        this.minimized.pipe(takeUntil(this.destroy)).subscribe((minimize) => {
            this.hostElementRef.nativeElement.style.height = minimize ? this.minimizedHeight : 'initial';
            this.debounce.next(() => this._collapse.next(minimize));
        });
        this.dir.change.pipe(takeUntil(this.destroy)).subscribe(() => this.direction = this.direction === 'rtl' ? 'ltr' : 'rtl');
    }
    /** @internal */
    onEnter() {
        if (this.minimized.value)
            this.debounceUserEvent.next(() => this._collapse.next(false));
    }
    /** @internal */
    onLeave() {
        if (this.minimized.value)
            this.debounceUserEvent.next(() => this._collapse.next(true));
    }
    /** @internal */
    onFocus() {
        if (this.minimized.value)
            this.debounceUserEvent.next(() => this._collapse.next(false));
    }
    /** @internal */
    onBlur() {
        if (this.minimized.value)
            this.debounceUserEvent.next(() => this._collapse.next(true));
    }
    /** @internal */
    ngOnDestroy() {
        this.destroy.next(true);
    }
    /**
     * Minimize / maximize sidebar
     * Min size: 48px
     * Max size: content size or container size
     *
     * @internal */
    toggleMinimize() {
        this.debounceUserEvent.next(() => {
            this.minimized.next(!this.minimized.value);
        });
    }
    /** @internal */
    _onAnimationStart(event) {
        this.debounce.next(() => {
            if (event.fromState)
                this.event.next(EuiSidebarEnum.EXPAND_START);
            else
                this.event.next(EuiSidebarEnum.COLLAPSE_START);
        });
    }
    /** @internal */
    _onAnimationEnd(event) {
        this.debounce.next(() => {
            if (event.fromState)
                this.event.next(EuiSidebarEnum.EXPAND_END);
            else
                this.event.next(EuiSidebarEnum.COLLAPSE_END);
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSidebarComponent, deps: [{ token: i0.ElementRef }, { token: i1$5.Directionality }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.2.1", type: EuiSidebarComponent, isStandalone: false, selector: "eui-sidebar", inputs: { minimizedHeight: "minimizedHeight", direction: "direction" }, host: { listeners: { "mouseenter": "onEnter()", "mouseleave": "onLeave()", "focusin": "onFocus()", "focusout": "onBlur()" } }, ngImport: i0, template: "<!--\n    Copyright 2025 One Identity LLC.\n    ALL RIGHTS RESERVED.\n-->\n\n<div class=\"eui-sidebar mat-elevation-z2\" [ngClass]=\"{'eui-sidebar-minimized': minimized | async}\" [class]=\"'eui-sidebar-direction-'+direction\">\n  <div class=\"eui-sidebar-layout\" [@sidebarToggle]=\"_collapse | async\" (@sidebarToggle.start)=\"_onAnimationStart($event)\" (@sidebarToggle.done)=\"_onAnimationEnd($event)\">\n    <div class=\"eui-sidebar-header\">\n      <ng-content select=\"[data-content-area=header]\"></ng-content>\n    </div>\n    <div class=\"eui-sidebar-main\">\n      <ng-content></ng-content>\n    </div>\n    <div class=\"eui-sidebar-footer\">\n      <ng-content select=\"[data-content-area=footer]\"></ng-content>\n    </div>\n  </div>\n</div>\n", styles: [":host{display:inline-block;height:100%;min-width:48px;max-width:fit-content;position:relative}:host-context(.eui-dark-theme){background:#444647}:host-context(.eui-dark-theme) .eui-sidebar-layout{background:#444647}.eui-sidebar{min-width:48px;height:100%}.eui-sidebar.eui-sidebar-minimized{position:absolute;width:max-content}.eui-sidebar.eui-sidebar-minimized.eui-sidebar-direction-rtl{right:0}.eui-sidebar.eui-sidebar-minimized.eui-sidebar-direction-ltr{left:0}.eui-sidebar-layout{height:100%;display:grid;grid-template-columns:minmax(0,1fr);grid-template-rows:auto minmax(0,1fr) auto;grid-template-areas:\"sidebar-header\" \"sidebar-main\" \"sidebar-footer\";background:#fff;color:#000}.eui-sidebar-header{grid-area:sidebar-header}.eui-sidebar-main{grid-area:sidebar-main;overflow:hidden}.eui-sidebar-footer{grid-area:sidebar-footer}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "pipe", type: i2.AsyncPipe, name: "async" }], animations: [sidebarToggleAnimation], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSidebarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-sidebar', animations: [sidebarToggleAnimation], changeDetection: ChangeDetectionStrategy.OnPush, standalone: false, template: "<!--\n    Copyright 2025 One Identity LLC.\n    ALL RIGHTS RESERVED.\n-->\n\n<div class=\"eui-sidebar mat-elevation-z2\" [ngClass]=\"{'eui-sidebar-minimized': minimized | async}\" [class]=\"'eui-sidebar-direction-'+direction\">\n  <div class=\"eui-sidebar-layout\" [@sidebarToggle]=\"_collapse | async\" (@sidebarToggle.start)=\"_onAnimationStart($event)\" (@sidebarToggle.done)=\"_onAnimationEnd($event)\">\n    <div class=\"eui-sidebar-header\">\n      <ng-content select=\"[data-content-area=header]\"></ng-content>\n    </div>\n    <div class=\"eui-sidebar-main\">\n      <ng-content></ng-content>\n    </div>\n    <div class=\"eui-sidebar-footer\">\n      <ng-content select=\"[data-content-area=footer]\"></ng-content>\n    </div>\n  </div>\n</div>\n", styles: [":host{display:inline-block;height:100%;min-width:48px;max-width:fit-content;position:relative}:host-context(.eui-dark-theme){background:#444647}:host-context(.eui-dark-theme) .eui-sidebar-layout{background:#444647}.eui-sidebar{min-width:48px;height:100%}.eui-sidebar.eui-sidebar-minimized{position:absolute;width:max-content}.eui-sidebar.eui-sidebar-minimized.eui-sidebar-direction-rtl{right:0}.eui-sidebar.eui-sidebar-minimized.eui-sidebar-direction-ltr{left:0}.eui-sidebar-layout{height:100%;display:grid;grid-template-columns:minmax(0,1fr);grid-template-rows:auto minmax(0,1fr) auto;grid-template-areas:\"sidebar-header\" \"sidebar-main\" \"sidebar-footer\";background:#fff;color:#000}.eui-sidebar-header{grid-area:sidebar-header}.eui-sidebar-main{grid-area:sidebar-main;overflow:hidden}.eui-sidebar-footer{grid-area:sidebar-footer}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1$5.Directionality }], propDecorators: { minimizedHeight: [{
                type: Input
            }], direction: [{
                type: Input
            }], onEnter: [{
                type: HostListener,
                args: ['mouseenter']
            }], onLeave: [{
                type: HostListener,
                args: ['mouseleave']
            }], onFocus: [{
                type: HostListener,
                args: ['focusin']
            }], onBlur: [{
                type: HostListener,
                args: ['focusout']
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
/** @internal */
const SPLASH_SCREEN_OPTIONS = new InjectionToken('SPLASH_SCREEN_OPTIONS');

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiSplashScreenComponent {
    constructor(options) {
        this.options = options;
        /** @internal */
        this.class = 'eui-splash-screen';
        /** @internal */
        this.testId = 'eui-splash-screen';
        /** @internal */
        this.isVisible = true;
        /** @internal */
        this.animationStateChanged = new EventEmitter();
    }
    /** @internal */
    close() {
        this.isVisible = false;
    }
    /** @internal */
    onAnimationDone(event) {
        this.animationStateChanged.emit(event);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSplashScreenComponent, deps: [{ token: SPLASH_SCREEN_OPTIONS }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.2.1", type: EuiSplashScreenComponent, isStandalone: false, selector: "eui-splash-screen", host: { properties: { "class": "this.class", "data-testid": "this.testId" } }, ngImport: i0, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<div class=\"splash-screen-container\" [@slideUpOut]=\"isVisible\" (@slideUpOut.done)=\"onAnimationDone($event)\">\n  <div class=\"ss-position\">\n    <div class=\"ss-content\">\n      @if (!options.customLogo) {\n        <h1 class=\"ss-app-logo\">\n          @if (options.icon !== 'oi-horizontal') {\n            <eui-icon [icon]=\"options.icon\"></eui-icon>\n          }\n          @if (options.icon === 'oi-horizontal') {\n            <eui-logo [size]=\"56\"></eui-logo>\n          }\n        </h1>\n      }\n      @if (options.customLogo) {\n        <h1 class=\"ss-app-logo\">\n          <img [src]=\"options.customLogo.url\" [style.height]=\"options.customLogo.height\" [alt]=\"options.customLogo.altText\" />\n        </h1>\n      }\n\n      @if (options.applicationName) {\n        <h2 class=\"ss-app-name\">{{ options.applicationName }}</h2>\n      }\n\n      @if (options.message) {\n        <div class=\"ss-message\">{{ options.message }}</div>\n      }\n\n      @if (options.showSpinner) {\n        <div class=\"ss-spinner\">\n          <mat-spinner [diameter]=\"50\"></mat-spinner>\n        </div>\n      }\n    </div>\n\n    @if (options.copyright) {\n      <div class=\"ss-copyright\">{{ options.copyright }}</div>\n    }\n  </div>\n</div>\n", styles: [":host-context(.eui-dark-theme) .splash-screen-container{background-color:#016b91;color:#f2f6f7}:host-context(.eui-dark-theme) .splash-screen-container .ss-message{border-top:1px solid #8acbe3;border-bottom:1px solid #8acbe3}:host-context(.eui-dark-theme) .splash-screen-container .ss-spinner ::ng-deep .mat-mdc-progress-spinner circle{stroke:#f2f6f7}:host-context(.eui-contrast-theme) .splash-screen-container{background-color:#00384d;color:#f2f6f7}:host-context(.eui-contrast-theme) .splash-screen-container .ss-message{border-top:1px solid #8acbe3;border-bottom:1px solid #8acbe3}:host-context(.eui-contrast-theme) .splash-screen-container .ss-spinner ::ng-deep .mat-mdc-progress-spinner circle{stroke:#f2f6f7}.splash-screen-container{background-color:#0a96d1;color:#fff}.splash-screen-container .ss-message{border-top:1px solid #cbe8f2;border-bottom:1px solid #cbe8f2}.splash-screen-container .ss-spinner ::ng-deep .mat-mdc-progress-spinner circle{stroke:#fff}::ng-deep .eui-splash-screen-panel{width:100%;height:100%}::ng-deep .eui-splash-screen-panel .eui-splash-screen{width:100%}.splash-screen-container{width:100%;height:100%;text-align:center;overflow:auto}.splash-screen-container .ss-position{display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100%;width:100%;height:100%;max-width:100%;padding:15px 0}.splash-screen-container .ss-position .ss-content{width:50%;flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center}.splash-screen-container .ss-position .ss-content .ss-app-logo{margin-bottom:30px}.splash-screen-container .ss-position .ss-content .ss-app-logo .eui-icon{font-size:90px}.splash-screen-container .ss-position .ss-content .ss-app-name{font-size:36px;font-weight:300;margin-bottom:30px}.splash-screen-container .ss-position .ss-content .ss-message{font-size:14px;width:100%;margin-bottom:20px;padding-top:1em;padding-bottom:1em}.splash-screen-container .ss-position .ss-content .ss-spinner{display:inline-block;padding:30px 0}.splash-screen-container .ss-position .ss-copyright{font-size:.6rem;text-align:center;margin-top:1em;padding:1em 0;position:relative}@media screen and (max-width: 992px){.splash-screen-container .ss-position .ss-content{padding-top:30px!important}.splash-screen-container .ss-position .ss-content .ss-app-name{font-size:30px}.splash-screen-container .ss-position .ss-content .ss-app-logo{font-size:1.5em;max-height:100px;max-width:100%}}@media screen and (max-width: 768px){.splash-screen-container .ss-position .ss-content{width:90%;padding:1em 0!important}.splash-screen-container .ss-position .ss-content .ss-app-name{font-size:24px}}@media screen and (max-width: 480px){.splash-screen-container .ss-position .ss-content .ss-app-logo eui-logo,.splash-screen-container .ss-position .ss-content .ss-app-logo eui-logo svg{height:40px}}\n"], dependencies: [{ kind: "component", type: i1$2.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "component", type: EuiIconComponent, selector: "eui-icon", inputs: ["aria-hidden", "setLineHeight", "icon", "size"] }, { kind: "component", type: EuiLogoComponent, selector: "eui-logo", inputs: ["size"] }], animations: [
            trigger('slideUpOut', [state('false', style({ transform: 'translateY(-100%)' })), transition('true => false', animate('500ms ease'))]),
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSplashScreenComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-splash-screen', animations: [
                        trigger('slideUpOut', [state('false', style({ transform: 'translateY(-100%)' })), transition('true => false', animate('500ms ease'))]),
                    ], standalone: false, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<div class=\"splash-screen-container\" [@slideUpOut]=\"isVisible\" (@slideUpOut.done)=\"onAnimationDone($event)\">\n  <div class=\"ss-position\">\n    <div class=\"ss-content\">\n      @if (!options.customLogo) {\n        <h1 class=\"ss-app-logo\">\n          @if (options.icon !== 'oi-horizontal') {\n            <eui-icon [icon]=\"options.icon\"></eui-icon>\n          }\n          @if (options.icon === 'oi-horizontal') {\n            <eui-logo [size]=\"56\"></eui-logo>\n          }\n        </h1>\n      }\n      @if (options.customLogo) {\n        <h1 class=\"ss-app-logo\">\n          <img [src]=\"options.customLogo.url\" [style.height]=\"options.customLogo.height\" [alt]=\"options.customLogo.altText\" />\n        </h1>\n      }\n\n      @if (options.applicationName) {\n        <h2 class=\"ss-app-name\">{{ options.applicationName }}</h2>\n      }\n\n      @if (options.message) {\n        <div class=\"ss-message\">{{ options.message }}</div>\n      }\n\n      @if (options.showSpinner) {\n        <div class=\"ss-spinner\">\n          <mat-spinner [diameter]=\"50\"></mat-spinner>\n        </div>\n      }\n    </div>\n\n    @if (options.copyright) {\n      <div class=\"ss-copyright\">{{ options.copyright }}</div>\n    }\n  </div>\n</div>\n", styles: [":host-context(.eui-dark-theme) .splash-screen-container{background-color:#016b91;color:#f2f6f7}:host-context(.eui-dark-theme) .splash-screen-container .ss-message{border-top:1px solid #8acbe3;border-bottom:1px solid #8acbe3}:host-context(.eui-dark-theme) .splash-screen-container .ss-spinner ::ng-deep .mat-mdc-progress-spinner circle{stroke:#f2f6f7}:host-context(.eui-contrast-theme) .splash-screen-container{background-color:#00384d;color:#f2f6f7}:host-context(.eui-contrast-theme) .splash-screen-container .ss-message{border-top:1px solid #8acbe3;border-bottom:1px solid #8acbe3}:host-context(.eui-contrast-theme) .splash-screen-container .ss-spinner ::ng-deep .mat-mdc-progress-spinner circle{stroke:#f2f6f7}.splash-screen-container{background-color:#0a96d1;color:#fff}.splash-screen-container .ss-message{border-top:1px solid #cbe8f2;border-bottom:1px solid #cbe8f2}.splash-screen-container .ss-spinner ::ng-deep .mat-mdc-progress-spinner circle{stroke:#fff}::ng-deep .eui-splash-screen-panel{width:100%;height:100%}::ng-deep .eui-splash-screen-panel .eui-splash-screen{width:100%}.splash-screen-container{width:100%;height:100%;text-align:center;overflow:auto}.splash-screen-container .ss-position{display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100%;width:100%;height:100%;max-width:100%;padding:15px 0}.splash-screen-container .ss-position .ss-content{width:50%;flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center}.splash-screen-container .ss-position .ss-content .ss-app-logo{margin-bottom:30px}.splash-screen-container .ss-position .ss-content .ss-app-logo .eui-icon{font-size:90px}.splash-screen-container .ss-position .ss-content .ss-app-name{font-size:36px;font-weight:300;margin-bottom:30px}.splash-screen-container .ss-position .ss-content .ss-message{font-size:14px;width:100%;margin-bottom:20px;padding-top:1em;padding-bottom:1em}.splash-screen-container .ss-position .ss-content .ss-spinner{display:inline-block;padding:30px 0}.splash-screen-container .ss-position .ss-copyright{font-size:.6rem;text-align:center;margin-top:1em;padding:1em 0;position:relative}@media screen and (max-width: 992px){.splash-screen-container .ss-position .ss-content{padding-top:30px!important}.splash-screen-container .ss-position .ss-content .ss-app-name{font-size:30px}.splash-screen-container .ss-position .ss-content .ss-app-logo{font-size:1.5em;max-height:100px;max-width:100%}}@media screen and (max-width: 768px){.splash-screen-container .ss-position .ss-content{width:90%;padding:1em 0!important}.splash-screen-container .ss-position .ss-content .ss-app-name{font-size:24px}}@media screen and (max-width: 480px){.splash-screen-container .ss-position .ss-content .ss-app-logo eui-logo,.splash-screen-container .ss-position .ss-content .ss-app-logo eui-logo svg{height:40px}}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [SPLASH_SCREEN_OPTIONS]
                }] }], propDecorators: { class: [{
                type: HostBinding,
                args: ['class']
            }], testId: [{
                type: HostBinding,
                args: ['data-testid']
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
/**
 * A service that displays a splash screen
 */
class EuiSplashScreenService {
    /**
     * Returns whether the splash screen is currently open or not
     */
    get isOpen() {
        return this._isOpen;
    }
    constructor(overlay, injector) {
        this.overlay = overlay;
        this.injector = injector;
        this._isOpen = false;
    }
    /**
     * Opens the splash screen component. Only one instance can be opened.
     *
     * @param config Configuration options for the splash screen. See the [[EuiSplashScreenConfig]] interface for more information.
     */
    open(config) {
        if (!this.isOpen) {
            this._isOpen = true;
            const overlayConfig = this.getOverlayConfig(config);
            this.overlayRef = this.overlay.create(overlayConfig);
            const staticProviders = [{ provide: SPLASH_SCREEN_OPTIONS, useValue: config }];
            const portalInjector = Injector.create({ providers: staticProviders, parent: this.injector });
            const componentPortal = new ComponentPortal(EuiSplashScreenComponent, null, portalInjector);
            const containerRef = this.overlayRef.attach(componentPortal);
            this.component = containerRef.instance;
        }
    }
    /**
     * Updates the options used to set the visual state of the splash screen.
     *
     * @param options Options for visual appearance of the splash screen. See the [[EuiSplashScreenOptions]] interface for more information.
     */
    updateState(options) {
        if (this.component) {
            this.component.options = { ...this.component.options, ...options };
        }
    }
    /**
     * Closes the splash screen
     */
    close() {
        if (this.isOpen) {
            this._isOpen = false;
            this.animationState$ = this.component.animationStateChanged.subscribe(() => this.closeOverlay());
            this.component.close();
        }
    }
    closeOverlay() {
        if (!this.animationState$.closed) {
            this.animationState$.unsubscribe();
        }
        if (this.overlayRef?.hasAttached()) {
            this.overlayRef.dispose();
        }
        setTimeout(() => {
            this.overlayRef = undefined;
            this.component = undefined;
        });
    }
    getOverlayConfig(config) {
        const positionStrategy = this.overlay.position().global().centerHorizontally().centerVertically();
        return new OverlayConfig({
            hasBackdrop: false,
            panelClass: 'eui-splash-screen-panel',
            direction: config.textDirection,
            scrollStrategy: this.overlay.scrollStrategies.block(),
            positionStrategy,
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSplashScreenService, deps: [{ token: i1$4.Overlay }, { token: i0.Injector }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSplashScreenService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSplashScreenService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$4.Overlay }, { type: i0.Injector }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiSubscribeContext {
    constructor() {
        this.$implicit = null;
        this.euiSubscribe = null;
    }
}
/**
 * This directive can subscribe to multiple observables so that they are available within
 * the template. It will also unsubscribe when this directive is destroyed.
 *
 * @example
 * <ng-container *euiSubscribe="{
 *   timelineConfig: timelineConfig,
 *   fetchProgress: fetchProgress,
 *   seekedIndex: seekedIndex,
 *   selectedElement: selectedElement
 * } as _subs">
 *     <div>{{ _subs.selectedElement.time }}</div>
 * </ng-container>
 */
class EuiSubscribeDirective {
    /**
     * Set the observables to subscribe to.
     *
     * @category Input
     * @param inputObservable An observable or array of observables to subscribe to.
     */
    set euiSubscribe(inputObservable) {
        if (isObservable(inputObservable)) {
            if (this.observable !== inputObservable) {
                this.observable = inputObservable;
                if (this.subscription !== null)
                    this.subscription.unsubscribe();
                this.subscription = this.observable.subscribe({
                    next: (value) => {
                        this.context.euiSubscribe = value;
                        this.cdr.markForCheck();
                    },
                    error: () => ({}),
                });
            }
        }
        else {
            if (this.observable === null) {
                this.observable = {};
                this.subscription = {};
                this.context.euiSubscribe = {};
            }
            for (const key of Object.keys(inputObservable)) {
                const obsKey = key;
                const subKey = key;
                if (this.observable[obsKey] !== inputObservable[obsKey]) {
                    this.observable[obsKey] = inputObservable[obsKey];
                    if (this.subscription[subKey] !== undefined)
                        this.subscription[subKey].unsubscribe();
                    this.subscription[subKey] = this.observable[obsKey].subscribe({
                        next: (value) => {
                            this.context.euiSubscribe[obsKey] = value;
                            this.cdr.markForCheck();
                        },
                        error: () => ({}),
                    });
                }
            }
        }
    }
    constructor(viewContainer, cdr, templateReference) {
        this.viewContainer = viewContainer;
        this.cdr = cdr;
        this.templateReference = templateReference;
        this.context = new EuiSubscribeContext();
        this.observable = null;
        this.subscription = null;
    }
    ngOnInit() {
        this.viewContainer.createEmbeddedView(this.templateReference, this.context);
    }
    ngOnDestroy() {
        if (this.subscription === null)
            return;
        if (this.subscription instanceof Subscription) {
            this.subscription.unsubscribe();
        }
        else {
            for (const key of Object.keys(this.subscription))
                this.subscription[key].unsubscribe();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSubscribeDirective, deps: [{ token: i0.ViewContainerRef }, { token: i0.ChangeDetectorRef }, { token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.2.1", type: EuiSubscribeDirective, isStandalone: false, selector: "[euiSubscribe]", inputs: { euiSubscribe: "euiSubscribe" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiSubscribeDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[euiSubscribe]',
                    standalone: false
                }]
        }], ctorParameters: () => [{ type: i0.ViewContainerRef }, { type: i0.ChangeDetectorRef }, { type: i0.TemplateRef }], propDecorators: { euiSubscribe: [{
                type: Input
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
/** @ignore */
const EUI_UC_DIALOG_TEXT_DEFAULTS = {
    title: 'Unsaved Changes',
    body: 'There are unsaved changes on this page. Your changes will be lost if you leave without saving.',
    cancelButton: 'Cancel',
    discardButton: 'Discard changes',
};

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
/** @internal */
const EUI_TCM_DEFAULT_LABEL_TRANSLATIONS = {
    actionButtons: {
        selectLabel: 'Select:',
        allButton: 'All',
        allButtonTooltip: 'Select all columns',
        noneButton: 'None',
        noneButtonTooltip: 'Remove all column selections that are not required',
        resetButton: 'Default',
        resetButtonTooltip: 'Resets selection and order of all columns to the default state',
        activeOnlyToggle: 'Selected',
        showAllTooltip: 'Show all',
        showSelectedTooltip: 'Show selected only',
        applyButton: 'Apply',
        cancelButton: 'Cancel',
    },
    list: {
        searchPlaceholder: 'Search column names',
        dragHandleTooltip: 'Drag to reorder columns',
        inputAriaLabel: 'Enter the column order for the {columnName} column',
        requiredColumn: 'This column is required',
        noMatchingColumns: 'No columns match your search',
        noActiveMatchingColumns: 'No active columns match your search',
        inputTooltip: 'Set column order number then press the Enter/Return key',
        sort: {
            text: {
                asc: 'Active sort (A - Z)',
                desc: 'Active sort (Z - A)',
            },
            date: {
                asc: 'Active sort (oldest first)',
                desc: 'Active sort (newest first)',
            },
            boolean: {
                asc: 'Active sort (False - True)',
                desc: 'Active sort (True - False)',
            },
            number: {
                asc: 'Active sort (0 - 9)',
                desc: 'Active sort (9 - 0)',
            }
        }
    },
    sidesheet: {
        openButton: 'Show/Hide Columns',
        openerButtonTooltip: 'Manage table columns',
        title: 'Table Columns',
        unsavedChanges: structuredClone(EUI_UC_DIALOG_TEXT_DEFAULTS),
    },
};
/** @internal */
const EUI_TCM_NEW_TABLE_LAYOUT = {
    name: '',
    sort: { default: { active: '', direction: 'asc' }, current: { active: '', direction: 'asc' }, },
    columns: [
        { name: '', displayValue: '', required: false, default: { selected: false, sequence: 0 }, current: { selected: false, sequence: 0 }, },
    ],
};
/** @internal */
const EUI_TCM_NEW_SAVED_TABLE_LAYOUT = {
    sort: { active: '', direction: 'asc' },
    columns: [],
};
/** @internal */
const EUI_TCM_NEW_CONFIG = {
    tableLayout: EUI_TCM_NEW_TABLE_LAYOUT,
};

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
/**
 * A utility service with static methods to normalize the EuiTableColumnManagementConfig, convert layout structures,
 */
class EuiTableColumnUtilitiesService {
    /**
     * Processes a EuiTableColumnManagementConfig object to fill in default values
     *
     * @param config A EuiTableColumnManagementConfig structure. The structure is processed in place.
     */
    static normalizeConfig(config) {
        const names = config.tableLayout.columns.map((x) => (x.name));
        if ([...new Set(names)].length !== names.length) {
            throw new Error('Column names in a tableLayout must be unique');
        }
        config.labelTranslations = EuiTableColumnUtilitiesService.populateLabelTranslations(config.labelTranslations);
        EuiTableColumnUtilitiesService.normalizeDataTypes(config.tableLayout);
        config.useApplyCancel = !!config.useApplyCancel;
        config.hideSearch = !!config.hideSearch;
    }
    /**
     * Serializes a EuiTableColumnManagementTableLayout object to a JSON string of EuiTableColumnManagementSavedTableLayout that can then be saved to a user preferences data store.
     *
     * @param layout A EuiTableColumnManagementSavedTableLayout object to convert
     * @return A EuiTableColumnManagementSavedTableLayout as a JSON string
     *
     */
    static createSavedLayout(layout) {
        return JSON.stringify(EuiTableColumnUtilitiesService.convertToSaved(layout));
    }
    /**
     * Process a EuiTableColumnManagementSavedTableLayout object or a JSON string of such to populate an existing EuiTableColumnManagementTableLayout object
     *
     * @param savedLayout Either a JSON string or EuiTableColumnManagementSavedTableLayout object to process
     * @param existingLayout A EuiTableColumnManagementTableLayout to populate or update from the savedLayout
     *
     */
    static processSavedLayout(savedLayout, existingLayout) {
        let layout = EUI_TCM_NEW_SAVED_TABLE_LAYOUT;
        if (typeof savedLayout === 'string') {
            try {
                layout = JSON.parse(savedLayout);
            }
            catch {
                throw new Error('Unable to parse savedLayout string to EuiTableColumnManagementSavedTableLayout object.');
            }
        }
        else {
            layout = savedLayout;
        }
        existingLayout.sort.current.active = layout.sort.active;
        existingLayout.sort.current.direction = layout.sort.direction;
        layout.columns.forEach((column) => {
            const existingColumn = existingLayout.columns.find((x) => column.name === x.name);
            if (existingColumn) {
                existingColumn.current.selected = column.selected;
                existingColumn.current.sequence = column.sequence;
            }
        });
    }
    /**
     * Convert a EuiTableColumnManagementTableLayout to a EuiTableColumnManagementSavedTableLayout
     *
     * @param layout A EuiTableColumnManagementTableLayout to convert
     * @return A populated EuiTableColumnManagementSavedTableLayout object
     */
    static convertToSaved(layout) {
        const savedLayout = {
            sort: structuredClone(layout.sort.current),
            columns: layout.columns.map((x) => ({
                name: x.name,
                selected: x.current.selected,
                sequence: x.current.sequence,
            }))
        };
        return savedLayout;
    }
    /**
     * Compares an original and current EuiTableColumnManagementSavedTableLayout to detect changes
     *
     * @param original EuiTableColumnManagementSavedTableLayout
     * @param current EuiTableColumnManagementSavedTableLayout
     * @return boolean True if any changes are detected in sort or column selection / sequence
     */
    static anyEdits(original, current) {
        return current.sort.current.active !== original.sort.active ||
            current.sort.current.direction !== original.sort.direction ||
            original.columns.some((x) => {
                const target = current.columns.find((y) => y.name === x.name);
                if (target !== undefined && (target.current.selected !== x.selected || target.current.sequence !== x.sequence)) {
                    return true;
                }
            });
    }
    static normalizeDataTypes(tableLayout) {
        tableLayout.columns.forEach((c) => c.dataType = c.dataType ?? 'text');
    }
    static populateLabelTranslations(supplied) {
        const keys = Object.keys(supplied ?? {});
        let retval = {};
        if (supplied === null || keys.length === 0) {
            retval = structuredClone(EUI_TCM_DEFAULT_LABEL_TRANSLATIONS);
            return retval;
        }
        retval = EuiTableColumnUtilitiesService.doNested(supplied, EUI_TCM_DEFAULT_LABEL_TRANSLATIONS);
        if (retval.list.inputAriaLabel && !retval.list.inputAriaLabel.includes('{columnName}')) {
            retval.list.inputAriaLabel += ' {columnName}';
        }
        return retval;
    }
    static doNested(supplied, defaults) {
        const keys = Object.keys(defaults);
        const retval = {};
        keys.forEach(k => {
            if (supplied[k] === null || supplied[k] === undefined) {
                if (typeof defaults[k] === 'string') {
                    retval[k] = defaults[k];
                }
                else {
                    retval[k] = structuredClone(defaults[k]);
                }
            }
            else if (typeof supplied[k] === 'string') {
                retval[k] = supplied[k] || defaults[k];
            }
            else if (typeof supplied[k] === 'object') {
                retval[k] = EuiTableColumnUtilitiesService.doNested(supplied[k], defaults[k]);
            }
        });
        return retval;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTableColumnUtilitiesService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTableColumnUtilitiesService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTableColumnUtilitiesService, decorators: [{
            type: Injectable
        }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiUnsavedChangesDialogComponent {
    /** @ignore */
    constructor(dialogText, dialogRef) {
        this.dialogText = dialogText;
        this.dialogRef = dialogRef;
    }
    /** @ignore */
    buttonClicked(discard) {
        this.dialogRef.close(discard);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiUnsavedChangesDialogComponent, deps: [{ token: MAT_DIALOG_DATA }, { token: i1$7.MatDialogRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.2.1", type: EuiUnsavedChangesDialogComponent, isStandalone: false, selector: "eui-unsaved-changes-dialog", ngImport: i0, template: "<h1 mat-dialog-title>\n  <eui-icon icon=\"warning\"></eui-icon>\n  <span class=\"unsaved-changes-dialog-text title\">{{ dialogText.title }}</span>\n</h1>\n<div mat-dialog-content>\n   <p class=\"unsaved-changes-dialog-text body\">{{ dialogText.body }}</p>\n</div>\n<div mat-dialog-actions align=\"end\">\n  <button mat-stroked-button (click)=\"buttonClicked(false)\">\n     <span class=\"unsaved-changes-dialog-text cancelButton\">{{ dialogText.cancelButton }}</span>\n  </button>\n  <button mat-flat-button color=\"primary\" (click)=\"buttonClicked(true)\" cdkFocusInitial>\n     <span class=\"unsaved-changes-dialog-text discardButton\">{{ dialogText.discardButton }}</span>\n  </button>\n</div>\n", styles: [":host-context(.eui-dark-theme) h1.mat-mdc-dialog-title .eui-icon{color:#edbe8e}:host-context(.eui-dark-theme) div.mat-mdc-dialog-actions .mat-primary{background-color:#edbe8e}:host-context(.eui-contrast-theme) h1.mat-mdc-dialog-title .eui-icon{color:#f7e4d0}:host-context(.eui-contrast-theme) div.mat-mdc-dialog-actions .mat-primary{background-color:#f7e4d0}h1.mat-mdc-dialog-title .eui-icon{color:#e36a00}div.mat-mdc-dialog-actions .mat-primary{background-color:#e36a00}h1.mat-mdc-dialog-title .eui-icon{margin-right:8px;vertical-align:bottom}\n"], dependencies: [{ kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: i1$7.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$7.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$7.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "component", type: EuiIconComponent, selector: "eui-icon", inputs: ["aria-hidden", "setLineHeight", "icon", "size"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiUnsavedChangesDialogComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'eui-unsaved-changes-dialog', template: "<h1 mat-dialog-title>\n  <eui-icon icon=\"warning\"></eui-icon>\n  <span class=\"unsaved-changes-dialog-text title\">{{ dialogText.title }}</span>\n</h1>\n<div mat-dialog-content>\n   <p class=\"unsaved-changes-dialog-text body\">{{ dialogText.body }}</p>\n</div>\n<div mat-dialog-actions align=\"end\">\n  <button mat-stroked-button (click)=\"buttonClicked(false)\">\n     <span class=\"unsaved-changes-dialog-text cancelButton\">{{ dialogText.cancelButton }}</span>\n  </button>\n  <button mat-flat-button color=\"primary\" (click)=\"buttonClicked(true)\" cdkFocusInitial>\n     <span class=\"unsaved-changes-dialog-text discardButton\">{{ dialogText.discardButton }}</span>\n  </button>\n</div>\n", styles: [":host-context(.eui-dark-theme) h1.mat-mdc-dialog-title .eui-icon{color:#edbe8e}:host-context(.eui-dark-theme) div.mat-mdc-dialog-actions .mat-primary{background-color:#edbe8e}:host-context(.eui-contrast-theme) h1.mat-mdc-dialog-title .eui-icon{color:#f7e4d0}:host-context(.eui-contrast-theme) div.mat-mdc-dialog-actions .mat-primary{background-color:#f7e4d0}h1.mat-mdc-dialog-title .eui-icon{color:#e36a00}div.mat-mdc-dialog-actions .mat-primary{background-color:#e36a00}h1.mat-mdc-dialog-title .eui-icon{margin-right:8px;vertical-align:bottom}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }, { type: i1$7.MatDialogRef }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiUnsavedChangesService {
    /** @ignore */
    constructor(dialog) {
        this.dialog = dialog;
    }
    /**
     * Displays the "Unsaved changes" dialog.
     *
     * Can be used in places where the controlled element is a sidesheet.
     *
     * @param ref Reference to the sidesheet.
     * @param hasUnsavedChanges Function which controls when to display the warning (if true the warning will appear).
     * @param dialogText a structure containing pre-translated text to display in the dialog. Default English US text will be used if not supplied.
     * @param closeWith Optional parameter to pass when closing the sidesheet
     *
     */
    handleSidesheetUnsavedChanges(ref, hasUnsavedChanges, dialogText, closeWith) {
        const component = ref.componentInstance;
        component.disableClose = true;
        return ref
            .closeClicked()
            .pipe(switchMap(() => {
            if (hasUnsavedChanges()) {
                return this.openDialog(dialogText);
            }
            else {
                return of(true);
            }
        }), tap$1((result) => {
            if (result) {
                ref.close(closeWith ? closeWith() : undefined);
            }
        }), finalize$1(() => {
            // Must reset .disableClose, because in components where handleSidesheetUnsavedChanges(...) is not called, you are unable to close the sidesheet
            // e.g. "General" tab calls this method, but "History" tab does not
            component.disableClose = false;
        }));
    }
    /**
     * Displays the "Unsaved changes" dialog.
     *
     * Can be used in places where the controlled element is a dialog.
     *
     * @param ref Reference to the dialog.
     * @param hasUnsavedChanges Function which controls when to display the warning (if true the warning will appear).
     * @param dialogText a structure containing pre-translated text to display in the dialog. Default English US text will be used if not supplied.
     *
     */
    handleDialogUnsavedChanges(ref, hasUnsavedChanges, dialogText) {
        ref.disableClose = true;
        return merge(ref.backdropClick(), ref.keydownEvents())
            .pipe(switchMap((event) => {
            if (event instanceof MouseEvent || (event instanceof KeyboardEvent && event.key === 'Escape')) {
                if (hasUnsavedChanges()) {
                    return this.openDialog(dialogText);
                }
                else {
                    return of(true);
                }
            }
            return of(false);
        }), tap$1((result) => {
            if (result) {
                ref.close();
            }
        }));
    }
    /**
     * Displays the "Unsaved changes" dialog.
     *
     * @param dialogText a structure containing pre-translated text to display in the dialog. Default English US text will be used if not supplied.
     * @return True if discard changes option is clicked
     * @return False if cancel option is clicked
     *
     */
    showUnsavedChangesWarning(dialogText) {
        return this.openDialog(dialogText);
    }
    openDialog(dialogText) {
        dialogText = this.populateTranslations(dialogText);
        return this.dialog.open(EuiUnsavedChangesDialogComponent, {
            autoFocus: true,
            data: dialogText,
            width: '400px'
        }).afterClosed();
    }
    populateTranslations(supplied) {
        const keys = Object.keys(supplied ?? {});
        let retval = {};
        if (supplied === null || keys.length === 0) {
            retval = structuredClone(EUI_UC_DIALOG_TEXT_DEFAULTS);
            return retval;
        }
        // Dialog text defaults are currently a single-level object. If it eventually becomes nested
        // objects then a recursive approach will be required, like in EuiTableColumnUtilitiesService.
        Object.keys(EUI_UC_DIALOG_TEXT_DEFAULTS).forEach(k => {
            const k1 = k;
            if (supplied[k1] === null || supplied[k1] === undefined) {
                if (typeof EUI_UC_DIALOG_TEXT_DEFAULTS[k1] === 'string') {
                    retval[k1] = EUI_UC_DIALOG_TEXT_DEFAULTS[k1];
                }
                else {
                    retval[k1] = structuredClone(EUI_UC_DIALOG_TEXT_DEFAULTS[k1]);
                }
            }
            else if (typeof supplied[k1] === 'string') {
                retval[k1] = supplied[k1] || EUI_UC_DIALOG_TEXT_DEFAULTS[k1];
            }
        });
        return retval;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiUnsavedChangesService, deps: [{ token: i1$7.MatDialog }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiUnsavedChangesService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiUnsavedChangesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1$7.MatDialog }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
/**
 * Directive that applies tooltip behavior to overflowing text elements.
 *
 * This directive automatically applies an overflow styling class and sets a fallback width
 * if the element does not have a defined width. It also configures the tooltip message and delay.
 *
 * Configuration:
 * - Accepts optional injection of EUI_TOOLTIP_DEFAULTS to override default values.
 *
 * Host Directives:
 * - MatTooltip: Inherited tooltip behavior from Angular Material.
 */
class EuiOverflowTooltipDirective {
    /**
     * Tooltip message to display. If not provided, the element's text content is used.
     *
     * @category Input
     */
    set euiOverflowTooltip(value) {
        this._euiOverflowTooltip = value;
        this.updateTooltip();
    }
    get euiOverflowTooltip() {
        return this._euiOverflowTooltip;
    }
    /** @internal */
    constructor(config) {
        /**
         * Delay in milliseconds before showing the tooltip (default is 500ms).
         *
         * @category Input
         */
        this.matTooltipShowDelay = 500;
        /**
         * CSS variable name to use for fallback width. (default is '--eui-default-max-width').
         *
         * @category Input
         */
        this.cssFallbackWidthVariableName = '--eui-default-max-width';
        /** @internal */
        this.matTooltip = inject(MatTooltip);
        /** @internal */
        this.elementRef = inject(ElementRef);
        /** @internal */
        this.renderer = inject(Renderer2);
        /** @internal */
        this.cdr = inject(ChangeDetectorRef);
        this.globalOverflowClass = 'eui-text-ellipsis';
        this.globalOverflowClass = config?.globalOverflowClass ?? 'eui-text-ellipsis';
        this.matTooltipShowDelay = config?.matTooltipShowDelay ?? 500;
        this.cssFallbackWidthVariableName = config?.cssFallbackWidthVariableName ?? '--eui-default-max-width';
    }
    /** @internal */
    ngOnInit() {
        this.applyOverflowStyling();
    }
    /** @internal */
    ngAfterViewInit() {
        this.updateTooltip();
        this.cdr.detectChanges();
    }
    /** @internal */
    updateTooltip() {
        this.matTooltip.showDelay = this.matTooltipShowDelay;
        // If explicitly set to null, empty tooltip
        if (this._euiOverflowTooltip === null) {
            this.matTooltip.message = '';
        }
        else {
            const element = this.elementRef.nativeElement;
            const message = this._euiOverflowTooltip || element.textContent || '';
            this.matTooltip.message = message.trim();
        }
    }
    /** @internal */
    applyOverflowStyling() {
        const element = this.elementRef.nativeElement;
        this.renderer.addClass(element, this.globalOverflowClass);
        const computedStyle = getComputedStyle(element);
        const maxWidthNotSet = computedStyle.maxWidth === 'none' || computedStyle.maxWidth === '';
        if (maxWidthNotSet) {
            this.renderer.setStyle(element, 'max-width', `var(${this.cssFallbackWidthVariableName})`);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiOverflowTooltipDirective, deps: [{ token: EUI_TOOLTIP_DEFAULTS, optional: true }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.2.1", type: EuiOverflowTooltipDirective, isStandalone: false, selector: "[euiOverflowTooltip]", inputs: { euiOverflowTooltip: "euiOverflowTooltip", matTooltipShowDelay: "matTooltipShowDelay", cssFallbackWidthVariableName: "cssFallbackWidthVariableName" }, hostDirectives: [{ directive: i1$6.MatTooltip, inputs: ["matTooltipPosition", "matTooltipPosition", "matTooltipDisabled", "matTooltipDisabled", "matTooltipHideDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltipTouchGestures", "matTooltipClass", "matTooltipClass"] }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiOverflowTooltipDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[euiOverflowTooltip]',
                    standalone: false,
                    hostDirectives: [
                        {
                            directive: MatTooltip,
                            inputs: [
                                'matTooltipPosition: matTooltipPosition',
                                'matTooltipDisabled: matTooltipDisabled',
                                'matTooltipHideDelay: matTooltipHideDelay',
                                'matTooltipTouchGestures: matTooltipTouchGestures',
                                'matTooltipClass: matTooltipClass',
                            ]
                        }
                    ],
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [EUI_TOOLTIP_DEFAULTS]
                }] }], propDecorators: { euiOverflowTooltip: [{
                type: Input
            }], matTooltipShowDelay: [{
                type: Input
            }], cssFallbackWidthVariableName: [{
                type: Input
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiTableColumnManagementSelectColumnsComponent {
    get filteredColumns() {
        if (this.tableLayout) {
            return this.tableLayout.columns
                .sort((a, b) => a.current.sequence - b.current.sequence)
                .filter((x) => (x.current.selected || !this.showOnlySelected.value) && (!this.isFiltered || this.filteredColumnNames.includes(x.displayValue)));
        }
        else {
            return [];
        }
    }
    get allDefaults() {
        return this.tableLayout.columns.every((a) => a.current.sequence == a.default.sequence && a.current.selected == a.default.selected);
    }
    // Slightly misleading name. Required columns are *always* selected so they are ignored.
    get noneSelected() {
        return this.tableLayout.columns.filter((a) => !a.required).every((a) => !a.current.selected);
    }
    get allSelected() {
        return this.tableLayout.columns.every((a) => a.current.selected);
    }
    get allRequired() {
        return this.tableLayout.columns.every((a) => a.required);
    }
    get anyEdits() {
        return EuiTableColumnUtilitiesService.anyEdits(this.originalLayout, this.tableLayout);
    }
    constructor(data, sidesheet, sidesheetRef, destroyRef, unsavedChanges) {
        this.data = data;
        this.sidesheet = sidesheet;
        this.sidesheetRef = sidesheetRef;
        this.destroyRef = destroyRef;
        this.unsavedChanges = unsavedChanges;
        this.showOnlySelected = new FormControl(false, { nonNullable: true });
        this.searchFormControl = new FormControl('');
        this.isDragging = false;
        this.useApplyCancel = false;
        this.showSearch = false;
        this.isFiltered = false;
        this.testId = 'table-column-management-select-columns';
        this.filteredColumnNames = [];
        this.destroy = new Subject();
        this.saving = false;
        this.filterValueChange = () => {
            if (this.searchFormControl.valid) {
                this.filterColumns();
            }
        };
        this.labelTranslations = data.labelTranslations;
        this.tableLayout = data.tableLayout;
        this.originalLayout = EuiTableColumnUtilitiesService.convertToSaved(data.tableLayout);
        this.useApplyCancel = data.useApplyCancel;
        this.testId = data.testId || this.testId;
        this.showSearch = !(data.hideSearch ?? false);
        this.destroyRef.onDestroy(() => {
            this.destroy.next(true);
            this.destroy.complete();
        });
    }
    ngOnInit() {
        this.searchFormControl.valueChanges
            .pipe(takeUntil$1(this.destroy), debounceTime$1(500))
            .subscribe(this.filterValueChange);
        if (this.useApplyCancel) {
            this.unsavedChanges
                .handleSidesheetUnsavedChanges(this.sidesheetRef, () => this.anyEdits && !this.saving, this.labelTranslations.sidesheet.unsavedChanges)
                .pipe(takeUntil$1(this.destroy))
                .subscribe();
        }
    }
    selectColumn(selectedColumn, event) {
        // We'll never get a column that can't be found, so tell the compiler it's ok
        // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
        const column = this.tableLayout.columns.find((x) => x.name === selectedColumn.name);
        column.current.selected = event.checked !== undefined ? event.checked : !column.current.selected;
    }
    moveColumn(event) {
        const current = this.filteredColumns.map((x) => ({ name: x.name, sequence: x.current.sequence }));
        moveItemInArray(current, event.previousIndex, event.currentIndex);
        current.forEach((x, index) => {
            // Tell the compiler we know what we're doing with non-null assertions
            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
            this.tableLayout.columns.find((column) => column.name === x.name).current.sequence = index;
        });
    }
    setDragging(dragging) {
        const body = document.body;
        this.isDragging = dragging;
        if (dragging) {
            body.classList.add('force-dragging-cursor');
        }
        else {
            body.classList.remove('force-dragging-cursor');
        }
    }
    selectAll() {
        this.tableLayout.columns.forEach((x) => x.current.selected = true);
    }
    selectNone() {
        this.tableLayout.columns.forEach((x) => x.current.selected = x.required || false);
    }
    resetToDefault() {
        this.tableLayout.columns.forEach((x) => {
            x.current.selected = x.default.selected;
            x.current.sequence = x.default.sequence;
        });
    }
    editColumnSequence(event, column) {
        const newSequence = event.target.value.trim();
        if (newSequence === '') {
            event.target.value = column.current.sequence + 1;
            return;
        }
        let newIndex = parseInt(newSequence, 10);
        if (newIndex.toString() !== newSequence) {
            // type=number inputs allow things that *could* be numeric and
            // will pass parseInt(), like, 2e3 == 2 * 10^3, but parseInt calls
            // it "2".  So if what they put in doesn't match what it *should*
            // look like then throw it away and put the old value back.
            event.target.value = column.current.sequence + 1;
            return;
        }
        newIndex--;
        if (newIndex === column.current.sequence) {
            event.target.value = column.current.sequence + 1;
            return;
        }
        const current = this.filteredColumns
            .map((x) => x.current)
            .sort((a, b) => a.sequence - b.sequence);
        if (newIndex < 0) {
            newIndex = 0;
            event.target.value = newIndex + 1;
        }
        else if (newIndex > current.length - 1) {
            newIndex = current.length;
            event.target.value = newIndex;
        }
        moveItemInArray(current, column.current.sequence, newIndex);
        current.forEach((x, i) => x.sequence = i);
        setTimeout(() => {
            event.target.scrollIntoView({ block: 'center', behavior: 'auto' });
            event.target.focus();
            event.target.select();
        }, 100);
    }
    cancel() {
        this.sidesheet.close(false);
    }
    apply() {
        this.saving = true;
        this.sidesheet.close(true);
    }
    filterColumns() {
        const searchText = this.searchFormControl.value ? this.searchFormControl.value.trim().toLowerCase() : '';
        const columnNames = this.tableLayout.columns
            .filter((column) => searchText === '' || column.displayValue.toLowerCase().includes(searchText))
            .map((column) => (column.displayValue));
        this.isFiltered = searchText !== '';
        this.filteredColumnNames = columnNames;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTableColumnManagementSelectColumnsComponent, deps: [{ token: EUI_SIDESHEET_DATA }, { token: EuiSidesheetService }, { token: EuiSidesheetRef }, { token: i0.DestroyRef }, { token: EuiUnsavedChangesService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.2.1", type: EuiTableColumnManagementSelectColumnsComponent, isStandalone: false, selector: "eui-table-column-management-select-columns", viewQueries: [{ propertyName: "searchInput", first: true, predicate: ["searchInput"], descendants: true }], ngImport: i0, template: "<div eui-sidesheet-content class=\"select-columns\">\n  @if (showSearch) {\n     <div class=\"search\">\n       <eui-search\n         #searchInput\n         [placeholder]=\"labelTranslations.list.searchPlaceholder\"\n         width=\"100%\"\n         size=\"m\"\n         [searchControl]=\"searchFormControl\"\n         attr.data-testid=\"{{testId}.search\"></eui-search>\n     </div>\n  }\n\n  <div class=\"select-columns__header-actions\">\n    <div class=\"buttons\">\n      @if (!isFiltered) {\n      <span class=\"label\">{{ labelTranslations.actionButtons.selectLabel }}</span>\n      <a\n        euiClickable\n        [ngClass]=\"{'eui-clickable': true, 'eui-clickable--primary': !allSelected, 'eui-clickable--disabled': allSelected }\"\n        (click)=\"selectAll()\"\n        [euiClickableDisabled]=\"allSelected\"\n        [matTooltip]=\"allSelected ? null : labelTranslations.actionButtons.allButtonTooltip\"\n        [matTooltipShowDelay]=\"500\"\n        attr.data-testid=\"{{testId}}.select-all\">\n        {{ labelTranslations.actionButtons.allButton }}\n      </a>\n      <a\n        euiClickable\n        [ngClass]=\"{'eui-clickable': true, 'eui-clickable--primary': !(allRequired || noneSelected), 'eui-clickable--disabled': allRequired || noneSelected }\"\n        (click)=\"selectNone()\"\n        [euiClickableDisabled]=\"allRequired || noneSelected\"\n        [matTooltip]=\"allRequired || noneSelected ? null : labelTranslations.actionButtons.noneButtonTooltip\"\n        [matTooltipShowDelay]=\"500\"\n        attr.data-testid=\"{{testId}}.select-none\">\n        {{ labelTranslations.actionButtons.noneButton }}\n      </a>\n      <a\n        euiClickable\n        [ngClass]=\"{'eui-clickable': true, 'eui-clickable--primary': !allDefaults, 'eui-clickable--disabled': allDefaults }\"\n        (click)=\"resetToDefault()\"\n        [euiClickableDisabled]=\"allDefaults\"\n        [matTooltip]=\"allDefaults ? null : labelTranslations.actionButtons.resetButtonTooltip\"\n        [matTooltipShowDelay]=\"500\"\n        attr.data-testid=\"{{testId}}.default\">\n        {{ labelTranslations.actionButtons.resetButton }}\n      </a>\n      }\n    </div>\n\n    <mat-slide-toggle\n      [formControl]=\"showOnlySelected\"\n      labelPosition=\"before\"\n      [matTooltipShowDelay]=\"500\"\n      [matTooltip]=\"showOnlySelected.value ? labelTranslations.actionButtons.showAllTooltip : labelTranslations.actionButtons.showSelectedTooltip\"\n      attr.data-testid=\"{{testId}}.show-selected-checkbox\">\n      {{ labelTranslations.actionButtons.activeOnlyToggle }}\n    </mat-slide-toggle>\n  </div>\n\n  <div class=\"select-columns__list\" [ngClass]=\"{ 'use-apply-cancel': useApplyCancel, 'show-search': showSearch }\" cdkDropList (cdkDropListDropped)=\"moveColumn($event)\">\n    @if (filteredColumns.length === 0) {\n      <h4 class=\"report-column eui-list-row no-results\">{{ showOnlySelected.value ? labelTranslations.list.noActiveMatchingColumns : labelTranslations.list.noMatchingColumns }}</h4>\n    }\n    @for (column of filteredColumns; track column; let index = $index) {\n      <div\n        class=\"report-column eui-list-row\"\n        cdkDrag\n        [cdkDragData]=\"column\"\n        cdkDragLockAxis=\"y\"\n        [cdkDragDisabled]=\"isFiltered\"\n        [ngClass]=\"{\n           'eui-list-selectable-row': !column.required,\n           'eui-list-row-selected': column.current.selected,\n           'eui-list-row-disabled': !column.current.selected\n        }\"\n        (cdkDragStarted)=\"setDragging(true)\"\n        (cdkDragEnded)=\"setDragging(false)\">\n        <div class=\"report-column-placeholder\" *cdkDragPlaceholder></div>\n        <div class=\"handle-name-sort\">\n           @if (!isFiltered) {\n             <button\n               matIconButton\n               cdkDragHandle\n               class=\"handle\"\n               [euiTooltip]=\"labelTranslations.list.dragHandleTooltip\"\n               [attr.data-testid]=\"testId + '.drag-handle.' + column.name\">\n               <eui-icon size=\"20px\" icon=\"draghandles\"/>\n             </button>\n\n             <eui-form-field\n               [hideMargins]=\"true\"\n               class=\"sequence-form-field\"\n               appearance=\"outline\">\n               <input\n                 matInput\n                 class=\"sequence-input\"\n                 type=\"number\"\n                 [attr.aria-label]=\"labelTranslations.list.inputAriaLabel.replace('{columnName}', column.displayValue)\"\n                 min=\"1\"\n                 [euiTooltip]=\"labelTranslations.list.inputTooltip\"\n                 [max]=\"filteredColumns.length\"\n                 [value]=\"index + 1\"\n                 (change)=\"editColumnSequence($event, column)\"\n                 [attr.data-testid]=\"testId + '.sequence-edit.' + column.name\">\n             </eui-form-field>\n           }\n\n          <div class=\"name\">\n            <span class=\"selection-control\">\n              @if (column.required) {\n                <span class=\"select-control-disabled\">\n                  <eui-icon\n                    size=\"20px\"\n                    icon=\"check\"\n                    [euiTooltip]=\"labelTranslations.list.requiredColumn\"\n                  />\n                </span>\n                <span cdkDragHandle euiOverflowTooltip class=\"column-display-name\" [ngClass]=\"{handle: !isFiltered, sorted: column.name === tableLayout.sort.current.active}\">{{ column.displayValue }}</span>\n              } @else {\n                <mat-checkbox\n                  [checked]=\"column.current.selected\"\n                  (change)=\"selectColumn(column, $event)\"\n                  [attr.data-testid]=\"testId + '.select.' + column.name\">\n                  <span cdkDragHandle euiOverflowTooltip class=\"column-display-name\" [ngClass]=\"{handle: !isFiltered, sorted: column.name === tableLayout.sort.current.active}\">{{ column.displayValue }}</span>\n                </mat-checkbox>\n              }\n            </span>\n\n            @if (column.name === tableLayout.sort.current.active && tableLayout.sort.current.direction) {\n              <span class=\"sort-indicator\">\n                <eui-icon\n                  size=\"16px\"\n                  [icon]=\"tableLayout.sort.current.direction === 'asc' ? 'sortup' : 'sortdown'\"\n                  [euiTooltip]=\"labelTranslations.list.sort[column.dataType ?? 'text'][tableLayout.sort.current.direction]\"\n                />\n              </span>\n            }\n          </div>\n        </div>\n      </div>\n    }\n  </div>\n</div>\n@if (useApplyCancel) {\n  <div eui-sidesheet-actions class=\"footer-buttons\">\n     <button mat-stroked-button\n       (click)=\"cancel()\"\n       attr.data-testid=\"{{testId}}.cancel\">\n        {{ labelTranslations.actionButtons.cancelButton }}\n     </button>\n\n     <button mat-flat-button\n       color=\"primary\"\n       (click)=\"apply()\"\n       [disabled]=\"!anyEdits\"\n       attr.data-testid=\"{{testId}}.apply\">\n        {{ labelTranslations.actionButtons.applyButton }}\n     </button>\n  </div>\n}\n", styles: [".eui-sidesheet-content{padding-bottom:0}:host-context(.eui-dark-theme) .select-columns__list{border-top:1px solid #dfe4e6}:host-context(.eui-dark-theme) .report-column{border-bottom:1px solid #dfe4e6}:host-context(.eui-dark-theme) .handle-name-sort .name .selection-control .eui-icon{color:#c4cacc}:host-context(.eui-dark-theme) .handle-name-sort .name .selection-control .sort-indicator{color:#aab0b3}:host-context(.eui-dark-theme) .cdk-drag-preview{box-shadow:0 5px 5px -3px #0003,0 8px 10px 1px #00000024,0 3px 14px 2px #0000001f;background-color:#000!important}:host-context(.eui-dark-theme) .report-column-placeholder{background:#232626;border-bottom:1px solid #dfe4e6}:host-context(.eui-dark-theme) .eui-list-row.eui-list-row-selected,:host-context(.eui-dark-theme) .eui-list-row.eui-list-row-selected.eui-list-selectable-row:not(.eui-list-row-selected):hover{background-color:#016b9140}:host-context(.eui-dark-theme) .eui-list-row.eui-list-row-disabled.eui-list-selectable-row:not(.oic-row-selected):hover{background-color:#18191a}:host-context(.eui-contrast-theme) .select-columns__list{border-top:1px solid #dfe4e6}:host-context(.eui-contrast-theme) .report-column{border-bottom:1px solid #dfe4e6}:host-context(.eui-contrast-theme) .handle-name-sort .name .selection-control .eui-icon{color:#c4cacc}:host-context(.eui-contrast-theme) .handle-name-sort .name .selection-control .sort-indicator{color:#aab0b3}:host-context(.eui-contrast-theme) .cdk-drag-preview{box-shadow:0 5px 5px -3px #0003,0 8px 10px 1px #00000024,0 3px 14px 2px #0000001f;background-color:#000!important}:host-context(.eui-contrast-theme) .report-column-placeholder{background:#232626;border-bottom:1px solid #dfe4e6}:host-context(.eui-contrast-theme) .eui-list-row.eui-list-row-selected,:host-context(.eui-contrast-theme) .eui-list-row.eui-list-row-selected.eui-list-selectable-row:not(.eui-list-row-selected):hover{background-color:#016b9140}:host-context(.eui-contrast-theme) .eui-list-row.eui-list-row-disabled.eui-list-selectable-row:not(.oic-row-selected):hover{background-color:#18191a}.select-columns__list{border-top:1px solid #c4cacc}.report-column{border-bottom:1px solid #c4cacc}.handle-name-sort .name .selection-control .eui-icon{color:#919799}.handle-name-sort .name .selection-control .sort-indicator{color:#616566}.cdk-drag-preview{box-shadow:0 5px 5px -3px #0003,0 8px 10px 1px #00000024,0 3px 14px 2px #0000001f;background-color:#ffffffbf!important}.report-column-placeholder{background:#dfe4e6;border-bottom:1px solid #c4cacc}.eui-list-row.eui-list-row-selected,.eui-list-row.eui-list-row-selected.eui-list-selectable-row:not(.eui-list-row-selected):hover{background-color:#0a96d10f}.eui-list-row.eui-list-row-disabled.eui-list-selectable-row:not(.oic-row-selected):hover{background-color:#f9fbfc}::ng-deep body.force-dragging-cursor *{cursor:grabbing!important}.eui-text-ellipsis{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.select-columns{display:flex;flex-direction:column;gap:16px;overflow:auto}.select-columns__header-actions{display:flex;justify-content:space-between;align-items:center}.select-columns__header-actions .buttons{display:flex;gap:16px;height:36px;align-items:center}.select-columns__header-actions .buttons .label,.select-columns__header-actions .buttons a{font-weight:600;font-size:14px}.select-columns__header-actions .buttons a.eui-clickable--disabled{text-decoration:none}.select-columns__list{overflow-y:auto;overflow-x:hidden;font-size:14px}.select-columns__list>:last-child{margin-bottom:20px}.report-column{height:52px;width:410px;padding:0 21px 0 8px;display:flex;flex-direction:row;align-items:center;gap:16px}.report-column .select-control-disabled{width:36px;text-align:center}.handle-name-sort{display:flex;flex-direction:row;gap:8px;flex-grow:1}.handle-name-sort .sequence-form-field{height:36px;width:40px}.handle-name-sort .sequence-form-field input.sequence-input{text-align:right}.handle-name-sort .sequence-form-field ::ng-deep .mat-mdc-text-field-wrapper{padding:0 8px}.handle-name-sort .handle{cursor:grab}.handle-name-sort .handle:active{cursor:grabbing}.handle-name-sort .name{flex-grow:1;display:flex;flex-direction:row;gap:4px;align-items:center;justify-content:space-between}.handle-name-sort .name .selection-control{display:flex;flex-direction:row;gap:4px;width:100%}.handle-name-sort .name .selection-control .column-display-name{font-weight:600;display:inline-block;width:100%;--eui-default-max-width: 249px}.handle-name-sort .name .selection-control .sorted{--eui-default-max-width: 219px}.handle-name-sort .name .selection-control ::ng-deep .mat-mdc-checkbox{width:100%}.handle-name-sort .name .selection-control ::ng-deep .mat-mdc-checkbox ::ng-deep .mdc-form-field{width:100%}.handle-name-sort .name .selection-control ::ng-deep .mat-mdc-checkbox ::ng-deep .mdc-form-field ::ng-deep .mdc-label{width:100%}.handle-name-sort .name .selection-control ::ng-deep .mat-mdc-checkbox ::ng-deep .mdc-form-field ::ng-deep .mdc-label>div{width:100%}.handle-name-sort .name .selection-control .eui-icon{width:36px}.handle-name-sort .name .selection-control .sort-indicator{flex:0 0 20px}input.sequence-input::-webkit-outer-spin-button,input.sequence-input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}input.sequence-input[type=number]{-moz-appearance:textfield}.cdk-drag-preview{box-sizing:border-box;border-radius:4px;box-shadow:0 5px 5px -3px #0003,0 8px 10px 1px #00000024,0 3px 14px 2px #0000001f;display:flex;align-items:center;justify-content:center}.cdk-drag-animating{transition:transform .25s cubic-bezier(0,0,.2,1)}.select-columns__list.cdk-drop-list-dragging .report-column:not(.cdk-drag-placeholder){transition:transform .25s cubic-bezier(0,0,.2,1)}.report-column-placeholder{min-height:52px;width:400px;transition:transform .25s cubic-bezier(0,0,.2,1);display:flex;flex-direction:row;align-items:center;gap:16px}.footer-buttons{border-top:1px solid rgba(0,0,0,.2)}.no-results{color:#616566;justify-content:center;padding:64px 0}@media screen and (max-width: 768px){.report-column,.report-column-placeholder{width:100%}}@media screen and (max-width: 480px){.select-columns__header-actions{flex-direction:column;gap:16px;align-items:flex-start}}:host-context([dir=rtl]) .report-column{padding:0 8px 0 21px}:host-context([dir=rtl]) .handle-name-sort .sequence-form-field input.sequence-input{text-align:left}.eui-list-row:not(.eui-list-row-selected):not(.eui-list-selectable-row):hover{background-color:transparent}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i6$1.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "aria-expanded", "aria-controls", "aria-owns", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "component", type: i8$1.MatSlideToggle, selector: "mat-slide-toggle", inputs: ["name", "id", "labelPosition", "aria-label", "aria-labelledby", "aria-describedby", "required", "color", "disabled", "disableRipple", "tabIndex", "checked", "hideIcon", "disabledInteractive"], outputs: ["change", "toggleChange"], exportAs: ["matSlideToggle"] }, { kind: "directive", type: i1$6.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "directive", type: i10.CdkDropList, selector: "[cdkDropList], cdk-drop-list", inputs: ["cdkDropListConnectedTo", "cdkDropListData", "cdkDropListOrientation", "id", "cdkDropListLockAxis", "cdkDropListDisabled", "cdkDropListSortingDisabled", "cdkDropListEnterPredicate", "cdkDropListSortPredicate", "cdkDropListAutoScrollDisabled", "cdkDropListAutoScrollStep", "cdkDropListElementContainer", "cdkDropListHasAnchor"], outputs: ["cdkDropListDropped", "cdkDropListEntered", "cdkDropListExited", "cdkDropListSorted"], exportAs: ["cdkDropList"] }, { kind: "directive", type: i10.CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: i10.CdkDragHandle, selector: "[cdkDragHandle]", inputs: ["cdkDragHandleDisabled"] }, { kind: "directive", type: i10.CdkDragPlaceholder, selector: "ng-template[cdkDragPlaceholder]", inputs: ["data"] }, { kind: "directive", type: i6.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i6.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "component", type: EuiIconComponent, selector: "eui-icon", inputs: ["aria-hidden", "setLineHeight", "icon", "size"] }, { kind: "component", type: EuiSearchComponent, selector: "eui-search", inputs: ["customFiltersConfig", "placeholder", "searchControl", "width", "disabled"], outputs: ["searchIconClick", "customFiltersChanged"] }, { kind: "directive", type: EuiSidesheetContentDirective, selector: "[eui-sidesheet-content], eui-sidesheet-content, [euiSidesheetContent]" }, { kind: "directive", type: EuiSidesheetActionsDirective, selector: "[eui-sidesheet-actions], eui-sidesheet-actions, [euiSidesheetActions]" }, { kind: "directive", type: EuiClickableDirective, selector: "[euiClickable]", inputs: ["euiClickable", "euiClickableDisabled"] }, { kind: "component", type: EuiFormFieldComponent, selector: "eui-form-field", inputs: ["appearance", "hideMargins", "width", "useLegacyFloatingLabel", "readonly"] }, { kind: "directive", type: EuiOverflowTooltipDirective, selector: "[euiOverflowTooltip]", inputs: ["euiOverflowTooltip", "matTooltipShowDelay", "cssFallbackWidthVariableName"] }, { kind: "directive", type: EuiTooltipDirective, selector: "[euiTooltip]", inputs: ["euiTooltip", "matTooltipShowDelay"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTableColumnManagementSelectColumnsComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'eui-table-column-management-select-columns', template: "<div eui-sidesheet-content class=\"select-columns\">\n  @if (showSearch) {\n     <div class=\"search\">\n       <eui-search\n         #searchInput\n         [placeholder]=\"labelTranslations.list.searchPlaceholder\"\n         width=\"100%\"\n         size=\"m\"\n         [searchControl]=\"searchFormControl\"\n         attr.data-testid=\"{{testId}.search\"></eui-search>\n     </div>\n  }\n\n  <div class=\"select-columns__header-actions\">\n    <div class=\"buttons\">\n      @if (!isFiltered) {\n      <span class=\"label\">{{ labelTranslations.actionButtons.selectLabel }}</span>\n      <a\n        euiClickable\n        [ngClass]=\"{'eui-clickable': true, 'eui-clickable--primary': !allSelected, 'eui-clickable--disabled': allSelected }\"\n        (click)=\"selectAll()\"\n        [euiClickableDisabled]=\"allSelected\"\n        [matTooltip]=\"allSelected ? null : labelTranslations.actionButtons.allButtonTooltip\"\n        [matTooltipShowDelay]=\"500\"\n        attr.data-testid=\"{{testId}}.select-all\">\n        {{ labelTranslations.actionButtons.allButton }}\n      </a>\n      <a\n        euiClickable\n        [ngClass]=\"{'eui-clickable': true, 'eui-clickable--primary': !(allRequired || noneSelected), 'eui-clickable--disabled': allRequired || noneSelected }\"\n        (click)=\"selectNone()\"\n        [euiClickableDisabled]=\"allRequired || noneSelected\"\n        [matTooltip]=\"allRequired || noneSelected ? null : labelTranslations.actionButtons.noneButtonTooltip\"\n        [matTooltipShowDelay]=\"500\"\n        attr.data-testid=\"{{testId}}.select-none\">\n        {{ labelTranslations.actionButtons.noneButton }}\n      </a>\n      <a\n        euiClickable\n        [ngClass]=\"{'eui-clickable': true, 'eui-clickable--primary': !allDefaults, 'eui-clickable--disabled': allDefaults }\"\n        (click)=\"resetToDefault()\"\n        [euiClickableDisabled]=\"allDefaults\"\n        [matTooltip]=\"allDefaults ? null : labelTranslations.actionButtons.resetButtonTooltip\"\n        [matTooltipShowDelay]=\"500\"\n        attr.data-testid=\"{{testId}}.default\">\n        {{ labelTranslations.actionButtons.resetButton }}\n      </a>\n      }\n    </div>\n\n    <mat-slide-toggle\n      [formControl]=\"showOnlySelected\"\n      labelPosition=\"before\"\n      [matTooltipShowDelay]=\"500\"\n      [matTooltip]=\"showOnlySelected.value ? labelTranslations.actionButtons.showAllTooltip : labelTranslations.actionButtons.showSelectedTooltip\"\n      attr.data-testid=\"{{testId}}.show-selected-checkbox\">\n      {{ labelTranslations.actionButtons.activeOnlyToggle }}\n    </mat-slide-toggle>\n  </div>\n\n  <div class=\"select-columns__list\" [ngClass]=\"{ 'use-apply-cancel': useApplyCancel, 'show-search': showSearch }\" cdkDropList (cdkDropListDropped)=\"moveColumn($event)\">\n    @if (filteredColumns.length === 0) {\n      <h4 class=\"report-column eui-list-row no-results\">{{ showOnlySelected.value ? labelTranslations.list.noActiveMatchingColumns : labelTranslations.list.noMatchingColumns }}</h4>\n    }\n    @for (column of filteredColumns; track column; let index = $index) {\n      <div\n        class=\"report-column eui-list-row\"\n        cdkDrag\n        [cdkDragData]=\"column\"\n        cdkDragLockAxis=\"y\"\n        [cdkDragDisabled]=\"isFiltered\"\n        [ngClass]=\"{\n           'eui-list-selectable-row': !column.required,\n           'eui-list-row-selected': column.current.selected,\n           'eui-list-row-disabled': !column.current.selected\n        }\"\n        (cdkDragStarted)=\"setDragging(true)\"\n        (cdkDragEnded)=\"setDragging(false)\">\n        <div class=\"report-column-placeholder\" *cdkDragPlaceholder></div>\n        <div class=\"handle-name-sort\">\n           @if (!isFiltered) {\n             <button\n               matIconButton\n               cdkDragHandle\n               class=\"handle\"\n               [euiTooltip]=\"labelTranslations.list.dragHandleTooltip\"\n               [attr.data-testid]=\"testId + '.drag-handle.' + column.name\">\n               <eui-icon size=\"20px\" icon=\"draghandles\"/>\n             </button>\n\n             <eui-form-field\n               [hideMargins]=\"true\"\n               class=\"sequence-form-field\"\n               appearance=\"outline\">\n               <input\n                 matInput\n                 class=\"sequence-input\"\n                 type=\"number\"\n                 [attr.aria-label]=\"labelTranslations.list.inputAriaLabel.replace('{columnName}', column.displayValue)\"\n                 min=\"1\"\n                 [euiTooltip]=\"labelTranslations.list.inputTooltip\"\n                 [max]=\"filteredColumns.length\"\n                 [value]=\"index + 1\"\n                 (change)=\"editColumnSequence($event, column)\"\n                 [attr.data-testid]=\"testId + '.sequence-edit.' + column.name\">\n             </eui-form-field>\n           }\n\n          <div class=\"name\">\n            <span class=\"selection-control\">\n              @if (column.required) {\n                <span class=\"select-control-disabled\">\n                  <eui-icon\n                    size=\"20px\"\n                    icon=\"check\"\n                    [euiTooltip]=\"labelTranslations.list.requiredColumn\"\n                  />\n                </span>\n                <span cdkDragHandle euiOverflowTooltip class=\"column-display-name\" [ngClass]=\"{handle: !isFiltered, sorted: column.name === tableLayout.sort.current.active}\">{{ column.displayValue }}</span>\n              } @else {\n                <mat-checkbox\n                  [checked]=\"column.current.selected\"\n                  (change)=\"selectColumn(column, $event)\"\n                  [attr.data-testid]=\"testId + '.select.' + column.name\">\n                  <span cdkDragHandle euiOverflowTooltip class=\"column-display-name\" [ngClass]=\"{handle: !isFiltered, sorted: column.name === tableLayout.sort.current.active}\">{{ column.displayValue }}</span>\n                </mat-checkbox>\n              }\n            </span>\n\n            @if (column.name === tableLayout.sort.current.active && tableLayout.sort.current.direction) {\n              <span class=\"sort-indicator\">\n                <eui-icon\n                  size=\"16px\"\n                  [icon]=\"tableLayout.sort.current.direction === 'asc' ? 'sortup' : 'sortdown'\"\n                  [euiTooltip]=\"labelTranslations.list.sort[column.dataType ?? 'text'][tableLayout.sort.current.direction]\"\n                />\n              </span>\n            }\n          </div>\n        </div>\n      </div>\n    }\n  </div>\n</div>\n@if (useApplyCancel) {\n  <div eui-sidesheet-actions class=\"footer-buttons\">\n     <button mat-stroked-button\n       (click)=\"cancel()\"\n       attr.data-testid=\"{{testId}}.cancel\">\n        {{ labelTranslations.actionButtons.cancelButton }}\n     </button>\n\n     <button mat-flat-button\n       color=\"primary\"\n       (click)=\"apply()\"\n       [disabled]=\"!anyEdits\"\n       attr.data-testid=\"{{testId}}.apply\">\n        {{ labelTranslations.actionButtons.applyButton }}\n     </button>\n  </div>\n}\n", styles: [".eui-sidesheet-content{padding-bottom:0}:host-context(.eui-dark-theme) .select-columns__list{border-top:1px solid #dfe4e6}:host-context(.eui-dark-theme) .report-column{border-bottom:1px solid #dfe4e6}:host-context(.eui-dark-theme) .handle-name-sort .name .selection-control .eui-icon{color:#c4cacc}:host-context(.eui-dark-theme) .handle-name-sort .name .selection-control .sort-indicator{color:#aab0b3}:host-context(.eui-dark-theme) .cdk-drag-preview{box-shadow:0 5px 5px -3px #0003,0 8px 10px 1px #00000024,0 3px 14px 2px #0000001f;background-color:#000!important}:host-context(.eui-dark-theme) .report-column-placeholder{background:#232626;border-bottom:1px solid #dfe4e6}:host-context(.eui-dark-theme) .eui-list-row.eui-list-row-selected,:host-context(.eui-dark-theme) .eui-list-row.eui-list-row-selected.eui-list-selectable-row:not(.eui-list-row-selected):hover{background-color:#016b9140}:host-context(.eui-dark-theme) .eui-list-row.eui-list-row-disabled.eui-list-selectable-row:not(.oic-row-selected):hover{background-color:#18191a}:host-context(.eui-contrast-theme) .select-columns__list{border-top:1px solid #dfe4e6}:host-context(.eui-contrast-theme) .report-column{border-bottom:1px solid #dfe4e6}:host-context(.eui-contrast-theme) .handle-name-sort .name .selection-control .eui-icon{color:#c4cacc}:host-context(.eui-contrast-theme) .handle-name-sort .name .selection-control .sort-indicator{color:#aab0b3}:host-context(.eui-contrast-theme) .cdk-drag-preview{box-shadow:0 5px 5px -3px #0003,0 8px 10px 1px #00000024,0 3px 14px 2px #0000001f;background-color:#000!important}:host-context(.eui-contrast-theme) .report-column-placeholder{background:#232626;border-bottom:1px solid #dfe4e6}:host-context(.eui-contrast-theme) .eui-list-row.eui-list-row-selected,:host-context(.eui-contrast-theme) .eui-list-row.eui-list-row-selected.eui-list-selectable-row:not(.eui-list-row-selected):hover{background-color:#016b9140}:host-context(.eui-contrast-theme) .eui-list-row.eui-list-row-disabled.eui-list-selectable-row:not(.oic-row-selected):hover{background-color:#18191a}.select-columns__list{border-top:1px solid #c4cacc}.report-column{border-bottom:1px solid #c4cacc}.handle-name-sort .name .selection-control .eui-icon{color:#919799}.handle-name-sort .name .selection-control .sort-indicator{color:#616566}.cdk-drag-preview{box-shadow:0 5px 5px -3px #0003,0 8px 10px 1px #00000024,0 3px 14px 2px #0000001f;background-color:#ffffffbf!important}.report-column-placeholder{background:#dfe4e6;border-bottom:1px solid #c4cacc}.eui-list-row.eui-list-row-selected,.eui-list-row.eui-list-row-selected.eui-list-selectable-row:not(.eui-list-row-selected):hover{background-color:#0a96d10f}.eui-list-row.eui-list-row-disabled.eui-list-selectable-row:not(.oic-row-selected):hover{background-color:#f9fbfc}::ng-deep body.force-dragging-cursor *{cursor:grabbing!important}.eui-text-ellipsis{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.select-columns{display:flex;flex-direction:column;gap:16px;overflow:auto}.select-columns__header-actions{display:flex;justify-content:space-between;align-items:center}.select-columns__header-actions .buttons{display:flex;gap:16px;height:36px;align-items:center}.select-columns__header-actions .buttons .label,.select-columns__header-actions .buttons a{font-weight:600;font-size:14px}.select-columns__header-actions .buttons a.eui-clickable--disabled{text-decoration:none}.select-columns__list{overflow-y:auto;overflow-x:hidden;font-size:14px}.select-columns__list>:last-child{margin-bottom:20px}.report-column{height:52px;width:410px;padding:0 21px 0 8px;display:flex;flex-direction:row;align-items:center;gap:16px}.report-column .select-control-disabled{width:36px;text-align:center}.handle-name-sort{display:flex;flex-direction:row;gap:8px;flex-grow:1}.handle-name-sort .sequence-form-field{height:36px;width:40px}.handle-name-sort .sequence-form-field input.sequence-input{text-align:right}.handle-name-sort .sequence-form-field ::ng-deep .mat-mdc-text-field-wrapper{padding:0 8px}.handle-name-sort .handle{cursor:grab}.handle-name-sort .handle:active{cursor:grabbing}.handle-name-sort .name{flex-grow:1;display:flex;flex-direction:row;gap:4px;align-items:center;justify-content:space-between}.handle-name-sort .name .selection-control{display:flex;flex-direction:row;gap:4px;width:100%}.handle-name-sort .name .selection-control .column-display-name{font-weight:600;display:inline-block;width:100%;--eui-default-max-width: 249px}.handle-name-sort .name .selection-control .sorted{--eui-default-max-width: 219px}.handle-name-sort .name .selection-control ::ng-deep .mat-mdc-checkbox{width:100%}.handle-name-sort .name .selection-control ::ng-deep .mat-mdc-checkbox ::ng-deep .mdc-form-field{width:100%}.handle-name-sort .name .selection-control ::ng-deep .mat-mdc-checkbox ::ng-deep .mdc-form-field ::ng-deep .mdc-label{width:100%}.handle-name-sort .name .selection-control ::ng-deep .mat-mdc-checkbox ::ng-deep .mdc-form-field ::ng-deep .mdc-label>div{width:100%}.handle-name-sort .name .selection-control .eui-icon{width:36px}.handle-name-sort .name .selection-control .sort-indicator{flex:0 0 20px}input.sequence-input::-webkit-outer-spin-button,input.sequence-input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}input.sequence-input[type=number]{-moz-appearance:textfield}.cdk-drag-preview{box-sizing:border-box;border-radius:4px;box-shadow:0 5px 5px -3px #0003,0 8px 10px 1px #00000024,0 3px 14px 2px #0000001f;display:flex;align-items:center;justify-content:center}.cdk-drag-animating{transition:transform .25s cubic-bezier(0,0,.2,1)}.select-columns__list.cdk-drop-list-dragging .report-column:not(.cdk-drag-placeholder){transition:transform .25s cubic-bezier(0,0,.2,1)}.report-column-placeholder{min-height:52px;width:400px;transition:transform .25s cubic-bezier(0,0,.2,1);display:flex;flex-direction:row;align-items:center;gap:16px}.footer-buttons{border-top:1px solid rgba(0,0,0,.2)}.no-results{color:#616566;justify-content:center;padding:64px 0}@media screen and (max-width: 768px){.report-column,.report-column-placeholder{width:100%}}@media screen and (max-width: 480px){.select-columns__header-actions{flex-direction:column;gap:16px;align-items:flex-start}}:host-context([dir=rtl]) .report-column{padding:0 8px 0 21px}:host-context([dir=rtl]) .handle-name-sort .sequence-form-field input.sequence-input{text-align:left}.eui-list-row:not(.eui-list-row-selected):not(.eui-list-selectable-row):hover{background-color:transparent}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [EUI_SIDESHEET_DATA]
                }] }, { type: EuiSidesheetService }, { type: EuiSidesheetRef }, { type: i0.DestroyRef }, { type: EuiUnsavedChangesService }], propDecorators: { searchInput: [{
                type: ViewChild,
                args: ['searchInput']
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
/**
 * A service that opens the table column selection sidesheet
 */
class EuiTableColumnManagementService {
    /** @ignore */
    constructor(_sidesheetService) {
        this._sidesheetService = _sidesheetService;
        /** @ignore */
        this.dataToSave$ = new Subject();
        this.tableLayout = structuredClone(EUI_TCM_NEW_TABLE_LAYOUT);
        this.config = structuredClone(EUI_TCM_NEW_CONFIG);
        this.originalConfig = structuredClone(EUI_TCM_NEW_CONFIG);
        this.savedData = structuredClone(EUI_TCM_NEW_SAVED_TABLE_LAYOUT);
    }
    /**
     * Opens the column selection sidesheet
     *
     * Can be used to open from code where the caller either is not using the
     * EuiTableColumnManagement in an html template or needs additional control.
     *
     * @param config A EuiTableColumnManagementConfig object describing the table
     * layout, parameters for the sidesheet, and localized text for display
     * @return Observable<EuiTableColumnManagementSavedTableLayout> Saved layout
     * is returned when sidesheet is dismissed. If config.useApplyCancel is true
     * data is only returned when Apply button is clicked
     *
     */
    openSidesheet(config) {
        EuiTableColumnUtilitiesService.normalizeConfig(config);
        if (config.useApplyCancel) {
            this.config = structuredClone(config);
            this.originalConfig = config;
        }
        else {
            this.config = config;
        }
        this.tableLayout = this.config.tableLayout;
        const existing = EuiTableColumnUtilitiesService.convertToSaved(this.tableLayout);
        return this._sidesheetService
            .open(EuiTableColumnManagementSelectColumnsComponent, {
            width: '450px',
            title: this.config.labelTranslations.sidesheet.title,
            icon: 'columns',
            padding: '0',
            autoFocus: true,
            data: this.config,
            panelClass: this.config.panelClass,
        })
            .afterClosed()
            .pipe(filter$1((applyButton) => (!!applyButton && this.config.useApplyCancel) || (!this.config.useApplyCancel && EuiTableColumnUtilitiesService.anyEdits(existing, this.tableLayout))), tap$1(() => of(this.saveLayout())), switchMap(() => of(this.savedData)));
    }
    saveLayout() {
        const dataToSave = EuiTableColumnUtilitiesService.convertToSaved(this.tableLayout);
        if (this.config.useApplyCancel) {
            this.tableLayout.columns.forEach((column, index) => {
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                const orig = this.originalConfig.tableLayout.columns.find((y) => y.name === column.name).current;
                orig.selected = column.current.selected;
                orig.sequence = column.current.sequence;
            });
        }
        this.dataToSave$.next(dataToSave);
        this.savedData = dataToSave;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTableColumnManagementService, deps: [{ token: EuiSidesheetService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTableColumnManagementService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTableColumnManagementService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: EuiSidesheetService }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiTableColumnManagementComponent {
    /** @ignore */
    constructor(management, destroyRef) {
        this.management = management;
        this.destroyRef = destroyRef;
        /**
         * Controls whether the button that opens the sidesheet is enabled or disabled.
         *
         * @category Input
         */
        this.disabled = false;
        /**
         * Optional type of button to display. Predefined options:
         * - icon
         * - button (a mat-stroked-button)
         * - link
         *
         * @category Input
         */
        this.buttonType = 'icon';
        /**
         * Emits an event on sidesheet close when table layout has been changed. If no
         * changes from the original layout are detected the event is not emitted.
         *
         * Data is emitted in a EuiTableColumnManagementSavedTableLayout object that can
         * be written to a user preferences data store by the caller.
         * - When config.useApplyCancel is false this event is emitted when the sidesheet is closed.
         * - When config.useApplyCancel is true this event is only emitted when the Apply button is clicked.
         *
         * @category Output
         * @event
         */
        this.saveData = new EventEmitter();
        /** @ignore */
        this.testId = 'eui-table-column-management';
        this.destroy = new Subject();
        this.destroyRef.onDestroy(() => {
            this.destroy.next(true);
            this.destroy.complete();
        });
    }
    /** @ignore */
    ngOnInit() {
        EuiTableColumnUtilitiesService.normalizeConfig(this.config);
        this.testId = this.config.testId || this.testId;
    }
    /** @ignore */
    openTableColumnManagement() {
        this.management.dataToSave$
            .pipe(takeUntil$1(this.destroy), take$1(1), tap$1((dataToSave) => this.saveData.emit(dataToSave)))
            .subscribe();
        this.management
            .openSidesheet(this.config)
            .pipe(takeUntil$1(this.destroy))
            .subscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTableColumnManagementComponent, deps: [{ token: EuiTableColumnManagementService, self: true }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.2.1", type: EuiTableColumnManagementComponent, isStandalone: false, selector: "eui-table-column-management", inputs: { config: "config", disabled: "disabled", buttonType: "buttonType" }, outputs: { saveData: "saveData" }, providers: [EuiTableColumnManagementService], ngImport: i0, template: "@switch (buttonType) {\n   @case (\"icon\") {\n      <button\n        matIconButton\n        class=\"eui-table-column-management-button eui-table-column-management-icon-button\"\n        (click)=\"openTableColumnManagement()\"\n        [matTooltip]=\"config.labelTranslations.sidesheet.openerButtonTooltip\"\n        [matTooltipShowDelay]=\"500\"\n        [disabled]=\"disabled\"\n        attr.data-testid=\"{{testId}}.opener-btn\">\n        <eui-icon size=\"20px\" icon=\"columns\"/>\n      </button>\n   }\n\n   @case (\"button\") {\n      <button\n        mat-stroked-button\n        class=\"eui-table-column-management-button eui-table-column-management-stroked-button\"\n        (click)=\"openTableColumnManagement()\"\n        [disabled]=\"disabled\"\n        attr.data-testid=\"{{testId}}.opener-btn\">\n        <span class=\"eui-table-column-managment-control-contents\">\n           <eui-icon size=\"20px\" icon=\"columns\"/>\n           <span>{{config.labelTranslations.sidesheet.openButton}}</span>\n         </span>\n      </button>\n   }\n\n   @case (\"link\") {\n      <span euiClickable [euiClickableDisabled]=\"disabled\"\n         (click)=\"openTableColumnManagement()\"\n         class=\"eui-table-column-management-button eui-table-column-management-link-button eui-table-column-managment-control-contents eui-table-column-managment-control-contents-text\"\n         [ngClass]=\"{'eui-table-column-managment-disabled': disabled}\"\n         attr.data-testid=\"{{testId}}.opener-btn\">\n        <eui-icon size=\"20px\" icon=\"columns\"/>\n        @if(disabled) {\n          <span class=\"eui-table-column-management-link-button--disabled\">{{config.labelTranslations.sidesheet.openButton}}</span>\n        }\n        @else {\n          <a>{{config.labelTranslations.sidesheet.openButton}}</a>\n        }\n      </span>\n   }\n}\n", styles: [":host-context(.eui-dark-theme) .eui-table-column-managment-control-contents-text{color:#cbe8f2;font-size:14px}:host-context(.eui-dark-theme) .eui-table-column-managment-disabled{color:#c4cacc}:host-context(.eui-contrast-theme) .eui-table-column-managment-control-contents-text{color:#cbe8f2;font-size:14px}:host-context(.eui-contrast-theme) .eui-table-column-managment-disabled{color:#c4cacc}.eui-table-column-managment-control-contents-text{color:#0a96d1;font-size:14px}.eui-table-column-managment-disabled{color:#c4cacc}.eui-table-column-managment-control-contents{display:flex;flex-direction:row;gap:8px;width:fit-content}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: i1$6.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "component", type: EuiIconComponent, selector: "eui-icon", inputs: ["aria-hidden", "setLineHeight", "icon", "size"] }, { kind: "directive", type: EuiClickableDirective, selector: "[euiClickable]", inputs: ["euiClickable", "euiClickableDisabled"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTableColumnManagementComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'eui-table-column-management', providers: [EuiTableColumnManagementService], template: "@switch (buttonType) {\n   @case (\"icon\") {\n      <button\n        matIconButton\n        class=\"eui-table-column-management-button eui-table-column-management-icon-button\"\n        (click)=\"openTableColumnManagement()\"\n        [matTooltip]=\"config.labelTranslations.sidesheet.openerButtonTooltip\"\n        [matTooltipShowDelay]=\"500\"\n        [disabled]=\"disabled\"\n        attr.data-testid=\"{{testId}}.opener-btn\">\n        <eui-icon size=\"20px\" icon=\"columns\"/>\n      </button>\n   }\n\n   @case (\"button\") {\n      <button\n        mat-stroked-button\n        class=\"eui-table-column-management-button eui-table-column-management-stroked-button\"\n        (click)=\"openTableColumnManagement()\"\n        [disabled]=\"disabled\"\n        attr.data-testid=\"{{testId}}.opener-btn\">\n        <span class=\"eui-table-column-managment-control-contents\">\n           <eui-icon size=\"20px\" icon=\"columns\"/>\n           <span>{{config.labelTranslations.sidesheet.openButton}}</span>\n         </span>\n      </button>\n   }\n\n   @case (\"link\") {\n      <span euiClickable [euiClickableDisabled]=\"disabled\"\n         (click)=\"openTableColumnManagement()\"\n         class=\"eui-table-column-management-button eui-table-column-management-link-button eui-table-column-managment-control-contents eui-table-column-managment-control-contents-text\"\n         [ngClass]=\"{'eui-table-column-managment-disabled': disabled}\"\n         attr.data-testid=\"{{testId}}.opener-btn\">\n        <eui-icon size=\"20px\" icon=\"columns\"/>\n        @if(disabled) {\n          <span class=\"eui-table-column-management-link-button--disabled\">{{config.labelTranslations.sidesheet.openButton}}</span>\n        }\n        @else {\n          <a>{{config.labelTranslations.sidesheet.openButton}}</a>\n        }\n      </span>\n   }\n}\n", styles: [":host-context(.eui-dark-theme) .eui-table-column-managment-control-contents-text{color:#cbe8f2;font-size:14px}:host-context(.eui-dark-theme) .eui-table-column-managment-disabled{color:#c4cacc}:host-context(.eui-contrast-theme) .eui-table-column-managment-control-contents-text{color:#cbe8f2;font-size:14px}:host-context(.eui-contrast-theme) .eui-table-column-managment-disabled{color:#c4cacc}.eui-table-column-managment-control-contents-text{color:#0a96d1;font-size:14px}.eui-table-column-managment-disabled{color:#c4cacc}.eui-table-column-managment-control-contents{display:flex;flex-direction:row;gap:8px;width:fit-content}\n"] }]
        }], ctorParameters: () => [{ type: EuiTableColumnManagementService, decorators: [{
                    type: Self
                }] }, { type: i0.DestroyRef }], propDecorators: { config: [{
                type: Input,
                args: [{ required: true }]
            }], disabled: [{
                type: Input
            }], buttonType: [{
                type: Input
            }], saveData: [{
                type: Output
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiThemeSwitcherComponent {
    constructor(euiThemeService) {
        this.euiThemeService = euiThemeService;
        /**
         * Label of the theme switcher
         *
         * @category Input
         */
        this.label = 'Select theme';
        /**
         * Controls whether the legacy floating label is displayed or a label above the form field
         *
         * @category Input
         */
        this.useLegacyFloatingLabel = false;
        /**
         * Text of the light theme option
         *
         * @category Input
         */
        this.lightThemeDisplayText = 'Light';
        /**
         * Text of the dark theme option
         *
         * @category Input
         */
        this.darkThemeDisplayText = 'Dark';
        /**
         * Text of the auto theme option
         *
         * @category Input
         */
        this.autoThemeDisplayText = 'Auto';
        /**
         * Text of the contrast theme option
         *
         * @category Input
         */
        this.contrastThemeDisplayText = 'High Contrast';
        /**
         * Hiding the light theme option
         *
         * @category Input
         */
        this.hideLightTheme = false;
        /**
         * Hiding the dark theme option
         *
         * @category Input
         */
        this.hideDarkTheme = false;
        /**
         * Hiding the contrast theme option
         *
         * @category Input
         */
        this.hideContrastTheme = false;
        /**
         * Hiding the auto theme option
         *
         * @category Input
         */
        this.hideAutoTheme = false;
        /**
         * Display custom themes in theme switcher
         *
         * @category Input
         */
        this.customThemes = [];
        /** @internal */
        this.EuiTheme = EuiTheme;
        this.themeSwitcherState = this.euiThemeService.getThemeSwitcherState();
    }
    /** @internal */
    onChange(event) {
        this.euiThemeService.setTheme(event.value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiThemeSwitcherComponent, deps: [{ token: EuiThemeService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.2.1", type: EuiThemeSwitcherComponent, isStandalone: false, selector: "eui-theme-switcher", inputs: { label: "label", useLegacyFloatingLabel: "useLegacyFloatingLabel", lightThemeDisplayText: "lightThemeDisplayText", darkThemeDisplayText: "darkThemeDisplayText", autoThemeDisplayText: "autoThemeDisplayText", contrastThemeDisplayText: "contrastThemeDisplayText", hideLightTheme: "hideLightTheme", hideDarkTheme: "hideDarkTheme", hideContrastTheme: "hideContrastTheme", hideAutoTheme: "hideAutoTheme", customThemes: "customThemes" }, ngImport: i0, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<eui-form-field [useLegacyFloatingLabel]=\"useLegacyFloatingLabel\">\n  @if (!useLegacyFloatingLabel) {\n    <eui-label>{{ label }}</eui-label>\n  }\n  @if (useLegacyFloatingLabel) {\n    <mat-label>{{ label }}</mat-label>\n  }\n  <mat-select [value]=\"themeSwitcherState | async\" (selectionChange)=\"onChange($event)\" [attr.aria-label]=\"label\">\n    @if (!hideLightTheme) {\n      <mat-option [value]=\"EuiTheme.LIGHT\">{{ lightThemeDisplayText }}</mat-option>\n    }\n    @if (!hideDarkTheme) {\n      <mat-option [value]=\"EuiTheme.DARK\">{{ darkThemeDisplayText }}</mat-option>\n    }\n    @if (!hideContrastTheme) {\n      <mat-option [value]=\"EuiTheme.CONTRAST\">{{ contrastThemeDisplayText }}</mat-option>\n    }\n    @for (theme of customThemes; track theme) {\n      <mat-option [value]=\"theme.class\">{{ theme.name }}</mat-option>\n    }\n    @if (!hideAutoTheme) {\n      <mat-option [value]=\"EuiTheme.AUTO\">{{ autoThemeDisplayText }}</mat-option>\n    }\n  </mat-select>\n</eui-form-field>\n", dependencies: [{ kind: "component", type: i2$2.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "directive", type: i2$1.MatLabel, selector: "mat-label" }, { kind: "component", type: i8.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "component", type: EuiFormFieldComponent, selector: "eui-form-field", inputs: ["appearance", "hideMargins", "width", "useLegacyFloatingLabel", "readonly"] }, { kind: "component", type: EuiLabelComponent, selector: "eui-label", inputs: ["for", "required", "errorState", "disabled"] }, { kind: "pipe", type: i2.AsyncPipe, name: "async" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiThemeSwitcherComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-theme-switcher', encapsulation: ViewEncapsulation.None, standalone: false, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<eui-form-field [useLegacyFloatingLabel]=\"useLegacyFloatingLabel\">\n  @if (!useLegacyFloatingLabel) {\n    <eui-label>{{ label }}</eui-label>\n  }\n  @if (useLegacyFloatingLabel) {\n    <mat-label>{{ label }}</mat-label>\n  }\n  <mat-select [value]=\"themeSwitcherState | async\" (selectionChange)=\"onChange($event)\" [attr.aria-label]=\"label\">\n    @if (!hideLightTheme) {\n      <mat-option [value]=\"EuiTheme.LIGHT\">{{ lightThemeDisplayText }}</mat-option>\n    }\n    @if (!hideDarkTheme) {\n      <mat-option [value]=\"EuiTheme.DARK\">{{ darkThemeDisplayText }}</mat-option>\n    }\n    @if (!hideContrastTheme) {\n      <mat-option [value]=\"EuiTheme.CONTRAST\">{{ contrastThemeDisplayText }}</mat-option>\n    }\n    @for (theme of customThemes; track theme) {\n      <mat-option [value]=\"theme.class\">{{ theme.name }}</mat-option>\n    }\n    @if (!hideAutoTheme) {\n      <mat-option [value]=\"EuiTheme.AUTO\">{{ autoThemeDisplayText }}</mat-option>\n    }\n  </mat-select>\n</eui-form-field>\n" }]
        }], ctorParameters: () => [{ type: EuiThemeService }], propDecorators: { label: [{
                type: Input
            }], useLegacyFloatingLabel: [{
                type: Input
            }], lightThemeDisplayText: [{
                type: Input
            }], darkThemeDisplayText: [{
                type: Input
            }], autoThemeDisplayText: [{
                type: Input
            }], contrastThemeDisplayText: [{
                type: Input
            }], hideLightTheme: [{
                type: Input
            }], hideDarkTheme: [{
                type: Input
            }], hideContrastTheme: [{
                type: Input
            }], hideAutoTheme: [{
                type: Input
            }], customThemes: [{
                type: Input
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiTimePickerComponent {
    /**
     * FormControl used to manage component
     *
     * @category Input
     */
    set timeControl(control) {
        this._timeControl = control;
        if (this._timeControlSub) {
            this._timeControlSub.unsubscribe();
        }
        this._timeControlSub = this._timeControl.valueChanges.subscribe((value) => {
            this.setValue(value, false);
        });
        if (this._timeControl.value) {
            this.setValue(this._timeControl.value, false);
        }
    }
    /**
     * Gets the FormControl used to manage component
     *
     * @internal */
    get timeControl() {
        return this._timeControl;
    }
    /**
     * Sets the disabled state of the component
     *
     * @category Input
     */
    set disabled(disabled) {
        this._disabled = disabled;
        if (disabled) {
            this.hourControl.disable();
            this.minuteControl.disable();
        }
        else {
            this.hourControl.enable();
            if (!this._hourOnly) {
                this.minuteControl.enable();
            }
        }
    }
    /**
     * Gets the disabled state of the component
     *
     * @internal */
    get disabled() {
        return this._disabled;
    }
    /** @internal */
    get isRequired() {
        if (this.readonly) {
            return false;
        }
        if (this.required) {
            return true;
        }
        return this.timeControl?.hasValidator(Validators.required) ?? false;
    }
    /**
     * Sets minimum accepted value for the component
     *
     * @category Input
     */
    set min(minvalue) {
        if (!minvalue.isSame(this._min, 'minute')) {
            this._min = minvalue;
            this.setTimeSelects();
        }
    }
    /**
     * Gets minimum accepted value for the component
     *
     * @internal */
    get min() {
        return this._min;
    }
    /**
     * Sets maximum accepted value for the component
     *
     * @category Input
     */
    set max(maxvalue) {
        if (!maxvalue.isSame(this._max, 'minute')) {
            this._max = maxvalue;
            this.setTimeSelects();
        }
    }
    /**
     * Gets maximum accepted value for the component
     *
     * @internal */
    get max() {
        return this._max;
    }
    /**
     * If true, the minute field will be disabled and set to "00"
     *
     * @category Input
     */
    set hourOnly(hronly) {
        this._hourOnly = hronly;
        if (hronly === true) {
            if (this._value) {
                this._value = this._value.minute(0);
            }
            this.minuteControl.setValue('00');
            this.minuteControl.disable();
        }
        else if (!this._disabled) {
            this.minuteControl.enable();
        }
    }
    /**
     * Gets whether or not the component is set to allow hours only
     *
     * @internal */
    get hourOnly() {
        return this._hourOnly;
    }
    /**
     * Sets an array of hours that can be selected (values from 0 - 23).
     *
     * @category Input
     */
    set permittedHours(hours) {
        hours = [...new Set(hours)].sort((a, b) => a - b);
        if (hours.find((h) => h < 0 || h > 23)) {
            hours = hours.filter((h) => h >= 0 && h <= 23);
        }
        if (hours.join(',') !== this._permittedHours.join(',')) {
            this._permittedHours = hours;
            this.setTimeSelects();
        }
    }
    /**
     * An array of hours that can be selected (values from 0 - 23).
     *    If none are supplied, then all hours are allowed. If any are passed in,
     *    the hours select list will have disabled and enabled items, and the
     *    validation will reject any hour of the day that's not in the permitted list.
     *
     * @internal */
    get permittedHours() {
        return this._permittedHours;
    }
    /**
     * Sets the value of the picker to the passed in Moment object
     *
     * @category Input
     */
    set value(val) {
        this.setValue(val, true);
    }
    /**
     * Gets the value of the picker as a Moment object
     *
     * @internal */
    get value() {
        return this._value;
    }
    /**
     * Sets the minute resolution of the items in the minute drop-down (must be a divisor of 60).
     *    For a value of 15, the minute drop-down list will contain [0, 15, 30, 45].
     *    For a value of 10, the minute drop-down list will contain [0, 10, 20, 30, 40, 50].
     *    If the value is not a divisor of 60, it will be set to 15.
     *    Default: 15
     *
     * @category Input
     */
    set minuteResolution(minutes) {
        let newMin = minutes || 15;
        if (newMin < 0 || newMin > 30 || 60 % newMin !== 0) {
            newMin = 15;
        }
        if (newMin !== this._minuteResolution) {
            this._minuteResolution = newMin;
            this.setTimeSelects('minute');
        }
    }
    /**
     * Gets the minute resolution of the items in the minute drop-down (must be a divisor of 60).
     *    For a value of 15, the minute drop-down list will contain [0, 15, 30, 45].
     *    For a value of 10, the minute drop-down list will contain [0, 10, 20, 30, 40, 50].
     *    If the value is not a divisor of 60, it will be set to 15.
     *    Default: 15
     *
     * @internal */
    get minuteResolution() {
        return this._minuteResolution;
    }
    /**
     * Gets whether the current time is in the AM or PM hours
     *
     * @internal */
    get amOrPm() {
        return this._amOrPm;
    }
    /**
     * Sets whether the current time is in the AM or PM hours
     *
     * @internal */
    set amOrPm(ampm) {
        if (ampm && ampm !== this._amOrPm) {
            this.toggleAmPm();
        }
    }
    /**
     * Returns when the AM/PM button should be shown
     *
     * @internal */
    get showAmPm() {
        const show = !/[0-9]$/.test(moment$1().format('LT'));
        if (show !== this._showAmPm) {
            this._showAmPm = show;
            setTimeout(() => this.setTimeSelects('hour'));
        }
        return show;
    }
    get isAm() {
        return this._amOrPm === 'am';
    }
    constructor() {
        /**
         * Test Id prefix
         *
         * @category Input
         */
        this.testId = 'time-picker';
        /**
         * When set to false, the user is not allowed to type into the text fields
         *
         * @category Input
         */
        this.allowTextInput = true;
        /**
         * Appearance mode of the mat-form-field element
         *
         * @category Input
         */
        this.appearance = 'outline';
        /**
         * Sets whether the component is required or not
         *
         * @category Input
         */
        this.required = false;
        /**
         * Sets whether the component is read-only or not
         *
         * @category Input
         */
        this.readonly = false;
        /**
         * Sets whether there is a margin at the bottom of the component
         *
         * @category Input
         */
        this.noMargin = false;
        /**
         * Emits an event when the value of the picker changes
         *
         * @category Output
         * @event
         */
        this.valueChange = new EventEmitter();
        /** @internal */
        this.hourControl = new FormControl('');
        /** @internal */
        this.minuteControl = new FormControl('');
        /** @internal */
        this.hours = [];
        /** @internal */
        this.minutes = [];
        /**
         * Contains style key-value pairs for mat-form-field element
         *
         * @internal */
        this.fieldStyles = {};
        this._showAmPm = true;
        this._disabled = false;
        // hourOnly - the caller only wants an hour to be selected, minutes are
        // forced to "00" and minute entry is disabled.
        this._hourOnly = false;
        this._permittedHours = [];
        // value - the current time to display
        // changes will be emitted with the valueChange event
        this._value = null;
        this._minuteResolution = 15;
        this._amOrPm = 'am';
    }
    /** @internal */
    ngOnInit() {
        this.hourControl.setValue(this.value?.format(this.showAmPm ? 'h' : 'HH'));
        this.hourControl.setValidators(this.getHourValidator());
        this.hourControl.valueChanges.subscribe((newValue) => {
            this.timeChanged(newValue, 'hour');
        });
        this.minuteControl.setValue(this.value?.format('mm'));
        this.minuteControl.setValidators(this.getMinuteValidator());
        this.minuteControl.valueChanges.subscribe((newValue) => {
            this.timeChanged(newValue, 'minute');
        });
        this.setTimeSelects();
        if (this.width) {
            this.fieldStyles = { width: this.width };
        }
    }
    /**
     * Gets the hours to show in the drop-down
     *
     * @internal */
    get clockHours() {
        return this.hours.filter((h) => !this.showAmPm || (this.isAm ? h.hour < 12 : h.hour >= 12));
    }
    /**
     * Gets whether the current time is "AM" or "PM"
     *
     * @internal */
    get timeAmPm() {
        return (this._value || moment$1().startOf('day')).locale(moment$1().locale()).format('A');
    }
    /**
     * Toggles the current time between "AM" and "PM"
     *
     * @internal */
    toggleAmPm() {
        this._amOrPm = this._amOrPm === 'am' ? 'pm' : 'am';
        if (!this._value) {
            this._value = moment$1().hour(0).minute(0).second(0).milliseconds(0);
            this.hourControl.setValue(this._value.format(this.showAmPm ? 'h' : 'HH'));
            this.minuteControl.setValue(this._value.format('mm'), { emitEvent: false });
        }
        this._value.add(this.isAm ? -12 : 12, 'hour');
        this.hourControl.updateValueAndValidity();
        this.minuteControl.updateValueAndValidity();
        this.valueOutput();
    }
    /**
     * Sets the value of the hour or minute field to the selected value from the drop-down
     *
     * @param value: The numeric to set the field to
     * @param which: The field to set ('hour' or 'minute')
     * @internal */
    timeMenu(value, which) {
        switch (which) {
            case 'hour':
                this.hourControl.setValue(value.hourText + '');
                break;
            case 'minute':
                this.minuteControl.setValue(value.minuteText + '');
                break;
        }
    }
    /**
     * Returns whether the hour and minute fields' FormControls contains errors
     *
     * @internal */
    hasErrors() {
        return this.hourControl.errors != null || this.minuteControl.errors != null;
    }
    /**
     * Returns all errors associated with the hour and minute fields' FormControls
     *
     * @internal */
    getErrors() {
        return Object.assign(this.hourControl.errors || {}, this.minuteControl.errors || {});
    }
    /**
     * If allowTextInput=false, this prevents the user from typing in the field.
     *
     * @internal */
    onKeyDown(event) {
        if (!this.allowTextInput) {
            const key = this.mapKey(event);
            if (key === 'tab') {
                // Allow the user to tab out of the field
            }
            else if (key === 'escape' || key === 'enter') {
                // Let the event pass through
            }
            else {
                // Ignore other keys
                event.preventDefault();
                event.stopPropagation();
            }
        }
    }
    /**
     * Returns the hour value, accounting for AM/PM, for the passed-in value
     */
    hour24(value) {
        const hr = typeof value === 'string' ? parseInt(value, 10) : value;
        const hr24 = this.isAm ? 0 : 12;
        return this.showAmPm ? (hr % 12) + hr24 : hr;
    }
    /**
     * Called when the user changes the value of the hour or minute input field
     */
    timeChanged(value, which) {
        switch (which) {
            case 'hour':
                const newHour = this.hour24(value);
                if (newHour === this._value?.hour()) {
                    return;
                }
                if (!this._value) {
                    this._value = moment$1().hour(0).minute(0).second(0).milliseconds(0);
                    this.minuteControl.setValue(this._value.format('mm'), { emitEvent: false });
                }
                this._value.hour(newHour);
                // Make validation run on minute field, too.
                this.minuteControl.markAsTouched();
                this.minuteControl.updateValueAndValidity({ emitEvent: false });
                break;
            case 'minute':
                const newMinute = parseInt(value, 10);
                if (newMinute === this._value?.minute()) {
                    return;
                }
                if (!this._value) {
                    this._value = moment$1().hour(0).minute(0).second(0).milliseconds(0);
                    this.hourControl.setValue(this._value?.format(this.showAmPm ? 'h' : 'HH'));
                }
                this._value.minute(newMinute);
                // Make validation run on hour field, too.
                this.hourControl.markAsTouched();
                this.hourControl.updateValueAndValidity({ emitEvent: false });
                break;
        }
        this.valueOutput();
    }
    /**
     * Maps a key event to a standard set of key codes.
     */
    mapKey(event) {
        const key = (event.key || '').toLowerCase();
        if (key) {
            return key;
        }
        return '';
    }
    /**
     * Sends notification that the value has changed
     */
    valueOutput() {
        let newValue = this._value;
        if (this.hourOnly && newValue && newValue.minutes() > 0) {
            const modifiedValue = moment$1([newValue.year(), newValue.month(), newValue.date(), newValue.hours(), 0, 0, 0]);
            newValue = moment$1(modifiedValue, 'LT');
            this.hourControl.setValue(newValue.format('LT'), { emitEvent: false });
            this.minuteControl.setValue('00', { emitEvent: false });
        }
        this.valueChange.emit(newValue);
        this.timeControl?.setValue(newValue);
    }
    /**
     * Populates the arrays used in the drop-down lists
     */
    setTimeSelects(which) {
        const curTime = moment$1().hour(0).minute(0).second(0).milliseconds(0);
        if (this._min) {
            this._min = moment$1([curTime.year(), curTime.month(), curTime.date(), this._min.hours(), this._min.minutes(), 0, 0]);
        }
        if (this._max) {
            this._max = moment$1([curTime.year(), curTime.month(), curTime.date(), this._max.hours(), this._max.minutes(), 0, 0]);
        }
        if (this._min && this._max && this._min.isAfter(this._max)) {
            [this._min, this._max] = [this._max, this._min];
        }
        this._amOrPm = (this._value?.hour() || 0) < 12 ? 'am' : 'pm';
        if ((which || 'hour') === 'hour') {
            this.hours = [];
            for (let i = 0; i <= 23; i++) {
                // AM/PM shows hours from 1 - 12, 24-hr shows hours from 00 - 23
                this.hours.push({
                    hour: i,
                    hourText: this.showAmPm ? (i === 0 || i === 12 ? 12 : i % 12).toString() : i.toString(),
                    minute: 0,
                    minuteText: '',
                    disabled: (this.permittedHours.length > 0 && this.permittedHours.indexOf(i) === -1) ||
                        !curTime.isBetween(this._min ?? curTime, this._max ?? curTime, 'hour', '[]'),
                });
                curTime.add(1, 'hour');
            }
            if (this.showAmPm) {
                // If we're showing AM/PM the menu will only show hours 1 - 12, and it
                // looks really weird to have 12 (hour==0) be the first one
                this.hours.sort((a, b) => parseInt(a.hourText, 10) - parseInt(b.hourText, 10));
            }
        }
        if ((which || 'minute') === 'minute') {
            this.minutes = [];
            for (let m = 0; m < 60; m += this._minuteResolution) {
                const minStr = '0' + m.toString();
                const minStrLength = minStr.length;
                this.minutes.push({
                    hour: 0,
                    hourText: '',
                    minute: m,
                    minuteText: minStrLength > 2 ? minStr.substring(minStrLength - 2) : minStr,
                    disabled: false,
                });
            }
        }
    }
    /**
     * Internal method to set the current value, if changed
     */
    setValue(val, emitEvent = true) {
        if (!this._value || !this._value.isSame(val)) {
            const hourChanged = this._value?.hour() !== val?.hour();
            const minuteChanged = this._value?.minute() !== val?.minute();
            this._value = val ? moment$1(val) : val;
            this._amOrPm = (val?.hour() || 0) < 12 ? 'am' : 'pm';
            if (hourChanged) {
                this.hourControl.setValue(this.value?.format(this.showAmPm ? 'h' : 'HH'), { emitEvent: false });
                this.hourControl.markAsTouched(); // Make validation run
            }
            if (minuteChanged) {
                this.minuteControl.setValue(this.value?.format('mm'), { emitEvent: false });
                this.minuteControl.markAsTouched(); // Make validation run
            }
            if ((hourChanged || minuteChanged) && emitEvent) {
                this.valueOutput();
            }
        }
    }
    /**
     * Gets a validator for the minutes field
     */
    getMinuteValidator() {
        return (control) => {
            const newValue = (control.value || '').trim();
            if ((control.untouched && !control.dirty) || (newValue === '' && !this.required)) {
                return null;
            }
            if (/[^0-9]/.test(newValue) || newValue === '') {
                control.markAsTouched();
                return { invalidTime: true };
            }
            const minute = parseInt(newValue, 10);
            if (minute < 0 || minute > 59) {
                control.markAsTouched();
                return { invalidTime: true };
            }
            const newTime = (this._value || moment$1()).clone().minute(minute);
            if (this.min) {
                const minCheck = moment$1([
                    this.min.year(),
                    this.min.month(),
                    this.min.date(),
                    newTime.hours(),
                    newTime.minutes(),
                    this.min.seconds(),
                    this.min.milliseconds(),
                ]);
                if (minCheck < this.min) {
                    return { min: true };
                }
            }
            if (this.max) {
                const maxCheck = moment$1([
                    this.max.year(),
                    this.max.month(),
                    this.max.date(),
                    newTime.hours(),
                    newTime.minutes(),
                    this.max.seconds(),
                    this.max.milliseconds(),
                ]);
                if (maxCheck > this.max) {
                    return { max: true };
                }
            }
            return null;
        };
    }
    /**
     * Gets a validator for the hours field
     */
    getHourValidator() {
        return (control) => {
            const newValue = (control.value || '').trim();
            if ((control.untouched && !control.dirty) || (newValue === '' && !this.required)) {
                return null;
            }
            if (/[^0-9]/.test(newValue) || newValue === '') {
                control.markAsTouched();
                return { invalidTime: true };
            }
            let hr = parseInt(newValue, 10);
            // If we're in am/pm mode and the user types in a 0 (12AM)
            // or 13 - 23 then do the math for them, update the displayed
            // value, and let the validator run again with the new value.
            if (this.showAmPm && (hr === 0 || (hr > 12 && hr <= 23))) {
                this._amOrPm = hr === 0 ? 'am' : 'pm';
                hr = hr === 0 ? 12 : hr - 12;
                setTimeout(() => {
                    control.setValue(hr.toString());
                }, 0);
                return null;
            }
            if (hr < 0 || hr > 23) {
                control.markAsTouched();
                return { invalidTime: true };
            }
            hr = this.hour24(hr);
            const hrStruct = this.hours.find((h) => h.hour === hr);
            if (hrStruct?.disabled) {
                control.markAsTouched();
                return { unpermittedTime: true };
            }
            const newTime = (this._value || moment$1())
                .clone()
                .hour(hr)
                .minute(this._value?.minutes() || 0);
            if (this.min) {
                const minCheck = moment$1([
                    this.min.year(),
                    this.min.month(),
                    this.min.date(),
                    newTime.hours(),
                    newTime.minutes(),
                    this.min.seconds(),
                    this.min.milliseconds(),
                ]);
                if (minCheck < this.min) {
                    return { min: true };
                }
            }
            if (this.max) {
                const maxCheck = moment$1([
                    this.max.year(),
                    this.max.month(),
                    this.max.date(),
                    newTime.hours(),
                    newTime.minutes(),
                    this.max.seconds(),
                    this.max.milliseconds(),
                ]);
                if (maxCheck > this.max) {
                    return { max: true };
                }
            }
            return null;
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTimePickerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.2.1", type: EuiTimePickerComponent, isStandalone: false, selector: "eui-time-picker", inputs: { testId: "testId", timeControl: "timeControl", allowTextInput: "allowTextInput", label: "label", appearance: "appearance", disabled: "disabled", required: "required", readonly: "readonly", min: "min", max: "max", width: "width", hourOnly: "hourOnly", permittedHours: "permittedHours", noMargin: "noMargin", value: "value", minuteResolution: "minuteResolution" }, outputs: { valueChange: "valueChange" }, ngImport: i0, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n<div class=\"eui-time-picker-container\" [ngStyle]=\"fieldStyles\">\n  @if (label) {\n    <eui-label [required]=\"isRequired\" [disabled]=\"disabled\" [errorState]=\"hasErrors()\">{{ label }}</eui-label>\n  }\n  \n  @if (readonly) {\n    <span class=\"eui-time-picker--readonly\">\n      <span #readonlyProjectedContent>\n        <ng-content select=\"eui-readonly-label\"></ng-content>\n      </span>\n      @if (!readonlyProjectedContent.childElementCount) {\n        @if (timeControl.value){\n          {{ timeControl.value | euiDateFormat:'LT' }}\n        }\n        @else {\n          &mdash;\n        }\n      }\n    </span>\n  }\n  \n  <span [ngClass]=\"{'eui-hidden': readonly }\">\n    <mat-form-field class=\"time-selects eui-input--no-margin\" [appearance]=\"appearance\">\n      <input\n        matInput\n        class=\"time-input\"\n        [formControl]=\"hourControl\"\n        autocomplete=\"off\"\n        [matAutocomplete]=\"hourAutocomplete\"\n        [attr.data-testid]=\"testId + '.input.hour'\"\n        (keydown)=\"onKeyDown($event)\"\n        />\n    </mat-form-field>\n    <div class=\"separator\">:</div>\n    <mat-form-field class=\"time-selects eui-input--no-margin\" [appearance]=\"appearance\">\n      <input\n        matInput\n        class=\"time-input\"\n        [formControl]=\"minuteControl\"\n        autocomplete=\"off\"\n        [matAutocomplete]=\"minuteAutocomplete\"\n        [attr.data-testid]=\"testId + '.input.minute'\"\n        (keydown)=\"onKeyDown($event)\"\n        />\n    </mat-form-field>\n\n    @if (showAmPm) {\n      <button mat-flat-button class=\"ampm-toggle\" color=\"primary\" [disabled]=\"disabled\" (click)=\"toggleAmPm()\" [attr.data-testid]=\"testId + '.button.amPmToggle'\">\n        {{ timeAmPm }}\n      </button>\n    }\n\n    <div class=\"errorContainer\" [ngClass]=\"{ 'no-margin': noMargin }\">\n      <mat-error class=\"eui-form-field-subscript\">\n        <ng-content select=\"mat-error\"></ng-content>\n      </mat-error>\n    </div>\n  </span>\n</div>\n\n<mat-autocomplete #hourAutocomplete=\"matAutocomplete\">\n  @for (hour of clockHours; track hour) {\n    <mat-option\n      class=\"eui-time-picker-option\"\n      [value]=\"hour.hourText\"\n      [disabled]=\"hour.disabled\"\n      [attr.data-testid]=\"testId + '.hourmenu.' + hour.hour\"\n      >{{ hour.hourText }}</mat-option\n      >\n  }\n</mat-autocomplete>\n\n<mat-autocomplete #minuteAutocomplete=\"matAutocomplete\">\n  @if (!hourOnly) {\n    @for (minute of minutes; track minute) {\n      <mat-option\n        class=\"eui-time-picker-option\"\n        [value]=\"minute.minuteText\"\n        [disabled]=\"minute.disabled\"\n        [attr.data-testid]=\"testId + '.minutemenu.' + minute.minute\"\n        >{{ minute.minuteText }}</mat-option\n        >\n      }\n    }\n  </mat-autocomplete>\n", styles: [".eui-time-picker-container{display:inline-block}.eui-time-picker-container .mat-mdc-form-field.time-selects{width:45px;vertical-align:middle}.eui-time-picker-container .time-input{text-align:center}.eui-time-picker-container .separator{margin:0 5px;display:inline-block}.eui-time-picker-container .ampm-toggle{margin-left:10px;min-width:0;width:39px;padding:0;line-height:39px;vertical-align:middle}.eui-time-picker-container .errorContainer{margin-top:4px;min-height:16px}.eui-time-picker-container .errorContainer.no-margin{min-height:0;margin-top:0}.eui-time-picker-container .errorContainer .eui-form-field-subscript:before{content:inherit}.eui-time-picker-container .eui-time-picker--readonly{white-space:pre-line;word-wrap:break-word;word-break:break-word}:host-context([dir=rtl]) .eui-time-picker-container .ampm-toggle{margin-left:0;margin-right:10px}::ng-deep .eui-time-picker-option .mat-pseudo-checkbox{display:none}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: i2$2.MatAutocomplete, selector: "mat-autocomplete", inputs: ["aria-label", "aria-labelledby", "displayWith", "autoActiveFirstOption", "autoSelectActiveOption", "requireSelection", "panelWidth", "disableRipple", "class", "hideSingleSelectionIndicator"], outputs: ["optionSelected", "opened", "closed", "optionActivated"], exportAs: ["matAutocomplete"] }, { kind: "component", type: i2$2.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "directive", type: i2$2.MatAutocompleteTrigger, selector: "input[matAutocomplete], textarea[matAutocomplete]", inputs: ["matAutocomplete", "matAutocompletePosition", "matAutocompleteConnectedTo", "autocomplete", "matAutocompleteDisabled"], exportAs: ["matAutocompleteTrigger"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i2$1.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i2$1.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "directive", type: i6.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i6.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i6.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "component", type: EuiLabelComponent, selector: "eui-label", inputs: ["for", "required", "errorState", "disabled"] }, { kind: "pipe", type: EuiDateFormatPipe, name: "euiDateFormat" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTimePickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-time-picker', standalone: false, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n<div class=\"eui-time-picker-container\" [ngStyle]=\"fieldStyles\">\n  @if (label) {\n    <eui-label [required]=\"isRequired\" [disabled]=\"disabled\" [errorState]=\"hasErrors()\">{{ label }}</eui-label>\n  }\n  \n  @if (readonly) {\n    <span class=\"eui-time-picker--readonly\">\n      <span #readonlyProjectedContent>\n        <ng-content select=\"eui-readonly-label\"></ng-content>\n      </span>\n      @if (!readonlyProjectedContent.childElementCount) {\n        @if (timeControl.value){\n          {{ timeControl.value | euiDateFormat:'LT' }}\n        }\n        @else {\n          &mdash;\n        }\n      }\n    </span>\n  }\n  \n  <span [ngClass]=\"{'eui-hidden': readonly }\">\n    <mat-form-field class=\"time-selects eui-input--no-margin\" [appearance]=\"appearance\">\n      <input\n        matInput\n        class=\"time-input\"\n        [formControl]=\"hourControl\"\n        autocomplete=\"off\"\n        [matAutocomplete]=\"hourAutocomplete\"\n        [attr.data-testid]=\"testId + '.input.hour'\"\n        (keydown)=\"onKeyDown($event)\"\n        />\n    </mat-form-field>\n    <div class=\"separator\">:</div>\n    <mat-form-field class=\"time-selects eui-input--no-margin\" [appearance]=\"appearance\">\n      <input\n        matInput\n        class=\"time-input\"\n        [formControl]=\"minuteControl\"\n        autocomplete=\"off\"\n        [matAutocomplete]=\"minuteAutocomplete\"\n        [attr.data-testid]=\"testId + '.input.minute'\"\n        (keydown)=\"onKeyDown($event)\"\n        />\n    </mat-form-field>\n\n    @if (showAmPm) {\n      <button mat-flat-button class=\"ampm-toggle\" color=\"primary\" [disabled]=\"disabled\" (click)=\"toggleAmPm()\" [attr.data-testid]=\"testId + '.button.amPmToggle'\">\n        {{ timeAmPm }}\n      </button>\n    }\n\n    <div class=\"errorContainer\" [ngClass]=\"{ 'no-margin': noMargin }\">\n      <mat-error class=\"eui-form-field-subscript\">\n        <ng-content select=\"mat-error\"></ng-content>\n      </mat-error>\n    </div>\n  </span>\n</div>\n\n<mat-autocomplete #hourAutocomplete=\"matAutocomplete\">\n  @for (hour of clockHours; track hour) {\n    <mat-option\n      class=\"eui-time-picker-option\"\n      [value]=\"hour.hourText\"\n      [disabled]=\"hour.disabled\"\n      [attr.data-testid]=\"testId + '.hourmenu.' + hour.hour\"\n      >{{ hour.hourText }}</mat-option\n      >\n  }\n</mat-autocomplete>\n\n<mat-autocomplete #minuteAutocomplete=\"matAutocomplete\">\n  @if (!hourOnly) {\n    @for (minute of minutes; track minute) {\n      <mat-option\n        class=\"eui-time-picker-option\"\n        [value]=\"minute.minuteText\"\n        [disabled]=\"minute.disabled\"\n        [attr.data-testid]=\"testId + '.minutemenu.' + minute.minute\"\n        >{{ minute.minuteText }}</mat-option\n        >\n      }\n    }\n  </mat-autocomplete>\n", styles: [".eui-time-picker-container{display:inline-block}.eui-time-picker-container .mat-mdc-form-field.time-selects{width:45px;vertical-align:middle}.eui-time-picker-container .time-input{text-align:center}.eui-time-picker-container .separator{margin:0 5px;display:inline-block}.eui-time-picker-container .ampm-toggle{margin-left:10px;min-width:0;width:39px;padding:0;line-height:39px;vertical-align:middle}.eui-time-picker-container .errorContainer{margin-top:4px;min-height:16px}.eui-time-picker-container .errorContainer.no-margin{min-height:0;margin-top:0}.eui-time-picker-container .errorContainer .eui-form-field-subscript:before{content:inherit}.eui-time-picker-container .eui-time-picker--readonly{white-space:pre-line;word-wrap:break-word;word-break:break-word}:host-context([dir=rtl]) .eui-time-picker-container .ampm-toggle{margin-left:0;margin-right:10px}::ng-deep .eui-time-picker-option .mat-pseudo-checkbox{display:none}\n"] }]
        }], ctorParameters: () => [], propDecorators: { testId: [{
                type: Input
            }], timeControl: [{
                type: Input
            }], allowTextInput: [{
                type: Input
            }], label: [{
                type: Input
            }], appearance: [{
                type: Input
            }], disabled: [{
                type: Input
            }], required: [{
                type: Input
            }], readonly: [{
                type: Input
            }], min: [{
                type: Input
            }], max: [{
                type: Input
            }], width: [{
                type: Input
            }], hourOnly: [{
                type: Input
            }], permittedHours: [{
                type: Input
            }], noMargin: [{
                type: Input
            }], value: [{
                type: Input
            }], minuteResolution: [{
                type: Input
            }], valueChange: [{
                type: Output
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiTopNavigationCustomMenuItemComponent {
    /** @internal */
    ngOnInit() {
        const viewContainerRef = this.viewContainerRef;
        viewContainerRef.clear();
        viewContainerRef.createComponent(this.component);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTopNavigationCustomMenuItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.2.1", type: EuiTopNavigationCustomMenuItemComponent, isStandalone: false, selector: "eui-top-navigation-custom-menu-item", inputs: { component: "component" }, viewQueries: [{ propertyName: "viewContainerRef", first: true, predicate: ["dynamic"], descendants: true, read: ViewContainerRef, static: true }], ngImport: i0, template: "<!--\n    Copyright 2025 One Identity LLC.\n    ALL RIGHTS RESERVED.\n-->\n\n<ng-template #dynamic></ng-template>\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTopNavigationCustomMenuItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-top-navigation-custom-menu-item', standalone: false, template: "<!--\n    Copyright 2025 One Identity LLC.\n    ALL RIGHTS RESERVED.\n-->\n\n<ng-template #dynamic></ng-template>\n" }]
        }], propDecorators: { component: [{
                type: Input
            }], viewContainerRef: [{
                type: ViewChild,
                args: ['dynamic', { read: ViewContainerRef, static: true }]
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
/**
 * Enum for valid types of top navigation items.
 */
var EuiTopNavigationItemType;
(function (EuiTopNavigationItemType) {
    EuiTopNavigationItemType[EuiTopNavigationItemType["RouterLink"] = 0] = "RouterLink";
    EuiTopNavigationItemType[EuiTopNavigationItemType["ExternalLink"] = 1] = "ExternalLink";
    EuiTopNavigationItemType[EuiTopNavigationItemType["Menu"] = 2] = "Menu";
    EuiTopNavigationItemType[EuiTopNavigationItemType["Custom"] = 3] = "Custom";
})(EuiTopNavigationItemType || (EuiTopNavigationItemType = {}));

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiTestIdPipe {
    transform(value, ...args) {
        const params = args.join('-').toLowerCase();
        const newParam = params.replace(/ /g, '-');
        return value + newParam;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTestIdPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "20.2.1", ngImport: i0, type: EuiTestIdPipe, isStandalone: false, name: "euiTestId" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTestIdPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'euiTestId',
                    standalone: false,
                }]
        }] });

class EuiTopNavigationMenuItemComponent {
    constructor(router) {
        this.router = router;
        /**
         * Allows the EuiTopNavigationItemType enum to be used within the component HTML.
         *
         * @internal */
        this.itemTypes = EuiTopNavigationItemType;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTopNavigationMenuItemComponent, deps: [{ token: i1$8.Router }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.2.1", type: EuiTopNavigationMenuItemComponent, isStandalone: false, selector: "eui-top-navigation-menu-item", inputs: { items: "items", direction: "direction" }, viewQueries: [{ propertyName: "childMenu", first: true, predicate: ["childMenu"], descendants: true, static: true }], ngImport: i0, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<div [dir]=\"direction\">\n  <mat-menu #childMenu=\"matMenu\" [overlapTrigger]=\"false\" class=\"eui-top-navigation-menu\">\n    @for (child of items; track child) {\n      <span>\n        @switch (child.type) {\n          @case (itemTypes.Menu) {\n            <span>\n              <button mat-menu-item [matMenuTriggerFor]=\"menu.childMenu\" [attr.data-testid]=\"'eui-top-navigation-child-item-' | euiTestId : child.testIdSuffix ?? child.text\">\n                <span [attr.aria-label]=\"child.text\">{{ child.text }}</span>\n              </button>\n              <eui-top-navigation-menu-item #menu [items]=\"child.items\" [direction]=\"direction\"></eui-top-navigation-menu-item>\n            </span>\n          }\n          @case (itemTypes.RouterLink) {\n            <span>\n              <button mat-menu-item [routerLink]=\"child.url\" [attr.data-testid]=\"'eui-top-navigation-child-item-' | euiTestId : child.testIdSuffix ?? child.text\">\n                <span [attr.aria-label]=\"child.text\">{{ child.text }}</span>\n              </button>\n            </span>\n          }\n          @case (itemTypes.ExternalLink) {\n            <span>\n              <a [href]=\"child.url\" target=\"_blank\" [attr.data-testid]=\"'eui-top-navigation-child-item-' | euiTestId : child.testIdSuffix ?? child.text\">\n                <button mat-menu-item>\n                  <span [attr.aria-label]=\"child.text\">{{ child.text }}</span>\n                </button>\n              </a>\n            </span>\n          }\n          @case (itemTypes.Custom) {\n            <span>\n              <eui-top-navigation-custom-menu-item [component]=\"child.component\"></eui-top-navigation-custom-menu-item>\n            </span>\n          }\n        }\n      </span>\n    }\n  </mat-menu>\n</div>\n", dependencies: [{ kind: "directive", type: i1$5.Dir, selector: "[dir]", inputs: ["dir"], outputs: ["dirChange"], exportAs: ["dir"] }, { kind: "component", type: i3$4.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: i3$4.MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "directive", type: i3$4.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "directive", type: i1$8.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: EuiTopNavigationCustomMenuItemComponent, selector: "eui-top-navigation-custom-menu-item", inputs: ["component"] }, { kind: "component", type: EuiTopNavigationMenuItemComponent, selector: "eui-top-navigation-menu-item", inputs: ["items", "direction"] }, { kind: "pipe", type: EuiTestIdPipe, name: "euiTestId" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTopNavigationMenuItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-top-navigation-menu-item', standalone: false, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<div [dir]=\"direction\">\n  <mat-menu #childMenu=\"matMenu\" [overlapTrigger]=\"false\" class=\"eui-top-navigation-menu\">\n    @for (child of items; track child) {\n      <span>\n        @switch (child.type) {\n          @case (itemTypes.Menu) {\n            <span>\n              <button mat-menu-item [matMenuTriggerFor]=\"menu.childMenu\" [attr.data-testid]=\"'eui-top-navigation-child-item-' | euiTestId : child.testIdSuffix ?? child.text\">\n                <span [attr.aria-label]=\"child.text\">{{ child.text }}</span>\n              </button>\n              <eui-top-navigation-menu-item #menu [items]=\"child.items\" [direction]=\"direction\"></eui-top-navigation-menu-item>\n            </span>\n          }\n          @case (itemTypes.RouterLink) {\n            <span>\n              <button mat-menu-item [routerLink]=\"child.url\" [attr.data-testid]=\"'eui-top-navigation-child-item-' | euiTestId : child.testIdSuffix ?? child.text\">\n                <span [attr.aria-label]=\"child.text\">{{ child.text }}</span>\n              </button>\n            </span>\n          }\n          @case (itemTypes.ExternalLink) {\n            <span>\n              <a [href]=\"child.url\" target=\"_blank\" [attr.data-testid]=\"'eui-top-navigation-child-item-' | euiTestId : child.testIdSuffix ?? child.text\">\n                <button mat-menu-item>\n                  <span [attr.aria-label]=\"child.text\">{{ child.text }}</span>\n                </button>\n              </a>\n            </span>\n          }\n          @case (itemTypes.Custom) {\n            <span>\n              <eui-top-navigation-custom-menu-item [component]=\"child.component\"></eui-top-navigation-custom-menu-item>\n            </span>\n          }\n        }\n      </span>\n    }\n  </mat-menu>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1$8.Router }], propDecorators: { items: [{
                type: Input
            }], direction: [{
                type: Input
            }], childMenu: [{
                type: ViewChild,
                args: ['childMenu', { static: true }]
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiTopNavigationService {
    constructor(router) {
        this.router = router;
    }
    /**
     * Returns a boolean for whether the top navigation item passed to it is active or not.
     *
     * @param item Top navigation item that needs the isActive check
     * @param children Optional array of top navigation item children that should be checked for isActive
     */
    isActive(item, children) {
        let active = false;
        if (!children) {
            children = item.items;
        }
        children.forEach((childItem) => {
            if (childItem.type === EuiTopNavigationItemType.RouterLink) {
                const url = typeof childItem.url === 'string' ? [childItem.url] : childItem.url;
                const urlCreationOptions = {
                    relativeTo: childItem.routerLinkOptions?.relativeTo,
                    queryParams: childItem.routerLinkOptions?.queryParams,
                    fragment: childItem.routerLinkOptions?.fragment,
                    queryParamsHandling: childItem.routerLinkOptions?.queryParamsHandling,
                    preserveFragment: childItem.routerLinkOptions?.preserveFragment,
                };
                const urlOrTree = this.router.createUrlTree(url, urlCreationOptions);
                const routerLinkActiveOptions = childItem.routerLinkActiveOptions || {
                    paths: 'subset',
                    queryParams: 'subset',
                    matrixParams: 'ignored',
                    fragment: 'ignored',
                };
                if (this.router.isActive(urlOrTree, routerLinkActiveOptions)) {
                    active = true;
                }
            }
            if (childItem.type === EuiTopNavigationItemType.Menu) {
                const isActive = this.isActive(item, childItem.items);
                if (isActive) {
                    active = true;
                }
            }
        });
        return active;
    }
    /**
     * Collapses all items that are not active.
     *
     * @param items Items array that needs to be collapsed if not active
     */
    collapseItems(items) {
        if (!items) {
            return;
        }
        items.forEach((item) => {
            if (item.type === EuiTopNavigationItemType.Menu) {
                item.expanded = this.isActive(item);
                this.collapseItems(item.items);
            }
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTopNavigationService, deps: [{ token: i1$8.Router }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTopNavigationService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTopNavigationService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1$8.Router }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiTopNavigationMobileMenuItemComponent {
    constructor(router, topNav) {
        this.router = router;
        this.topNav = topNav;
        /**
         * Allows the EuiTopNavigationItemType enum to be used within the component HTML.
         */
        this.itemTypes = EuiTopNavigationItemType;
    }
    /**
     * Updates expanded property of item passed to it.
     *
     * @param item Item whose expanded property will be updated.
     * @internal */
    expand(item) {
        item.expanded = item.expanded ? false : true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTopNavigationMobileMenuItemComponent, deps: [{ token: i1$8.Router }, { token: EuiTopNavigationService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.2.1", type: EuiTopNavigationMobileMenuItemComponent, isStandalone: false, selector: "eui-top-navigation-mobile-menu-item", inputs: { items: "items", level: "level" }, ngImport: i0, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n<div class=\"eui-top-navigation-mobile-menu\" [ngClass]=\"{ 'eui-top-navigation-mobile-menu-level-1': level === 1, 'eui-top-navigation-mobile-menu-level-2': level >= 2 }\">\n  @for (child of items; track child) {\n    <span>\n      @switch (child.type) {\n        @case (itemTypes.Menu) {\n          <span>\n            <button\n              mat-button\n              (click)=\"expand(child)\"\n              [ngClass]=\"{ 'eui-top-navigation-item-active': topNav.isActive(child), 'eui-top-navigation-item-expanded-btn': child.expanded }\"\n              [attr.aria-current]=\"topNav.isActive(child)\"\n              [attr.aria-expanded]=\"child.expanded\"\n              [attr.data-testid]=\"'eui-top-navigation-child-mobile-item-' | euiTestId : child.testIdSuffix ?? child.text\"\n              >\n              <span [attr.aria-label]=\"child.text\">{{ child.text }}</span>\n              <eui-icon [icon]=\"child.expanded ? 'chevronup' : 'chevrondown'\" size=\"14px\"></eui-icon>\n            </button>\n            <eui-top-navigation-mobile-menu-item\n              [items]=\"child.items\"\n              [level]=\"level + 1\"\n              [ngClass]=\"{ 'eui-top-navigation-item-expanded': child.expanded }\"\n            ></eui-top-navigation-mobile-menu-item>\n          </span>\n        }\n        @case (itemTypes.RouterLink) {\n          <span>\n            <button\n              mat-button\n              [routerLink]=\"child.url\"\n              routerLinkActive=\"eui-top-navigation-item-active-link\"\n              [routerLinkActiveOptions]=\"child.routerLinkActiveOptions || { paths: 'subset', queryParams: 'subset', matrixParams: 'ignored', fragment: 'ignored' }\"\n              [attr.data-testid]=\"'eui-top-navigation-child-mobile-item-' | euiTestId : child.testIdSuffix ?? child.text\"\n              [queryParams]=\"child.routerLinkOptions?.queryParams\"\n              [fragment]=\"child.routerLinkOptions?.fragment\"\n              [queryParamsHandling]=\"child.routerLinkOptions?.queryParamsHandling\"\n              [preserveFragment]=\"child.routerLinkOptions?.preserveFragment\"\n              [skipLocationChange]=\"child.routerLinkOptions?.skipLocationChange\"\n              [replaceUrl]=\"child.routerLinkOptions?.replaceUrl\"\n              [state]=\"child.routerLinkOptions?.state\"\n              [relativeTo]=\"child.routerLinkOptions?.relativeTo\"\n              >\n              <span [attr.aria-label]=\"child.text\">{{ child.text }}</span>\n            </button>\n          </span>\n        }\n        @case (itemTypes.ExternalLink) {\n          <span>\n            <a [href]=\"child.url\" target=\"_blank\" [attr.data-testid]=\"'eui-top-navigation-child-mobile-item-' | euiTestId : child.testIdSuffix ?? child.text\">\n              <button mat-button>\n                <span [attr.aria-label]=\"child.text\">{{ child.text }}</span>\n              </button>\n            </a>\n          </span>\n        }\n        @case (itemTypes.Custom) {\n          <span>\n            <eui-top-navigation-custom-menu-item [component]=\"child.component\"></eui-top-navigation-custom-menu-item>\n          </span>\n        }\n      }\n    </span>\n  }\n</div>\n", dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: i1$8.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: i1$8.RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "component", type: EuiIconComponent, selector: "eui-icon", inputs: ["aria-hidden", "setLineHeight", "icon", "size"] }, { kind: "component", type: EuiTopNavigationCustomMenuItemComponent, selector: "eui-top-navigation-custom-menu-item", inputs: ["component"] }, { kind: "component", type: EuiTopNavigationMobileMenuItemComponent, selector: "eui-top-navigation-mobile-menu-item", inputs: ["items", "level"] }, { kind: "pipe", type: EuiTestIdPipe, name: "euiTestId" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTopNavigationMobileMenuItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-top-navigation-mobile-menu-item', standalone: false, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n<div class=\"eui-top-navigation-mobile-menu\" [ngClass]=\"{ 'eui-top-navigation-mobile-menu-level-1': level === 1, 'eui-top-navigation-mobile-menu-level-2': level >= 2 }\">\n  @for (child of items; track child) {\n    <span>\n      @switch (child.type) {\n        @case (itemTypes.Menu) {\n          <span>\n            <button\n              mat-button\n              (click)=\"expand(child)\"\n              [ngClass]=\"{ 'eui-top-navigation-item-active': topNav.isActive(child), 'eui-top-navigation-item-expanded-btn': child.expanded }\"\n              [attr.aria-current]=\"topNav.isActive(child)\"\n              [attr.aria-expanded]=\"child.expanded\"\n              [attr.data-testid]=\"'eui-top-navigation-child-mobile-item-' | euiTestId : child.testIdSuffix ?? child.text\"\n              >\n              <span [attr.aria-label]=\"child.text\">{{ child.text }}</span>\n              <eui-icon [icon]=\"child.expanded ? 'chevronup' : 'chevrondown'\" size=\"14px\"></eui-icon>\n            </button>\n            <eui-top-navigation-mobile-menu-item\n              [items]=\"child.items\"\n              [level]=\"level + 1\"\n              [ngClass]=\"{ 'eui-top-navigation-item-expanded': child.expanded }\"\n            ></eui-top-navigation-mobile-menu-item>\n          </span>\n        }\n        @case (itemTypes.RouterLink) {\n          <span>\n            <button\n              mat-button\n              [routerLink]=\"child.url\"\n              routerLinkActive=\"eui-top-navigation-item-active-link\"\n              [routerLinkActiveOptions]=\"child.routerLinkActiveOptions || { paths: 'subset', queryParams: 'subset', matrixParams: 'ignored', fragment: 'ignored' }\"\n              [attr.data-testid]=\"'eui-top-navigation-child-mobile-item-' | euiTestId : child.testIdSuffix ?? child.text\"\n              [queryParams]=\"child.routerLinkOptions?.queryParams\"\n              [fragment]=\"child.routerLinkOptions?.fragment\"\n              [queryParamsHandling]=\"child.routerLinkOptions?.queryParamsHandling\"\n              [preserveFragment]=\"child.routerLinkOptions?.preserveFragment\"\n              [skipLocationChange]=\"child.routerLinkOptions?.skipLocationChange\"\n              [replaceUrl]=\"child.routerLinkOptions?.replaceUrl\"\n              [state]=\"child.routerLinkOptions?.state\"\n              [relativeTo]=\"child.routerLinkOptions?.relativeTo\"\n              >\n              <span [attr.aria-label]=\"child.text\">{{ child.text }}</span>\n            </button>\n          </span>\n        }\n        @case (itemTypes.ExternalLink) {\n          <span>\n            <a [href]=\"child.url\" target=\"_blank\" [attr.data-testid]=\"'eui-top-navigation-child-mobile-item-' | euiTestId : child.testIdSuffix ?? child.text\">\n              <button mat-button>\n                <span [attr.aria-label]=\"child.text\">{{ child.text }}</span>\n              </button>\n            </a>\n          </span>\n        }\n        @case (itemTypes.Custom) {\n          <span>\n            <eui-top-navigation-custom-menu-item [component]=\"child.component\"></eui-top-navigation-custom-menu-item>\n          </span>\n        }\n      }\n    </span>\n  }\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1$8.Router }, { type: EuiTopNavigationService }], propDecorators: { items: [{
                type: Input
            }], level: [{
                type: Input
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiTopNavigationComponent {
    constructor(router, changeRef, topNav) {
        this.router = router;
        this.changeRef = changeRef;
        this.topNav = topNav;
        /**
         * The direction that the text should display. This affects which side the menu opens on.
         *
         * @category Input
         */
        this.direction = 'ltr';
        /**
         * Allows the EuiTopNavigationItemType enum to be used within the component HTML.
         *
         * @internal
         */
        this.itemTypes = EuiTopNavigationItemType;
        /**
         * Defines whether the mobile menu sidebar is displayed.
         *
         * @internal
         */
        this.showMobileMenu = false;
        this.router.events.subscribe(() => {
            this.showMobileMenu = false;
            this.topNav.collapseItems(this.items);
        });
    }
    /**
     * Triggered when the window size changes. Hides the mobile menu if the viewport size is greater than the mobile breakpoint size.
     *
     * @internal
     */
    onResize() {
        if (!this.isMobile) {
            this.showMobileMenu = false;
        }
        this.changeRef.markForCheck();
    }
    /**
     * Checks the viewport width to see if it is smaller than or equal to the mobile breakpoint size.
     *
     * @internal
     */
    get isMobile() {
        return document.body.offsetWidth <= 768;
    }
    /**
     * Determines whether the navigation item or any of its children are active
     *
     * @internal
     */
    isActive(item, children) {
        return this.topNav.isActive(item, children);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTopNavigationComponent, deps: [{ token: i1$8.Router }, { token: i0.ChangeDetectorRef }, { token: EuiTopNavigationService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.2.1", type: EuiTopNavigationComponent, isStandalone: false, selector: "eui-top-navigation", inputs: { items: "items", direction: "direction", centered: "centered" }, host: { listeners: { "window:resize": "onResize()" } }, ngImport: i0, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n@if (!isMobile) {\n  <div class=\"eui-top-navigation-desktop\">\n    <ng-template [ngTemplateOutlet]=\"navContent\"></ng-template>\n  </div>\n}\n\n@if (showMobileMenu) {\n  <div class=\"eui-top-navigation-mobile-overlay\" (click)=\"showMobileMenu = false\" data-testid=\"eui-top-navigation-mobile-menu-overlay\"></div>\n}\n\n@if (isMobile && showMobileMenu) {\n  <div class=\"eui-top-navigation-mobile\" [@slideInOut]=\"direction\">\n    <div class=\"eui-top-navigation-mobile-content\">\n      <ng-template [ngTemplateOutlet]=\"navContent\"></ng-template>\n    </div>\n    <div class=\"eui-top-navigation-mobile-footer\" #footer [hidden]=\"!footer.innerHTML.trim()\">\n      <ng-content select=\"[eui-top-navigation-mobile-footer]\"></ng-content>\n    </div>\n  </div>\n}\n\n<div class=\"eui-top-navigation-mobile-hamburger\">\n  <button mat-button (click)=\"showMobileMenu = !showMobileMenu\" data-testid=\"eui-top-navigation-mobile-menu-toggle\">\n    <mat-icon>menu</mat-icon>\n  </button>\n</div>\n\n<ng-template #navContent>\n  <div class=\"eui-top-navigation\">\n    <div class=\"eui-top-navigation-content\" [ngClass]=\"{ 'eui-top-navigation-centered': centered }\">\n      @for (item of items; track item) {\n        <div class=\"eui-top-navigation-item\">\n          <span>\n            @switch (item.type) {\n              @case (itemTypes.ExternalLink) {\n                <span>\n                  <a [href]=\"item.url\" target=\"_blank\" [attr.data-testid]=\"'eui-top-navigation-item-' | euiTestId : item.testIdSuffix ?? item.text\" role=\"button\">\n                    <button mat-button>\n                      <span [attr.aria-label]=\"item.text\">{{ item.text }}</span>\n                    </button>\n                  </a>\n                </span>\n              }\n              @case (itemTypes.RouterLink) {\n                <span>\n                  <button\n                    mat-button\n                    [routerLink]=\"item.url\"\n                    routerLinkActive=\"eui-top-navigation-item-active-link\"\n                    [routerLinkActiveOptions]=\"item.routerLinkActiveOptions || { paths: 'subset', queryParams: 'subset', matrixParams: 'ignored', fragment: 'ignored' }\"\n                    [attr.data-testid]=\"'eui-top-navigation-item-' | euiTestId : item.testIdSuffix ?? item.text\"\n                    [queryParams]=\"item.routerLinkOptions?.queryParams\"\n                    [fragment]=\"item.routerLinkOptions?.fragment\"\n                    [queryParamsHandling]=\"item.routerLinkOptions?.queryParamsHandling\"\n                    [preserveFragment]=\"item.routerLinkOptions?.preserveFragment\"\n                    [skipLocationChange]=\"item.routerLinkOptions?.skipLocationChange\"\n                    [replaceUrl]=\"item.routerLinkOptions?.replaceUrl\"\n                    [state]=\"item.routerLinkOptions?.state\"\n                    [relativeTo]=\"item.routerLinkOptions?.relativeTo\"\n                    >\n                    <span [attr.aria-label]=\"item.text\">{{ item.text }}</span>\n                  </button>\n                </span>\n              }\n              @case (itemTypes.Menu) {\n                <span>\n                  @if (!isMobile) {\n                    <span>\n                      <button\n                        mat-button\n                        [matMenuTriggerFor]=\"menu.childMenu\"\n                        #menuTrigger=\"matMenuTrigger\"\n                        [ngClass]=\"{ 'eui-top-navigation-item-active': isActive(item) }\"\n                        [attr.aria-current]=\"isActive(item)\"\n                        [attr.data-testid]=\"'eui-top-navigation-item-' | euiTestId : item.testIdSuffix ?? item.text\"\n                        >\n                        <span [attr.aria-label]=\"item.text\">{{ item.text }}</span>\n                        <eui-icon icon=\"collapsedown\" class=\"eui-top-navigation-menu-icon\"></eui-icon>\n                      </button>\n                      <eui-top-navigation-menu-item #menu [items]=\"item.items\" [direction]=\"direction\"> </eui-top-navigation-menu-item>\n                    </span>\n                  }\n                  @if (isMobile) {\n                    <span>\n                      <button\n                        mat-button\n                        (click)=\"mobilemenu.expand(item)\"\n                        [ngClass]=\"{ 'eui-top-navigation-item-active': isActive(item), 'eui-top-navigation-item-expanded-btn': item.expanded }\"\n                        [attr.aria-current]=\"isActive(item)\"\n                        [attr.data-testid]=\"'eui-top-navigation-item-' | euiTestId : item.testIdSuffix ?? item.text\"\n                        >\n                        <span [attr.aria-label]=\"item.text\">{{ item.text }}</span>\n                        <eui-icon [icon]=\"item.expanded ? 'chevronup' : 'chevrondown'\" size=\"14px\"></eui-icon>\n                      </button>\n                      <eui-top-navigation-mobile-menu-item\n                        #mobilemenu\n                        [items]=\"item.items\"\n                        [level]=\"1\"\n                        [ngClass]=\"{ 'eui-top-navigation-item-expanded': item.expanded }\"\n                      ></eui-top-navigation-mobile-menu-item>\n                    </span>\n                  }\n                </span>\n              }\n              @case (itemTypes.Custom) {\n                <span>\n                  <eui-top-navigation-custom-menu-item [component]=\"item.component\"></eui-top-navigation-custom-menu-item>\n                </span>\n              }\n            }\n          </span>\n        </div>\n      }\n    </div>\n  </div>\n</ng-template>\n", styles: [".eui-dark-theme .eui-top-navigation-desktop .eui-top-navigation{background-color:#444647;border-bottom:1px solid rgba(255,255,255,.3)}.eui-dark-theme .eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-item-active .mat-mdc-button,.eui-dark-theme .eui-top-navigation-desktop .eui-top-navigation .mat-mdc-button.eui-top-navigation-item-active,.eui-dark-theme .eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-item-active-link .mat-mdc-button,.eui-dark-theme .eui-top-navigation-desktop .eui-top-navigation .mat-mdc-button.eui-top-navigation-item-active-link{border-bottom:2px solid #8acbe3;color:#8acbe3}.eui-dark-theme .eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-menu-icon,.eui-dark-theme .eui-top-navigation-menu .mat-mdc-menu-submenu-icon{color:#8acbe3}.eui-contrast-theme .eui-top-navigation-desktop .eui-top-navigation{background-color:#2f3233;border-bottom:1px solid rgba(255,255,255,.8)}.eui-contrast-theme .eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-item-active .mat-mdc-button,.eui-contrast-theme .eui-top-navigation-desktop .eui-top-navigation .mat-mdc-button.eui-top-navigation-item-active,.eui-contrast-theme .eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-item-active-link .mat-mdc-button,.eui-contrast-theme .eui-top-navigation-desktop .eui-top-navigation .mat-mdc-button.eui-top-navigation-item-active-link{border-bottom:2px solid #8acbe3;color:#8acbe3}.eui-contrast-theme .eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-menu-icon,.eui-contrast-theme .eui-top-navigation-menu .mat-mdc-menu-submenu-icon{color:#8acbe3}.eui-top-navigation-desktop .eui-top-navigation{background-color:#fff;border-bottom:1px solid rgba(0,0,0,.2)}.eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-item-active .mat-mdc-button,.eui-top-navigation-desktop .eui-top-navigation .mat-mdc-button.eui-top-navigation-item-active,.eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-item-active-link .mat-mdc-button,.eui-top-navigation-desktop .eui-top-navigation .mat-mdc-button.eui-top-navigation-item-active-link{border-bottom:2px solid #0a96d1;color:#0a96d1}.eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-menu-icon,.eui-top-navigation-menu .mat-mdc-menu-submenu-icon{color:#0a96d1}.eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-menu-icon{font-size:18px;line-height:18px;margin-top:1px}.eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-content{display:block;padding:0 32px}.eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-content .eui-top-navigation-item{display:inline-block;vertical-align:top}.eui-top-navigation-desktop .eui-top-navigation a{color:inherit;outline:0}.eui-top-navigation-desktop .eui-top-navigation a:focus .mat-mdc-button .mat-mdc-button-persistent-ripple:before{opacity:.12}.eui-top-navigation-desktop .eui-top-navigation .mat-mdc-button{min-width:inherit;font-weight:400;border-radius:0;padding-bottom:2px;padding-left:16px;padding-right:16px}.eui-top-navigation-desktop .eui-top-navigation .mat-mdc-button .eui-icon{margin-right:-4px}[dir=rtl] .eui-top-navigation-desktop .eui-top-navigation .mat-mdc-button .eui-icon{margin-left:-4px;margin-right:0}.eui-top-navigation-desktop .eui-top-navigation .mat-mdc-button.eui-top-navigation-item-active,.eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-item-active .mat-mdc-button,.eui-top-navigation-desktop .eui-top-navigation .mat-mdc-button.eui-top-navigation-item-active-link,.eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-item-active-link .mat-mdc-button{padding-bottom:0;font-weight:600}.eui-top-navigation-menu.mat-mdc-menu-panel{max-height:calc(100vh - 120px)}.eui-top-navigation-centered{max-width:1180px;margin:0 auto}@media screen and (max-width: 768px){.eui-top-navigation-menu.mat-mdc-menu-panel{max-height:calc(100vh - 200px)}.eui-top-navigation-menu.eui-top-navigation-menu-top.mat-mdc-menu-panel{margin-left:16px;margin-right:-16px}[dir=rtl] .eui-top-navigation-menu.eui-top-navigation-menu-top.mat-mdc-menu-panel{margin-left:-16px;margin-right:16px}}\n", ".eui-dark-theme .eui-top-navigation-mobile{background-color:#2f3233}.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content{border-bottom:1px solid #f2f6f7}.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button .eui-icon{color:#8acbe3}.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active,.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active-link{border-left:4px solid #8acbe3}[dir=rtl] .eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active,[dir=rtl] .eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active-link{border-right:4px solid #8acbe3}.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-expanded-btn{box-shadow:0 10px 10px -10px #0006}.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active .mat-mdc-button,.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active-link .mat-mdc-button{border-left:4px solid #8acbe3}[dir=rtl] .eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active .mat-mdc-button,[dir=rtl] .eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active-link .mat-mdc-button{border-right:4px solid #8acbe3}.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active-link,.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active,.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active-link .mat-mdc-button,.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active .mat-mdc-button{color:#8acbe3}.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1{background-color:#444647}.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2{background-color:#616566}.eui-dark-theme .eui-top-navigation-mobile-hamburger .mat-mdc-button{color:#f2f6f7}.eui-dark-theme .eui-top-navigation-mobile-overlay{background-color:#00000040}.eui-top-navigation-mobile{background-color:#fff}.eui-top-navigation-mobile .eui-top-navigation-mobile-content{border-bottom:1px solid #444647}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button .eui-icon{color:#0a96d1}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active,.eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active-link{border-left:4px solid #0a96d1}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active,[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active-link{border-right:4px solid #0a96d1}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-expanded-btn{box-shadow:0 10px 10px -10px #0006}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active .mat-mdc-button,.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active-link .mat-mdc-button{border-left:4px solid #0a96d1}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active .mat-mdc-button,[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active-link .mat-mdc-button{border-right:4px solid #0a96d1}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active-link,.eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active,.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active-link .mat-mdc-button,.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active .mat-mdc-button{color:#0a96d1}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1{background-color:#f2f6f7}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2{background-color:#c4cacc80}.eui-top-navigation-mobile-hamburger .mat-mdc-button{color:#fff}.eui-top-navigation-mobile-overlay{background-color:#00000040}.eui-top-navigation-mobile{z-index:960;width:250px;height:calc(100% - 56px);position:fixed;display:flex;flex-direction:column}.eui-top-navigation-mobile .eui-top-navigation-mobile-footer{padding:10px 4px}.eui-top-navigation-mobile .eui-top-navigation-mobile-footer .mat-mdc-button{margin:4px 0;width:100%;overflow:hidden;text-overflow:ellipsis;text-align:left}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-footer .mat-mdc-button{text-align:right}.eui-top-navigation-mobile .eui-top-navigation-mobile-footer .mat-mdc-button .mdc-button__label{width:100%;display:flex;align-items:center}.eui-top-navigation-mobile .eui-top-navigation-mobile-content{padding:16px 4px;flex:1;overflow:auto}.eui-top-navigation-mobile .eui-top-navigation-mobile-content a{color:inherit}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button{width:calc(100% + 8px);text-align:left;border-radius:0;margin-left:-4px;margin-right:-4px;padding:4px 16px 4px 20px;font-weight:500;margin-bottom:4px}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button .mdc-button__label{display:flex;align-items:center;justify-content:space-between;width:100%}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button .mdc-button__label>span{overflow:hidden;text-overflow:ellipsis}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button{padding-left:16px;padding-right:20px;text-align:right}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active,.eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active-link{padding-left:16px}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active,[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active-link{padding-right:16px;border-left:0}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active .mat-mdc-button,.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active-link .mat-mdc-button{padding-left:16px}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active .mat-mdc-button,[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active-link .mat-mdc-button{padding-left:inherit;padding-right:16px;border-left:0}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-expanded>.eui-top-navigation-mobile-menu{max-height:500px}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-expanded>.eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2{max-height:300px}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu{margin:-4px -4px 0;padding:0 4px;overflow:hidden;max-height:0;transition:max-height .5s}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu .mat-mdc-button:last-of-type{margin-bottom:0}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1 .mat-mdc-button{padding-left:40px}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1 .mat-mdc-button{padding-left:16px;padding-right:40px}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1 .mat-mdc-button.eui-top-navigation-item-active,.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1 .mat-mdc-button.eui-top-navigation-item-active-link{padding-left:36px}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1 .mat-mdc-button.eui-top-navigation-item-active,[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1 .mat-mdc-button.eui-top-navigation-item-active-link{padding-left:16px;padding-right:36px}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1 .eui-top-navigation-item-active .mat-mdc-button,.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1 .eui-top-navigation-item-active-link .mat-mdc-button{padding-left:36px}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1 .eui-top-navigation-item-active .mat-mdc-button,[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1 .eui-top-navigation-item-active-link .mat-mdc-button{padding-left:16px;padding-right:36px}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2{margin-top:0}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2 .mat-mdc-button{padding-left:60px}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2 .mat-mdc-button{padding-left:16px;padding-right:60px}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2 .mat-mdc-button.eui-top-navigation-item-active,.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2 .mat-mdc-button.eui-top-navigation-item-active-link{padding-left:56px}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2 .mat-mdc-button.eui-top-navigation-item-active,[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2 .mat-mdc-button.eui-top-navigation-item-active-link{padding-left:16px;padding-right:56px}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2 .eui-top-navigation-item-active .mat-mdc-button,.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2 .eui-top-navigation-item-active-link .mat-mdc-button{padding-left:56px}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2 .eui-top-navigation-item-active .mat-mdc-button,[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2 .eui-top-navigation-item-active-link .mat-mdc-button{padding-left:16px;padding-right:56px}.eui-top-navigation-mobile-hamburger{height:64px;display:flex;align-items:center;position:fixed;left:13px;top:0;z-index:950}[dir=rtl] .eui-top-navigation-mobile-hamburger{left:inherit;right:13px}.eui-top-navigation-mobile-hamburger .mat-mdc-button{padding:0;min-width:44px}.eui-top-navigation-mobile-hamburger .mat-mdc-button>.mat-icon{margin-right:0}[dir=rtl] .eui-top-navigation-mobile-hamburger .mat-mdc-button>.mat-icon{margin-left:0}.eui-top-navigation-mobile-hamburger .mat-icon{font-size:32px;height:35px;width:32px}.eui-top-navigation-mobile-overlay{position:fixed;inset:64px 0 0;z-index:900}@media screen and (min-width: 769px){.eui-top-navigation-mobile,.eui-top-navigation-mobile-hamburger,.eui-top-navigation-mobile-overlay{display:none!important}}@media screen and (max-width: 768px){.eui-top-navigation-mobile .eui-top-navigation-mobile-footer .mat-mdc-button.eui-masthead--icon-button{width:100%}.eui-top-navigation-mobile .eui-top-navigation-mobile-footer .mat-mdc-button.eui-masthead--icon-button .mdc-button__label span{display:inline-block}}@media screen and (max-width: 768px){.eui-top-navigation-mobile-hamburger{left:9px;height:56px}[dir=rtl] .eui-top-navigation-mobile-hamburger{left:inherit;right:9px}.eui-top-navigation-mobile-overlay{top:56px}}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i5$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: i3$4.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "directive", type: i1$8.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: i1$8.RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "component", type: EuiIconComponent, selector: "eui-icon", inputs: ["aria-hidden", "setLineHeight", "icon", "size"] }, { kind: "component", type: EuiTopNavigationCustomMenuItemComponent, selector: "eui-top-navigation-custom-menu-item", inputs: ["component"] }, { kind: "component", type: EuiTopNavigationMenuItemComponent, selector: "eui-top-navigation-menu-item", inputs: ["items", "direction"] }, { kind: "component", type: EuiTopNavigationMobileMenuItemComponent, selector: "eui-top-navigation-mobile-menu-item", inputs: ["items", "level"] }, { kind: "pipe", type: EuiTestIdPipe, name: "euiTestId" }], animations: [
            trigger('slideInOut', [
                transition('void => ltr', [
                    style({ transform: 'translateX(-100%)' }),
                    animate('200ms ease-in', style({ transform: 'translateX(0%)' })),
                ]),
                transition('ltr => void', [animate('200ms ease-in', style({ transform: 'translateX(-100%)' }))]),
                transition('void => rtl', [
                    style({ transform: 'translateX(100%)' }),
                    animate('200ms ease-in', style({ transform: 'translateX(0%)' })),
                ]),
                transition('rtl => void', [animate('200ms ease-in', style({ transform: 'translateX(100%)' }))]),
            ]),
        ], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiTopNavigationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-top-navigation', encapsulation: ViewEncapsulation.None, animations: [
                        trigger('slideInOut', [
                            transition('void => ltr', [
                                style({ transform: 'translateX(-100%)' }),
                                animate('200ms ease-in', style({ transform: 'translateX(0%)' })),
                            ]),
                            transition('ltr => void', [animate('200ms ease-in', style({ transform: 'translateX(-100%)' }))]),
                            transition('void => rtl', [
                                style({ transform: 'translateX(100%)' }),
                                animate('200ms ease-in', style({ transform: 'translateX(0%)' })),
                            ]),
                            transition('rtl => void', [animate('200ms ease-in', style({ transform: 'translateX(100%)' }))]),
                        ]),
                    ], standalone: false, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n@if (!isMobile) {\n  <div class=\"eui-top-navigation-desktop\">\n    <ng-template [ngTemplateOutlet]=\"navContent\"></ng-template>\n  </div>\n}\n\n@if (showMobileMenu) {\n  <div class=\"eui-top-navigation-mobile-overlay\" (click)=\"showMobileMenu = false\" data-testid=\"eui-top-navigation-mobile-menu-overlay\"></div>\n}\n\n@if (isMobile && showMobileMenu) {\n  <div class=\"eui-top-navigation-mobile\" [@slideInOut]=\"direction\">\n    <div class=\"eui-top-navigation-mobile-content\">\n      <ng-template [ngTemplateOutlet]=\"navContent\"></ng-template>\n    </div>\n    <div class=\"eui-top-navigation-mobile-footer\" #footer [hidden]=\"!footer.innerHTML.trim()\">\n      <ng-content select=\"[eui-top-navigation-mobile-footer]\"></ng-content>\n    </div>\n  </div>\n}\n\n<div class=\"eui-top-navigation-mobile-hamburger\">\n  <button mat-button (click)=\"showMobileMenu = !showMobileMenu\" data-testid=\"eui-top-navigation-mobile-menu-toggle\">\n    <mat-icon>menu</mat-icon>\n  </button>\n</div>\n\n<ng-template #navContent>\n  <div class=\"eui-top-navigation\">\n    <div class=\"eui-top-navigation-content\" [ngClass]=\"{ 'eui-top-navigation-centered': centered }\">\n      @for (item of items; track item) {\n        <div class=\"eui-top-navigation-item\">\n          <span>\n            @switch (item.type) {\n              @case (itemTypes.ExternalLink) {\n                <span>\n                  <a [href]=\"item.url\" target=\"_blank\" [attr.data-testid]=\"'eui-top-navigation-item-' | euiTestId : item.testIdSuffix ?? item.text\" role=\"button\">\n                    <button mat-button>\n                      <span [attr.aria-label]=\"item.text\">{{ item.text }}</span>\n                    </button>\n                  </a>\n                </span>\n              }\n              @case (itemTypes.RouterLink) {\n                <span>\n                  <button\n                    mat-button\n                    [routerLink]=\"item.url\"\n                    routerLinkActive=\"eui-top-navigation-item-active-link\"\n                    [routerLinkActiveOptions]=\"item.routerLinkActiveOptions || { paths: 'subset', queryParams: 'subset', matrixParams: 'ignored', fragment: 'ignored' }\"\n                    [attr.data-testid]=\"'eui-top-navigation-item-' | euiTestId : item.testIdSuffix ?? item.text\"\n                    [queryParams]=\"item.routerLinkOptions?.queryParams\"\n                    [fragment]=\"item.routerLinkOptions?.fragment\"\n                    [queryParamsHandling]=\"item.routerLinkOptions?.queryParamsHandling\"\n                    [preserveFragment]=\"item.routerLinkOptions?.preserveFragment\"\n                    [skipLocationChange]=\"item.routerLinkOptions?.skipLocationChange\"\n                    [replaceUrl]=\"item.routerLinkOptions?.replaceUrl\"\n                    [state]=\"item.routerLinkOptions?.state\"\n                    [relativeTo]=\"item.routerLinkOptions?.relativeTo\"\n                    >\n                    <span [attr.aria-label]=\"item.text\">{{ item.text }}</span>\n                  </button>\n                </span>\n              }\n              @case (itemTypes.Menu) {\n                <span>\n                  @if (!isMobile) {\n                    <span>\n                      <button\n                        mat-button\n                        [matMenuTriggerFor]=\"menu.childMenu\"\n                        #menuTrigger=\"matMenuTrigger\"\n                        [ngClass]=\"{ 'eui-top-navigation-item-active': isActive(item) }\"\n                        [attr.aria-current]=\"isActive(item)\"\n                        [attr.data-testid]=\"'eui-top-navigation-item-' | euiTestId : item.testIdSuffix ?? item.text\"\n                        >\n                        <span [attr.aria-label]=\"item.text\">{{ item.text }}</span>\n                        <eui-icon icon=\"collapsedown\" class=\"eui-top-navigation-menu-icon\"></eui-icon>\n                      </button>\n                      <eui-top-navigation-menu-item #menu [items]=\"item.items\" [direction]=\"direction\"> </eui-top-navigation-menu-item>\n                    </span>\n                  }\n                  @if (isMobile) {\n                    <span>\n                      <button\n                        mat-button\n                        (click)=\"mobilemenu.expand(item)\"\n                        [ngClass]=\"{ 'eui-top-navigation-item-active': isActive(item), 'eui-top-navigation-item-expanded-btn': item.expanded }\"\n                        [attr.aria-current]=\"isActive(item)\"\n                        [attr.data-testid]=\"'eui-top-navigation-item-' | euiTestId : item.testIdSuffix ?? item.text\"\n                        >\n                        <span [attr.aria-label]=\"item.text\">{{ item.text }}</span>\n                        <eui-icon [icon]=\"item.expanded ? 'chevronup' : 'chevrondown'\" size=\"14px\"></eui-icon>\n                      </button>\n                      <eui-top-navigation-mobile-menu-item\n                        #mobilemenu\n                        [items]=\"item.items\"\n                        [level]=\"1\"\n                        [ngClass]=\"{ 'eui-top-navigation-item-expanded': item.expanded }\"\n                      ></eui-top-navigation-mobile-menu-item>\n                    </span>\n                  }\n                </span>\n              }\n              @case (itemTypes.Custom) {\n                <span>\n                  <eui-top-navigation-custom-menu-item [component]=\"item.component\"></eui-top-navigation-custom-menu-item>\n                </span>\n              }\n            }\n          </span>\n        </div>\n      }\n    </div>\n  </div>\n</ng-template>\n", styles: [".eui-dark-theme .eui-top-navigation-desktop .eui-top-navigation{background-color:#444647;border-bottom:1px solid rgba(255,255,255,.3)}.eui-dark-theme .eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-item-active .mat-mdc-button,.eui-dark-theme .eui-top-navigation-desktop .eui-top-navigation .mat-mdc-button.eui-top-navigation-item-active,.eui-dark-theme .eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-item-active-link .mat-mdc-button,.eui-dark-theme .eui-top-navigation-desktop .eui-top-navigation .mat-mdc-button.eui-top-navigation-item-active-link{border-bottom:2px solid #8acbe3;color:#8acbe3}.eui-dark-theme .eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-menu-icon,.eui-dark-theme .eui-top-navigation-menu .mat-mdc-menu-submenu-icon{color:#8acbe3}.eui-contrast-theme .eui-top-navigation-desktop .eui-top-navigation{background-color:#2f3233;border-bottom:1px solid rgba(255,255,255,.8)}.eui-contrast-theme .eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-item-active .mat-mdc-button,.eui-contrast-theme .eui-top-navigation-desktop .eui-top-navigation .mat-mdc-button.eui-top-navigation-item-active,.eui-contrast-theme .eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-item-active-link .mat-mdc-button,.eui-contrast-theme .eui-top-navigation-desktop .eui-top-navigation .mat-mdc-button.eui-top-navigation-item-active-link{border-bottom:2px solid #8acbe3;color:#8acbe3}.eui-contrast-theme .eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-menu-icon,.eui-contrast-theme .eui-top-navigation-menu .mat-mdc-menu-submenu-icon{color:#8acbe3}.eui-top-navigation-desktop .eui-top-navigation{background-color:#fff;border-bottom:1px solid rgba(0,0,0,.2)}.eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-item-active .mat-mdc-button,.eui-top-navigation-desktop .eui-top-navigation .mat-mdc-button.eui-top-navigation-item-active,.eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-item-active-link .mat-mdc-button,.eui-top-navigation-desktop .eui-top-navigation .mat-mdc-button.eui-top-navigation-item-active-link{border-bottom:2px solid #0a96d1;color:#0a96d1}.eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-menu-icon,.eui-top-navigation-menu .mat-mdc-menu-submenu-icon{color:#0a96d1}.eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-menu-icon{font-size:18px;line-height:18px;margin-top:1px}.eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-content{display:block;padding:0 32px}.eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-content .eui-top-navigation-item{display:inline-block;vertical-align:top}.eui-top-navigation-desktop .eui-top-navigation a{color:inherit;outline:0}.eui-top-navigation-desktop .eui-top-navigation a:focus .mat-mdc-button .mat-mdc-button-persistent-ripple:before{opacity:.12}.eui-top-navigation-desktop .eui-top-navigation .mat-mdc-button{min-width:inherit;font-weight:400;border-radius:0;padding-bottom:2px;padding-left:16px;padding-right:16px}.eui-top-navigation-desktop .eui-top-navigation .mat-mdc-button .eui-icon{margin-right:-4px}[dir=rtl] .eui-top-navigation-desktop .eui-top-navigation .mat-mdc-button .eui-icon{margin-left:-4px;margin-right:0}.eui-top-navigation-desktop .eui-top-navigation .mat-mdc-button.eui-top-navigation-item-active,.eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-item-active .mat-mdc-button,.eui-top-navigation-desktop .eui-top-navigation .mat-mdc-button.eui-top-navigation-item-active-link,.eui-top-navigation-desktop .eui-top-navigation .eui-top-navigation-item-active-link .mat-mdc-button{padding-bottom:0;font-weight:600}.eui-top-navigation-menu.mat-mdc-menu-panel{max-height:calc(100vh - 120px)}.eui-top-navigation-centered{max-width:1180px;margin:0 auto}@media screen and (max-width: 768px){.eui-top-navigation-menu.mat-mdc-menu-panel{max-height:calc(100vh - 200px)}.eui-top-navigation-menu.eui-top-navigation-menu-top.mat-mdc-menu-panel{margin-left:16px;margin-right:-16px}[dir=rtl] .eui-top-navigation-menu.eui-top-navigation-menu-top.mat-mdc-menu-panel{margin-left:-16px;margin-right:16px}}\n", ".eui-dark-theme .eui-top-navigation-mobile{background-color:#2f3233}.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content{border-bottom:1px solid #f2f6f7}.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button .eui-icon{color:#8acbe3}.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active,.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active-link{border-left:4px solid #8acbe3}[dir=rtl] .eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active,[dir=rtl] .eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active-link{border-right:4px solid #8acbe3}.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-expanded-btn{box-shadow:0 10px 10px -10px #0006}.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active .mat-mdc-button,.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active-link .mat-mdc-button{border-left:4px solid #8acbe3}[dir=rtl] .eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active .mat-mdc-button,[dir=rtl] .eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active-link .mat-mdc-button{border-right:4px solid #8acbe3}.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active-link,.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active,.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active-link .mat-mdc-button,.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active .mat-mdc-button{color:#8acbe3}.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1{background-color:#444647}.eui-dark-theme .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2{background-color:#616566}.eui-dark-theme .eui-top-navigation-mobile-hamburger .mat-mdc-button{color:#f2f6f7}.eui-dark-theme .eui-top-navigation-mobile-overlay{background-color:#00000040}.eui-top-navigation-mobile{background-color:#fff}.eui-top-navigation-mobile .eui-top-navigation-mobile-content{border-bottom:1px solid #444647}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button .eui-icon{color:#0a96d1}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active,.eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active-link{border-left:4px solid #0a96d1}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active,[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active-link{border-right:4px solid #0a96d1}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-expanded-btn{box-shadow:0 10px 10px -10px #0006}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active .mat-mdc-button,.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active-link .mat-mdc-button{border-left:4px solid #0a96d1}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active .mat-mdc-button,[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active-link .mat-mdc-button{border-right:4px solid #0a96d1}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active-link,.eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active,.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active-link .mat-mdc-button,.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active .mat-mdc-button{color:#0a96d1}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1{background-color:#f2f6f7}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2{background-color:#c4cacc80}.eui-top-navigation-mobile-hamburger .mat-mdc-button{color:#fff}.eui-top-navigation-mobile-overlay{background-color:#00000040}.eui-top-navigation-mobile{z-index:960;width:250px;height:calc(100% - 56px);position:fixed;display:flex;flex-direction:column}.eui-top-navigation-mobile .eui-top-navigation-mobile-footer{padding:10px 4px}.eui-top-navigation-mobile .eui-top-navigation-mobile-footer .mat-mdc-button{margin:4px 0;width:100%;overflow:hidden;text-overflow:ellipsis;text-align:left}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-footer .mat-mdc-button{text-align:right}.eui-top-navigation-mobile .eui-top-navigation-mobile-footer .mat-mdc-button .mdc-button__label{width:100%;display:flex;align-items:center}.eui-top-navigation-mobile .eui-top-navigation-mobile-content{padding:16px 4px;flex:1;overflow:auto}.eui-top-navigation-mobile .eui-top-navigation-mobile-content a{color:inherit}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button{width:calc(100% + 8px);text-align:left;border-radius:0;margin-left:-4px;margin-right:-4px;padding:4px 16px 4px 20px;font-weight:500;margin-bottom:4px}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button .mdc-button__label{display:flex;align-items:center;justify-content:space-between;width:100%}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button .mdc-button__label>span{overflow:hidden;text-overflow:ellipsis}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button{padding-left:16px;padding-right:20px;text-align:right}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active,.eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active-link{padding-left:16px}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active,[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .mat-mdc-button.eui-top-navigation-item-active-link{padding-right:16px;border-left:0}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active .mat-mdc-button,.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active-link .mat-mdc-button{padding-left:16px}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active .mat-mdc-button,[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-active-link .mat-mdc-button{padding-left:inherit;padding-right:16px;border-left:0}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-expanded>.eui-top-navigation-mobile-menu{max-height:500px}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-item-expanded>.eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2{max-height:300px}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu{margin:-4px -4px 0;padding:0 4px;overflow:hidden;max-height:0;transition:max-height .5s}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu .mat-mdc-button:last-of-type{margin-bottom:0}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1 .mat-mdc-button{padding-left:40px}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1 .mat-mdc-button{padding-left:16px;padding-right:40px}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1 .mat-mdc-button.eui-top-navigation-item-active,.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1 .mat-mdc-button.eui-top-navigation-item-active-link{padding-left:36px}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1 .mat-mdc-button.eui-top-navigation-item-active,[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1 .mat-mdc-button.eui-top-navigation-item-active-link{padding-left:16px;padding-right:36px}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1 .eui-top-navigation-item-active .mat-mdc-button,.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1 .eui-top-navigation-item-active-link .mat-mdc-button{padding-left:36px}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1 .eui-top-navigation-item-active .mat-mdc-button,[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-1 .eui-top-navigation-item-active-link .mat-mdc-button{padding-left:16px;padding-right:36px}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2{margin-top:0}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2 .mat-mdc-button{padding-left:60px}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2 .mat-mdc-button{padding-left:16px;padding-right:60px}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2 .mat-mdc-button.eui-top-navigation-item-active,.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2 .mat-mdc-button.eui-top-navigation-item-active-link{padding-left:56px}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2 .mat-mdc-button.eui-top-navigation-item-active,[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2 .mat-mdc-button.eui-top-navigation-item-active-link{padding-left:16px;padding-right:56px}.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2 .eui-top-navigation-item-active .mat-mdc-button,.eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2 .eui-top-navigation-item-active-link .mat-mdc-button{padding-left:56px}[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2 .eui-top-navigation-item-active .mat-mdc-button,[dir=rtl] .eui-top-navigation-mobile .eui-top-navigation-mobile-content .eui-top-navigation-mobile-menu.eui-top-navigation-mobile-menu-level-2 .eui-top-navigation-item-active-link .mat-mdc-button{padding-left:16px;padding-right:56px}.eui-top-navigation-mobile-hamburger{height:64px;display:flex;align-items:center;position:fixed;left:13px;top:0;z-index:950}[dir=rtl] .eui-top-navigation-mobile-hamburger{left:inherit;right:13px}.eui-top-navigation-mobile-hamburger .mat-mdc-button{padding:0;min-width:44px}.eui-top-navigation-mobile-hamburger .mat-mdc-button>.mat-icon{margin-right:0}[dir=rtl] .eui-top-navigation-mobile-hamburger .mat-mdc-button>.mat-icon{margin-left:0}.eui-top-navigation-mobile-hamburger .mat-icon{font-size:32px;height:35px;width:32px}.eui-top-navigation-mobile-overlay{position:fixed;inset:64px 0 0;z-index:900}@media screen and (min-width: 769px){.eui-top-navigation-mobile,.eui-top-navigation-mobile-hamburger,.eui-top-navigation-mobile-overlay{display:none!important}}@media screen and (max-width: 768px){.eui-top-navigation-mobile .eui-top-navigation-mobile-footer .mat-mdc-button.eui-masthead--icon-button{width:100%}.eui-top-navigation-mobile .eui-top-navigation-mobile-footer .mat-mdc-button.eui-masthead--icon-button .mdc-button__label span{display:inline-block}}@media screen and (max-width: 768px){.eui-top-navigation-mobile-hamburger{left:9px;height:56px}[dir=rtl] .eui-top-navigation-mobile-hamburger{left:inherit;right:9px}.eui-top-navigation-mobile-overlay{top:56px}}\n"] }]
        }], ctorParameters: () => [{ type: i1$8.Router }, { type: i0.ChangeDetectorRef }, { type: EuiTopNavigationService }], propDecorators: { items: [{
                type: Input
            }], direction: [{
                type: Input
            }], centered: [{
                type: Input
            }], onResize: [{
                type: HostListener,
                args: ['window:resize']
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
var EuiVerticalNavigationItemType;
(function (EuiVerticalNavigationItemType) {
    EuiVerticalNavigationItemType["EXTERNAL_LINK"] = "EXTERNAL_LINK";
    EuiVerticalNavigationItemType["NODE"] = "NODE";
    EuiVerticalNavigationItemType["ROUTER_LINK"] = "ROUTER_LINK";
})(EuiVerticalNavigationItemType || (EuiVerticalNavigationItemType = {}));

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
const submenuToggleAnimation = trigger('submenuToggle', [
    state('true', style({ height: '*' })),
    state('false', style({ height: 0, visibility: 'hidden' })),
    transition('true <=> false', animate('150ms ease-in-out')),
]);
class EuiVerticalNavigationComponent {
    /**
     * Menu data structure.
     * Use the "SgMenuItems" interface.
     *
     * @category Input
     * @default [] (empty array)
     */
    set items(items) {
        if (items !== null)
            this.setItems(items);
    }
    /**
     * Web Accessibility requirement ("nav" element "aria-label" property).
     * Label menus to make them easier to find and understand.
     * Labels should be short but descriptive, to allow users to distinguish between multiple menus on a web page.
     * [guideline] https://www.w3.org/WAI/tutorials/menus/structure/
     *
     * @category Input
     * @default Main Navigation
     */
    set name(name) {
        this._name = name;
    }
    /** @internal */
    get name() {
        return this._name;
    }
    constructor(router) {
        this.router = router;
        /**
         * Collapse/expand animation ended.
         *
         * @internal */
        this.onAnimationEnd = new Subject();
        /** @internal */
        this.menuItems = new BehaviorSubject([]);
        /** @internal */
        this.type = EuiVerticalNavigationItemType;
        this.savedNodes = [];
        this.activeItems = [];
        this.destroy = new Subject();
        this._name = 'Main Navigation';
    }
    /** @internal */
    ngOnInit() {
        this.router.events.pipe(takeUntil(this.destroy)).subscribe((routerEvent) => {
            if (routerEvent instanceof NavigationEnd)
                this.setItems(this.menuItems.value);
        });
    }
    /** @internal */
    ngOnDestroy() {
        this.destroy.next(true);
    }
    /**
     * Collapse currently open menu nodes.
     *
     * @internal */
    collapse() {
        this.setSavedNodesOpenedState(false);
    }
    /**
     * Expand previously opened menu nodes.
     *
     * @internal */
    expand() {
        this.setSavedNodesOpenedState(true);
    }
    /** @internal */
    toggleNode(item) {
        // 1.) save new opened state
        const opened = !item.opened;
        // 2.) close previous opened nodes
        this.closeAllOpenedNodes();
        // 3.) set current item
        item.opened = opened;
        if (opened)
            this.savedNodes.push(item);
        // 4.) open all parents
        let parent = item.parent;
        while (parent) {
            parent.opened = true;
            this.savedNodes.push(parent);
            parent = parent.parent;
        }
        // 5.) set state
        this.menuItems.next(this.menuItems.value);
    }
    /** @internal */
    routerLinkOnClick(item) {
        if (this.router.isActive(item.url, item.exact))
            this.setItems(this.menuItems.value);
    }
    /** @internal */
    onToggleEnd() {
        this.onAnimationEnd.next(true);
    }
    setSavedNodesOpenedState(value) {
        for (const node of this.savedNodes)
            node.opened = value;
        this.menuItems.next(this.menuItems.value);
    }
    setItems(items) {
        this.setActiveItems(items);
        this.menuItems.next(items);
    }
    closeAllOpenedNodes() {
        for (const node of this.savedNodes)
            node.opened = false;
        this.savedNodes = [];
    }
    resetAllActiveItems() {
        for (const item of this.activeItems)
            item.active = false;
        this.activeItems = [];
    }
    setActiveItems(items) {
        this.closeAllOpenedNodes();
        this.resetAllActiveItems();
        this.setActiveItemsRecursive(items);
    }
    setActiveItemsRecursive(items) {
        for (const item of items) {
            if (item.type === EuiVerticalNavigationItemType.ROUTER_LINK && this.router.isActive(item.url, item.exact)) {
                item.active = true;
                this.activeItems.push(item);
                // set parent nodes
                let parent = item.parent;
                while (parent) {
                    parent.opened = true;
                    parent.active = true;
                    this.savedNodes.push(parent);
                    this.activeItems.push(parent);
                    parent = parent.parent;
                }
            }
            else if (item.type === EuiVerticalNavigationItemType.NODE) {
                this.setActiveItemsRecursive(item.children);
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiVerticalNavigationComponent, deps: [{ token: i1$8.Router }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.2.1", type: EuiVerticalNavigationComponent, isStandalone: false, selector: "eui-vertical-navigation", inputs: { items: "items", name: "name" }, ngImport: i0, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<ng-template #menuItem let-item>\n  <span class=\"eui-vertical-navigation-marker\" [ngClass]=\"{ active: item.active }\"></span>\n  <span class=\"eui-vertical-navigation-spacer\"></span>\n  @if (item.icon) {\n    <eui-icon class=\"eui-vertical-navigation-icon\" [icon]=\"item.icon\" size=\"18px\" setLineHeight=\"true\"></eui-icon>\n  }\n  <span class=\"eui-vertical-navigation-label\">{{ item.title }}</span>\n  <span class=\"eui-vertical-navigation-label-spacer\"></span>\n</ng-template>\n\n<ng-template #menuLevel let-items let-type=\"type\">\n  @for (item of items; track item) {\n    <li role=\"menuitem\">\n      @switch (item.type) {\n        <!-- Router link -->\n        @case (type.ROUTER_LINK) {\n          <a\n            (click)=\"routerLinkOnClick(item)\"\n            [attr.data-testid]=\"item.testId\"\n            [routerLink]=\"item.url\"\n            [ngClass]=\"{ active: item.active }\"\n            [attr.aria-current]=\"item.active\"\n            matRipple\n            class=\"eui-vertical-navigation-item\"\n            >\n            <ng-container *ngTemplateOutlet=\"menuItem; context: { $implicit: item }\"></ng-container>\n          </a>\n        }\n        <!-- External link -->\n        @case (type.EXTERNAL_LINK) {\n          <a\n            [attr.data-testid]=\"item.testId\"\n            [href]=\"item.href\"\n            [target]=\"item.target\"\n            matRipple\n            rel=\"noopener noreferrer\"\n            class=\"eui-vertical-navigation-item\"\n            >\n            <ng-container *ngTemplateOutlet=\"menuItem; context: { $implicit: item }\"></ng-container>\n          </a>\n        }\n        <!-- Node -->\n        @case (type.NODE) {\n          <a\n            (click)=\"toggleNode(item)\"\n            [attr.data-testid]=\"item.testId\"\n            [attr.aria-expanded]=\"item.opened\"\n            [ngClass]=\"{ active: item.active, opened: item.opened }\"\n            matRipple\n            aria-haspopup=\"true\"\n            href=\"javascript:void(0)\"\n            role=\"button\"\n            class=\"eui-vertical-navigation-item\"\n            >\n            <ng-container *ngTemplateOutlet=\"menuItem; context: { $implicit: item }\"></ng-container>\n            <eui-icon class=\"eui-vertical-navigation-expand\" [ngClass]=\"{ expanded: item.opened }\" icon=\"collapsedown\" size=\"s\" setLineHeight=\"true\"></eui-icon>\n          </a>\n          <ul\n            [@submenuToggle]=\"item.opened\"\n            (@submenuToggle.done)=\"onToggleEnd()\"\n            [attr.data-testid]=\"item.testId\"\n            [attr.aria-label]=\"item.title\"\n            [attr.aria-hidden]=\"!item.opened\"\n            role=\"menu\"\n            class=\"eui-vertical-navigation-submenu\"\n            >\n            <ng-container *ngTemplateOutlet=\"menuLevel; context: { $implicit: item.children, type: type }\"></ng-container>\n          </ul>\n        }\n      }\n    </li>\n  }\n</ng-template>\n\n<nav class=\"eui-vertical-navigation\" [attr.aria-label]=\"name\">\n  <ul role=\"menubar\">\n    <ng-container *ngTemplateOutlet=\"menuLevel; context: { $implicit: menuItems | async, type: type }\"></ng-container>\n  </ul>\n</nav>\n", styles: [":host-context(.eui-dark-theme) .eui-vertical-navigation-submenu{background:#424445}:host-context(.eui-dark-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:24px}:host-context(.eui-dark-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#404243}:host-context(.eui-dark-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:48px}:host-context(.eui-dark-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#3e4041}:host-context(.eui-dark-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:72px}:host-context(.eui-dark-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#3c3e3e}:host-context(.eui-dark-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:96px}:host-context(.eui-dark-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#3a3c3c}:host-context(.eui-dark-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:120px}:host-context(.eui-dark-theme) .eui-sidebar-main{background-color:#444647}:host-context(.eui-dark-theme) .eui-vertical-navigation{background:#444647}:host-context(.eui-dark-theme) .eui-vertical-navigation-item,:host-context(.eui-dark-theme) .eui-vertical-navigation-item:hover,:host-context(.eui-dark-theme) .eui-vertical-navigation-item:focus{color:#dfe4e6}:host-context(.eui-dark-theme) .eui-vertical-navigation-item:hover{background-image:linear-gradient(#ffffff0a 0 0)}:host-context(.eui-dark-theme) .eui-vertical-navigation-item:focus{background-image:linear-gradient(#ffffff1f 0 0)}:host-context(.eui-dark-theme) .eui-vertical-navigation-item.active{color:#8acbe3}:host-context(.eui-dark-theme) .eui-vertical-navigation-marker.active{background:#8acbe3}:host-context(.eui-dark-theme) .eui-vertical-navigation-icon,:host-context(.eui-dark-theme) .eui-vertical-navigation-expand{color:#8acbe3}:host-context(.eui-dark-theme) .eui-vertical-navigation-separator .eui-vertical-navigation-label{border-top:1px solid #444647}:host-context(.eui-contrast-theme) .eui-vertical-navigation-submenu{background:#2e3131}:host-context(.eui-contrast-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:24px}:host-context(.eui-contrast-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#2c2f30}:host-context(.eui-contrast-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:48px}:host-context(.eui-contrast-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#2b2e2e}:host-context(.eui-contrast-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:72px}:host-context(.eui-contrast-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#292c2d}:host-context(.eui-contrast-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:96px}:host-context(.eui-contrast-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#282b2b}:host-context(.eui-contrast-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:120px}:host-context(.eui-contrast-theme) .eui-sidebar-main{background-color:#2f3233}:host-context(.eui-contrast-theme) .eui-vertical-navigation{background:#2f3233}:host-context(.eui-contrast-theme) .eui-vertical-navigation-item,:host-context(.eui-contrast-theme) .eui-vertical-navigation-item:hover,:host-context(.eui-contrast-theme) .eui-vertical-navigation-item:focus{color:#f9fbfc}:host-context(.eui-contrast-theme) .eui-vertical-navigation-item:hover{background-image:linear-gradient(#ffffff0a 0 0)}:host-context(.eui-contrast-theme) .eui-vertical-navigation-item:focus{background-image:linear-gradient(#ffffff1f 0 0)}:host-context(.eui-contrast-theme) .eui-vertical-navigation-item.active{color:#8acbe3}:host-context(.eui-contrast-theme) .eui-vertical-navigation-marker.active{background:#8acbe3}:host-context(.eui-contrast-theme) .eui-vertical-navigation-icon,:host-context(.eui-contrast-theme) .eui-vertical-navigation-expand{color:#8acbe3}:host-context(.eui-contrast-theme) .eui-vertical-navigation-separator .eui-vertical-navigation-label{border-top:1px solid #2f3233}:host{display:inline-block}.eui-vertical-navigation-submenu{background:#eff4f7}.eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:24px}.eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#e5eef2}.eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:48px}.eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#dbe7ed}.eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:72px}.eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#d1e0e8}.eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:96px}.eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#c7dae3}.eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:120px}.eui-sidebar-main{background-color:#fff}.eui-vertical-navigation{background:#fff}.eui-vertical-navigation-item,.eui-vertical-navigation-item:hover,.eui-vertical-navigation-item:focus{color:#2f3233}.eui-vertical-navigation-item:hover{background-image:linear-gradient(#0000000a 0 0)}.eui-vertical-navigation-item:focus{background-image:linear-gradient(#0000001f 0 0)}.eui-vertical-navigation-item.active{color:#0a96d1}.eui-vertical-navigation-marker.active{background:#0a96d1}.eui-vertical-navigation-icon,.eui-vertical-navigation-expand{color:#0a96d1}.eui-vertical-navigation-separator .eui-vertical-navigation-label{border-top:1px solid #f9fbfc}.eui-vertical-navigation{display:inline-block;white-space:nowrap;-webkit-user-select:none;user-select:none;font-size:14px;width:inherit;max-width:inherit}.eui-vertical-navigation ul,.eui-vertical-navigation li,.eui-vertical-navigation a{margin:0;padding:0;list-style:none;text-decoration:none;outline:none}.eui-vertical-navigation-item{display:flex;flex-direction:row;flex-wrap:nowrap;align-items:center;height:42px;line-height:42px;cursor:pointer;position:relative}.eui-vertical-navigation-item .eui-vertical-navigation-marker,.eui-vertical-navigation-item .eui-vertical-navigation-spacer,.eui-vertical-navigation-item .eui-vertical-navigation-icon,.eui-vertical-navigation-item .eui-vertical-navigation-label,.eui-vertical-navigation-item .eui-vertical-navigation-expand{overflow:hidden;height:inherit;line-height:inherit}.eui-vertical-navigation-item .eui-vertical-navigation-spacer{flex-grow:0;flex-shrink:0}.eui-vertical-navigation-item .eui-vertical-navigation-label-spacer{flex-grow:0;flex-shrink:0;width:24px}.eui-vertical-navigation-item .eui-vertical-navigation-icon{flex-grow:0;flex-shrink:0;width:40px;height:18px;text-align:center}.eui-vertical-navigation-item .eui-vertical-navigation-expand{transition:transform .2s ease;flex-grow:0;flex-shrink:0;width:40px;height:18px;text-align:center}.eui-vertical-navigation-item .eui-vertical-navigation-expand.expanded{transform:rotate(-180deg)}.eui-vertical-navigation-item .eui-vertical-navigation-marker{flex-grow:0;flex-shrink:0;width:4px}.eui-vertical-navigation-item .eui-vertical-navigation-label{flex-grow:1;padding:0 4px;text-overflow:ellipsis}.eui-vertical-navigation-submenu{overflow:hidden;box-shadow:inset 0 8px 8px -8px #00000080}.eui-vertical-navigation-submenu .eui-vertical-navigation-item{height:42px;line-height:42px}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i3$5.MatRipple, selector: "[mat-ripple], [matRipple]", inputs: ["matRippleColor", "matRippleUnbounded", "matRippleCentered", "matRippleRadius", "matRippleAnimation", "matRippleDisabled", "matRippleTrigger"], exportAs: ["matRipple"] }, { kind: "directive", type: i1$8.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: EuiIconComponent, selector: "eui-icon", inputs: ["aria-hidden", "setLineHeight", "icon", "size"] }, { kind: "pipe", type: i2.AsyncPipe, name: "async" }], animations: [submenuToggleAnimation], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiVerticalNavigationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'eui-vertical-navigation', animations: [submenuToggleAnimation], changeDetection: ChangeDetectionStrategy.OnPush, standalone: false, template: "<!--\nCopyright 2025 One Identity LLC.\nALL RIGHTS RESERVED.\n-->\n\n<ng-template #menuItem let-item>\n  <span class=\"eui-vertical-navigation-marker\" [ngClass]=\"{ active: item.active }\"></span>\n  <span class=\"eui-vertical-navigation-spacer\"></span>\n  @if (item.icon) {\n    <eui-icon class=\"eui-vertical-navigation-icon\" [icon]=\"item.icon\" size=\"18px\" setLineHeight=\"true\"></eui-icon>\n  }\n  <span class=\"eui-vertical-navigation-label\">{{ item.title }}</span>\n  <span class=\"eui-vertical-navigation-label-spacer\"></span>\n</ng-template>\n\n<ng-template #menuLevel let-items let-type=\"type\">\n  @for (item of items; track item) {\n    <li role=\"menuitem\">\n      @switch (item.type) {\n        <!-- Router link -->\n        @case (type.ROUTER_LINK) {\n          <a\n            (click)=\"routerLinkOnClick(item)\"\n            [attr.data-testid]=\"item.testId\"\n            [routerLink]=\"item.url\"\n            [ngClass]=\"{ active: item.active }\"\n            [attr.aria-current]=\"item.active\"\n            matRipple\n            class=\"eui-vertical-navigation-item\"\n            >\n            <ng-container *ngTemplateOutlet=\"menuItem; context: { $implicit: item }\"></ng-container>\n          </a>\n        }\n        <!-- External link -->\n        @case (type.EXTERNAL_LINK) {\n          <a\n            [attr.data-testid]=\"item.testId\"\n            [href]=\"item.href\"\n            [target]=\"item.target\"\n            matRipple\n            rel=\"noopener noreferrer\"\n            class=\"eui-vertical-navigation-item\"\n            >\n            <ng-container *ngTemplateOutlet=\"menuItem; context: { $implicit: item }\"></ng-container>\n          </a>\n        }\n        <!-- Node -->\n        @case (type.NODE) {\n          <a\n            (click)=\"toggleNode(item)\"\n            [attr.data-testid]=\"item.testId\"\n            [attr.aria-expanded]=\"item.opened\"\n            [ngClass]=\"{ active: item.active, opened: item.opened }\"\n            matRipple\n            aria-haspopup=\"true\"\n            href=\"javascript:void(0)\"\n            role=\"button\"\n            class=\"eui-vertical-navigation-item\"\n            >\n            <ng-container *ngTemplateOutlet=\"menuItem; context: { $implicit: item }\"></ng-container>\n            <eui-icon class=\"eui-vertical-navigation-expand\" [ngClass]=\"{ expanded: item.opened }\" icon=\"collapsedown\" size=\"s\" setLineHeight=\"true\"></eui-icon>\n          </a>\n          <ul\n            [@submenuToggle]=\"item.opened\"\n            (@submenuToggle.done)=\"onToggleEnd()\"\n            [attr.data-testid]=\"item.testId\"\n            [attr.aria-label]=\"item.title\"\n            [attr.aria-hidden]=\"!item.opened\"\n            role=\"menu\"\n            class=\"eui-vertical-navigation-submenu\"\n            >\n            <ng-container *ngTemplateOutlet=\"menuLevel; context: { $implicit: item.children, type: type }\"></ng-container>\n          </ul>\n        }\n      }\n    </li>\n  }\n</ng-template>\n\n<nav class=\"eui-vertical-navigation\" [attr.aria-label]=\"name\">\n  <ul role=\"menubar\">\n    <ng-container *ngTemplateOutlet=\"menuLevel; context: { $implicit: menuItems | async, type: type }\"></ng-container>\n  </ul>\n</nav>\n", styles: [":host-context(.eui-dark-theme) .eui-vertical-navigation-submenu{background:#424445}:host-context(.eui-dark-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:24px}:host-context(.eui-dark-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#404243}:host-context(.eui-dark-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:48px}:host-context(.eui-dark-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#3e4041}:host-context(.eui-dark-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:72px}:host-context(.eui-dark-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#3c3e3e}:host-context(.eui-dark-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:96px}:host-context(.eui-dark-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#3a3c3c}:host-context(.eui-dark-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:120px}:host-context(.eui-dark-theme) .eui-sidebar-main{background-color:#444647}:host-context(.eui-dark-theme) .eui-vertical-navigation{background:#444647}:host-context(.eui-dark-theme) .eui-vertical-navigation-item,:host-context(.eui-dark-theme) .eui-vertical-navigation-item:hover,:host-context(.eui-dark-theme) .eui-vertical-navigation-item:focus{color:#dfe4e6}:host-context(.eui-dark-theme) .eui-vertical-navigation-item:hover{background-image:linear-gradient(#ffffff0a 0 0)}:host-context(.eui-dark-theme) .eui-vertical-navigation-item:focus{background-image:linear-gradient(#ffffff1f 0 0)}:host-context(.eui-dark-theme) .eui-vertical-navigation-item.active{color:#8acbe3}:host-context(.eui-dark-theme) .eui-vertical-navigation-marker.active{background:#8acbe3}:host-context(.eui-dark-theme) .eui-vertical-navigation-icon,:host-context(.eui-dark-theme) .eui-vertical-navigation-expand{color:#8acbe3}:host-context(.eui-dark-theme) .eui-vertical-navigation-separator .eui-vertical-navigation-label{border-top:1px solid #444647}:host-context(.eui-contrast-theme) .eui-vertical-navigation-submenu{background:#2e3131}:host-context(.eui-contrast-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:24px}:host-context(.eui-contrast-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#2c2f30}:host-context(.eui-contrast-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:48px}:host-context(.eui-contrast-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#2b2e2e}:host-context(.eui-contrast-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:72px}:host-context(.eui-contrast-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#292c2d}:host-context(.eui-contrast-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:96px}:host-context(.eui-contrast-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#282b2b}:host-context(.eui-contrast-theme) .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:120px}:host-context(.eui-contrast-theme) .eui-sidebar-main{background-color:#2f3233}:host-context(.eui-contrast-theme) .eui-vertical-navigation{background:#2f3233}:host-context(.eui-contrast-theme) .eui-vertical-navigation-item,:host-context(.eui-contrast-theme) .eui-vertical-navigation-item:hover,:host-context(.eui-contrast-theme) .eui-vertical-navigation-item:focus{color:#f9fbfc}:host-context(.eui-contrast-theme) .eui-vertical-navigation-item:hover{background-image:linear-gradient(#ffffff0a 0 0)}:host-context(.eui-contrast-theme) .eui-vertical-navigation-item:focus{background-image:linear-gradient(#ffffff1f 0 0)}:host-context(.eui-contrast-theme) .eui-vertical-navigation-item.active{color:#8acbe3}:host-context(.eui-contrast-theme) .eui-vertical-navigation-marker.active{background:#8acbe3}:host-context(.eui-contrast-theme) .eui-vertical-navigation-icon,:host-context(.eui-contrast-theme) .eui-vertical-navigation-expand{color:#8acbe3}:host-context(.eui-contrast-theme) .eui-vertical-navigation-separator .eui-vertical-navigation-label{border-top:1px solid #2f3233}:host{display:inline-block}.eui-vertical-navigation-submenu{background:#eff4f7}.eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:24px}.eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#e5eef2}.eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:48px}.eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#dbe7ed}.eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:72px}.eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#d1e0e8}.eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:96px}.eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu{background:#c7dae3}.eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-submenu .eui-vertical-navigation-spacer{width:120px}.eui-sidebar-main{background-color:#fff}.eui-vertical-navigation{background:#fff}.eui-vertical-navigation-item,.eui-vertical-navigation-item:hover,.eui-vertical-navigation-item:focus{color:#2f3233}.eui-vertical-navigation-item:hover{background-image:linear-gradient(#0000000a 0 0)}.eui-vertical-navigation-item:focus{background-image:linear-gradient(#0000001f 0 0)}.eui-vertical-navigation-item.active{color:#0a96d1}.eui-vertical-navigation-marker.active{background:#0a96d1}.eui-vertical-navigation-icon,.eui-vertical-navigation-expand{color:#0a96d1}.eui-vertical-navigation-separator .eui-vertical-navigation-label{border-top:1px solid #f9fbfc}.eui-vertical-navigation{display:inline-block;white-space:nowrap;-webkit-user-select:none;user-select:none;font-size:14px;width:inherit;max-width:inherit}.eui-vertical-navigation ul,.eui-vertical-navigation li,.eui-vertical-navigation a{margin:0;padding:0;list-style:none;text-decoration:none;outline:none}.eui-vertical-navigation-item{display:flex;flex-direction:row;flex-wrap:nowrap;align-items:center;height:42px;line-height:42px;cursor:pointer;position:relative}.eui-vertical-navigation-item .eui-vertical-navigation-marker,.eui-vertical-navigation-item .eui-vertical-navigation-spacer,.eui-vertical-navigation-item .eui-vertical-navigation-icon,.eui-vertical-navigation-item .eui-vertical-navigation-label,.eui-vertical-navigation-item .eui-vertical-navigation-expand{overflow:hidden;height:inherit;line-height:inherit}.eui-vertical-navigation-item .eui-vertical-navigation-spacer{flex-grow:0;flex-shrink:0}.eui-vertical-navigation-item .eui-vertical-navigation-label-spacer{flex-grow:0;flex-shrink:0;width:24px}.eui-vertical-navigation-item .eui-vertical-navigation-icon{flex-grow:0;flex-shrink:0;width:40px;height:18px;text-align:center}.eui-vertical-navigation-item .eui-vertical-navigation-expand{transition:transform .2s ease;flex-grow:0;flex-shrink:0;width:40px;height:18px;text-align:center}.eui-vertical-navigation-item .eui-vertical-navigation-expand.expanded{transform:rotate(-180deg)}.eui-vertical-navigation-item .eui-vertical-navigation-marker{flex-grow:0;flex-shrink:0;width:4px}.eui-vertical-navigation-item .eui-vertical-navigation-label{flex-grow:1;padding:0 4px;text-overflow:ellipsis}.eui-vertical-navigation-submenu{overflow:hidden;box-shadow:inset 0 8px 8px -8px #00000080}.eui-vertical-navigation-submenu .eui-vertical-navigation-item{height:42px;line-height:42px}\n"] }]
        }], ctorParameters: () => [{ type: i1$8.Router }], propDecorators: { items: [{
                type: Input
            }], name: [{
                type: Input
            }] } });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiMaterialModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiMaterialModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.2.1", ngImport: i0, type: EuiMaterialModule, imports: [MatAutocompleteModule,
            MatBadgeModule,
            MatButtonModule,
            MatButtonToggleModule,
            MatCardModule,
            MatCheckboxModule,
            MatChipsModule,
            MatDatepickerModule,
            MatDialogModule,
            MatDividerModule,
            MatExpansionModule,
            MatFormFieldModule,
            MatGridListModule,
            MatIconModule,
            MatInputModule,
            MatListModule,
            MatMenuModule,
            MatPaginatorModule,
            MatProgressSpinnerModule,
            MatProgressBarModule,
            MatRadioModule,
            MatSelectModule,
            MatSidenavModule,
            MatSliderModule,
            MatSlideToggleModule,
            MatSnackBarModule,
            MatSortModule,
            MatStepperModule,
            MatTableModule,
            MatTabsModule,
            MatToolbarModule,
            MatTooltipModule,
            MatTreeModule,
            MatRippleModule,
            MatBottomSheetModule,
            A11yModule,
            ScrollingModule,
            DragDropModule], exports: [MatAutocompleteModule,
            MatBadgeModule,
            MatButtonModule,
            MatButtonToggleModule,
            MatCardModule,
            MatCheckboxModule,
            MatChipsModule,
            MatDatepickerModule,
            MatDialogModule,
            MatDividerModule,
            MatExpansionModule,
            MatFormFieldModule,
            MatGridListModule,
            MatIconModule,
            MatInputModule,
            MatListModule,
            MatMenuModule,
            MatNativeDateModule,
            MatPaginatorModule,
            MatProgressSpinnerModule,
            MatProgressBarModule,
            MatRadioModule,
            MatSelectModule,
            MatSidenavModule,
            MatSliderModule,
            MatSlideToggleModule,
            MatSnackBarModule,
            MatSortModule,
            MatStepperModule,
            MatTableModule,
            MatTabsModule,
            MatToolbarModule,
            MatTooltipModule,
            MatTreeModule,
            MatRippleModule,
            MatBottomSheetModule,
            A11yModule,
            ScrollingModule,
            DragDropModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiMaterialModule, imports: [MatAutocompleteModule,
            MatBadgeModule,
            MatButtonModule,
            MatButtonToggleModule,
            MatCardModule,
            MatCheckboxModule,
            MatChipsModule,
            MatDatepickerModule,
            MatDialogModule,
            MatDividerModule,
            MatExpansionModule,
            MatFormFieldModule,
            MatGridListModule,
            MatIconModule,
            MatInputModule,
            MatListModule,
            MatMenuModule,
            MatPaginatorModule,
            MatProgressSpinnerModule,
            MatProgressBarModule,
            MatRadioModule,
            MatSelectModule,
            MatSidenavModule,
            MatSliderModule,
            MatSlideToggleModule,
            MatSnackBarModule,
            MatSortModule,
            MatStepperModule,
            MatTableModule,
            MatTabsModule,
            MatToolbarModule,
            MatTooltipModule,
            MatTreeModule,
            MatRippleModule,
            MatBottomSheetModule,
            A11yModule,
            ScrollingModule,
            DragDropModule, MatAutocompleteModule,
            MatBadgeModule,
            MatButtonModule,
            MatButtonToggleModule,
            MatCardModule,
            MatCheckboxModule,
            MatChipsModule,
            MatDatepickerModule,
            MatDialogModule,
            MatDividerModule,
            MatExpansionModule,
            MatFormFieldModule,
            MatGridListModule,
            MatIconModule,
            MatInputModule,
            MatListModule,
            MatMenuModule,
            MatNativeDateModule,
            MatPaginatorModule,
            MatProgressSpinnerModule,
            MatProgressBarModule,
            MatRadioModule,
            MatSelectModule,
            MatSidenavModule,
            MatSliderModule,
            MatSlideToggleModule,
            MatSnackBarModule,
            MatSortModule,
            MatStepperModule,
            MatTableModule,
            MatTabsModule,
            MatToolbarModule,
            MatTooltipModule,
            MatTreeModule,
            MatRippleModule,
            MatBottomSheetModule,
            A11yModule,
            ScrollingModule,
            DragDropModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiMaterialModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        MatAutocompleteModule,
                        MatBadgeModule,
                        MatButtonModule,
                        MatButtonToggleModule,
                        MatCardModule,
                        MatCheckboxModule,
                        MatChipsModule,
                        MatDatepickerModule,
                        MatDialogModule,
                        MatDividerModule,
                        MatExpansionModule,
                        MatFormFieldModule,
                        MatGridListModule,
                        MatIconModule,
                        MatInputModule,
                        MatListModule,
                        MatMenuModule,
                        MatPaginatorModule,
                        MatProgressSpinnerModule,
                        MatProgressBarModule,
                        MatRadioModule,
                        MatSelectModule,
                        MatSidenavModule,
                        MatSliderModule,
                        MatSlideToggleModule,
                        MatSnackBarModule,
                        MatSortModule,
                        MatStepperModule,
                        MatTableModule,
                        MatTabsModule,
                        MatToolbarModule,
                        MatTooltipModule,
                        MatTreeModule,
                        MatRippleModule,
                        MatBottomSheetModule,
                        A11yModule,
                        ScrollingModule,
                        DragDropModule
                    ],
                    declarations: [],
                    exports: [
                        MatAutocompleteModule,
                        MatBadgeModule,
                        MatButtonModule,
                        MatButtonToggleModule,
                        MatCardModule,
                        MatCheckboxModule,
                        MatChipsModule,
                        MatDatepickerModule,
                        MatDialogModule,
                        MatDividerModule,
                        MatExpansionModule,
                        MatFormFieldModule,
                        MatGridListModule,
                        MatIconModule,
                        MatInputModule,
                        MatListModule,
                        MatMenuModule,
                        MatNativeDateModule,
                        MatPaginatorModule,
                        MatProgressSpinnerModule,
                        MatProgressBarModule,
                        MatRadioModule,
                        MatSelectModule,
                        MatSidenavModule,
                        MatSliderModule,
                        MatSlideToggleModule,
                        MatSnackBarModule,
                        MatSortModule,
                        MatStepperModule,
                        MatTableModule,
                        MatTabsModule,
                        MatToolbarModule,
                        MatTooltipModule,
                        MatTreeModule,
                        MatRippleModule,
                        MatBottomSheetModule,
                        A11yModule,
                        ScrollingModule,
                        DragDropModule
                    ],
                }]
        }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class DummyComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: DummyComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.2.1", type: DummyComponent, isStandalone: false, selector: "ng-component", ngImport: i0, template: ' ', isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: DummyComponent, decorators: [{
            type: Component,
            args: [{
                    template: ' ',
                    standalone: false
                }]
        }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiCoreModule {
    constructor(themeService) { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiCoreModule, deps: [{ token: EuiThemeService }], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.2.1", ngImport: i0, type: EuiCoreModule, declarations: [EuiAlertBannerComponent,
            EuiAlertComponent,
            EuiAlertContentDirective,
            EuiAlertHeaderDirective,
            EuiBadgeComponent,
            EuiBillboardComponent,
            EuiDatePickerComponent,
            EuiTimePickerComponent,
            EuiIconComponent,
            EuiJoinPipe,
            EuiLoadingComponent,
            EuiLogoComponent,
            EuiMastheadComponent,
            EuiReadonlyLabelComponent,
            EuiSelectComponent,
            EuiPermissionDirective,
            EuiScrollComponent,
            EuiSearchComponent,
            EuiSearchCustomFiltersComponent,
            EuiSearchCustomFiltersGroupComponent,
            EuiSearchCustomFiltersConditionComponent,
            EuiSearchCustomFiltersIndividualActionsComponent,
            EuiSidebarComponent, EuiTableColumnManagementComponent, EuiTableColumnManagementSelectColumnsComponent, EuiTopNavigationComponent,
            EuiTopNavigationCustomMenuItemComponent,
            EuiTopNavigationMenuItemComponent,
            EuiTopNavigationMobileMenuItemComponent,
            EuiVerticalNavigationComponent, EuiSidesheetComponent, EuiSidesheetDirective, EuiSidesheetHeaderDirective, EuiSplashScreenComponent,
            EuiDownloadDirective,
            EuiDownloadLoaderComponent,
            EuiSidesheetContentDirective,
            EuiSidesheetActionsDirective,
            EuiClickableDirective,
            EuiTestIdPipe,
            DummyComponent,
            EuiThemeSwitcherComponent,
            EuiNumberComponent,
            EuiSubscribeDirective,
            EuiDateFormatPipe,
            EuiFormFieldComponent,
            EuiLabelComponent, EuiFlyoutComponent, EuiFlyoutTriggerDirective, EuiOrderByPipe,
            EuiUnsavedChangesDialogComponent,
            EuiOverflowTooltipDirective,
            EuiTooltipDirective], imports: [CommonModule, EuiMaterialModule, ReactiveFormsModule, RouterModule, FormsModule], exports: [EuiAlertBannerComponent,
            EuiAlertComponent,
            EuiAlertContentDirective,
            EuiAlertHeaderDirective,
            EuiBadgeComponent,
            EuiBillboardComponent,
            EuiDatePickerComponent,
            EuiTimePickerComponent,
            EuiIconComponent,
            EuiJoinPipe,
            EuiLoadingComponent,
            EuiLogoComponent,
            EuiMastheadComponent,
            EuiReadonlyLabelComponent,
            EuiSelectComponent,
            EuiPermissionDirective,
            EuiScrollComponent,
            EuiSearchComponent,
            EuiSidebarComponent, EuiSidesheetComponent, EuiTopNavigationComponent,
            EuiTopNavigationCustomMenuItemComponent,
            EuiTopNavigationMenuItemComponent,
            EuiTopNavigationMobileMenuItemComponent,
            EuiVerticalNavigationComponent,
            EuiSplashScreenComponent,
            EuiDownloadDirective,
            EuiDownloadLoaderComponent,
            EuiSidesheetContentDirective,
            EuiSidesheetActionsDirective,
            EuiClickableDirective,
            EuiThemeSwitcherComponent,
            EuiNumberComponent,
            EuiSubscribeDirective,
            EuiDateFormatPipe,
            EuiFormFieldComponent,
            EuiLabelComponent,
            EuiTestIdPipe, EuiFlyoutComponent, EuiFlyoutTriggerDirective, EuiOrderByPipe, EuiTableColumnManagementComponent, EuiOverflowTooltipDirective,
            EuiTooltipDirective] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiCoreModule, providers: [
            EuiAlertBannerService,
            EuiBillboardService,
            EuiLoadingService,
            EuiTopNavigationService,
            EuiSidesheetContentService,
            EuiSidesheetService,
            EuiSplashScreenService,
            EuiFlyoutPositionsService,
            EuiDownloadService,
            EuiTableColumnManagementService,
            EuiUnsavedChangesService,
        ], imports: [CommonModule, EuiMaterialModule, ReactiveFormsModule, RouterModule, FormsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.2.1", ngImport: i0, type: EuiCoreModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, EuiMaterialModule, ReactiveFormsModule, RouterModule, FormsModule],
                    declarations: [
                        EuiAlertBannerComponent,
                        EuiAlertComponent,
                        EuiAlertContentDirective,
                        EuiAlertHeaderDirective,
                        EuiBadgeComponent,
                        EuiBillboardComponent,
                        EuiDatePickerComponent,
                        EuiTimePickerComponent,
                        EuiIconComponent,
                        EuiJoinPipe,
                        EuiLoadingComponent,
                        EuiLogoComponent,
                        EuiMastheadComponent,
                        EuiReadonlyLabelComponent,
                        EuiSelectComponent,
                        EuiPermissionDirective,
                        EuiScrollComponent,
                        EuiSearchComponent,
                        EuiSearchCustomFiltersComponent,
                        EuiSearchCustomFiltersGroupComponent,
                        EuiSearchCustomFiltersConditionComponent,
                        EuiSearchCustomFiltersIndividualActionsComponent,
                        EuiSidebarComponent,
                        EuiTableColumnManagementComponent,
                        EuiTableColumnManagementSelectColumnsComponent,
                        EuiTopNavigationComponent,
                        EuiTopNavigationCustomMenuItemComponent,
                        EuiTopNavigationMenuItemComponent,
                        EuiTopNavigationMobileMenuItemComponent,
                        EuiVerticalNavigationComponent,
                        EuiSidesheetComponent,
                        EuiSidesheetDirective,
                        EuiSidesheetHeaderDirective,
                        EuiSplashScreenComponent,
                        EuiDownloadDirective,
                        EuiDownloadLoaderComponent,
                        EuiSidesheetContentDirective,
                        EuiSidesheetActionsDirective,
                        EuiClickableDirective,
                        EuiTestIdPipe,
                        DummyComponent,
                        EuiThemeSwitcherComponent,
                        EuiNumberComponent,
                        EuiSubscribeDirective,
                        EuiDateFormatPipe,
                        EuiFormFieldComponent,
                        EuiLabelComponent,
                        EuiFlyoutComponent,
                        EuiFlyoutTriggerDirective,
                        EuiOrderByPipe,
                        EuiUnsavedChangesDialogComponent,
                        EuiOverflowTooltipDirective,
                        EuiTooltipDirective,
                    ],
                    providers: [
                        EuiAlertBannerService,
                        EuiBillboardService,
                        EuiLoadingService,
                        EuiTopNavigationService,
                        EuiSidesheetContentService,
                        EuiSidesheetService,
                        EuiSplashScreenService,
                        EuiFlyoutPositionsService,
                        EuiDownloadService,
                        EuiTableColumnManagementService,
                        EuiUnsavedChangesService,
                    ],
                    exports: [
                        EuiAlertBannerComponent,
                        EuiAlertComponent,
                        EuiAlertContentDirective,
                        EuiAlertHeaderDirective,
                        EuiBadgeComponent,
                        EuiBillboardComponent,
                        EuiDatePickerComponent,
                        EuiTimePickerComponent,
                        EuiIconComponent,
                        EuiJoinPipe,
                        EuiLoadingComponent,
                        EuiLogoComponent,
                        EuiMastheadComponent,
                        EuiReadonlyLabelComponent,
                        EuiSelectComponent,
                        EuiPermissionDirective,
                        EuiScrollComponent,
                        EuiSearchComponent,
                        EuiSidebarComponent,
                        EuiSidesheetComponent,
                        EuiTopNavigationComponent,
                        EuiTopNavigationCustomMenuItemComponent,
                        EuiTopNavigationMenuItemComponent,
                        EuiTopNavigationMobileMenuItemComponent,
                        EuiVerticalNavigationComponent,
                        EuiSplashScreenComponent,
                        EuiDownloadDirective,
                        EuiDownloadLoaderComponent,
                        EuiSidesheetContentDirective,
                        EuiSidesheetActionsDirective,
                        EuiClickableDirective,
                        EuiThemeSwitcherComponent,
                        EuiNumberComponent,
                        EuiSubscribeDirective,
                        EuiDateFormatPipe,
                        EuiFormFieldComponent,
                        EuiLabelComponent,
                        EuiTestIdPipe,
                        EuiFlyoutComponent,
                        EuiFlyoutTriggerDirective,
                        EuiOrderByPipe,
                        EuiTableColumnManagementComponent,
                        EuiOverflowTooltipDirective,
                        EuiTooltipDirective,
                    ],
                }]
        }], ctorParameters: () => [{ type: EuiThemeService }] });

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
var EuiLinkTarget;
(function (EuiLinkTarget) {
    EuiLinkTarget["BLANK"] = "_blank";
    EuiLinkTarget["PARENT"] = "_parent";
    EuiLinkTarget["SELF"] = "_self";
    EuiLinkTarget["TOP"] = "_top";
})(EuiLinkTarget || (EuiLinkTarget = {}));

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiVerticalNavigationItem {
    constructor(options) {
        this.parent = null;
        const settings = {
            testId: null,
            icon: null,
            permission: null,
            permissionOperator: null,
            ...options,
        };
        this.testId = settings.testId;
        this.icon = settings.icon;
        this.title = settings.title;
        this.permission = settings.permission;
        this.permissionOperator = settings.permissionOperator;
    }
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiVerticalNavigationExternalLink extends EuiVerticalNavigationItem {
    constructor(options) {
        super(options);
        this.type = EuiVerticalNavigationItemType.EXTERNAL_LINK;
        const settings = { target: EuiLinkTarget.BLANK, ...options };
        this.href = settings.href;
        this.target = settings.target;
    }
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiVerticalNavigationNode extends EuiVerticalNavigationItem {
    constructor(options) {
        super(options);
        this.type = EuiVerticalNavigationItemType.NODE;
        this.opened = false;
        this.active = false;
        this.children = options.children;
        for (const child of this.children)
            child.parent = this;
    }
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiVerticalNavigationRouterLink extends EuiVerticalNavigationItem {
    constructor(options) {
        super(options);
        this.type = EuiVerticalNavigationItemType.ROUTER_LINK;
        this.active = false;
        const defaultIsActiveMatchOptions = {
            paths: 'subset',
            queryParams: 'subset',
            matrixParams: 'ignored',
            fragment: 'ignored',
        };
        const settings = {
            exact: defaultIsActiveMatchOptions,
            ...options,
        };
        this.url = settings.url;
        this.exact = settings.exact;
    }
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
class EuiVerticalNavigationPermissionUtil {
    constructor(permissionService) {
        this.permissionService = permissionService;
    }
    filterItems(items) {
        return this.filterItemsRecursive(items);
    }
    filterItemsRecursive(items) {
        const enabledItems = [];
        for (const item of items) {
            if (this.permissionService.hasPermission(item.permission, item.permissionOperator)) {
                if (item.type === EuiVerticalNavigationItemType.NODE) {
                    item.children = this.filterItemsRecursive(item.children);
                    if (item.children.length)
                        enabledItems.push(item);
                }
                else {
                    enabledItems.push(item);
                }
            }
        }
        return enabledItems;
    }
}

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */

/**
 * Copyright 2025 One Identity LLC.
 * ALL RIGHTS RESERVED.
 */
/*
 * Public API Surface of core
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DEFAULT_CONFIG, DOWNLOAD_LOADER_CONFIG, DOWNLOAD_REQUEST_SUBSCRIPTION, DUE_TIME, EUI_SIDESHEET_DATA, EUI_SIDESHEET_REF, EUI_SIDESHEET_TEST_ID, EUI_TCM_DEFAULT_LABEL_TRANSLATIONS, EUI_TCM_NEW_CONFIG, EUI_TCM_NEW_SAVED_TABLE_LAYOUT, EUI_TCM_NEW_TABLE_LAYOUT, EUI_THEME_AUTO_LIGHT, EUI_THEME_DEFAULT, EUI_THEME_SKIP_LOAD, EUI_THEME_SKIP_SAVE, EUI_THEME_STORAGE_KEY, EUI_TOOLTIP_DEFAULTS, EUI_UC_DIALOG_TEXT_DEFAULTS, EuiAlertBannerComponent, EuiAlertBannerService, EuiAlertComponent, EuiAlertContentDirective, EuiAlertHeaderDirective, EuiBadgeComponent, EuiBillboardComponent, EuiBillboardService, EuiClickableDirective, EuiCoreModule, EuiDateFormatPipe, EuiDatePickerComponent, EuiDownloadDirective, EuiDownloadLoaderComponent, EuiDownloadService, EuiFlyoutComponent, EuiFlyoutPositionsService, EuiFlyoutTriggerDirective, EuiFormFieldComponent, EuiIconComponent, EuiJoinPipe, EuiLabelComponent, EuiLinkTarget, EuiLoadingComponent, EuiLoadingService, EuiLogoComponent, EuiMastheadComponent, EuiMaterialModule, EuiNumberComponent, EuiOperator, EuiOrderByPipe, EuiOverflowTooltipDirective, EuiPermissionDirective, EuiPermissionGuard, EuiPermissionService, EuiReadonlyLabelComponent, EuiScrollComponent, EuiSearchComponent, EuiSelectComponent, EuiSidebarComponent, EuiSidebarEnum, EuiSidesheetActionsDirective, EuiSidesheetComponent, EuiSidesheetConfig, EuiSidesheetContentDirective, EuiSidesheetContentService, EuiSidesheetDirective, EuiSidesheetEscapeKeyAction, EuiSidesheetHeaderDirective, EuiSidesheetRef, EuiSidesheetService, EuiSplashScreenComponent, EuiSplashScreenService, EuiSubscribeContext, EuiSubscribeDirective, EuiTableColumnManagementComponent, EuiTableColumnManagementSelectColumnsComponent, EuiTableColumnManagementService, EuiTableColumnUtilitiesService, EuiTestIdPipe, EuiTheme, EuiThemeService, EuiThemeSwitcherComponent, EuiTimePickerComponent, EuiTooltipDirective, EuiTopNavigationComponent, EuiTopNavigationCustomMenuItemComponent, EuiTopNavigationItemType, EuiTopNavigationMenuItemComponent, EuiTopNavigationMobileMenuItemComponent, EuiTopNavigationService, EuiUnsavedChangesDialogComponent, EuiUnsavedChangesService, EuiVerticalNavigationComponent, EuiVerticalNavigationExternalLink, EuiVerticalNavigationItem, EuiVerticalNavigationItemType, EuiVerticalNavigationNode, EuiVerticalNavigationPermissionUtil, EuiVerticalNavigationRouterLink, SIDESHEET_CLOSE_ARIA_LABEL, SIDESHEET_DISABLE_CLOSE, SIDESHEET_HEADER_COLOUR, SIDESHEET_ICON, SIDESHEET_INTERNAL_CLOSE_ID, SIDESHEET_PADDING, SIDESHEET_SUB_TITLE, SIDESHEET_TEXT_DIRECTION, SIDESHEET_TITLE, SIDESHEET_WIDTH, SPLASH_SCREEN_OPTIONS, USER_EVENT_DUE_TIME };
//# sourceMappingURL=elemental-ui-core.mjs.map
