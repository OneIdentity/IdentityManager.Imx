import { ApiClient, ApiRequestOptions, DataModel, EntityCollectionData, EntityData, EntityKeysData, EntitySchema, EntityWriteData, EntityWriteDataColumn, EntityWriteDataSingle, ExtendedEntityCollectionData, ExtendedEntityWriteData, FilterData, FilterPropertyList, FilterTreeData, FkProviderItem, GroupInfoData, InteractiveEntityData, InteractiveEntityDeleteData, InteractiveEntityWriteData, IReadValue, IWriteValue, MethodDescriptor, ReadWriteExtTypedEntity, SqlExpression, SqlWizardExpression, StaticSchema, TranslationDataRead, TranslationDataWrite, TypedEntity, WriteExtTypedEntity } from 'imx-qbm-dbts';
export interface AccProductOwnershipInput {
    UidPerson?: string;
    CopyAllMembers: boolean;
}
export interface ApplicationExtendedDataRead {
    Translations?: TranslationDataRead;
    SqlExpression?: SqlWizardRead;
}
export interface ApplicationExtendedDataWrite extends TranslationDataWrite {
    SqlExpression?: SqlWizardWrite;
}
export interface ChartData {
    ObjectKey?: string;
    Name?: string;
    ObjectDisplay?: string;
    Points?: ChartDataPoint[];
}
export interface ChartDataPoint {
    Percentage?: number;
    Value: number;
    ValueZ: number;
    Date: Date;
}
export interface ChartDto {
    NegateThresholds: boolean;
    HistoryLength: number;
    AggregateFunction: StatisticAggregateFunction;
    AggregateFunctionTotal: StatisticAggregateFunction;
    ErrorThreshold: number;
    WarningThreshold: number;
    TimeScaleUnit: StatisticTimeScaleUnit;
    Unit?: string;
    Name?: string;
    Display?: string;
    Description?: string;
    Data?: ChartData[];
}
export interface EntitlementData {
    IsAssignedToMe: boolean;
    IsAssignedToOther: boolean;
    DisplayName?: string;
    CanonicalName?: string;
    UID_AOBApplicationConflicted?: string;
    DisplayApplicationConflicted?: string;
}
export interface EntitlementSystemRoleInput {
    UidApplication?: string;
    ObjectKeyEntitlements?: string[];
    UidEset?: string;
    NameNewEset?: string;
}
export interface EntitlementToAddData {
    Data?: EntitlementData[];
}
export interface EntityWriteDataBulk {
    Keys?: string[][];
    Data?: EntityWriteDataColumn[];
}
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface ExtendedEntityCollectionDataOfApplicationExtendedDataRead extends EntityCollectionData {
    ExtendedData?: ApplicationExtendedDataRead;
}
export interface ExtendedEntityWriteDataOfAccProductOwnershipInput extends EntityWriteData {
    ExtendedData?: AccProductOwnershipInput;
}
export interface ExtendedInteractiveEntityDataOfApplicationExtendedDataRead extends InteractiveEntityData {
    ExtendedData?: ApplicationExtendedDataRead;
}
export interface ExtendedInteractiveEntityWriteDataOfApplicationExtendedDataWrite extends InteractiveEntityWriteData {
    ExtendedData?: ApplicationExtendedDataWrite;
}
export interface SqlWizardRead {
    Expressions?: SqlWizardExpression[];
}
export interface SqlWizardWrite {
    Filters?: SqlExpression[];
}
export declare enum StatisticAggregateFunction {
    None = 0,
    Sum = 1,
    Average = 2
}
export declare enum StatisticTimeScaleUnit {
    Undefined = 0,
    Hour = 1,
    Day = 2,
    Week = 3,
    Month = 4,
    Quarter = 5,
    Year = 6
}
export declare class TypedClient {
    readonly PortalApplication: PortalApplicationWrapper;
    readonly PortalApplicationIdentities: PortalApplicationIdentitiesWrapper;
    readonly PortalApplicationIdentitiesbyidentity: PortalApplicationIdentitiesbyidentityWrapper;
    readonly PortalApplicationinshop: PortalApplicationinshopWrapper;
    readonly PortalApplicationInteractive: PortalApplicationInteractiveWrapper;
    readonly PortalApplicationNew: PortalApplicationNewWrapper;
    readonly PortalApplicationSqlwizardCandidates: PortalApplicationSqlwizardCandidatesWrapper;
    readonly PortalApplicationusesaccount: PortalApplicationusesaccountWrapper;
    readonly PortalApplicationusesaccountNew: PortalApplicationusesaccountNewWrapper;
    readonly PortalCandidatesAccproductparamcategory: PortalCandidatesAccproductparamcategoryWrapper;
    readonly PortalCandidatesAerole: PortalCandidatesAeroleWrapper;
    readonly PortalCandidatesAobapplication: PortalCandidatesAobapplicationWrapper;
    readonly PortalCandidatesApplication: PortalCandidatesApplicationWrapper;
    readonly PortalCandidatesEset: PortalCandidatesEsetWrapper;
    readonly PortalCandidatesFunctionalarea: PortalCandidatesFunctionalareaWrapper;
    readonly PortalCandidatesOrg: PortalCandidatesOrgWrapper;
    readonly PortalCandidatesPerson: PortalCandidatesPersonWrapper;
    readonly PortalCandidatesQerassign: PortalCandidatesQerassignWrapper;
    readonly PortalCandidatesQerresource: PortalCandidatesQerresourceWrapper;
    readonly PortalCandidatesQerreuse: PortalCandidatesQerreuseWrapper;
    readonly PortalCandidatesQerreuseus: PortalCandidatesQerreuseusWrapper;
    readonly PortalCandidatesQertermsofuse: PortalCandidatesQertermsofuseWrapper;
    readonly PortalCandidatesRpsreport: PortalCandidatesRpsreportWrapper;
    readonly PortalCandidatesTsbaccountdef: PortalCandidatesTsbaccountdefWrapper;
    readonly PortalCandidatesUnsaccountb: PortalCandidatesUnsaccountbWrapper;
    readonly PortalCandidatesUnsgroup: PortalCandidatesUnsgroupWrapper;
    readonly PortalCandidatesUnsroot: PortalCandidatesUnsrootWrapper;
    readonly PortalEntitlement: PortalEntitlementWrapper;
    readonly PortalEntitlementcandidatesEset: PortalEntitlementcandidatesEsetWrapper;
    readonly PortalEntitlementcandidatesQerresource: PortalEntitlementcandidatesQerresourceWrapper;
    readonly PortalEntitlementcandidatesRpsreport: PortalEntitlementcandidatesRpsreportWrapper;
    readonly PortalEntitlementcandidatesTsbaccountdef: PortalEntitlementcandidatesTsbaccountdefWrapper;
    readonly PortalEntitlementcandidatesUnsgroup: PortalEntitlementcandidatesUnsgroupWrapper;
    readonly PortalEntitlementInteractive: PortalEntitlementInteractiveWrapper;
    readonly PortalEntitlementServiceitem: PortalEntitlementServiceitemWrapper;
    readonly PortalEntitlementSystemrole: PortalEntitlementSystemroleWrapper;
    readonly PortalOwners: PortalOwnersWrapper;
    readonly PortalShops: PortalShopsWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalApplication extends ReadWriteExtTypedEntity<ApplicationExtendedDataRead, ApplicationExtendedDataWrite> {
    readonly ActivationDate: IWriteValue<Date>;
    readonly ApplicationEnvironment: IWriteValue<string>;
    readonly ApplicationWebURL: IWriteValue<string>;
    readonly AuthenticationRoot: IReadValue<string>;
    readonly Description: IWriteValue<string>;
    readonly Ident_AOBApplication: IWriteValue<string>;
    readonly IsAuthenticationIntegrated: IWriteValue<boolean>;
    readonly IsFederationEnabled: IWriteValue<boolean>;
    readonly IsInActive: IWriteValue<boolean>;
    readonly IsMultiFactorEnabled: IWriteValue<boolean>;
    readonly IsSSOEnabled: IWriteValue<boolean>;
    readonly JPegPhoto: IWriteValue<string>;
    readonly NextRunDate: IWriteValue<Date>;
    readonly PurchasedLicenses: IWriteValue<number>;
    readonly RiskIndex: IWriteValue<number>;
    readonly SSORedirectionUrl: IWriteValue<string>;
    readonly UID_AERoleApprover: IWriteValue<string>;
    readonly UID_AERoleOwner: IWriteValue<string>;
    readonly UID_AOBApplication: IReadValue<string>;
    readonly UID_FunctionalArea: IWriteValue<string>;
    readonly UID_ITShopSrcBT: IReadValue<string>;
    readonly UID_PersonHead: IWriteValue<string>;
    readonly WhereClause: IReadValue<string>;
    readonly WhereClauseAddOn: IReadValue<string>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XDateUpdated: IReadValue<Date>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XObjectKey: IReadValue<string>;
    readonly XTouched: IReadValue<string>;
    readonly XUserInserted: IReadValue<string>;
    readonly XUserUpdated: IReadValue<string>;
    readonly HasKpiIssues: IReadValue<boolean>;
    readonly UID_AccProductGroup: IReadValue<string>;
    readonly AuthenticationRootHelper: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'ActivationDate' | 'ApplicationEnvironment' | 'ApplicationWebURL' | 'AuthenticationRoot' | 'Description' | 'Ident_AOBApplication' | 'IsAuthenticationIntegrated' | 'IsFederationEnabled' | 'IsInActive' | 'IsMultiFactorEnabled' | 'IsSSOEnabled' | 'JPegPhoto' | 'NextRunDate' | 'PurchasedLicenses' | 'RiskIndex' | 'SSORedirectionUrl' | 'UID_AERoleApprover' | 'UID_AERoleOwner' | 'UID_AOBApplication' | 'UID_FunctionalArea' | 'UID_ITShopSrcBT' | 'UID_PersonHead' | 'WhereClause' | 'WhereClauseAddOn' | 'XDateInserted' | 'XDateUpdated' | 'XMarkedForDeletion' | 'XObjectKey' | 'XTouched' | 'XUserInserted' | 'XUserUpdated' | 'HasKpiIssues' | 'UID_AccProductGroup' | 'AuthenticationRootHelper'>;
}
/** @deprecated Use the PortalApplication type. */
export declare class PortalApplicationInteractive extends PortalApplication {
}
export declare class PortalApplicationIdentities extends TypedEntity {
    readonly DefaultEmailAddress: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'DefaultEmailAddress'>;
}
/** @deprecated Use the PortalApplicationIdentities type. */
export declare class PortalApplicationIdentitiesInteractive extends PortalApplicationIdentities {
}
export declare class PortalApplicationIdentitiesbyidentity extends TypedEntity {
    readonly ObjectKeyElement: IReadValue<string>;
    readonly UID_PersonWantsOrg: IReadValue<string>;
    readonly OrderState: IReadValue<string>;
    readonly IsRequestCancellable: IReadValue<boolean>;
    readonly ValidUntil: IReadValue<Date>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'ObjectKeyElement' | 'UID_PersonWantsOrg' | 'OrderState' | 'IsRequestCancellable' | 'ValidUntil'>;
}
/** @deprecated Use the PortalApplicationIdentitiesbyidentity type. */
export declare class PortalApplicationIdentitiesbyidentityInteractive extends PortalApplicationIdentitiesbyidentity {
}
export declare class PortalApplicationinshop extends TypedEntity {
    readonly UID_ITShopOrg: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_ITShopOrg'>;
}
/** @deprecated Use the PortalApplicationinshop type. */
export declare class PortalApplicationinshopInteractive extends PortalApplicationinshop {
}
export declare class PortalApplicationNew extends TypedEntity {
    readonly ActivationDate: IWriteValue<Date>;
    readonly ApplicationEnvironment: IWriteValue<string>;
    readonly ApplicationWebURL: IWriteValue<string>;
    readonly AuthenticationRoot: IReadValue<string>;
    readonly Description: IWriteValue<string>;
    readonly Ident_AOBApplication: IWriteValue<string>;
    readonly IsAuthenticationIntegrated: IWriteValue<boolean>;
    readonly IsFederationEnabled: IWriteValue<boolean>;
    readonly IsInActive: IWriteValue<boolean>;
    readonly IsMultiFactorEnabled: IWriteValue<boolean>;
    readonly IsSSOEnabled: IWriteValue<boolean>;
    readonly JPegPhoto: IWriteValue<string>;
    readonly NextRunDate: IWriteValue<Date>;
    readonly PurchasedLicenses: IWriteValue<number>;
    readonly RiskIndex: IWriteValue<number>;
    readonly SSORedirectionUrl: IWriteValue<string>;
    readonly UID_AERoleApprover: IWriteValue<string>;
    readonly UID_AERoleOwner: IWriteValue<string>;
    readonly UID_AOBApplication: IReadValue<string>;
    readonly UID_FunctionalArea: IWriteValue<string>;
    readonly UID_ITShopSrcBT: IReadValue<string>;
    readonly UID_PersonHead: IWriteValue<string>;
    readonly WhereClause: IReadValue<string>;
    readonly WhereClauseAddOn: IReadValue<string>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XDateUpdated: IReadValue<Date>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XObjectKey: IReadValue<string>;
    readonly XTouched: IReadValue<string>;
    readonly XUserInserted: IReadValue<string>;
    readonly XUserUpdated: IReadValue<string>;
    readonly UID_AccProductGroup: IWriteValue<string>;
    readonly AuthenticationRootHelper: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'ActivationDate' | 'ApplicationEnvironment' | 'ApplicationWebURL' | 'AuthenticationRoot' | 'Description' | 'Ident_AOBApplication' | 'IsAuthenticationIntegrated' | 'IsFederationEnabled' | 'IsInActive' | 'IsMultiFactorEnabled' | 'IsSSOEnabled' | 'JPegPhoto' | 'NextRunDate' | 'PurchasedLicenses' | 'RiskIndex' | 'SSORedirectionUrl' | 'UID_AERoleApprover' | 'UID_AERoleOwner' | 'UID_AOBApplication' | 'UID_FunctionalArea' | 'UID_ITShopSrcBT' | 'UID_PersonHead' | 'WhereClause' | 'WhereClauseAddOn' | 'XDateInserted' | 'XDateUpdated' | 'XMarkedForDeletion' | 'XObjectKey' | 'XTouched' | 'XUserInserted' | 'XUserUpdated' | 'UID_AccProductGroup' | 'AuthenticationRootHelper'>;
}
/** @deprecated Use the PortalApplicationNew type. */
export declare class PortalApplicationNewInteractive extends PortalApplicationNew {
}
export declare class PortalApplicationSqlwizardCandidates extends TypedEntity {
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<never>;
}
/** @deprecated Use the PortalApplicationSqlwizardCandidates type. */
export declare class PortalApplicationSqlwizardCandidatesInteractive extends PortalApplicationSqlwizardCandidates {
}
export declare class PortalApplicationusesaccount extends TypedEntity {
    readonly UID_AOBApplication: IReadValue<string>;
    readonly UID_AOBAppUsesAccount: IReadValue<string>;
    readonly ObjectKeyAccount: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_AOBApplication' | 'UID_AOBAppUsesAccount' | 'ObjectKeyAccount'>;
}
/** @deprecated Use the PortalApplicationusesaccount type. */
export declare class PortalApplicationusesaccountInteractive extends PortalApplicationusesaccount {
}
export declare class PortalApplicationusesaccountNew extends TypedEntity {
    readonly ObjectKeyAccount: IWriteValue<string>;
    readonly UID_AOBApplication: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'ObjectKeyAccount' | 'UID_AOBApplication'>;
}
/** @deprecated Use the PortalApplicationusesaccountNew type. */
export declare class PortalApplicationusesaccountNewInteractive extends PortalApplicationusesaccountNew {
}
export declare class PortalCandidatesAccproductparamcategory extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_AccProductParamCategory: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_AccProductParamCategory'>;
}
/** @deprecated Use the PortalCandidatesAccproductparamcategory type. */
export declare class PortalCandidatesAccproductparamcategoryInteractive extends PortalCandidatesAccproductparamcategory {
}
export declare class PortalCandidatesAerole extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_AERole: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_AERole'>;
}
/** @deprecated Use the PortalCandidatesAerole type. */
export declare class PortalCandidatesAeroleInteractive extends PortalCandidatesAerole {
}
export declare class PortalCandidatesAobapplication extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_AOBApplication: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_AOBApplication'>;
}
/** @deprecated Use the PortalCandidatesAobapplication type. */
export declare class PortalCandidatesAobapplicationInteractive extends PortalCandidatesAobapplication {
}
export declare class PortalCandidatesApplication extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_Application: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_Application'>;
}
/** @deprecated Use the PortalCandidatesApplication type. */
export declare class PortalCandidatesApplicationInteractive extends PortalCandidatesApplication {
}
export declare class PortalCandidatesEset extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_ESet: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_ESet'>;
}
/** @deprecated Use the PortalCandidatesEset type. */
export declare class PortalCandidatesEsetInteractive extends PortalCandidatesEset {
}
export declare class PortalCandidatesFunctionalarea extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_FunctionalArea: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_FunctionalArea'>;
}
/** @deprecated Use the PortalCandidatesFunctionalarea type. */
export declare class PortalCandidatesFunctionalareaInteractive extends PortalCandidatesFunctionalarea {
}
export declare class PortalCandidatesOrg extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_Org: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_Org'>;
}
/** @deprecated Use the PortalCandidatesOrg type. */
export declare class PortalCandidatesOrgInteractive extends PortalCandidatesOrg {
}
export declare class PortalCandidatesPerson extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_Person: IReadValue<string>;
    readonly DefaultEmailAddress: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_Person' | 'DefaultEmailAddress'>;
}
/** @deprecated Use the PortalCandidatesPerson type. */
export declare class PortalCandidatesPersonInteractive extends PortalCandidatesPerson {
}
export declare class PortalCandidatesQerassign extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_QERAssign: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_QERAssign'>;
}
/** @deprecated Use the PortalCandidatesQerassign type. */
export declare class PortalCandidatesQerassignInteractive extends PortalCandidatesQerassign {
}
export declare class PortalCandidatesQerresource extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_QERResource: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_QERResource'>;
}
/** @deprecated Use the PortalCandidatesQerresource type. */
export declare class PortalCandidatesQerresourceInteractive extends PortalCandidatesQerresource {
}
export declare class PortalCandidatesQerreuse extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_QERReuse: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_QERReuse'>;
}
/** @deprecated Use the PortalCandidatesQerreuse type. */
export declare class PortalCandidatesQerreuseInteractive extends PortalCandidatesQerreuse {
}
export declare class PortalCandidatesQerreuseus extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_QERReuseUS: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_QERReuseUS'>;
}
/** @deprecated Use the PortalCandidatesQerreuseus type. */
export declare class PortalCandidatesQerreuseusInteractive extends PortalCandidatesQerreuseus {
}
export declare class PortalCandidatesQertermsofuse extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_QERTermsOfUse: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_QERTermsOfUse'>;
}
/** @deprecated Use the PortalCandidatesQertermsofuse type. */
export declare class PortalCandidatesQertermsofuseInteractive extends PortalCandidatesQertermsofuse {
}
export declare class PortalCandidatesRpsreport extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_RPSReport: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_RPSReport'>;
}
/** @deprecated Use the PortalCandidatesRpsreport type. */
export declare class PortalCandidatesRpsreportInteractive extends PortalCandidatesRpsreport {
}
export declare class PortalCandidatesTsbaccountdef extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_TSBAccountDef: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_TSBAccountDef'>;
}
/** @deprecated Use the PortalCandidatesTsbaccountdef type. */
export declare class PortalCandidatesTsbaccountdefInteractive extends PortalCandidatesTsbaccountdef {
}
export declare class PortalCandidatesUnsaccountb extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_UNSAccountB: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_UNSAccountB'>;
}
/** @deprecated Use the PortalCandidatesUnsaccountb type. */
export declare class PortalCandidatesUnsaccountbInteractive extends PortalCandidatesUnsaccountb {
}
export declare class PortalCandidatesUnsgroup extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_UNSGroup: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_UNSGroup'>;
}
/** @deprecated Use the PortalCandidatesUnsgroup type. */
export declare class PortalCandidatesUnsgroupInteractive extends PortalCandidatesUnsgroup {
}
export declare class PortalCandidatesUnsroot extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_UNSRoot: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_UNSRoot'>;
}
/** @deprecated Use the PortalCandidatesUnsroot type. */
export declare class PortalCandidatesUnsrootInteractive extends PortalCandidatesUnsroot {
}
export declare class PortalEntitlement extends TypedEntity {
    readonly ActivationDate: IWriteValue<Date>;
    readonly Description: IWriteValue<string>;
    readonly Ident_AOBEntitlement: IWriteValue<string>;
    readonly IsDynamic: IReadValue<boolean>;
    readonly IsInActive: IWriteValue<boolean>;
    readonly JPegPhoto: IReadValue<string>;
    readonly ObjectKeyAdditionalApprover: IWriteValue<string>;
    readonly ObjectKeyElement: IWriteValue<string>;
    readonly UID_AERoleOwner: IWriteValue<string>;
    readonly UID_AOBApplication: IWriteValue<string>;
    readonly UID_AOBEntitlement: IReadValue<string>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XDateUpdated: IReadValue<Date>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XObjectKey: IReadValue<string>;
    readonly XTouched: IReadValue<string>;
    readonly XUserInserted: IReadValue<string>;
    readonly XUserUpdated: IReadValue<string>;
    readonly UID_AccProduct: IReadValue<string>;
    readonly IsOwnerOrAdmin: IReadValue<boolean>;
    readonly IsOutlierAssignment: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'ActivationDate' | 'Description' | 'Ident_AOBEntitlement' | 'IsDynamic' | 'IsInActive' | 'JPegPhoto' | 'ObjectKeyAdditionalApprover' | 'ObjectKeyElement' | 'UID_AERoleOwner' | 'UID_AOBApplication' | 'UID_AOBEntitlement' | 'XDateInserted' | 'XDateUpdated' | 'XMarkedForDeletion' | 'XObjectKey' | 'XTouched' | 'XUserInserted' | 'XUserUpdated' | 'UID_AccProduct' | 'IsOwnerOrAdmin' | 'IsOutlierAssignment'>;
}
/** @deprecated Use the PortalEntitlement type. */
export declare class PortalEntitlementInteractive extends PortalEntitlement {
}
export declare class PortalEntitlementcandidatesEset extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey'>;
}
/** @deprecated Use the PortalEntitlementcandidatesEset type. */
export declare class PortalEntitlementcandidatesEsetInteractive extends PortalEntitlementcandidatesEset {
}
export declare class PortalEntitlementcandidatesQerresource extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey'>;
}
/** @deprecated Use the PortalEntitlementcandidatesQerresource type. */
export declare class PortalEntitlementcandidatesQerresourceInteractive extends PortalEntitlementcandidatesQerresource {
}
export declare class PortalEntitlementcandidatesRpsreport extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey'>;
}
/** @deprecated Use the PortalEntitlementcandidatesRpsreport type. */
export declare class PortalEntitlementcandidatesRpsreportInteractive extends PortalEntitlementcandidatesRpsreport {
}
export declare class PortalEntitlementcandidatesTsbaccountdef extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey'>;
}
/** @deprecated Use the PortalEntitlementcandidatesTsbaccountdef type. */
export declare class PortalEntitlementcandidatesTsbaccountdefInteractive extends PortalEntitlementcandidatesTsbaccountdef {
}
export declare class PortalEntitlementcandidatesUnsgroup extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly CanonicalName: IReadValue<string>;
    readonly Description: IReadValue<string>;
    readonly UID_UNSRoot: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'CanonicalName' | 'Description' | 'UID_UNSRoot'>;
}
/** @deprecated Use the PortalEntitlementcandidatesUnsgroup type. */
export declare class PortalEntitlementcandidatesUnsgroupInteractive extends PortalEntitlementcandidatesUnsgroup {
}
export declare class PortalEntitlementServiceitem extends WriteExtTypedEntity<AccProductOwnershipInput> {
    readonly Description: IWriteValue<string>;
    readonly Ident_AccProduct: IWriteValue<string>;
    readonly IsApproveRequiresMfa: IWriteValue<boolean>;
    readonly IsInActive: IWriteValue<boolean>;
    readonly JPegPhoto: IWriteValue<string>;
    readonly MaxValidDays: IWriteValue<number>;
    readonly ProductURL: IWriteValue<string>;
    readonly SortOrder: IWriteValue<string>;
    readonly UID_AccProductGroup: IWriteValue<string>;
    readonly UID_AccProductParamCategory: IWriteValue<string>;
    readonly UID_FunctionalArea: IWriteValue<string>;
    readonly UID_OrgAttestator: IWriteValue<string>;
    readonly UID_OrgRuler: IWriteValue<string>;
    readonly UID_PWODecisionMethod: IWriteValue<string>;
    readonly UID_QERTermsOfUse: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'Description' | 'Ident_AccProduct' | 'IsApproveRequiresMfa' | 'IsInActive' | 'JPegPhoto' | 'MaxValidDays' | 'ProductURL' | 'SortOrder' | 'UID_AccProductGroup' | 'UID_AccProductParamCategory' | 'UID_FunctionalArea' | 'UID_OrgAttestator' | 'UID_OrgRuler' | 'UID_PWODecisionMethod' | 'UID_QERTermsOfUse'>;
}
/** @deprecated Use the PortalEntitlementServiceitem type. */
export declare class PortalEntitlementServiceitemInteractive extends PortalEntitlementServiceitem {
}
export declare class PortalEntitlementSystemrole extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey'>;
}
/** @deprecated Use the PortalEntitlementSystemrole type. */
export declare class PortalEntitlementSystemroleInteractive extends PortalEntitlementSystemrole {
}
export declare class PortalOwners extends TypedEntity {
    readonly DefaultEmailAddress: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'DefaultEmailAddress'>;
}
/** @deprecated Use the PortalOwners type. */
export declare class PortalOwnersInteractive extends PortalOwners {
}
export declare class PortalShops extends TypedEntity {
    readonly UID_ITShopOrg: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_ITShopOrg'>;
}
/** @deprecated Use the PortalShops type. */
export declare class PortalShopsInteractive extends PortalShops {
}
export declare class PortalApplicationWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_application_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplication, ApplicationExtendedDataRead>>;
    Delete(UID_AOBApplication: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplication, ApplicationExtendedDataRead>>;
}
export declare class PortalApplicationIdentitiesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidapplication: string, parametersOptional?: portal_application_identities_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplicationIdentities, unknown>>;
}
export declare class PortalApplicationIdentitiesbyidentityWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Getbyidentity(uidapplication: string, uidperson: string, parametersOptional?: portal_application_identitiesbyidentity_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplicationIdentitiesbyidentity, unknown>>;
}
export declare class PortalApplicationinshopWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidapplication: string, parametersOptional?: portal_applicationinshop_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplicationinshop, unknown>>;
}
export declare class PortalApplicationInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalApplication, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplication, ApplicationExtendedDataRead>>;
    Delete(inputParameterName: PortalApplication, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplication, ApplicationExtendedDataRead>>;
    Get_byid(UID_AOBApplication: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplication, ApplicationExtendedDataRead>>;
}
export declare class PortalApplicationNewWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalApplicationNew;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Post(inputParameterName: PortalApplicationNew, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplicationNew, unknown>>;
}
export declare class PortalApplicationSqlwizardCandidatesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(table: string, parametersOptional?: portal_application_sqlwizard_candidates_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplicationSqlwizardCandidates, unknown>>;
}
export declare class PortalApplicationusesaccountWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_AOBApplication: string, parametersOptional?: portal_applicationusesaccount_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplicationusesaccount, unknown>>;
    Delete(UID_AOBApplication: string, UID_AOBAppUsesAccount: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplicationusesaccount, unknown>>;
}
export declare class PortalApplicationusesaccountNewWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalApplicationusesaccountNew;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Post(inputParameterName: PortalApplicationusesaccountNew, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplicationusesaccountNew, unknown>>;
}
export declare class PortalCandidatesAccproductparamcategoryWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_AccProductParamCategory_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesAccproductparamcategory, unknown>>;
}
export declare class PortalCandidatesAeroleWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_AERole_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesAerole, unknown>>;
}
export declare class PortalCandidatesAobapplicationWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_AOBApplication_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesAobapplication, unknown>>;
}
export declare class PortalCandidatesApplicationWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_Application_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesApplication, unknown>>;
}
export declare class PortalCandidatesEsetWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_ESet_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesEset, unknown>>;
}
export declare class PortalCandidatesFunctionalareaWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_FunctionalArea_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesFunctionalarea, unknown>>;
}
export declare class PortalCandidatesOrgWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_Org_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesOrg, unknown>>;
}
export declare class PortalCandidatesPersonWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_Person_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesPerson, unknown>>;
}
export declare class PortalCandidatesQerassignWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_QERAssign_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesQerassign, unknown>>;
}
export declare class PortalCandidatesQerresourceWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_QERResource_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesQerresource, unknown>>;
}
export declare class PortalCandidatesQerreuseWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_QERReuse_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesQerreuse, unknown>>;
}
export declare class PortalCandidatesQerreuseusWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_QERReuseUS_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesQerreuseus, unknown>>;
}
export declare class PortalCandidatesQertermsofuseWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_QERTermsOfUse_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesQertermsofuse, unknown>>;
}
export declare class PortalCandidatesRpsreportWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_RPSReport_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesRpsreport, unknown>>;
}
export declare class PortalCandidatesTsbaccountdefWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_TSBAccountDef_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesTsbaccountdef, unknown>>;
}
export declare class PortalCandidatesUnsaccountbWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_UNSAccountB_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesUnsaccountb, unknown>>;
}
export declare class PortalCandidatesUnsgroupWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_UNSGroup_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesUnsgroup, unknown>>;
}
export declare class PortalCandidatesUnsrootWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_UNSRoot_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesUnsroot, unknown>>;
}
export declare class PortalEntitlementWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_entitlement_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlement, unknown>>;
    Delete(UID_AOBEntitlement: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlement, unknown>>;
}
export declare class PortalEntitlementcandidatesEsetWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_entitlementcandidates_ESet_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlementcandidatesEset, unknown>>;
}
export declare class PortalEntitlementcandidatesQerresourceWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_entitlementcandidates_QERResource_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlementcandidatesQerresource, unknown>>;
}
export declare class PortalEntitlementcandidatesRpsreportWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_entitlementcandidates_RPSReport_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlementcandidatesRpsreport, unknown>>;
}
export declare class PortalEntitlementcandidatesTsbaccountdefWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_entitlementcandidates_TSBAccountDef_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlementcandidatesTsbaccountdef, unknown>>;
}
export declare class PortalEntitlementcandidatesUnsgroupWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_entitlementcandidates_UNSGroup_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlementcandidatesUnsgroup, unknown>>;
}
export declare class PortalEntitlementInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalEntitlement, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlement, unknown>>;
    Delete(inputParameterName: PortalEntitlement, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlement, unknown>>;
    Get_byid(UID_AOBEntitlement: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlement, unknown>>;
    Get(parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlement, unknown>>;
}
export declare class PortalEntitlementServiceitemWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_entitlement_serviceitem_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlementServiceitem, unknown>>;
    Put(inputParameterName: PortalEntitlementServiceitem, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlementServiceitem, unknown>>;
}
export declare class PortalEntitlementSystemroleWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidapplication: string, parametersOptional?: portal_entitlement_systemrole_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlementSystemrole, unknown>>;
}
export declare class PortalOwnersWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(tablename: string, uid: string, parametersOptional?: portal_owners_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalOwners, unknown>>;
}
export declare class PortalShopsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_shops_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShops, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    portal_application_get(filterkpi: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<ExtendedEntityCollectionData<ApplicationExtendedDataRead>>;
    portal_application_delete(UID_AOBApplication: string): MethodDescriptor<ExtendedEntityCollectionData<ApplicationExtendedDataRead>>;
    portal_application_map_post(UID_AOBApplication: string): MethodDescriptor<void>;
    portal_application_identities_get(uidapplication: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_application_identitiesbyidentity_get(uidapplication: string, uidperson: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_application_kpi_get(uidapplication: string): MethodDescriptor<ChartDto[]>;
    portal_application_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean): MethodDescriptor<GroupInfoData>;
    portal_application_interactive_put(inputParameterName: any): MethodDescriptor<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    portal_application_interactive_delete(inputParameterName: InteractiveEntityDeleteData): MethodDescriptor<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    portal_application_interactive_entitlementstoadd_get(entityid: string, keys: string[], state: string): MethodDescriptor<EntitlementToAddData>;
    portal_application_interactive_byid_get(UID_AOBApplication: string): MethodDescriptor<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    portal_application_interactive_UID_AERoleApprover_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_application_interactive_UID_AERoleApprover_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_application_interactive_UID_AERoleOwner_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_application_interactive_UID_AERoleOwner_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_application_new_post(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_application_new_UID_AccProductGroup_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_application_new_UID_AccProductGroup_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_application_new_UID_AERoleApprover_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_application_new_UID_AERoleApprover_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_application_new_UID_AERoleOwner_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_application_new_UID_AERoleOwner_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_application_sqlwizard_candidates_get(table: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_application_sqlwizard_tables_columns_get(table: string): MethodDescriptor<FilterPropertyList>;
    portal_applicationimage_get(uidapplication: string): MethodDescriptor<Blob>;
    portal_applicationimage_post(uidapplication: string, inputParameterName: Blob): MethodDescriptor<any>;
    portal_applicationinshop_get(uidapplication: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_applicationinshop_put(uidapplication: string, uidshop: string, inputParameterName: any): MethodDescriptor<void>;
    portal_applicationinshop_delete(uidapplication: string, uidshop: string, inputParameterName: any): MethodDescriptor<void>;
    portal_applicationusesaccount_get(UID_AOBApplication: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_applicationusesaccount_delete(UID_AOBApplication: string, UID_AOBAppUsesAccount: string): MethodDescriptor<EntityCollectionData>;
    portal_applicationusesaccount_new_post(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AccProductParamCategory_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AccProductParamCategory_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_AERole_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AERole_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_AOBApplication_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AOBApplication_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_AOBApplication_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_Application_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Application_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_ESet_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_ESet_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_FunctionalArea_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_FunctionalArea_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_Org_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Org_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_Person_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Person_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERAssign_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERAssign_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERResource_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERResource_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERReuse_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERReuse_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERReuseUS_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERReuseUS_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERTermsOfUse_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERTermsOfUse_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_RPSReport_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_RPSReport_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_TSBAccountDef_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_TSBAccountDef_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_UNSAccountB_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_UNSAccountB_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_UNSGroup_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_UNSGroup_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_UNSRoot_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_UNSRoot_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_entitlement_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_delete(UID_AOBEntitlement: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_systemrole_get(uidapplication: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean): MethodDescriptor<GroupInfoData>;
    portal_entitlement_interactive_get(): MethodDescriptor<InteractiveEntityData>;
    portal_entitlement_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_entitlement_interactive_delete(inputParameterName: InteractiveEntityDeleteData): MethodDescriptor<InteractiveEntityData>;
    portal_entitlement_interactive_byid_get(UID_AOBEntitlement: string): MethodDescriptor<InteractiveEntityData>;
    portal_entitlement_interactive_UID_AERoleOwner_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_interactive_UID_AERoleOwner_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_entitlement_serviceitem_get(uid_aobentitlement: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_entitlement_serviceitem_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_entitlement_serviceitem_UID_AccProductGroup_candidates_post(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, inputParameterName: EntityKeysData): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_serviceitem_UID_AccProductGroup_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_entitlement_serviceitem_UID_OrgAttestator_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_serviceitem_UID_OrgAttestator_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_entitlement_serviceitem_UID_OrgRuler_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_serviceitem_UID_OrgRuler_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_entitlement_systemrole_post(inputParameterName: EntitlementSystemRoleInput): MethodDescriptor<void>;
    portal_entitlementcandidates_ESet_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlementcandidates_ESet_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_entitlementcandidates_ESet_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean): MethodDescriptor<GroupInfoData>;
    portal_entitlementcandidates_QERResource_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlementcandidates_QERResource_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_entitlementcandidates_QERResource_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean): MethodDescriptor<GroupInfoData>;
    portal_entitlementcandidates_RPSReport_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlementcandidates_RPSReport_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_entitlementcandidates_RPSReport_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean): MethodDescriptor<GroupInfoData>;
    portal_entitlementcandidates_TSBAccountDef_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlementcandidates_TSBAccountDef_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_entitlementcandidates_TSBAccountDef_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean): MethodDescriptor<GroupInfoData>;
    portal_entitlementcandidates_UNSGroup_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, namespace: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlementcandidates_UNSGroup_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_entitlementcandidates_UNSGroup_filtertree_get(filter: FilterData[], parentkey: string): MethodDescriptor<FilterTreeData>;
    portal_entitlementcandidates_UNSGroup_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, namespace: string): MethodDescriptor<GroupInfoData>;
    portal_entitlementimage_get(uidentitlement: string): MethodDescriptor<Blob>;
    portal_entitlementimage_post(uidentitlement: string, inputParameterName: Blob): MethodDescriptor<any>;
    portal_kpi_get(): MethodDescriptor<ChartDto[]>;
    portal_owners_get(tablename: string, uid: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_publish_application_post(uidapplication: string, date: Date, inputParameterName: any): MethodDescriptor<any>;
    portal_shops_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_application_get(filterkpi: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ApplicationExtendedDataRead>>;
    portal_application_delete(UID_AOBApplication: string, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ApplicationExtendedDataRead>>;
    /** Starts the entitlement mapping process for the specified application. */
    portal_application_map_post(UID_AOBApplication: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns all identities having access to at least one entitlement of the application. */
    portal_application_identities_get(uidapplication: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns all entitlements that the specified identity has access to. */
    portal_application_identitiesbyidentity_get(uidapplication: string, uidperson: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns application-specific KPI information. */
    portal_application_kpi_get(uidapplication: string, requestOptions?: ApiRequestOptions): Promise<ChartDto[]>;
    portal_application_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    portal_application_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    portal_application_interactive_delete(inputParameterName: InteractiveEntityDeleteData, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    portal_application_interactive_entitlementstoadd_get(entityid: string, keys: string[], state: string, requestOptions?: ApiRequestOptions): Promise<EntitlementToAddData>;
    portal_application_interactive_byid_get(UID_AOBApplication: string, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    /** Returns a list of objects that can be assigned to the property UID_AERoleApprover. */
    portal_application_interactive_UID_AERoleApprover_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the application/interactive/UID_AERoleApprover/candidates endpoint. */
    portal_application_interactive_UID_AERoleApprover_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AERoleOwner. */
    portal_application_interactive_UID_AERoleOwner_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the application/interactive/UID_AERoleOwner/candidates endpoint. */
    portal_application_interactive_UID_AERoleOwner_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_application_new_post(inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_AccProductGroup. */
    portal_application_new_UID_AccProductGroup_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the application/new/UID_AccProductGroup/candidates endpoint. */
    portal_application_new_UID_AccProductGroup_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AERoleApprover. */
    portal_application_new_UID_AERoleApprover_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the application/new/UID_AERoleApprover/candidates endpoint. */
    portal_application_new_UID_AERoleApprover_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AERoleOwner. */
    portal_application_new_UID_AERoleOwner_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the application/new/UID_AERoleOwner/candidates endpoint. */
    portal_application_new_UID_AERoleOwner_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned as a filter parameter. */
    portal_application_sqlwizard_candidates_get(table: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns the filterable properties for the specified table. */
    portal_application_sqlwizard_tables_columns_get(table: string, requestOptions?: ApiRequestOptions): Promise<FilterPropertyList>;
    portal_applicationimage_get(uidapplication: string, requestOptions?: ApiRequestOptions): Promise<Blob>;
    portal_applicationimage_post(uidapplication: string, inputParameterName: Blob, requestOptions?: ApiRequestOptions): Promise<any>;
    portal_applicationinshop_get(uidapplication: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Assigns an application to a shop. */
    portal_applicationinshop_put(uidapplication: string, uidshop: string, inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Removes an application from a shop. */
    portal_applicationinshop_delete(uidapplication: string, uidshop: string, inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns the list of accounts used by the specified application. */
    portal_applicationusesaccount_get(UID_AOBApplication: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns the list of accounts used by the specified application. */
    portal_applicationusesaccount_delete(UID_AOBApplication: string, UID_AOBAppUsesAccount: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Defines that an application uses a specific account. */
    portal_applicationusesaccount_new_post(inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of candidate objects from the table AccProductParamCategory. */
    portal_candidates_AccProductParamCategory_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/AccProductParamCategory endpoint. */
    portal_candidates_AccProductParamCategory_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table AERole. */
    portal_candidates_AERole_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/AERole endpoint. */
    portal_candidates_AERole_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table AOBApplication. */
    portal_candidates_AOBApplication_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/AOBApplication endpoint. */
    portal_candidates_AOBApplication_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the candidates/AOBApplication endpoint. */
    portal_candidates_AOBApplication_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table Application. */
    portal_candidates_Application_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/Application endpoint. */
    portal_candidates_Application_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table ESet. */
    portal_candidates_ESet_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/ESet endpoint. */
    portal_candidates_ESet_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table FunctionalArea. */
    portal_candidates_FunctionalArea_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/FunctionalArea endpoint. */
    portal_candidates_FunctionalArea_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table Org. */
    portal_candidates_Org_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/Org endpoint. */
    portal_candidates_Org_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table Person. */
    portal_candidates_Person_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/Person endpoint. */
    portal_candidates_Person_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERAssign. */
    portal_candidates_QERAssign_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/QERAssign endpoint. */
    portal_candidates_QERAssign_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERResource. */
    portal_candidates_QERResource_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/QERResource endpoint. */
    portal_candidates_QERResource_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERReuse. */
    portal_candidates_QERReuse_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/QERReuse endpoint. */
    portal_candidates_QERReuse_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERReuseUS. */
    portal_candidates_QERReuseUS_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/QERReuseUS endpoint. */
    portal_candidates_QERReuseUS_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERTermsOfUse. */
    portal_candidates_QERTermsOfUse_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/QERTermsOfUse endpoint. */
    portal_candidates_QERTermsOfUse_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table RPSReport. */
    portal_candidates_RPSReport_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/RPSReport endpoint. */
    portal_candidates_RPSReport_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table TSBAccountDef. */
    portal_candidates_TSBAccountDef_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/TSBAccountDef endpoint. */
    portal_candidates_TSBAccountDef_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table UNSAccountB. */
    portal_candidates_UNSAccountB_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/UNSAccountB endpoint. */
    portal_candidates_UNSAccountB_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table UNSGroup. */
    portal_candidates_UNSGroup_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/UNSGroup endpoint. */
    portal_candidates_UNSGroup_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table UNSRoot. */
    portal_candidates_UNSRoot_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/UNSRoot endpoint. */
    portal_candidates_UNSRoot_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_entitlement_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_entitlement_delete(UID_AOBEntitlement: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_entitlement_systemrole_get(uidapplication: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_entitlement_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    portal_entitlement_interactive_get(requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_entitlement_interactive_put(inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_entitlement_interactive_delete(inputParameterName: InteractiveEntityDeleteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_entitlement_interactive_byid_get(UID_AOBEntitlement: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    /** Returns a list of objects that can be assigned to the property UID_AERoleOwner. */
    portal_entitlement_interactive_UID_AERoleOwner_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the entitlement/interactive/UID_AERoleOwner/candidates endpoint. */
    portal_entitlement_interactive_UID_AERoleOwner_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_entitlement_serviceitem_get(uid_aobentitlement: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_entitlement_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_entitlement_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the entitlement/serviceitem endpoint. */
    portal_entitlement_serviceitem_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns a list of objects that can be assigned to the property UID_AccProductGroup. */
    portal_entitlement_serviceitem_UID_AccProductGroup_candidates_post(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, inputParameterName: EntityKeysData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the entitlement/serviceitem/UID_AccProductGroup/candidates endpoint. */
    portal_entitlement_serviceitem_UID_AccProductGroup_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgAttestator. */
    portal_entitlement_serviceitem_UID_OrgAttestator_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the entitlement/serviceitem/UID_OrgAttestator/candidates endpoint. */
    portal_entitlement_serviceitem_UID_OrgAttestator_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgRuler. */
    portal_entitlement_serviceitem_UID_OrgRuler_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the entitlement/serviceitem/UID_OrgRuler/candidates endpoint. */
    portal_entitlement_serviceitem_UID_OrgRuler_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_PWODecisionMethod. */
    portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the entitlement/serviceitem/UID_PWODecisionMethod/candidates endpoint. */
    portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Adds entitlements to a new or existing system role, and adds the system role to the application. */
    portal_entitlement_systemrole_post(inputParameterName: EntitlementSystemRoleInput, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_entitlementcandidates_ESet_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the entitlementcandidates/ESet endpoint. */
    portal_entitlementcandidates_ESet_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_entitlementcandidates_ESet_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    portal_entitlementcandidates_QERResource_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the entitlementcandidates/QERResource endpoint. */
    portal_entitlementcandidates_QERResource_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_entitlementcandidates_QERResource_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    portal_entitlementcandidates_RPSReport_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the entitlementcandidates/RPSReport endpoint. */
    portal_entitlementcandidates_RPSReport_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_entitlementcandidates_RPSReport_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    portal_entitlementcandidates_TSBAccountDef_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the entitlementcandidates/TSBAccountDef endpoint. */
    portal_entitlementcandidates_TSBAccountDef_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_entitlementcandidates_TSBAccountDef_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    portal_entitlementcandidates_UNSGroup_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, namespace: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the entitlementcandidates/UNSGroup endpoint. */
    portal_entitlementcandidates_UNSGroup_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the entitlementcandidates/UNSGroup endpoint. */
    portal_entitlementcandidates_UNSGroup_filtertree_get(filter: FilterData[], parentkey: string, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_entitlementcandidates_UNSGroup_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, namespace: string, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    portal_entitlementimage_get(uidentitlement: string, requestOptions?: ApiRequestOptions): Promise<Blob>;
    portal_entitlementimage_post(uidentitlement: string, inputParameterName: Blob, requestOptions?: ApiRequestOptions): Promise<any>;
    /** Returns global KPI information for application governance. */
    portal_kpi_get(requestOptions?: ApiRequestOptions): Promise<ChartDto[]>;
    /** Returns owner information for the specified entitlement */
    portal_owners_get(tablename: string, uid: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_publish_application_post(uidapplication: string, date: Date, inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<any>;
    portal_shops_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
}
export interface portal_application_get_args {
    /** Returns only applications with KPI violations */ filterkpi?: boolean;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_application_identities_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_application_identitiesbyidentity_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_application_group_get_args {
    /** Comma-seperated list of columns */ by?: string;
    /** Pipe-seperated list of grouping definition data */ def?: string;
    /** Filter definition */ filter?: FilterData[];
    /** Index of first group to return */ StartIndex?: number;
    /** Number of groups to return */ PageSize?: number;
    /** Includes count of items for each group */ withcount?: boolean;
}
export interface portal_application_interactive_entitlementstoadd_get_args {
    keys?: string[];
    state?: string;
}
export interface portal_application_interactive_UID_AERoleApprover_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_ParentAERole) */ ParentKey?: string;
}
export interface portal_application_interactive_UID_AERoleApprover_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_application_interactive_UID_AERoleOwner_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_ParentAERole) */ ParentKey?: string;
}
export interface portal_application_interactive_UID_AERoleOwner_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_application_new_UID_AccProductGroup_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_AccProductGroupParent) */ ParentKey?: string;
}
export interface portal_application_new_UID_AccProductGroup_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_application_new_UID_AERoleApprover_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_ParentAERole) */ ParentKey?: string;
}
export interface portal_application_new_UID_AERoleApprover_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_application_new_UID_AERoleOwner_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_ParentAERole) */ ParentKey?: string;
}
export interface portal_application_new_UID_AERoleOwner_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_application_sqlwizard_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (dynamic) */ ParentKey?: string;
}
export interface portal_applicationinshop_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_ParentITShopOrg) */ ParentKey?: string;
}
export interface portal_applicationusesaccount_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_candidates_AccProductParamCategory_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_candidates_AccProductParamCategory_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_candidates_AERole_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_ParentAERole) */ ParentKey?: string;
}
export interface portal_candidates_AERole_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_candidates_AOBApplication_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_candidates_AOBApplication_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_candidates_AOBApplication_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_candidates_Application_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_candidates_Application_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_candidates_ESet_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_candidates_ESet_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_candidates_FunctionalArea_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_ParentFunctionalArea) */ ParentKey?: string;
}
export interface portal_candidates_FunctionalArea_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_candidates_Org_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_ParentOrg) */ ParentKey?: string;
}
export interface portal_candidates_Org_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_candidates_Person_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_candidates_Person_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_candidates_QERAssign_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_candidates_QERAssign_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_candidates_QERResource_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_candidates_QERResource_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_candidates_QERReuse_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_candidates_QERReuse_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_candidates_QERReuseUS_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_candidates_QERReuseUS_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_candidates_QERTermsOfUse_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_candidates_QERTermsOfUse_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_candidates_RPSReport_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_candidates_RPSReport_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_candidates_TSBAccountDef_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_candidates_TSBAccountDef_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_candidates_UNSAccountB_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_candidates_UNSAccountB_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_candidates_UNSGroup_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_candidates_UNSGroup_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_candidates_UNSRoot_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_candidates_UNSRoot_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_entitlement_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_entitlement_systemrole_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_entitlement_group_get_args {
    /** Comma-seperated list of columns */ by?: string;
    /** Pipe-seperated list of grouping definition data */ def?: string;
    /** Filter definition */ filter?: FilterData[];
    /** Index of first group to return */ StartIndex?: number;
    /** Number of groups to return */ PageSize?: number;
    /** Includes count of items for each group */ withcount?: boolean;
}
export interface portal_entitlement_interactive_UID_AERoleOwner_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_ParentAERole) */ ParentKey?: string;
}
export interface portal_entitlement_interactive_UID_AERoleOwner_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_entitlement_serviceitem_get_args {
    /** Returns only the service item for a specific entitlement */ uid_aobentitlement?: string;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_entitlement_serviceitem_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_entitlement_serviceitem_UID_AccProductGroup_candidates_post_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_AccProductGroupParent) */ ParentKey?: string;
}
export interface portal_entitlement_serviceitem_UID_AccProductGroup_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_entitlement_serviceitem_UID_OrgAttestator_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_ParentAERole) */ ParentKey?: string;
}
export interface portal_entitlement_serviceitem_UID_OrgAttestator_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_entitlement_serviceitem_UID_OrgRuler_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_ParentAERole) */ ParentKey?: string;
}
export interface portal_entitlement_serviceitem_UID_OrgRuler_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_entitlementcandidates_ESet_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_entitlementcandidates_ESet_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_entitlementcandidates_ESet_group_get_args {
    /** Comma-seperated list of columns */ by?: string;
    /** Pipe-seperated list of grouping definition data */ def?: string;
    /** Filter definition */ filter?: FilterData[];
    /** Index of first group to return */ StartIndex?: number;
    /** Number of groups to return */ PageSize?: number;
    /** Includes count of items for each group */ withcount?: boolean;
}
export interface portal_entitlementcandidates_QERResource_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_entitlementcandidates_QERResource_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_entitlementcandidates_QERResource_group_get_args {
    /** Comma-seperated list of columns */ by?: string;
    /** Pipe-seperated list of grouping definition data */ def?: string;
    /** Filter definition */ filter?: FilterData[];
    /** Index of first group to return */ StartIndex?: number;
    /** Number of groups to return */ PageSize?: number;
    /** Includes count of items for each group */ withcount?: boolean;
}
export interface portal_entitlementcandidates_RPSReport_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_entitlementcandidates_RPSReport_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_entitlementcandidates_RPSReport_group_get_args {
    /** Comma-seperated list of columns */ by?: string;
    /** Pipe-seperated list of grouping definition data */ def?: string;
    /** Filter definition */ filter?: FilterData[];
    /** Index of first group to return */ StartIndex?: number;
    /** Number of groups to return */ PageSize?: number;
    /** Includes count of items for each group */ withcount?: boolean;
}
export interface portal_entitlementcandidates_TSBAccountDef_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_entitlementcandidates_TSBAccountDef_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_entitlementcandidates_TSBAccountDef_group_get_args {
    /** Comma-seperated list of columns */ by?: string;
    /** Pipe-seperated list of grouping definition data */ def?: string;
    /** Filter definition */ filter?: FilterData[];
    /** Index of first group to return */ StartIndex?: number;
    /** Number of groups to return */ PageSize?: number;
    /** Includes count of items for each group */ withcount?: boolean;
}
export interface portal_entitlementcandidates_UNSGroup_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Unique target system type identifier */ namespace?: string;
}
export interface portal_entitlementcandidates_UNSGroup_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_entitlementcandidates_UNSGroup_filtertree_get_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_entitlementcandidates_UNSGroup_group_get_args {
    /** Comma-seperated list of columns */ by?: string;
    /** Pipe-seperated list of grouping definition data */ def?: string;
    /** Filter definition */ filter?: FilterData[];
    /** Index of first group to return */ StartIndex?: number;
    /** Number of groups to return */ PageSize?: number;
    /** Includes count of items for each group */ withcount?: boolean;
    /** Unique target system type identifier */ namespace?: string;
}
export interface portal_owners_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shops_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_ParentITShopOrg) */ ParentKey?: string;
}
export declare class V2ApiClientMethodFactory {
    portal_application_get(options?: portal_application_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<ApplicationExtendedDataRead>>;
    portal_application_delete(/** Application */ UID_AOBApplication: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<ApplicationExtendedDataRead>>;
    portal_application_map_post(/** Unique application identifier */ UID_AOBApplication: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_application_identities_get(/** Unique application identifier */ uidapplication: string, options?: portal_application_identities_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_application_identitiesbyidentity_get(/** Unique application identifier */ uidapplication: string, /** Unique identity identifier */ uidperson: string, options?: portal_application_identitiesbyidentity_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_application_kpi_get(/** Unique application identifier */ uidapplication: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ChartDto[]>;
    portal_application_group_get(options?: portal_application_group_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfoData>;
    portal_application_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    portal_application_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    portal_application_interactive_entitlementstoadd_get(entityid: string, options?: portal_application_interactive_entitlementstoadd_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntitlementToAddData>;
    portal_application_interactive_byid_get(/** Primary key value UID_AOBApplication */ UID_AOBApplication: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    portal_application_interactive_UID_AERoleApprover_candidates_get(options?: portal_application_interactive_UID_AERoleApprover_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_application_interactive_UID_AERoleApprover_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: portal_application_interactive_UID_AERoleApprover_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_application_interactive_UID_AERoleOwner_candidates_get(options?: portal_application_interactive_UID_AERoleOwner_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_application_interactive_UID_AERoleOwner_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: portal_application_interactive_UID_AERoleOwner_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_application_new_post(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_application_new_UID_AccProductGroup_candidates_get(options?: portal_application_new_UID_AccProductGroup_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_application_new_UID_AccProductGroup_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_application_new_UID_AccProductGroup_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_application_new_UID_AERoleApprover_candidates_get(options?: portal_application_new_UID_AERoleApprover_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_application_new_UID_AERoleApprover_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_application_new_UID_AERoleApprover_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_application_new_UID_AERoleOwner_candidates_get(options?: portal_application_new_UID_AERoleOwner_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_application_new_UID_AERoleOwner_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_application_new_UID_AERoleOwner_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_application_sqlwizard_candidates_get(/** Name of the candidate table */ table: string, options?: portal_application_sqlwizard_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_application_sqlwizard_tables_columns_get(/** Name of the filtered database table */ table: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterPropertyList>;
    portal_applicationimage_get(/** Unique application identifier */ uidapplication: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<Blob>;
    portal_applicationimage_post(/** Unique application identifier */ uidapplication: string, inputParameterName: Blob, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    portal_applicationinshop_get(uidapplication: string, options?: portal_applicationinshop_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_applicationinshop_put(uidapplication: string, uidshop: string, inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_applicationinshop_delete(uidapplication: string, uidshop: string, inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_applicationusesaccount_get(UID_AOBApplication: string, options?: portal_applicationusesaccount_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_applicationusesaccount_delete(UID_AOBApplication: string, /** Application: user account assignment */ UID_AOBAppUsesAccount: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_applicationusesaccount_new_post(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AccProductParamCategory_get(options?: portal_candidates_AccProductParamCategory_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AccProductParamCategory_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_AccProductParamCategory_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_AERole_get(options?: portal_candidates_AERole_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AERole_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_AERole_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_AOBApplication_get(options?: portal_candidates_AOBApplication_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AOBApplication_datamodel_get(options?: portal_candidates_AOBApplication_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_candidates_AOBApplication_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_AOBApplication_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_Application_get(options?: portal_candidates_Application_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Application_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_Application_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_ESet_get(options?: portal_candidates_ESet_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_ESet_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_ESet_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_FunctionalArea_get(options?: portal_candidates_FunctionalArea_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_FunctionalArea_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_FunctionalArea_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_Org_get(options?: portal_candidates_Org_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Org_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_Org_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_Person_get(options?: portal_candidates_Person_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Person_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_Person_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERAssign_get(options?: portal_candidates_QERAssign_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERAssign_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_QERAssign_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERResource_get(options?: portal_candidates_QERResource_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERResource_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_QERResource_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERReuse_get(options?: portal_candidates_QERReuse_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERReuse_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_QERReuse_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERReuseUS_get(options?: portal_candidates_QERReuseUS_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERReuseUS_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_QERReuseUS_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERTermsOfUse_get(options?: portal_candidates_QERTermsOfUse_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERTermsOfUse_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_QERTermsOfUse_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_RPSReport_get(options?: portal_candidates_RPSReport_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_RPSReport_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_RPSReport_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_TSBAccountDef_get(options?: portal_candidates_TSBAccountDef_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_TSBAccountDef_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_TSBAccountDef_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_UNSAccountB_get(options?: portal_candidates_UNSAccountB_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_UNSAccountB_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_UNSAccountB_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_UNSGroup_get(options?: portal_candidates_UNSGroup_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_UNSGroup_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_UNSGroup_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_UNSRoot_get(options?: portal_candidates_UNSRoot_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_UNSRoot_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_UNSRoot_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_entitlement_get(options?: portal_entitlement_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_delete(/** Entitlement */ UID_AOBEntitlement: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_systemrole_get(/** Unique application identifier */ uidapplication: string, options?: portal_entitlement_systemrole_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_group_get(options?: portal_entitlement_group_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfoData>;
    portal_entitlement_interactive_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_entitlement_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_entitlement_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_entitlement_interactive_byid_get(/** Primary key value UID_AOBEntitlement */ UID_AOBEntitlement: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_entitlement_interactive_UID_AERoleOwner_candidates_get(options?: portal_entitlement_interactive_UID_AERoleOwner_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_interactive_UID_AERoleOwner_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: portal_entitlement_interactive_UID_AERoleOwner_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_entitlement_serviceitem_get(options?: portal_entitlement_serviceitem_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_entitlement_serviceitem_datamodel_get(options?: portal_entitlement_serviceitem_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_entitlement_serviceitem_UID_AccProductGroup_candidates_post(inputParameterName: EntityKeysData, options?: portal_entitlement_serviceitem_UID_AccProductGroup_candidates_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_serviceitem_UID_AccProductGroup_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_entitlement_serviceitem_UID_AccProductGroup_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_entitlement_serviceitem_UID_OrgAttestator_candidates_get(options?: portal_entitlement_serviceitem_UID_OrgAttestator_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_serviceitem_UID_OrgAttestator_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_entitlement_serviceitem_UID_OrgAttestator_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_entitlement_serviceitem_UID_OrgRuler_candidates_get(options?: portal_entitlement_serviceitem_UID_OrgRuler_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_serviceitem_UID_OrgRuler_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_entitlement_serviceitem_UID_OrgRuler_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_get(options?: portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_entitlement_systemrole_post(inputParameterName: EntitlementSystemRoleInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_entitlementcandidates_ESet_get(options?: portal_entitlementcandidates_ESet_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlementcandidates_ESet_datamodel_get(options?: portal_entitlementcandidates_ESet_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_entitlementcandidates_ESet_group_get(options?: portal_entitlementcandidates_ESet_group_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfoData>;
    portal_entitlementcandidates_QERResource_get(options?: portal_entitlementcandidates_QERResource_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlementcandidates_QERResource_datamodel_get(options?: portal_entitlementcandidates_QERResource_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_entitlementcandidates_QERResource_group_get(options?: portal_entitlementcandidates_QERResource_group_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfoData>;
    portal_entitlementcandidates_RPSReport_get(options?: portal_entitlementcandidates_RPSReport_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlementcandidates_RPSReport_datamodel_get(options?: portal_entitlementcandidates_RPSReport_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_entitlementcandidates_RPSReport_group_get(options?: portal_entitlementcandidates_RPSReport_group_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfoData>;
    portal_entitlementcandidates_TSBAccountDef_get(options?: portal_entitlementcandidates_TSBAccountDef_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlementcandidates_TSBAccountDef_datamodel_get(options?: portal_entitlementcandidates_TSBAccountDef_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_entitlementcandidates_TSBAccountDef_group_get(options?: portal_entitlementcandidates_TSBAccountDef_group_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfoData>;
    portal_entitlementcandidates_UNSGroup_get(options?: portal_entitlementcandidates_UNSGroup_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlementcandidates_UNSGroup_datamodel_get(options?: portal_entitlementcandidates_UNSGroup_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_entitlementcandidates_UNSGroup_filtertree_get(options?: portal_entitlementcandidates_UNSGroup_filtertree_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_entitlementcandidates_UNSGroup_group_get(options?: portal_entitlementcandidates_UNSGroup_group_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfoData>;
    portal_entitlementimage_get(/** Unique entitlement identifier */ uidentitlement: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<Blob>;
    portal_entitlementimage_post(/** Unique entitlement identifier */ uidentitlement: string, inputParameterName: Blob, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    portal_kpi_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ChartDto[]>;
    portal_owners_get(/** Object type of the entitlement */ tablename: string, /** UID of the entitlement */ uid: string, options?: portal_owners_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_publish_application_post(uidapplication: string, date: Date, inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    portal_shops_get(options?: portal_shops_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_application_get(options?: portal_application_get_args, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ApplicationExtendedDataRead>>;
    portal_application_delete(/** Application */ UID_AOBApplication: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ApplicationExtendedDataRead>>;
    /** Starts the entitlement mapping process for the specified application. */
    portal_application_map_post(/** Unique application identifier */ UID_AOBApplication: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns all identities having access to at least one entitlement of the application. */
    portal_application_identities_get(/** Unique application identifier */ uidapplication: string, options?: portal_application_identities_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns all entitlements that the specified identity has access to. */
    portal_application_identitiesbyidentity_get(/** Unique application identifier */ uidapplication: string, /** Unique identity identifier */ uidperson: string, options?: portal_application_identitiesbyidentity_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns application-specific KPI information. */
    portal_application_kpi_get(/** Unique application identifier */ uidapplication: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ChartDto[]>;
    portal_application_group_get(options?: portal_application_group_get_args, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    portal_application_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    portal_application_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    portal_application_interactive_entitlementstoadd_get(entityid: string, options?: portal_application_interactive_entitlementstoadd_get_args, requestOptions?: ApiRequestOptions): Promise<EntitlementToAddData>;
    portal_application_interactive_byid_get(/** Primary key value UID_AOBApplication */ UID_AOBApplication: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    /** Returns a list of objects that can be assigned to the property UID_AERoleApprover. */
    portal_application_interactive_UID_AERoleApprover_candidates_get(options?: portal_application_interactive_UID_AERoleApprover_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the application/interactive/UID_AERoleApprover/candidates endpoint. */
    portal_application_interactive_UID_AERoleApprover_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: portal_application_interactive_UID_AERoleApprover_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AERoleOwner. */
    portal_application_interactive_UID_AERoleOwner_candidates_get(options?: portal_application_interactive_UID_AERoleOwner_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the application/interactive/UID_AERoleOwner/candidates endpoint. */
    portal_application_interactive_UID_AERoleOwner_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: portal_application_interactive_UID_AERoleOwner_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_application_new_post(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_AccProductGroup. */
    portal_application_new_UID_AccProductGroup_candidates_get(options?: portal_application_new_UID_AccProductGroup_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the application/new/UID_AccProductGroup/candidates endpoint. */
    portal_application_new_UID_AccProductGroup_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_application_new_UID_AccProductGroup_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AERoleApprover. */
    portal_application_new_UID_AERoleApprover_candidates_get(options?: portal_application_new_UID_AERoleApprover_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the application/new/UID_AERoleApprover/candidates endpoint. */
    portal_application_new_UID_AERoleApprover_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_application_new_UID_AERoleApprover_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AERoleOwner. */
    portal_application_new_UID_AERoleOwner_candidates_get(options?: portal_application_new_UID_AERoleOwner_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the application/new/UID_AERoleOwner/candidates endpoint. */
    portal_application_new_UID_AERoleOwner_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_application_new_UID_AERoleOwner_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned as a filter parameter. */
    portal_application_sqlwizard_candidates_get(/** Name of the candidate table */ table: string, options?: portal_application_sqlwizard_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns the filterable properties for the specified table. */
    portal_application_sqlwizard_tables_columns_get(/** Name of the filtered database table */ table: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<FilterPropertyList>;
    portal_applicationimage_get(/** Unique application identifier */ uidapplication: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<Blob>;
    portal_applicationimage_post(/** Unique application identifier */ uidapplication: string, inputParameterName: Blob, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    portal_applicationinshop_get(uidapplication: string, options?: portal_applicationinshop_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Assigns an application to a shop. */
    portal_applicationinshop_put(uidapplication: string, uidshop: string, inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Removes an application from a shop. */
    portal_applicationinshop_delete(uidapplication: string, uidshop: string, inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns the list of accounts used by the specified application. */
    portal_applicationusesaccount_get(UID_AOBApplication: string, options?: portal_applicationusesaccount_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns the list of accounts used by the specified application. */
    portal_applicationusesaccount_delete(UID_AOBApplication: string, /** Application: user account assignment */ UID_AOBAppUsesAccount: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Defines that an application uses a specific account. */
    portal_applicationusesaccount_new_post(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of candidate objects from the table AccProductParamCategory. */
    portal_candidates_AccProductParamCategory_get(options?: portal_candidates_AccProductParamCategory_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/AccProductParamCategory endpoint. */
    portal_candidates_AccProductParamCategory_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_AccProductParamCategory_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table AERole. */
    portal_candidates_AERole_get(options?: portal_candidates_AERole_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/AERole endpoint. */
    portal_candidates_AERole_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_AERole_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table AOBApplication. */
    portal_candidates_AOBApplication_get(options?: portal_candidates_AOBApplication_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/AOBApplication endpoint. */
    portal_candidates_AOBApplication_datamodel_get(options?: portal_candidates_AOBApplication_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the candidates/AOBApplication endpoint. */
    portal_candidates_AOBApplication_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_AOBApplication_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table Application. */
    portal_candidates_Application_get(options?: portal_candidates_Application_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/Application endpoint. */
    portal_candidates_Application_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_Application_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table ESet. */
    portal_candidates_ESet_get(options?: portal_candidates_ESet_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/ESet endpoint. */
    portal_candidates_ESet_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_ESet_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table FunctionalArea. */
    portal_candidates_FunctionalArea_get(options?: portal_candidates_FunctionalArea_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/FunctionalArea endpoint. */
    portal_candidates_FunctionalArea_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_FunctionalArea_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table Org. */
    portal_candidates_Org_get(options?: portal_candidates_Org_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/Org endpoint. */
    portal_candidates_Org_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_Org_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table Person. */
    portal_candidates_Person_get(options?: portal_candidates_Person_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/Person endpoint. */
    portal_candidates_Person_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_Person_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERAssign. */
    portal_candidates_QERAssign_get(options?: portal_candidates_QERAssign_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/QERAssign endpoint. */
    portal_candidates_QERAssign_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_QERAssign_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERResource. */
    portal_candidates_QERResource_get(options?: portal_candidates_QERResource_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/QERResource endpoint. */
    portal_candidates_QERResource_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_QERResource_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERReuse. */
    portal_candidates_QERReuse_get(options?: portal_candidates_QERReuse_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/QERReuse endpoint. */
    portal_candidates_QERReuse_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_QERReuse_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERReuseUS. */
    portal_candidates_QERReuseUS_get(options?: portal_candidates_QERReuseUS_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/QERReuseUS endpoint. */
    portal_candidates_QERReuseUS_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_QERReuseUS_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERTermsOfUse. */
    portal_candidates_QERTermsOfUse_get(options?: portal_candidates_QERTermsOfUse_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/QERTermsOfUse endpoint. */
    portal_candidates_QERTermsOfUse_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_QERTermsOfUse_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table RPSReport. */
    portal_candidates_RPSReport_get(options?: portal_candidates_RPSReport_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/RPSReport endpoint. */
    portal_candidates_RPSReport_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_RPSReport_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table TSBAccountDef. */
    portal_candidates_TSBAccountDef_get(options?: portal_candidates_TSBAccountDef_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/TSBAccountDef endpoint. */
    portal_candidates_TSBAccountDef_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_TSBAccountDef_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table UNSAccountB. */
    portal_candidates_UNSAccountB_get(options?: portal_candidates_UNSAccountB_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/UNSAccountB endpoint. */
    portal_candidates_UNSAccountB_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_UNSAccountB_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table UNSGroup. */
    portal_candidates_UNSGroup_get(options?: portal_candidates_UNSGroup_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/UNSGroup endpoint. */
    portal_candidates_UNSGroup_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_UNSGroup_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table UNSRoot. */
    portal_candidates_UNSRoot_get(options?: portal_candidates_UNSRoot_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/UNSRoot endpoint. */
    portal_candidates_UNSRoot_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_UNSRoot_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_entitlement_get(options?: portal_entitlement_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_entitlement_delete(/** Entitlement */ UID_AOBEntitlement: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_entitlement_systemrole_get(/** Unique application identifier */ uidapplication: string, options?: portal_entitlement_systemrole_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_entitlement_group_get(options?: portal_entitlement_group_get_args, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    portal_entitlement_interactive_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_entitlement_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_entitlement_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_entitlement_interactive_byid_get(/** Primary key value UID_AOBEntitlement */ UID_AOBEntitlement: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    /** Returns a list of objects that can be assigned to the property UID_AERoleOwner. */
    portal_entitlement_interactive_UID_AERoleOwner_candidates_get(options?: portal_entitlement_interactive_UID_AERoleOwner_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the entitlement/interactive/UID_AERoleOwner/candidates endpoint. */
    portal_entitlement_interactive_UID_AERoleOwner_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: portal_entitlement_interactive_UID_AERoleOwner_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_entitlement_serviceitem_get(options?: portal_entitlement_serviceitem_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_entitlement_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_entitlement_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the entitlement/serviceitem endpoint. */
    portal_entitlement_serviceitem_datamodel_get(options?: portal_entitlement_serviceitem_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns a list of objects that can be assigned to the property UID_AccProductGroup. */
    portal_entitlement_serviceitem_UID_AccProductGroup_candidates_post(inputParameterName: EntityKeysData, options?: portal_entitlement_serviceitem_UID_AccProductGroup_candidates_post_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the entitlement/serviceitem/UID_AccProductGroup/candidates endpoint. */
    portal_entitlement_serviceitem_UID_AccProductGroup_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_entitlement_serviceitem_UID_AccProductGroup_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgAttestator. */
    portal_entitlement_serviceitem_UID_OrgAttestator_candidates_get(options?: portal_entitlement_serviceitem_UID_OrgAttestator_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the entitlement/serviceitem/UID_OrgAttestator/candidates endpoint. */
    portal_entitlement_serviceitem_UID_OrgAttestator_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_entitlement_serviceitem_UID_OrgAttestator_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgRuler. */
    portal_entitlement_serviceitem_UID_OrgRuler_candidates_get(options?: portal_entitlement_serviceitem_UID_OrgRuler_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the entitlement/serviceitem/UID_OrgRuler/candidates endpoint. */
    portal_entitlement_serviceitem_UID_OrgRuler_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_entitlement_serviceitem_UID_OrgRuler_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_PWODecisionMethod. */
    portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_get(options?: portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the entitlement/serviceitem/UID_PWODecisionMethod/candidates endpoint. */
    portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Adds entitlements to a new or existing system role, and adds the system role to the application. */
    portal_entitlement_systemrole_post(inputParameterName: EntitlementSystemRoleInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_entitlementcandidates_ESet_get(options?: portal_entitlementcandidates_ESet_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the entitlementcandidates/ESet endpoint. */
    portal_entitlementcandidates_ESet_datamodel_get(options?: portal_entitlementcandidates_ESet_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_entitlementcandidates_ESet_group_get(options?: portal_entitlementcandidates_ESet_group_get_args, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    portal_entitlementcandidates_QERResource_get(options?: portal_entitlementcandidates_QERResource_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the entitlementcandidates/QERResource endpoint. */
    portal_entitlementcandidates_QERResource_datamodel_get(options?: portal_entitlementcandidates_QERResource_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_entitlementcandidates_QERResource_group_get(options?: portal_entitlementcandidates_QERResource_group_get_args, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    portal_entitlementcandidates_RPSReport_get(options?: portal_entitlementcandidates_RPSReport_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the entitlementcandidates/RPSReport endpoint. */
    portal_entitlementcandidates_RPSReport_datamodel_get(options?: portal_entitlementcandidates_RPSReport_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_entitlementcandidates_RPSReport_group_get(options?: portal_entitlementcandidates_RPSReport_group_get_args, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    portal_entitlementcandidates_TSBAccountDef_get(options?: portal_entitlementcandidates_TSBAccountDef_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the entitlementcandidates/TSBAccountDef endpoint. */
    portal_entitlementcandidates_TSBAccountDef_datamodel_get(options?: portal_entitlementcandidates_TSBAccountDef_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_entitlementcandidates_TSBAccountDef_group_get(options?: portal_entitlementcandidates_TSBAccountDef_group_get_args, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    portal_entitlementcandidates_UNSGroup_get(options?: portal_entitlementcandidates_UNSGroup_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the entitlementcandidates/UNSGroup endpoint. */
    portal_entitlementcandidates_UNSGroup_datamodel_get(options?: portal_entitlementcandidates_UNSGroup_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the entitlementcandidates/UNSGroup endpoint. */
    portal_entitlementcandidates_UNSGroup_filtertree_get(options?: portal_entitlementcandidates_UNSGroup_filtertree_get_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_entitlementcandidates_UNSGroup_group_get(options?: portal_entitlementcandidates_UNSGroup_group_get_args, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    portal_entitlementimage_get(/** Unique entitlement identifier */ uidentitlement: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<Blob>;
    portal_entitlementimage_post(/** Unique entitlement identifier */ uidentitlement: string, inputParameterName: Blob, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    /** Returns global KPI information for application governance. */
    portal_kpi_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<ChartDto[]>;
    /** Returns owner information for the specified entitlement */
    portal_owners_get(/** Object type of the entitlement */ tablename: string, /** UID of the entitlement */ uid: string, options?: portal_owners_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_publish_application_post(uidapplication: string, date: Date, inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    portal_shops_get(options?: portal_shops_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
}
