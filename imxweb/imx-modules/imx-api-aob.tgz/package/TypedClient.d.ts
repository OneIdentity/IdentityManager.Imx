import { ApiClient, ApiRequestOptions, DataModel, EntityCollectionData, EntityData, EntitySchema, EntityWriteData, EntityWriteDataColumn, EntityWriteDataSingle, ExtendedEntityCollectionData, ExtendedEntityWriteData, FilterData, FilterPropertyList, FilterTreeData, FkProviderItem, GroupInfo, InteractiveEntityData, InteractiveEntityDeleteData, InteractiveEntityWriteData, IReadValue, IWriteValue, MethodDescriptor, SqlExpression, SqlWizardExpression, StaticSchema, TypedEntity, WriteExtTypedEntity } from 'imx-qbm-dbts';
export interface AccProductOwnershipInput {
    UidPerson?: string;
    CopyAllMembers: boolean;
}
export interface ApplicationExtendedDataRead {
    Translations?: ITranslationDataRead;
    SqlExpression?: SqlWizardRead;
}
export interface ApplicationExtendedDataWrite extends TranslationDataWrite {
    SqlExpression?: SqlWizardWrite;
}
export interface ChartData {
    ObjectKey?: string;
    Name?: string;
    ObjectDisplay?: string;
    Points?: ChartDataPoint[];
}
export interface ChartDataPoint {
    Percentage: number;
    Value: number;
    ValueZ: number;
    Date: Date;
}
export interface ChartDto {
    NegateThresholds: boolean;
    AggregateFunction: StatisticAggregateFunction;
    AggregateFunctionTotal: StatisticAggregateFunction;
    ErrorThreshold: number;
    WarningThreshold: number;
    TimeScaleUnit: StatisticTimeScaleUnit;
    Unit?: string;
    Name?: string;
    Display?: string;
    Description?: string;
    Data?: ChartData[];
}
export interface EntitlementData {
    IsAssignedToMe: boolean;
    IsAssignedToOther: boolean;
    DisplayName?: string;
    CanonicalName?: string;
    UID_AOBApplicationConflicted?: string;
    DisplayApplicationConflicted?: string;
}
export interface EntitlementSystemRoleInput {
    UidApplication?: string;
    ObjectKeyEntitlements?: string[];
    UidEset?: string;
    NameNewEset?: string;
}
export interface EntitlementToAddData {
    Data?: EntitlementData[];
}
export interface EntityWriteDataBulk {
    Keys?: string[][];
    Data?: EntityWriteDataColumn[];
}
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface ExtendedEntityCollectionDataOfApplicationExtendedDataRead extends EntityCollectionData {
    ExtendedData?: ApplicationExtendedDataRead;
}
export interface ExtendedEntityWriteDataOfAccProductOwnershipInput extends EntityWriteData {
    ExtendedData?: AccProductOwnershipInput;
}
export interface ExtendedInteractiveEntityDataOfApplicationExtendedDataRead extends InteractiveEntityData {
    ExtendedData?: ApplicationExtendedDataRead;
}
export interface ExtendedInteractiveEntityWriteDataOfApplicationExtendedDataWrite extends InteractiveEntityWriteData {
    ExtendedData?: ApplicationExtendedDataWrite;
}
export interface ITranslationDataRead {
    ColumnNames: any[];
    Translations: any[];
}
export interface SqlWizardRead {
    Expressions?: SqlWizardExpression[];
}
export interface SqlWizardWrite {
    Filters?: SqlExpression[];
}
export declare enum StatisticAggregateFunction {
    None = 0,
    Sum = 1,
    Average = 2
}
export declare enum StatisticTimeScaleUnit {
    Undefined = 0,
    Hour = 1,
    Day = 2,
    Week = 3,
    Month = 4,
    Quarter = 5,
    Year = 6
}
export interface TranslationDataWrite {
    Translations?: TranslationDataWriteElement[];
}
export interface TranslationDataWriteElement {
    TranslationKey?: string;
    ColumnName?: string;
    TranslationValue?: string;
    UidCulture?: string;
}
export declare class TypedClient {
    readonly PortalApplication: PortalApplicationWrapper;
    readonly PortalApplicationIdentities: PortalApplicationIdentitiesWrapper;
    readonly PortalApplicationIdentitiesbyidentity: PortalApplicationIdentitiesbyidentityWrapper;
    readonly PortalApplicationinshop: PortalApplicationinshopWrapper;
    readonly PortalApplicationInteractive: PortalApplicationInteractiveWrapper;
    readonly PortalApplicationNew: PortalApplicationNewWrapper;
    readonly PortalApplicationSqlwizardCandidates: PortalApplicationSqlwizardCandidatesWrapper;
    readonly PortalApplicationusesaccount: PortalApplicationusesaccountWrapper;
    readonly PortalApplicationusesaccountNew: PortalApplicationusesaccountNewWrapper;
    readonly PortalCandidatesAccproductgroup: PortalCandidatesAccproductgroupWrapper;
    readonly PortalCandidatesAccproductparamcategory: PortalCandidatesAccproductparamcategoryWrapper;
    readonly PortalCandidatesAerole: PortalCandidatesAeroleWrapper;
    readonly PortalCandidatesAobapplication: PortalCandidatesAobapplicationWrapper;
    readonly PortalCandidatesApplication: PortalCandidatesApplicationWrapper;
    readonly PortalCandidatesEset: PortalCandidatesEsetWrapper;
    readonly PortalCandidatesFunctionalarea: PortalCandidatesFunctionalareaWrapper;
    readonly PortalCandidatesOrg: PortalCandidatesOrgWrapper;
    readonly PortalCandidatesPerson: PortalCandidatesPersonWrapper;
    readonly PortalCandidatesQerassign: PortalCandidatesQerassignWrapper;
    readonly PortalCandidatesQerresource: PortalCandidatesQerresourceWrapper;
    readonly PortalCandidatesQerreuse: PortalCandidatesQerreuseWrapper;
    readonly PortalCandidatesQerreuseus: PortalCandidatesQerreuseusWrapper;
    readonly PortalCandidatesQertermsofuse: PortalCandidatesQertermsofuseWrapper;
    readonly PortalCandidatesRpsreport: PortalCandidatesRpsreportWrapper;
    readonly PortalCandidatesTsbaccountdef: PortalCandidatesTsbaccountdefWrapper;
    readonly PortalCandidatesUnsaccountb: PortalCandidatesUnsaccountbWrapper;
    readonly PortalCandidatesUnsgroup: PortalCandidatesUnsgroupWrapper;
    readonly PortalCandidatesUnsroot: PortalCandidatesUnsrootWrapper;
    readonly PortalEntitlement: PortalEntitlementWrapper;
    readonly PortalEntitlementcandidatesEset: PortalEntitlementcandidatesEsetWrapper;
    readonly PortalEntitlementcandidatesQerresource: PortalEntitlementcandidatesQerresourceWrapper;
    readonly PortalEntitlementcandidatesRpsreport: PortalEntitlementcandidatesRpsreportWrapper;
    readonly PortalEntitlementcandidatesTsbaccountdef: PortalEntitlementcandidatesTsbaccountdefWrapper;
    readonly PortalEntitlementcandidatesUnsgroup: PortalEntitlementcandidatesUnsgroupWrapper;
    readonly PortalEntitlementInteractive: PortalEntitlementInteractiveWrapper;
    readonly PortalEntitlementServiceitem: PortalEntitlementServiceitemWrapper;
    readonly PortalEntitlementSystemrole: PortalEntitlementSystemroleWrapper;
    readonly PortalOwners: PortalOwnersWrapper;
    readonly PortalShops: PortalShopsWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalApplication extends WriteExtTypedEntity<ApplicationExtendedDataWrite> {
    readonly ActivationDate: IWriteValue<Date>;
    readonly ApplicationEnvironment: IWriteValue<string>;
    readonly ApplicationWebURL: IWriteValue<string>;
    readonly AuthenticationRoot: IReadValue<string>;
    readonly Description: IWriteValue<string>;
    readonly Ident_AOBApplication: IWriteValue<string>;
    readonly IsAuthenticationIntegrated: IWriteValue<boolean>;
    readonly IsFederationEnabled: IWriteValue<boolean>;
    readonly IsInActive: IWriteValue<boolean>;
    readonly IsMultiFactorEnabled: IWriteValue<boolean>;
    readonly IsSSOEnabled: IWriteValue<boolean>;
    readonly JPegPhoto: IWriteValue<string>;
    readonly NextRunDate: IWriteValue<Date>;
    readonly PurchasedLicenses: IWriteValue<number>;
    readonly RiskIndex: IWriteValue<number>;
    readonly SSORedirectionUrl: IWriteValue<string>;
    readonly UID_AERoleApprover: IWriteValue<string>;
    readonly UID_AERoleOwner: IWriteValue<string>;
    readonly UID_AOBApplication: IReadValue<string>;
    readonly UID_FunctionalArea: IWriteValue<string>;
    readonly UID_ITShopSrcBT: IReadValue<string>;
    readonly UID_PersonHead: IWriteValue<string>;
    readonly WhereClause: IReadValue<string>;
    readonly WhereClauseAddOn: IReadValue<string>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XDateUpdated: IReadValue<Date>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XObjectKey: IReadValue<string>;
    readonly XTouched: IReadValue<string>;
    readonly XUserInserted: IReadValue<string>;
    readonly XUserUpdated: IReadValue<string>;
    readonly HasKpiIssues: IReadValue<boolean>;
    readonly UID_AccProductGroup: IReadValue<string>;
    readonly AuthenticationRootHelper: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'ActivationDate' | 'ApplicationEnvironment' | 'ApplicationWebURL' | 'AuthenticationRoot' | 'Description' | 'Ident_AOBApplication' | 'IsAuthenticationIntegrated' | 'IsFederationEnabled' | 'IsInActive' | 'IsMultiFactorEnabled' | 'IsSSOEnabled' | 'JPegPhoto' | 'NextRunDate' | 'PurchasedLicenses' | 'RiskIndex' | 'SSORedirectionUrl' | 'UID_AERoleApprover' | 'UID_AERoleOwner' | 'UID_AOBApplication' | 'UID_FunctionalArea' | 'UID_ITShopSrcBT' | 'UID_PersonHead' | 'WhereClause' | 'WhereClauseAddOn' | 'XDateInserted' | 'XDateUpdated' | 'XMarkedForDeletion' | 'XObjectKey' | 'XTouched' | 'XUserInserted' | 'XUserUpdated' | 'HasKpiIssues' | 'UID_AccProductGroup' | 'AuthenticationRootHelper'>;
}
export declare class PortalApplicationIdentities extends TypedEntity {
    readonly DefaultEmailAddress: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'DefaultEmailAddress'>;
}
export declare class PortalApplicationIdentitiesbyidentity extends TypedEntity {
    readonly ObjectKeyElement: IReadValue<string>;
    readonly UID_PersonWantsOrg: IReadValue<string>;
    readonly OrderState: IReadValue<string>;
    readonly IsRequestCancellable: IReadValue<boolean>;
    readonly ValidUntil: IReadValue<Date>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'ObjectKeyElement' | 'UID_PersonWantsOrg' | 'OrderState' | 'IsRequestCancellable' | 'ValidUntil'>;
}
export declare class PortalApplicationinshop extends TypedEntity {
    readonly UID_ITShopOrg: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_ITShopOrg'>;
}
export declare class PortalApplicationInteractive extends WriteExtTypedEntity<ApplicationExtendedDataWrite> {
    readonly ActivationDate: IWriteValue<Date>;
    readonly ApplicationEnvironment: IWriteValue<string>;
    readonly ApplicationWebURL: IWriteValue<string>;
    readonly AuthenticationRoot: IReadValue<string>;
    readonly Description: IWriteValue<string>;
    readonly Ident_AOBApplication: IWriteValue<string>;
    readonly IsAuthenticationIntegrated: IWriteValue<boolean>;
    readonly IsFederationEnabled: IWriteValue<boolean>;
    readonly IsInActive: IWriteValue<boolean>;
    readonly IsMultiFactorEnabled: IWriteValue<boolean>;
    readonly IsSSOEnabled: IWriteValue<boolean>;
    readonly JPegPhoto: IWriteValue<string>;
    readonly NextRunDate: IWriteValue<Date>;
    readonly PurchasedLicenses: IWriteValue<number>;
    readonly RiskIndex: IWriteValue<number>;
    readonly SSORedirectionUrl: IWriteValue<string>;
    readonly UID_AERoleApprover: IWriteValue<string>;
    readonly UID_AERoleOwner: IWriteValue<string>;
    readonly UID_AOBApplication: IReadValue<string>;
    readonly UID_FunctionalArea: IWriteValue<string>;
    readonly UID_ITShopSrcBT: IReadValue<string>;
    readonly UID_PersonHead: IWriteValue<string>;
    readonly WhereClause: IReadValue<string>;
    readonly WhereClauseAddOn: IReadValue<string>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XDateUpdated: IReadValue<Date>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XObjectKey: IReadValue<string>;
    readonly XTouched: IReadValue<string>;
    readonly XUserInserted: IReadValue<string>;
    readonly XUserUpdated: IReadValue<string>;
    readonly HasKpiIssues: IReadValue<boolean>;
    readonly UID_AccProductGroup: IReadValue<string>;
    readonly AuthenticationRootHelper: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'ActivationDate' | 'ApplicationEnvironment' | 'ApplicationWebURL' | 'AuthenticationRoot' | 'Description' | 'Ident_AOBApplication' | 'IsAuthenticationIntegrated' | 'IsFederationEnabled' | 'IsInActive' | 'IsMultiFactorEnabled' | 'IsSSOEnabled' | 'JPegPhoto' | 'NextRunDate' | 'PurchasedLicenses' | 'RiskIndex' | 'SSORedirectionUrl' | 'UID_AERoleApprover' | 'UID_AERoleOwner' | 'UID_AOBApplication' | 'UID_FunctionalArea' | 'UID_ITShopSrcBT' | 'UID_PersonHead' | 'WhereClause' | 'WhereClauseAddOn' | 'XDateInserted' | 'XDateUpdated' | 'XMarkedForDeletion' | 'XObjectKey' | 'XTouched' | 'XUserInserted' | 'XUserUpdated' | 'HasKpiIssues' | 'UID_AccProductGroup' | 'AuthenticationRootHelper'>;
}
export declare class PortalApplicationNew extends TypedEntity {
    readonly ActivationDate: IWriteValue<Date>;
    readonly ApplicationEnvironment: IWriteValue<string>;
    readonly ApplicationWebURL: IWriteValue<string>;
    readonly AuthenticationRoot: IReadValue<string>;
    readonly Description: IWriteValue<string>;
    readonly Ident_AOBApplication: IWriteValue<string>;
    readonly IsAuthenticationIntegrated: IWriteValue<boolean>;
    readonly IsFederationEnabled: IWriteValue<boolean>;
    readonly IsInActive: IWriteValue<boolean>;
    readonly IsMultiFactorEnabled: IWriteValue<boolean>;
    readonly IsSSOEnabled: IWriteValue<boolean>;
    readonly JPegPhoto: IWriteValue<string>;
    readonly NextRunDate: IWriteValue<Date>;
    readonly PurchasedLicenses: IWriteValue<number>;
    readonly RiskIndex: IWriteValue<number>;
    readonly SSORedirectionUrl: IWriteValue<string>;
    readonly UID_AERoleApprover: IWriteValue<string>;
    readonly UID_AERoleOwner: IWriteValue<string>;
    readonly UID_AOBApplication: IReadValue<string>;
    readonly UID_FunctionalArea: IWriteValue<string>;
    readonly UID_ITShopSrcBT: IReadValue<string>;
    readonly UID_PersonHead: IWriteValue<string>;
    readonly WhereClause: IReadValue<string>;
    readonly WhereClauseAddOn: IReadValue<string>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XDateUpdated: IReadValue<Date>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XObjectKey: IReadValue<string>;
    readonly XTouched: IReadValue<string>;
    readonly XUserInserted: IReadValue<string>;
    readonly XUserUpdated: IReadValue<string>;
    readonly UID_AccProductGroup: IWriteValue<string>;
    readonly AuthenticationRootHelper: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'ActivationDate' | 'ApplicationEnvironment' | 'ApplicationWebURL' | 'AuthenticationRoot' | 'Description' | 'Ident_AOBApplication' | 'IsAuthenticationIntegrated' | 'IsFederationEnabled' | 'IsInActive' | 'IsMultiFactorEnabled' | 'IsSSOEnabled' | 'JPegPhoto' | 'NextRunDate' | 'PurchasedLicenses' | 'RiskIndex' | 'SSORedirectionUrl' | 'UID_AERoleApprover' | 'UID_AERoleOwner' | 'UID_AOBApplication' | 'UID_FunctionalArea' | 'UID_ITShopSrcBT' | 'UID_PersonHead' | 'WhereClause' | 'WhereClauseAddOn' | 'XDateInserted' | 'XDateUpdated' | 'XMarkedForDeletion' | 'XObjectKey' | 'XTouched' | 'XUserInserted' | 'XUserUpdated' | 'UID_AccProductGroup' | 'AuthenticationRootHelper'>;
}
export declare class PortalApplicationSqlwizardCandidates extends TypedEntity {
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<never>;
}
export declare class PortalApplicationusesaccount extends TypedEntity {
    readonly UID_AOBApplication: IReadValue<string>;
    readonly UID_AOBAppUsesAccount: IReadValue<string>;
    readonly ObjectKeyAccount: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_AOBApplication' | 'UID_AOBAppUsesAccount' | 'ObjectKeyAccount'>;
}
export declare class PortalApplicationusesaccountNew extends TypedEntity {
    readonly ObjectKeyAccount: IWriteValue<string>;
    readonly UID_AOBApplication: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'ObjectKeyAccount' | 'UID_AOBApplication'>;
}
export declare class PortalCandidatesAccproductgroup extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_AccProductGroup: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_AccProductGroup'>;
}
export declare class PortalCandidatesAccproductparamcategory extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_AccProductParamCategory: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_AccProductParamCategory'>;
}
export declare class PortalCandidatesAerole extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_AERole: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_AERole'>;
}
export declare class PortalCandidatesAobapplication extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_AOBApplication: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_AOBApplication'>;
}
export declare class PortalCandidatesApplication extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_Application: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_Application'>;
}
export declare class PortalCandidatesEset extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_ESet: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_ESet'>;
}
export declare class PortalCandidatesFunctionalarea extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_FunctionalArea: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_FunctionalArea'>;
}
export declare class PortalCandidatesOrg extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_Org: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_Org'>;
}
export declare class PortalCandidatesPerson extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_Person: IReadValue<string>;
    readonly DefaultEmailAddress: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_Person' | 'DefaultEmailAddress'>;
}
export declare class PortalCandidatesQerassign extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_QERAssign: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_QERAssign'>;
}
export declare class PortalCandidatesQerresource extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_QERResource: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_QERResource'>;
}
export declare class PortalCandidatesQerreuse extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_QERReuse: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_QERReuse'>;
}
export declare class PortalCandidatesQerreuseus extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_QERReuseUS: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_QERReuseUS'>;
}
export declare class PortalCandidatesQertermsofuse extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_QERTermsOfUse: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_QERTermsOfUse'>;
}
export declare class PortalCandidatesRpsreport extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_RPSReport: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_RPSReport'>;
}
export declare class PortalCandidatesTsbaccountdef extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_TSBAccountDef: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_TSBAccountDef'>;
}
export declare class PortalCandidatesUnsaccountb extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_UNSAccountB: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_UNSAccountB'>;
}
export declare class PortalCandidatesUnsgroup extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_UNSGroup: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_UNSGroup'>;
}
export declare class PortalCandidatesUnsroot extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_UNSRoot: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_UNSRoot'>;
}
export declare class PortalEntitlement extends TypedEntity {
    readonly ActivationDate: IWriteValue<Date>;
    readonly Description: IWriteValue<string>;
    readonly Ident_AOBEntitlement: IWriteValue<string>;
    readonly IsDynamic: IReadValue<boolean>;
    readonly IsInActive: IWriteValue<boolean>;
    readonly JPegPhoto: IReadValue<string>;
    readonly ObjectKeyAdditionalApprover: IWriteValue<string>;
    readonly ObjectKeyElement: IWriteValue<string>;
    readonly UID_AERoleOwner: IWriteValue<string>;
    readonly UID_AOBApplication: IWriteValue<string>;
    readonly UID_AOBEntitlement: IReadValue<string>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XDateUpdated: IReadValue<Date>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XObjectKey: IReadValue<string>;
    readonly XTouched: IReadValue<string>;
    readonly XUserInserted: IReadValue<string>;
    readonly XUserUpdated: IReadValue<string>;
    readonly UID_AccProduct: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'ActivationDate' | 'Description' | 'Ident_AOBEntitlement' | 'IsDynamic' | 'IsInActive' | 'JPegPhoto' | 'ObjectKeyAdditionalApprover' | 'ObjectKeyElement' | 'UID_AERoleOwner' | 'UID_AOBApplication' | 'UID_AOBEntitlement' | 'XDateInserted' | 'XDateUpdated' | 'XMarkedForDeletion' | 'XObjectKey' | 'XTouched' | 'XUserInserted' | 'XUserUpdated' | 'UID_AccProduct'>;
}
export declare class PortalEntitlementcandidatesEset extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey'>;
}
export declare class PortalEntitlementcandidatesQerresource extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey'>;
}
export declare class PortalEntitlementcandidatesRpsreport extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey'>;
}
export declare class PortalEntitlementcandidatesTsbaccountdef extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey'>;
}
export declare class PortalEntitlementcandidatesUnsgroup extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly CanonicalName: IReadValue<string>;
    readonly Description: IReadValue<string>;
    readonly UID_UNSRoot: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'CanonicalName' | 'Description' | 'UID_UNSRoot'>;
}
export declare class PortalEntitlementInteractive extends TypedEntity {
    readonly ActivationDate: IWriteValue<Date>;
    readonly Description: IWriteValue<string>;
    readonly Ident_AOBEntitlement: IWriteValue<string>;
    readonly IsDynamic: IReadValue<boolean>;
    readonly IsInActive: IWriteValue<boolean>;
    readonly JPegPhoto: IReadValue<string>;
    readonly ObjectKeyAdditionalApprover: IWriteValue<string>;
    readonly ObjectKeyElement: IWriteValue<string>;
    readonly UID_AERoleOwner: IWriteValue<string>;
    readonly UID_AOBApplication: IWriteValue<string>;
    readonly UID_AOBEntitlement: IReadValue<string>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XDateUpdated: IReadValue<Date>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XObjectKey: IReadValue<string>;
    readonly XTouched: IReadValue<string>;
    readonly XUserInserted: IReadValue<string>;
    readonly XUserUpdated: IReadValue<string>;
    readonly UID_AccProduct: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'ActivationDate' | 'Description' | 'Ident_AOBEntitlement' | 'IsDynamic' | 'IsInActive' | 'JPegPhoto' | 'ObjectKeyAdditionalApprover' | 'ObjectKeyElement' | 'UID_AERoleOwner' | 'UID_AOBApplication' | 'UID_AOBEntitlement' | 'XDateInserted' | 'XDateUpdated' | 'XMarkedForDeletion' | 'XObjectKey' | 'XTouched' | 'XUserInserted' | 'XUserUpdated' | 'UID_AccProduct'>;
}
export declare class PortalEntitlementServiceitem extends WriteExtTypedEntity<AccProductOwnershipInput> {
    readonly Description: IWriteValue<string>;
    readonly Ident_AccProduct: IWriteValue<string>;
    readonly IsApproveRequiresMfa: IWriteValue<boolean>;
    readonly IsInActive: IWriteValue<boolean>;
    readonly JPegPhoto: IWriteValue<string>;
    readonly MaxValidDays: IWriteValue<number>;
    readonly ProductURL: IWriteValue<string>;
    readonly SortOrder: IWriteValue<string>;
    readonly UID_AccProductGroup: IWriteValue<string>;
    readonly UID_AccProductParamCategory: IWriteValue<string>;
    readonly UID_FunctionalArea: IWriteValue<string>;
    readonly UID_OrgAttestator: IWriteValue<string>;
    readonly UID_OrgRuler: IWriteValue<string>;
    readonly UID_PWODecisionMethod: IWriteValue<string>;
    readonly UID_QERTermsOfUse: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Description' | 'Ident_AccProduct' | 'IsApproveRequiresMfa' | 'IsInActive' | 'JPegPhoto' | 'MaxValidDays' | 'ProductURL' | 'SortOrder' | 'UID_AccProductGroup' | 'UID_AccProductParamCategory' | 'UID_FunctionalArea' | 'UID_OrgAttestator' | 'UID_OrgRuler' | 'UID_PWODecisionMethod' | 'UID_QERTermsOfUse'>;
}
export declare class PortalEntitlementSystemrole extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey'>;
}
export declare class PortalOwners extends TypedEntity {
    readonly DefaultEmailAddress: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'DefaultEmailAddress'>;
}
export declare class PortalShops extends TypedEntity {
    readonly UID_ITShopOrg: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_ITShopOrg'>;
}
export declare class PortalApplicationWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        filterkpi?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplication, ApplicationExtendedDataRead>>;
    Delete(UID_AOBApplication: string, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplication, ApplicationExtendedDataRead>>;
}
export declare class PortalApplicationIdentitiesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidapplication: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplicationIdentities, unknown>>;
}
export declare class PortalApplicationIdentitiesbyidentityWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Getbyidentity(uidapplication: string, uidperson: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplicationIdentitiesbyidentity, unknown>>;
}
export declare class PortalApplicationinshopWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidapplication: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplicationinshop, unknown>>;
}
export declare class PortalApplicationInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalApplicationInteractive, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplicationInteractive, ApplicationExtendedDataRead>>;
    Delete(inputParameterName: PortalApplicationInteractive, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplicationInteractive, ApplicationExtendedDataRead>>;
    Get_byid(UID_AOBApplication: string, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplicationInteractive, ApplicationExtendedDataRead>>;
}
export declare class PortalApplicationNewWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalApplicationNew;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Post(inputParameterName: PortalApplicationNew, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplicationNew, unknown>>;
}
export declare class PortalApplicationSqlwizardCandidatesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(table: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplicationSqlwizardCandidates, unknown>>;
}
export declare class PortalApplicationusesaccountWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_AOBApplication: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplicationusesaccount, unknown>>;
    Delete(UID_AOBApplication: string, UID_AOBAppUsesAccount: string, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplicationusesaccount, unknown>>;
}
export declare class PortalApplicationusesaccountNewWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalApplicationusesaccountNew;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Post(inputParameterName: PortalApplicationusesaccountNew, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalApplicationusesaccountNew, unknown>>;
}
export declare class PortalCandidatesAccproductgroupWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesAccproductgroup, unknown>>;
}
export declare class PortalCandidatesAccproductparamcategoryWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesAccproductparamcategory, unknown>>;
}
export declare class PortalCandidatesAeroleWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesAerole, unknown>>;
}
export declare class PortalCandidatesAobapplicationWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesAobapplication, unknown>>;
}
export declare class PortalCandidatesApplicationWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesApplication, unknown>>;
}
export declare class PortalCandidatesEsetWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesEset, unknown>>;
}
export declare class PortalCandidatesFunctionalareaWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesFunctionalarea, unknown>>;
}
export declare class PortalCandidatesOrgWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesOrg, unknown>>;
}
export declare class PortalCandidatesPersonWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesPerson, unknown>>;
}
export declare class PortalCandidatesQerassignWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesQerassign, unknown>>;
}
export declare class PortalCandidatesQerresourceWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesQerresource, unknown>>;
}
export declare class PortalCandidatesQerreuseWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesQerreuse, unknown>>;
}
export declare class PortalCandidatesQerreuseusWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesQerreuseus, unknown>>;
}
export declare class PortalCandidatesQertermsofuseWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesQertermsofuse, unknown>>;
}
export declare class PortalCandidatesRpsreportWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesRpsreport, unknown>>;
}
export declare class PortalCandidatesTsbaccountdefWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesTsbaccountdef, unknown>>;
}
export declare class PortalCandidatesUnsaccountbWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesUnsaccountb, unknown>>;
}
export declare class PortalCandidatesUnsgroupWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesUnsgroup, unknown>>;
}
export declare class PortalCandidatesUnsrootWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesUnsroot, unknown>>;
}
export declare class PortalEntitlementWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlement, unknown>>;
    Delete(UID_AOBEntitlement: string, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlement, unknown>>;
}
export declare class PortalEntitlementcandidatesEsetWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlementcandidatesEset, unknown>>;
}
export declare class PortalEntitlementcandidatesQerresourceWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlementcandidatesQerresource, unknown>>;
}
export declare class PortalEntitlementcandidatesRpsreportWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlementcandidatesRpsreport, unknown>>;
}
export declare class PortalEntitlementcandidatesTsbaccountdefWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlementcandidatesTsbaccountdef, unknown>>;
}
export declare class PortalEntitlementcandidatesUnsgroupWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        namespace?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlementcandidatesUnsgroup, unknown>>;
}
export declare class PortalEntitlementInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalEntitlementInteractive, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlementInteractive, unknown>>;
    Delete(inputParameterName: PortalEntitlementInteractive, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlementInteractive, unknown>>;
    Get_byid(UID_AOBEntitlement: string, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlementInteractive, unknown>>;
    Get(requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlementInteractive, unknown>>;
}
export declare class PortalEntitlementServiceitemWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        uid_aobentitlement?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlementServiceitem, unknown>>;
    Put(inputParameterName: PortalEntitlementServiceitem, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlementServiceitem, unknown>>;
}
export declare class PortalEntitlementSystemroleWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidapplication: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalEntitlementSystemrole, unknown>>;
}
export declare class PortalOwnersWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(tablename: string, uid: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalOwners, unknown>>;
}
export declare class PortalShopsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShops, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    portal_application_get(filterkpi: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<ExtendedEntityCollectionData<ApplicationExtendedDataRead>>;
    portal_application_delete(UID_AOBApplication: string): MethodDescriptor<ExtendedEntityCollectionData<ApplicationExtendedDataRead>>;
    portal_application_map_post(UID_AOBApplication: string): MethodDescriptor<void>;
    portal_application_identities_get(uidapplication: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_application_identitiesbyidentity_get(uidapplication: string, uidperson: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_application_kpi_get(uidapplication: string): MethodDescriptor<ChartDto[]>;
    portal_application_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean): MethodDescriptor<GroupInfo[]>;
    portal_application_interactive_put(inputParameterName: any): MethodDescriptor<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    portal_application_interactive_delete(inputParameterName: InteractiveEntityDeleteData): MethodDescriptor<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    portal_application_interactive_entitlementstoadd_get(entityid: string, keys: string[], state: string): MethodDescriptor<EntitlementToAddData>;
    portal_application_interactive_byid_get(UID_AOBApplication: string): MethodDescriptor<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    portal_application_interactive_UID_AERoleApprover_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_application_interactive_UID_AERoleApprover_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_application_interactive_UID_AERoleOwner_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_application_interactive_UID_AERoleOwner_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_application_new_post(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_application_new_UID_AccProductGroup_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_application_new_UID_AccProductGroup_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_application_new_UID_AERoleApprover_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_application_new_UID_AERoleApprover_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_application_new_UID_AERoleOwner_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_application_new_UID_AERoleOwner_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_application_sqlwizard_candidates_get(table: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_application_sqlwizard_tables_columns_get(table: string): MethodDescriptor<FilterPropertyList>;
    portal_applicationimage_get(uidapplication: string): MethodDescriptor<Blob>;
    portal_applicationimage_post(uidapplication: string, inputParameterName: Blob): MethodDescriptor<any>;
    portal_applicationinshop_get(uidapplication: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_applicationinshop_put(uidapplication: string, uidshop: string, inputParameterName: any): MethodDescriptor<void>;
    portal_applicationinshop_delete(uidapplication: string, uidshop: string, inputParameterName: any): MethodDescriptor<void>;
    portal_applicationusesaccount_get(UID_AOBApplication: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_applicationusesaccount_delete(UID_AOBApplication: string, UID_AOBAppUsesAccount: string): MethodDescriptor<EntityCollectionData>;
    portal_applicationusesaccount_new_post(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AccProductGroup_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AccProductGroup_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_AccProductParamCategory_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AccProductParamCategory_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_AERole_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AERole_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_AOBApplication_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AOBApplication_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_AOBApplication_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_Application_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Application_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_ESet_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_ESet_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_FunctionalArea_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_FunctionalArea_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_Org_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Org_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_Person_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Person_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERAssign_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERAssign_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERResource_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERResource_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERReuse_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERReuse_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERReuseUS_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERReuseUS_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERTermsOfUse_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERTermsOfUse_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_RPSReport_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_RPSReport_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_TSBAccountDef_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_TSBAccountDef_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_UNSAccountB_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_UNSAccountB_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_UNSGroup_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_UNSGroup_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_UNSRoot_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_UNSRoot_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_entitlement_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_delete(UID_AOBEntitlement: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_systemrole_get(uidapplication: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean): MethodDescriptor<GroupInfo[]>;
    portal_entitlement_interactive_get(): MethodDescriptor<InteractiveEntityData>;
    portal_entitlement_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_entitlement_interactive_delete(inputParameterName: InteractiveEntityDeleteData): MethodDescriptor<InteractiveEntityData>;
    portal_entitlement_interactive_byid_get(UID_AOBEntitlement: string): MethodDescriptor<InteractiveEntityData>;
    portal_entitlement_interactive_UID_AERoleOwner_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_interactive_UID_AERoleOwner_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_entitlement_serviceitem_get(uid_aobentitlement: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_entitlement_serviceitem_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_entitlement_serviceitem_UID_OrgAttestator_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_serviceitem_UID_OrgAttestator_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_entitlement_serviceitem_UID_OrgRuler_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_serviceitem_UID_OrgRuler_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_entitlement_systemrole_post(inputParameterName: EntitlementSystemRoleInput): MethodDescriptor<void>;
    portal_entitlementcandidates_ESet_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlementcandidates_ESet_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_entitlementcandidates_ESet_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean): MethodDescriptor<GroupInfo[]>;
    portal_entitlementcandidates_QERResource_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlementcandidates_QERResource_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_entitlementcandidates_QERResource_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean): MethodDescriptor<GroupInfo[]>;
    portal_entitlementcandidates_RPSReport_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlementcandidates_RPSReport_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_entitlementcandidates_RPSReport_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean): MethodDescriptor<GroupInfo[]>;
    portal_entitlementcandidates_TSBAccountDef_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlementcandidates_TSBAccountDef_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_entitlementcandidates_TSBAccountDef_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean): MethodDescriptor<GroupInfo[]>;
    portal_entitlementcandidates_UNSGroup_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, namespace: string): MethodDescriptor<EntityCollectionData>;
    portal_entitlementcandidates_UNSGroup_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_entitlementcandidates_UNSGroup_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, namespace: string): MethodDescriptor<GroupInfo[]>;
    portal_entitlementimage_get(uidentitlement: string): MethodDescriptor<Blob>;
    portal_entitlementimage_post(uidentitlement: string, inputParameterName: Blob): MethodDescriptor<any>;
    portal_kpi_get(): MethodDescriptor<ChartDto[]>;
    portal_owners_get(tablename: string, uid: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_publish_application_post(uidapplication: string, date: Date, inputParameterName: any): MethodDescriptor<any>;
    portal_shops_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_application_get(filterkpi: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ApplicationExtendedDataRead>>;
    portal_application_delete(UID_AOBApplication: string, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ApplicationExtendedDataRead>>;
    /** Starts the entitlement mapping process for the specified application. */
    portal_application_map_post(UID_AOBApplication: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns all identities having access to at least one entitlement of the application. */
    portal_application_identities_get(uidapplication: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns all entitlements that the specified identity has access to. */
    portal_application_identitiesbyidentity_get(uidapplication: string, uidperson: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns application-specific KPI information. */
    portal_application_kpi_get(uidapplication: string, requestOptions?: ApiRequestOptions): Promise<ChartDto[]>;
    portal_application_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    portal_application_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    portal_application_interactive_delete(inputParameterName: InteractiveEntityDeleteData, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    portal_application_interactive_entitlementstoadd_get(entityid: string, keys: string[], state: string, requestOptions?: ApiRequestOptions): Promise<EntitlementToAddData>;
    portal_application_interactive_byid_get(UID_AOBApplication: string, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    /** Returns a list of objects that can be assigned to the property UID_AERoleApprover. */
    portal_application_interactive_UID_AERoleApprover_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the application/interactive/UID_AERoleApprover/candidates endpoint. */
    portal_application_interactive_UID_AERoleApprover_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AERoleOwner. */
    portal_application_interactive_UID_AERoleOwner_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the application/interactive/UID_AERoleOwner/candidates endpoint. */
    portal_application_interactive_UID_AERoleOwner_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_application_new_post(inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_AccProductGroup. */
    portal_application_new_UID_AccProductGroup_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the application/new/UID_AccProductGroup/candidates endpoint. */
    portal_application_new_UID_AccProductGroup_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AERoleApprover. */
    portal_application_new_UID_AERoleApprover_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the application/new/UID_AERoleApprover/candidates endpoint. */
    portal_application_new_UID_AERoleApprover_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AERoleOwner. */
    portal_application_new_UID_AERoleOwner_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the application/new/UID_AERoleOwner/candidates endpoint. */
    portal_application_new_UID_AERoleOwner_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned as a filter parameter. */
    portal_application_sqlwizard_candidates_get(table: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns the filterable properties for the specified table. */
    portal_application_sqlwizard_tables_columns_get(table: string, requestOptions?: ApiRequestOptions): Promise<FilterPropertyList>;
    portal_applicationimage_get(uidapplication: string, requestOptions?: ApiRequestOptions): Promise<Blob>;
    portal_applicationimage_post(uidapplication: string, inputParameterName: Blob, requestOptions?: ApiRequestOptions): Promise<any>;
    portal_applicationinshop_get(uidapplication: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Assigns an application to a shop. */
    portal_applicationinshop_put(uidapplication: string, uidshop: string, inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Removes an application from a shop. */
    portal_applicationinshop_delete(uidapplication: string, uidshop: string, inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns the list of accounts used by the specified application. */
    portal_applicationusesaccount_get(UID_AOBApplication: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns the list of accounts used by the specified application. */
    portal_applicationusesaccount_delete(UID_AOBApplication: string, UID_AOBAppUsesAccount: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Defines that an application uses a specific account. */
    portal_applicationusesaccount_new_post(inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of candidate objects from the table AccProductGroup. */
    portal_candidates_AccProductGroup_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/AccProductGroup endpoint. */
    portal_candidates_AccProductGroup_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table AccProductParamCategory. */
    portal_candidates_AccProductParamCategory_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/AccProductParamCategory endpoint. */
    portal_candidates_AccProductParamCategory_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table AERole. */
    portal_candidates_AERole_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/AERole endpoint. */
    portal_candidates_AERole_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table AOBApplication. */
    portal_candidates_AOBApplication_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/AOBApplication endpoint. */
    portal_candidates_AOBApplication_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the candidates/AOBApplication endpoint. */
    portal_candidates_AOBApplication_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table Application. */
    portal_candidates_Application_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/Application endpoint. */
    portal_candidates_Application_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table ESet. */
    portal_candidates_ESet_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/ESet endpoint. */
    portal_candidates_ESet_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table FunctionalArea. */
    portal_candidates_FunctionalArea_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/FunctionalArea endpoint. */
    portal_candidates_FunctionalArea_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table Org. */
    portal_candidates_Org_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/Org endpoint. */
    portal_candidates_Org_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table Person. */
    portal_candidates_Person_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/Person endpoint. */
    portal_candidates_Person_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERAssign. */
    portal_candidates_QERAssign_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/QERAssign endpoint. */
    portal_candidates_QERAssign_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERResource. */
    portal_candidates_QERResource_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/QERResource endpoint. */
    portal_candidates_QERResource_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERReuse. */
    portal_candidates_QERReuse_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/QERReuse endpoint. */
    portal_candidates_QERReuse_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERReuseUS. */
    portal_candidates_QERReuseUS_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/QERReuseUS endpoint. */
    portal_candidates_QERReuseUS_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERTermsOfUse. */
    portal_candidates_QERTermsOfUse_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/QERTermsOfUse endpoint. */
    portal_candidates_QERTermsOfUse_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table RPSReport. */
    portal_candidates_RPSReport_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/RPSReport endpoint. */
    portal_candidates_RPSReport_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table TSBAccountDef. */
    portal_candidates_TSBAccountDef_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/TSBAccountDef endpoint. */
    portal_candidates_TSBAccountDef_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table UNSAccountB. */
    portal_candidates_UNSAccountB_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/UNSAccountB endpoint. */
    portal_candidates_UNSAccountB_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table UNSGroup. */
    portal_candidates_UNSGroup_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/UNSGroup endpoint. */
    portal_candidates_UNSGroup_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table UNSRoot. */
    portal_candidates_UNSRoot_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/UNSRoot endpoint. */
    portal_candidates_UNSRoot_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_entitlement_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_entitlement_delete(UID_AOBEntitlement: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_entitlement_systemrole_get(uidapplication: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_entitlement_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    portal_entitlement_interactive_get(requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_entitlement_interactive_put(inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_entitlement_interactive_delete(inputParameterName: InteractiveEntityDeleteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_entitlement_interactive_byid_get(UID_AOBEntitlement: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    /** Returns a list of objects that can be assigned to the property UID_AERoleOwner. */
    portal_entitlement_interactive_UID_AERoleOwner_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the entitlement/interactive/UID_AERoleOwner/candidates endpoint. */
    portal_entitlement_interactive_UID_AERoleOwner_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_entitlement_serviceitem_get(uid_aobentitlement: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_entitlement_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_entitlement_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the entitlement/serviceitem endpoint. */
    portal_entitlement_serviceitem_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns a list of objects that can be assigned to the property UID_OrgAttestator. */
    portal_entitlement_serviceitem_UID_OrgAttestator_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the entitlement/serviceitem/UID_OrgAttestator/candidates endpoint. */
    portal_entitlement_serviceitem_UID_OrgAttestator_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgRuler. */
    portal_entitlement_serviceitem_UID_OrgRuler_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the entitlement/serviceitem/UID_OrgRuler/candidates endpoint. */
    portal_entitlement_serviceitem_UID_OrgRuler_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_PWODecisionMethod. */
    portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the entitlement/serviceitem/UID_PWODecisionMethod/candidates endpoint. */
    portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Adds entitlements to a new or existing system role, and adds the system role to the application. */
    portal_entitlement_systemrole_post(inputParameterName: EntitlementSystemRoleInput, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_entitlementcandidates_ESet_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the entitlementcandidates/ESet endpoint. */
    portal_entitlementcandidates_ESet_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_entitlementcandidates_ESet_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    portal_entitlementcandidates_QERResource_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the entitlementcandidates/QERResource endpoint. */
    portal_entitlementcandidates_QERResource_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_entitlementcandidates_QERResource_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    portal_entitlementcandidates_RPSReport_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the entitlementcandidates/RPSReport endpoint. */
    portal_entitlementcandidates_RPSReport_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_entitlementcandidates_RPSReport_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    portal_entitlementcandidates_TSBAccountDef_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the entitlementcandidates/TSBAccountDef endpoint. */
    portal_entitlementcandidates_TSBAccountDef_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_entitlementcandidates_TSBAccountDef_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    portal_entitlementcandidates_UNSGroup_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, namespace: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the entitlementcandidates/UNSGroup endpoint. */
    portal_entitlementcandidates_UNSGroup_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_entitlementcandidates_UNSGroup_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, namespace: string, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    portal_entitlementimage_get(uidentitlement: string, requestOptions?: ApiRequestOptions): Promise<Blob>;
    portal_entitlementimage_post(uidentitlement: string, inputParameterName: Blob, requestOptions?: ApiRequestOptions): Promise<any>;
    /** Returns global KPI information for application governance. */
    portal_kpi_get(requestOptions?: ApiRequestOptions): Promise<ChartDto[]>;
    /** Returns owner information for the specified entitlement */
    portal_owners_get(tablename: string, uid: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_publish_application_post(uidapplication: string, date: Date, inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<any>;
    portal_shops_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
}
export declare class V2ApiClientMethodFactory {
    portal_application_get(options?: {
        filterkpi?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<ApplicationExtendedDataRead>>;
    portal_application_delete(UID_AOBApplication: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<ApplicationExtendedDataRead>>;
    portal_application_map_post(UID_AOBApplication: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_application_identities_get(uidapplication: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_application_identitiesbyidentity_get(uidapplication: string, uidperson: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_application_kpi_get(uidapplication: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ChartDto[]>;
    portal_application_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfo[]>;
    portal_application_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    portal_application_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    portal_application_interactive_entitlementstoadd_get(entityid: string, options?: {
        keys?: string[];
        state?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntitlementToAddData>;
    portal_application_interactive_byid_get(UID_AOBApplication: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    portal_application_interactive_UID_AERoleApprover_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_application_interactive_UID_AERoleApprover_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_application_interactive_UID_AERoleOwner_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_application_interactive_UID_AERoleOwner_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_application_new_post(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_application_new_UID_AccProductGroup_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_application_new_UID_AccProductGroup_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_application_new_UID_AERoleApprover_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_application_new_UID_AERoleApprover_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_application_new_UID_AERoleOwner_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_application_new_UID_AERoleOwner_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_application_sqlwizard_candidates_get(table: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_application_sqlwizard_tables_columns_get(table: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterPropertyList>;
    portal_applicationimage_get(uidapplication: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<Blob>;
    portal_applicationimage_post(uidapplication: string, inputParameterName: Blob, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    portal_applicationinshop_get(uidapplication: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_applicationinshop_put(uidapplication: string, uidshop: string, inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_applicationinshop_delete(uidapplication: string, uidshop: string, inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_applicationusesaccount_get(UID_AOBApplication: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_applicationusesaccount_delete(UID_AOBApplication: string, UID_AOBAppUsesAccount: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_applicationusesaccount_new_post(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AccProductGroup_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AccProductGroup_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_AccProductParamCategory_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AccProductParamCategory_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_AERole_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AERole_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_AOBApplication_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AOBApplication_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_candidates_AOBApplication_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_Application_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Application_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_ESet_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_ESet_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_FunctionalArea_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_FunctionalArea_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_Org_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Org_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_Person_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Person_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERAssign_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERAssign_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERResource_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERResource_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERReuse_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERReuse_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERReuseUS_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERReuseUS_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERTermsOfUse_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERTermsOfUse_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_RPSReport_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_RPSReport_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_TSBAccountDef_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_TSBAccountDef_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_UNSAccountB_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_UNSAccountB_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_UNSGroup_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_UNSGroup_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_UNSRoot_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_UNSRoot_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_entitlement_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_delete(UID_AOBEntitlement: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_systemrole_get(uidapplication: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfo[]>;
    portal_entitlement_interactive_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_entitlement_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_entitlement_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_entitlement_interactive_byid_get(UID_AOBEntitlement: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_entitlement_interactive_UID_AERoleOwner_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_interactive_UID_AERoleOwner_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_entitlement_serviceitem_get(options?: {
        uid_aobentitlement?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_entitlement_serviceitem_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_entitlement_serviceitem_UID_OrgAttestator_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_serviceitem_UID_OrgAttestator_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_entitlement_serviceitem_UID_OrgRuler_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_serviceitem_UID_OrgRuler_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_entitlement_systemrole_post(inputParameterName: EntitlementSystemRoleInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_entitlementcandidates_ESet_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlementcandidates_ESet_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_entitlementcandidates_ESet_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfo[]>;
    portal_entitlementcandidates_QERResource_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlementcandidates_QERResource_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_entitlementcandidates_QERResource_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfo[]>;
    portal_entitlementcandidates_RPSReport_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlementcandidates_RPSReport_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_entitlementcandidates_RPSReport_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfo[]>;
    portal_entitlementcandidates_TSBAccountDef_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlementcandidates_TSBAccountDef_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_entitlementcandidates_TSBAccountDef_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfo[]>;
    portal_entitlementcandidates_UNSGroup_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        namespace?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_entitlementcandidates_UNSGroup_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_entitlementcandidates_UNSGroup_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
        namespace?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfo[]>;
    portal_entitlementimage_get(uidentitlement: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<Blob>;
    portal_entitlementimage_post(uidentitlement: string, inputParameterName: Blob, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    portal_kpi_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ChartDto[]>;
    portal_owners_get(tablename: string, uid: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_publish_application_post(uidapplication: string, date: Date, inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<any>;
    portal_shops_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_application_get(options?: {
        filterkpi?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ApplicationExtendedDataRead>>;
    portal_application_delete(UID_AOBApplication: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ApplicationExtendedDataRead>>;
    /** Starts the entitlement mapping process for the specified application. */
    portal_application_map_post(UID_AOBApplication: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns all identities having access to at least one entitlement of the application. */
    portal_application_identities_get(uidapplication: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns all entitlements that the specified identity has access to. */
    portal_application_identitiesbyidentity_get(uidapplication: string, uidperson: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns application-specific KPI information. */
    portal_application_kpi_get(uidapplication: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ChartDto[]>;
    portal_application_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
    }, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    portal_application_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    portal_application_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    portal_application_interactive_entitlementstoadd_get(entityid: string, options?: {
        keys?: string[];
        state?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntitlementToAddData>;
    portal_application_interactive_byid_get(UID_AOBApplication: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfApplicationExtendedDataRead>;
    /** Returns a list of objects that can be assigned to the property UID_AERoleApprover. */
    portal_application_interactive_UID_AERoleApprover_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the application/interactive/UID_AERoleApprover/candidates endpoint. */
    portal_application_interactive_UID_AERoleApprover_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AERoleOwner. */
    portal_application_interactive_UID_AERoleOwner_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the application/interactive/UID_AERoleOwner/candidates endpoint. */
    portal_application_interactive_UID_AERoleOwner_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_application_new_post(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_AccProductGroup. */
    portal_application_new_UID_AccProductGroup_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the application/new/UID_AccProductGroup/candidates endpoint. */
    portal_application_new_UID_AccProductGroup_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AERoleApprover. */
    portal_application_new_UID_AERoleApprover_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the application/new/UID_AERoleApprover/candidates endpoint. */
    portal_application_new_UID_AERoleApprover_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AERoleOwner. */
    portal_application_new_UID_AERoleOwner_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the application/new/UID_AERoleOwner/candidates endpoint. */
    portal_application_new_UID_AERoleOwner_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned as a filter parameter. */
    portal_application_sqlwizard_candidates_get(table: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns the filterable properties for the specified table. */
    portal_application_sqlwizard_tables_columns_get(table: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<FilterPropertyList>;
    portal_applicationimage_get(uidapplication: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<Blob>;
    portal_applicationimage_post(uidapplication: string, inputParameterName: Blob, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    portal_applicationinshop_get(uidapplication: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Assigns an application to a shop. */
    portal_applicationinshop_put(uidapplication: string, uidshop: string, inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Removes an application from a shop. */
    portal_applicationinshop_delete(uidapplication: string, uidshop: string, inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns the list of accounts used by the specified application. */
    portal_applicationusesaccount_get(UID_AOBApplication: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns the list of accounts used by the specified application. */
    portal_applicationusesaccount_delete(UID_AOBApplication: string, UID_AOBAppUsesAccount: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Defines that an application uses a specific account. */
    portal_applicationusesaccount_new_post(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of candidate objects from the table AccProductGroup. */
    portal_candidates_AccProductGroup_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/AccProductGroup endpoint. */
    portal_candidates_AccProductGroup_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table AccProductParamCategory. */
    portal_candidates_AccProductParamCategory_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/AccProductParamCategory endpoint. */
    portal_candidates_AccProductParamCategory_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table AERole. */
    portal_candidates_AERole_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/AERole endpoint. */
    portal_candidates_AERole_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table AOBApplication. */
    portal_candidates_AOBApplication_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/AOBApplication endpoint. */
    portal_candidates_AOBApplication_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the candidates/AOBApplication endpoint. */
    portal_candidates_AOBApplication_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table Application. */
    portal_candidates_Application_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/Application endpoint. */
    portal_candidates_Application_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table ESet. */
    portal_candidates_ESet_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/ESet endpoint. */
    portal_candidates_ESet_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table FunctionalArea. */
    portal_candidates_FunctionalArea_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/FunctionalArea endpoint. */
    portal_candidates_FunctionalArea_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table Org. */
    portal_candidates_Org_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/Org endpoint. */
    portal_candidates_Org_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table Person. */
    portal_candidates_Person_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/Person endpoint. */
    portal_candidates_Person_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERAssign. */
    portal_candidates_QERAssign_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/QERAssign endpoint. */
    portal_candidates_QERAssign_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERResource. */
    portal_candidates_QERResource_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/QERResource endpoint. */
    portal_candidates_QERResource_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERReuse. */
    portal_candidates_QERReuse_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/QERReuse endpoint. */
    portal_candidates_QERReuse_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERReuseUS. */
    portal_candidates_QERReuseUS_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/QERReuseUS endpoint. */
    portal_candidates_QERReuseUS_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERTermsOfUse. */
    portal_candidates_QERTermsOfUse_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/QERTermsOfUse endpoint. */
    portal_candidates_QERTermsOfUse_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table RPSReport. */
    portal_candidates_RPSReport_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/RPSReport endpoint. */
    portal_candidates_RPSReport_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table TSBAccountDef. */
    portal_candidates_TSBAccountDef_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/TSBAccountDef endpoint. */
    portal_candidates_TSBAccountDef_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table UNSAccountB. */
    portal_candidates_UNSAccountB_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/UNSAccountB endpoint. */
    portal_candidates_UNSAccountB_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table UNSGroup. */
    portal_candidates_UNSGroup_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/UNSGroup endpoint. */
    portal_candidates_UNSGroup_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table UNSRoot. */
    portal_candidates_UNSRoot_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/UNSRoot endpoint. */
    portal_candidates_UNSRoot_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_entitlement_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_entitlement_delete(UID_AOBEntitlement: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_entitlement_systemrole_get(uidapplication: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_entitlement_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
    }, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    portal_entitlement_interactive_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_entitlement_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_entitlement_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_entitlement_interactive_byid_get(UID_AOBEntitlement: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    /** Returns a list of objects that can be assigned to the property UID_AERoleOwner. */
    portal_entitlement_interactive_UID_AERoleOwner_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the entitlement/interactive/UID_AERoleOwner/candidates endpoint. */
    portal_entitlement_interactive_UID_AERoleOwner_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_entitlement_serviceitem_get(options?: {
        uid_aobentitlement?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_entitlement_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_entitlement_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the entitlement/serviceitem endpoint. */
    portal_entitlement_serviceitem_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns a list of objects that can be assigned to the property UID_OrgAttestator. */
    portal_entitlement_serviceitem_UID_OrgAttestator_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the entitlement/serviceitem/UID_OrgAttestator/candidates endpoint. */
    portal_entitlement_serviceitem_UID_OrgAttestator_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgRuler. */
    portal_entitlement_serviceitem_UID_OrgRuler_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the entitlement/serviceitem/UID_OrgRuler/candidates endpoint. */
    portal_entitlement_serviceitem_UID_OrgRuler_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_PWODecisionMethod. */
    portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the entitlement/serviceitem/UID_PWODecisionMethod/candidates endpoint. */
    portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Adds entitlements to a new or existing system role, and adds the system role to the application. */
    portal_entitlement_systemrole_post(inputParameterName: EntitlementSystemRoleInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_entitlementcandidates_ESet_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the entitlementcandidates/ESet endpoint. */
    portal_entitlementcandidates_ESet_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_entitlementcandidates_ESet_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
    }, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    portal_entitlementcandidates_QERResource_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the entitlementcandidates/QERResource endpoint. */
    portal_entitlementcandidates_QERResource_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_entitlementcandidates_QERResource_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
    }, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    portal_entitlementcandidates_RPSReport_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the entitlementcandidates/RPSReport endpoint. */
    portal_entitlementcandidates_RPSReport_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_entitlementcandidates_RPSReport_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
    }, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    portal_entitlementcandidates_TSBAccountDef_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the entitlementcandidates/TSBAccountDef endpoint. */
    portal_entitlementcandidates_TSBAccountDef_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_entitlementcandidates_TSBAccountDef_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
    }, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    portal_entitlementcandidates_UNSGroup_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        namespace?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the entitlementcandidates/UNSGroup endpoint. */
    portal_entitlementcandidates_UNSGroup_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_entitlementcandidates_UNSGroup_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
        namespace?: string;
    }, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
    portal_entitlementimage_get(uidentitlement: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<Blob>;
    portal_entitlementimage_post(uidentitlement: string, inputParameterName: Blob, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    /** Returns global KPI information for application governance. */
    portal_kpi_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<ChartDto[]>;
    /** Returns owner information for the specified entitlement */
    portal_owners_get(tablename: string, uid: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_publish_application_post(uidapplication: string, date: Date, inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<any>;
    portal_shops_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
}
