# One Identity Cadence Font

One Identity's cadence font package.

Maintained by One Identity UX team.

## Usage

You have several ways to use this iconset:
- Simply grab the font file from the `dist` folder.
- Include the package in your project: `npm i -s @elemental-ui/cadence-icon`, then import the styles in your scss:
 `@import "~@emelental-ui/cadence-icon"`. 
    
    Note: this package delivers a scss code by default. If you don't use scss you need to compile this file.
    
- Grab the `.png` files from the `dist/png` folder. 

## Contributing

Icon creation is restricted to the UX team. If you need a new icon or have an idea please create a work item for that.

##### For UX team members

- To submit a new icon simply update a cleaned `.svg` file to the `svg` folder.
- create a Pull Request for that.
    - Make sure that the 'Submit as a Pull Request' option is checked and you filled the branch field.
- When you are on the Pull Request page make sure the 'Remove source branch' is checked. 
- Please include a screenshot of the icon in the description. 
