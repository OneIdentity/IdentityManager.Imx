import { ApiClient, DataModel, EntityCollectionData, EntitySchema, EntityWriteData, EntityWriteDataColumn, FilterData, FkProviderItem, IReadValue, IWriteValue, MethodDescriptor, StaticSchema, TypedEntity } from 'imx-qbm-dbts';
export interface EntityWriteDataBulk {
    Keys?: string[][];
    Data?: EntityWriteDataColumn[];
}
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export declare class TypedClient {
    readonly PortalTargetsystemTeams: PortalTargetsystemTeamsWrapper;
    readonly PortalTargetsystemTeamsChannels: PortalTargetsystemTeamsChannelsWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalTargetsystemTeams extends TypedEntity {
    readonly WebUrl: IReadValue<string>;
    readonly UID_O3EUnifiedGroup: IReadValue<string>;
    readonly IsArchived: IWriteValue<boolean>;
    readonly fsAllowCustomMemes: IWriteValue<boolean>;
    readonly fsAllowGiphy: IWriteValue<boolean>;
    readonly fsAllowStickersAndMemes: IWriteValue<boolean>;
    readonly fsGiphyContentRating: IWriteValue<string>;
    readonly gsAllowCreateUpdateChannels: IWriteValue<boolean>;
    readonly gsAllowDeleteChannels: IWriteValue<boolean>;
    readonly msAllowChannelMentions: IWriteValue<boolean>;
    readonly msAllowOwnerDeleteMessages: IWriteValue<boolean>;
    readonly msAllowTeamMentions: IWriteValue<boolean>;
    readonly msAllowUserDeleteMessages: IWriteValue<boolean>;
    readonly msAllowUserEditMessages: IWriteValue<boolean>;
    readonly tmsAllowAddRemoveApps: IWriteValue<boolean>;
    readonly tmsAllowCreateUpdateChannels: IWriteValue<boolean>;
    readonly tmsAllowCreateUpdateRemoveConn: IWriteValue<boolean>;
    readonly tmsAllowCreateUpdateRemoveTabs: IWriteValue<boolean>;
    readonly tmsAllowDeleteChannels: IWriteValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'WebUrl' | 'UID_O3EUnifiedGroup' | 'IsArchived' | 'fsAllowCustomMemes' | 'fsAllowGiphy' | 'fsAllowStickersAndMemes' | 'fsGiphyContentRating' | 'gsAllowCreateUpdateChannels' | 'gsAllowDeleteChannels' | 'msAllowChannelMentions' | 'msAllowOwnerDeleteMessages' | 'msAllowTeamMentions' | 'msAllowUserDeleteMessages' | 'msAllowUserEditMessages' | 'tmsAllowAddRemoveApps' | 'tmsAllowCreateUpdateChannels' | 'tmsAllowCreateUpdateRemoveConn' | 'tmsAllowCreateUpdateRemoveTabs' | 'tmsAllowDeleteChannels'>;
}
export declare class PortalTargetsystemTeamsChannels extends TypedEntity {
    readonly UID_O3TTeam: IReadValue<string>;
    readonly WebUrl: IReadValue<string>;
    readonly Id: IReadValue<string>;
    readonly EMail: IReadValue<string>;
    readonly Description: IWriteValue<string>;
    readonly DisplayName: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_O3TTeam' | 'WebUrl' | 'Id' | 'EMail' | 'Description' | 'DisplayName'>;
}
export declare class PortalTargetsystemTeamsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        organization?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemTeams, unknown>>;
    Put(inputParameterName: PortalTargetsystemTeams): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemTeams, unknown>>;
}
export declare class PortalTargetsystemTeamsChannelsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_O3TTeam: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemTeamsChannels, unknown>>;
    Put(UID_O3TTeam: string, inputParameterName: PortalTargetsystemTeamsChannels): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemTeamsChannels, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    portal_targetsystem_teams_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, organization: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_teams_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_teams_channels_get(UID_O3TTeam: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_teams_channels_put(UID_O3TTeam: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_teams_channels_bulk_put(UID_O3TTeam: string, inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_teams_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_teams_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_targetsystem_teams_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, organization: string): Promise<EntityCollectionData>;
    portal_targetsystem_teams_put(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_targetsystem_teams_channels_get(UID_O3TTeam: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_targetsystem_teams_channels_put(UID_O3TTeam: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_targetsystem_teams_channels_bulk_put(UID_O3TTeam: string, inputParameterName: EntityWriteDataBulk): Promise<void>;
    portal_targetsystem_teams_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Returns data model information about query options for the targetsystem/teams endpoint. */
    portal_targetsystem_teams_datamodel_get(filter: FilterData[]): Promise<DataModel>;
}
export declare class V2ApiClientMethodFactory {
    portal_targetsystem_teams_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        organization?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_teams_put(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_teams_channels_get(UID_O3TTeam: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_teams_channels_put(UID_O3TTeam: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_teams_channels_bulk_put(UID_O3TTeam: string, inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_targetsystem_teams_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_targetsystem_teams_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_targetsystem_teams_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        organization?: string;
    }): Promise<EntityCollectionData>;
    portal_targetsystem_teams_put(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_targetsystem_teams_channels_get(UID_O3TTeam: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_targetsystem_teams_channels_put(UID_O3TTeam: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_targetsystem_teams_channels_bulk_put(UID_O3TTeam: string, inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    portal_targetsystem_teams_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Returns data model information about query options for the targetsystem/teams endpoint. */
    portal_targetsystem_teams_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
}
