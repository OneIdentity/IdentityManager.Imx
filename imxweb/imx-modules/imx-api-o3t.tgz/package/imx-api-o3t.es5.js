import { ValType, DisplayColumns, TypedEntity, TypedEntityBuilder, TimeZoneInfo, DisplayPattern, FkCandidateBuilder, MethodDefinition } from 'imx-qbm-dbts';

var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var TypedClient = /** @class */ (function () {
    function TypedClient(client, translationProvider) {
        this.PortalTargetsystemTeams = new PortalTargetsystemTeamsWrapper(client, translationProvider);
        this.PortalTargetsystemTeamsChannels = new PortalTargetsystemTeamsChannelsWrapper(client, translationProvider);
    }
    return TypedClient;
}());
var PortalTargetsystemTeams = /** @class */ (function (_super) {
    __extends(PortalTargetsystemTeams, _super);
    function PortalTargetsystemTeams() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.WebUrl = _this.GetEntityValue('WebUrl');
        _this.UID_O3EUnifiedGroup = _this.GetEntityValue('UID_O3EUnifiedGroup');
        _this.IsArchived = _this.GetEntityValue('IsArchived');
        _this.fsAllowCustomMemes = _this.GetEntityValue('fsAllowCustomMemes');
        _this.fsAllowGiphy = _this.GetEntityValue('fsAllowGiphy');
        _this.fsAllowStickersAndMemes = _this.GetEntityValue('fsAllowStickersAndMemes');
        _this.fsGiphyContentRating = _this.GetEntityValue('fsGiphyContentRating');
        _this.gsAllowCreateUpdateChannels = _this.GetEntityValue('gsAllowCreateUpdateChannels');
        _this.gsAllowDeleteChannels = _this.GetEntityValue('gsAllowDeleteChannels');
        _this.msAllowChannelMentions = _this.GetEntityValue('msAllowChannelMentions');
        _this.msAllowOwnerDeleteMessages = _this.GetEntityValue('msAllowOwnerDeleteMessages');
        _this.msAllowTeamMentions = _this.GetEntityValue('msAllowTeamMentions');
        _this.msAllowUserDeleteMessages = _this.GetEntityValue('msAllowUserDeleteMessages');
        _this.msAllowUserEditMessages = _this.GetEntityValue('msAllowUserEditMessages');
        _this.tmsAllowAddRemoveApps = _this.GetEntityValue('tmsAllowAddRemoveApps');
        _this.tmsAllowCreateUpdateChannels = _this.GetEntityValue('tmsAllowCreateUpdateChannels');
        _this.tmsAllowCreateUpdateRemoveConn = _this.GetEntityValue('tmsAllowCreateUpdateRemoveConn');
        _this.tmsAllowCreateUpdateRemoveTabs = _this.GetEntityValue('tmsAllowCreateUpdateRemoveTabs');
        _this.tmsAllowDeleteChannels = _this.GetEntityValue('tmsAllowDeleteChannels');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    PortalTargetsystemTeams.GetEntitySchema = function () {
        var columns = {
            'WebUrl': {
                ColumnName: 'WebUrl',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_O3EUnifiedGroup': {
                ColumnName: 'UID_O3EUnifiedGroup',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'IsArchived': {
                ColumnName: 'IsArchived',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'fsAllowCustomMemes': {
                ColumnName: 'fsAllowCustomMemes',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'fsAllowGiphy': {
                ColumnName: 'fsAllowGiphy',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'fsAllowStickersAndMemes': {
                ColumnName: 'fsAllowStickersAndMemes',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'fsGiphyContentRating': {
                ColumnName: 'fsGiphyContentRating',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'gsAllowCreateUpdateChannels': {
                ColumnName: 'gsAllowCreateUpdateChannels',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'gsAllowDeleteChannels': {
                ColumnName: 'gsAllowDeleteChannels',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'msAllowChannelMentions': {
                ColumnName: 'msAllowChannelMentions',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'msAllowOwnerDeleteMessages': {
                ColumnName: 'msAllowOwnerDeleteMessages',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'msAllowTeamMentions': {
                ColumnName: 'msAllowTeamMentions',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'msAllowUserDeleteMessages': {
                ColumnName: 'msAllowUserDeleteMessages',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'msAllowUserEditMessages': {
                ColumnName: 'msAllowUserEditMessages',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'tmsAllowAddRemoveApps': {
                ColumnName: 'tmsAllowAddRemoveApps',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'tmsAllowCreateUpdateChannels': {
                ColumnName: 'tmsAllowCreateUpdateChannels',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'tmsAllowCreateUpdateRemoveConn': {
                ColumnName: 'tmsAllowCreateUpdateRemoveConn',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'tmsAllowCreateUpdateRemoveTabs': {
                ColumnName: 'tmsAllowCreateUpdateRemoveTabs',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'tmsAllowDeleteChannels': {
                ColumnName: 'tmsAllowDeleteChannels',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'O3TTeam', Columns: columns };
    };
    return PortalTargetsystemTeams;
}(TypedEntity));
var PortalTargetsystemTeamsChannels = /** @class */ (function (_super) {
    __extends(PortalTargetsystemTeamsChannels, _super);
    function PortalTargetsystemTeamsChannels() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_O3TTeam = _this.GetEntityValue('UID_O3TTeam');
        _this.WebUrl = _this.GetEntityValue('WebUrl');
        _this.Id = _this.GetEntityValue('Id');
        _this.EMail = _this.GetEntityValue('EMail');
        _this.Description = _this.GetEntityValue('Description');
        _this.DisplayName = _this.GetEntityValue('DisplayName');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    PortalTargetsystemTeamsChannels.GetEntitySchema = function () {
        var columns = {
            'UID_O3TTeam': {
                ColumnName: 'UID_O3TTeam',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'WebUrl': {
                ColumnName: 'WebUrl',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Id': {
                ColumnName: 'Id',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'EMail': {
                ColumnName: 'EMail',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Description': {
                ColumnName: 'Description',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'DisplayName': {
                ColumnName: 'DisplayName',
                Type: ValType.String,
                IsReadOnly: false,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'O3TTeamChannel', Columns: columns };
    };
    return PortalTargetsystemTeamsChannels;
}(TypedEntity));
var PortalTargetsystemTeamsWrapper = /** @class */ (function () {
    function PortalTargetsystemTeamsWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_teams_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemTeamsWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/teams');
    };
    PortalTargetsystemTeamsWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/teams');
            this.builder = new TypedEntityBuilder(PortalTargetsystemTeams, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemTeamsWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_teams_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemTeamsWrapper.prototype.Put = function (inputParameterName, requestOpts) {
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_teams_put(inputParameterName.EntityWriteData, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemTeamsWrapper;
}());
var PortalTargetsystemTeamsChannelsWrapper = /** @class */ (function () {
    function PortalTargetsystemTeamsChannelsWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_teams_channels_put(entity.GetColumn('UID_O3TTeam').GetValue(), writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemTeamsChannelsWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/teams/{UID_O3TTeam}/channels');
    };
    PortalTargetsystemTeamsChannelsWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/teams/{UID_O3TTeam}/channels');
            this.builder = new TypedEntityBuilder(PortalTargetsystemTeamsChannels, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemTeamsChannelsWrapper.prototype.Get = function (UID_O3TTeam, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_teams_channels_get(UID_O3TTeam, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemTeamsChannelsWrapper.prototype.Put = function (UID_O3TTeam, inputParameterName, requestOpts) {
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_teams_channels_put(UID_O3TTeam, inputParameterName.EntityWriteData, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemTeamsChannelsWrapper;
}());
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
var ApiClientMethodFactory = /** @class */ (function () {
    function ApiClientMethodFactory() {
    }
    ApiClientMethodFactory.prototype.portal_targetsystem_teams_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, organization) {
        return {
            path: '/portal/targetsystem/teams',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'organization',
                    value: organization,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_teams_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/teams',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_teams_channels_get = function (UID_O3TTeam, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/targetsystem/teams/{UID_O3TTeam}/channels',
            parameters: [
                {
                    name: 'UID_O3TTeam',
                    value: UID_O3TTeam,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_teams_channels_put = function (UID_O3TTeam, inputParameterName) {
        return {
            path: '/portal/targetsystem/teams/{UID_O3TTeam}/channels',
            parameters: [
                {
                    name: 'UID_O3TTeam',
                    value: UID_O3TTeam,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_teams_channels_bulk_put = function (UID_O3TTeam, inputParameterName) {
        return {
            path: '/portal/targetsystem/teams/{UID_O3TTeam}/channels/bulk',
            parameters: [
                {
                    name: 'UID_O3TTeam',
                    value: UID_O3TTeam,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_teams_bulk_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/teams/bulk',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_teams_datamodel_get = function (filter) {
        return {
            path: '/portal/targetsystem/teams/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    return ApiClientMethodFactory;
}());
/** @deprecated Use the V2Client class for a stable method interface. */
var Client = /** @class */ (function () {
    function Client(apiClient, schemaProvider) {
        this.apiClient = apiClient;
        this.schemaProvider = schemaProvider;
        this.methodFactory = new ApiClientMethodFactory();
        if (!apiClient) {
            throw new Error("The value for the apiClient parameter is undefined.");
        }
    }
    Object.defineProperty(Client.prototype, "schemas", {
        get: function () {
            if (!this.schemaProvider) {
                throw new Error("The schema has not been loaded.");
            }
            return this.schemaProvider.schemas;
        },
        enumerable: false,
        configurable: true
    });
    Client.prototype.loadSchema = function (language) {
        return __awaiter(this, void 0, void 0, function () {
            var headers, dtos, schemas, key, dto, columns;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        headers = {};
                        if (language)
                            headers['Accept-Language'] = language;
                        return [4 /*yield*/, this.apiClient.processRequest({
                                path: '/imx/entityschema',
                                parameters: [],
                                method: 'GET',
                                headers: headers,
                                credentials: 'include',
                                observe: 'response',
                                responseType: 'json'
                            })];
                    case 1:
                        dtos = _a.sent();
                        schemas = {};
                        for (key in dtos) {
                            dto = dtos[key];
                            columns = dto.Properties;
                            columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
                            columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
                            schemas[key] = {
                                TypeName: dto.TypeName,
                                DisplayPattern: new DisplayPattern(dto.DisplayPattern),
                                Display: dto.Display,
                                DisplaySingular: dto.DisplaySingular,
                                FkCandidateRoutes: dto.FkCandidateRoutes,
                                Columns: columns
                            };
                        }
                        this.schemaProvider = { schemas: schemas };
                        return [2 /*return*/];
                }
            });
        });
    };
    Client.prototype.getFkProviderItems = function (methodKey) {
        var _a;
        return new FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
    };
    /** Returns the runtime schema for the named method. */
    Client.prototype.getSchema = function (methodKey) {
        var result = this.schemas[methodKey];
        if (!result)
            throw new Error('Unknown method: ' + methodKey);
        return result;
    };
    Client.prototype.portal_targetsystem_teams_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, organization, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_teams_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, organization), requestOptions);
    };
    Client.prototype.portal_targetsystem_teams_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_teams_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_teams_channels_get = function (UID_O3TTeam, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_teams_channels_get(UID_O3TTeam, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    Client.prototype.portal_targetsystem_teams_channels_put = function (UID_O3TTeam, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_teams_channels_put(UID_O3TTeam, inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_teams_channels_bulk_put = function (UID_O3TTeam, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_teams_channels_bulk_put(UID_O3TTeam, inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_teams_bulk_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_teams_bulk_put(inputParameterName), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/teams endpoint. */
    Client.prototype.portal_targetsystem_teams_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_teams_datamodel_get(filter), requestOptions);
    };
    return Client;
}());
var V2ApiClientMethodFactory = /** @class */ (function () {
    function V2ApiClientMethodFactory() {
    }
    V2ApiClientMethodFactory.prototype.portal_targetsystem_teams_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/teams',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_teams_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/teams',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_teams_channels_get = function (UID_O3TTeam, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/teams/{UID_O3TTeam}/channels',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_O3TTeam',
                    value: UID_O3TTeam,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_teams_channels_put = function (UID_O3TTeam, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/teams/{UID_O3TTeam}/channels',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_O3TTeam',
                    value: UID_O3TTeam,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_teams_channels_bulk_put = function (UID_O3TTeam, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/teams/{UID_O3TTeam}/channels/bulk',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_O3TTeam',
                    value: UID_O3TTeam,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_teams_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/teams/bulk',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_teams_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/teams/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    return V2ApiClientMethodFactory;
}());
var V2Client = /** @class */ (function () {
    function V2Client(apiClient, schemaProvider) {
        this.apiClient = apiClient;
        this.schemaProvider = schemaProvider;
        this.methodFactory = new V2ApiClientMethodFactory();
        if (!apiClient) {
            throw new Error("The value for the apiClient parameter is undefined.");
        }
    }
    Object.defineProperty(V2Client.prototype, "schemas", {
        get: function () {
            if (!this.schemaProvider) {
                throw new Error("The schema has not been loaded.");
            }
            return this.schemaProvider.schemas;
        },
        enumerable: false,
        configurable: true
    });
    V2Client.prototype.loadSchema = function (language) {
        return __awaiter(this, void 0, void 0, function () {
            var headers, dtos, schemas, key, dto, columns;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        headers = {};
                        if (language)
                            headers['Accept-Language'] = language;
                        return [4 /*yield*/, this.apiClient.processRequest({
                                path: '/imx/entityschema',
                                parameters: [],
                                method: 'GET',
                                headers: headers,
                                credentials: 'include',
                                observe: 'response',
                                responseType: 'json'
                            })];
                    case 1:
                        dtos = _a.sent();
                        schemas = {};
                        for (key in dtos) {
                            dto = dtos[key];
                            columns = dto.Properties;
                            columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
                            columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
                            schemas[key] = {
                                TypeName: dto.TypeName,
                                DisplayPattern: new DisplayPattern(dto.DisplayPattern),
                                Display: dto.Display,
                                DisplaySingular: dto.DisplaySingular,
                                FkCandidateRoutes: dto.FkCandidateRoutes,
                                Columns: columns
                            };
                        }
                        this.schemaProvider = { schemas: schemas };
                        return [2 /*return*/];
                }
            });
        });
    };
    V2Client.prototype.getFkProviderItems = function (methodKey) {
        var _a;
        return new FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
    };
    /** Returns the runtime schema for the named method. */
    V2Client.prototype.getSchema = function (methodKey) {
        var result = this.schemas[methodKey];
        if (!result)
            throw new Error('Unknown method: ' + methodKey);
        return result;
    };
    V2Client.prototype.portal_targetsystem_teams_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_teams_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_teams_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_teams_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_teams_channels_get = function (UID_O3TTeam, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_teams_channels_get(UID_O3TTeam, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_teams_channels_put = function (UID_O3TTeam, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_teams_channels_put(UID_O3TTeam, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_teams_channels_bulk_put = function (UID_O3TTeam, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_teams_channels_bulk_put(UID_O3TTeam, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_teams_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_teams_bulk_put(inputParameterName, options), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/teams endpoint. */
    V2Client.prototype.portal_targetsystem_teams_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_teams_datamodel_get(options), requestOptions);
    };
    return V2Client;
}());

export { ApiClientMethodFactory, Client, PortalTargetsystemTeams, PortalTargetsystemTeamsChannels, PortalTargetsystemTeamsChannelsWrapper, PortalTargetsystemTeamsWrapper, TypedClient, V2ApiClientMethodFactory, V2Client };
