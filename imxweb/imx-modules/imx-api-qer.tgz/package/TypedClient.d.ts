import { ApiClient, DataModel, EntityCollectionData, EntityColumnData, EntityData, EntityKeysData, EntitySchema, EntityWriteData, EntityWriteDataColumn, EntityWriteDataSingle, ExtendedEntityCollectionData, ExtendedEntityWriteData, FilterData, FilterPropertyList, FilterTreeData, FkCandidateRouteDto, FkProviderItem, GroupInfo, HistoryData, IClientProperty, InteractiveEntityData, InteractiveEntityDeleteData, InteractiveEntityStateData, InteractiveEntityWriteData, IReadValue, IWriteValue, MethodDescriptor, ParameterData, SqlExpression, SqlWizardExpression, StaticSchema, TypedEntity, WriteExtTypedEntity } from 'imx-qbm-dbts';
export interface AccProductOwnershipInput {
    UidPerson?: string;
    CopyAllMembers: boolean;
}
/** Represents the state of an action execution. */
export declare enum ActionState {
    NotExecuted = 0,
    Succeeded = 1,
    RolledBack = 2,
    Failed = 3
}
export interface ApplicationAuthConfig {
    SsoAuthentifiers?: string[];
    ManualAuthentifiers?: string[];
    AdditionalAuthProps?: string;
    AuthenticationType?: AuthType;
    AllowPersistentAuth?: boolean;
    Product?: string;
    SecondaryAuth?: ISecondaryAuthProvider;
}
/** Represents application-specific configuration of method sets. */
export interface ApplicationMethodConfig {
    ApiProjects?: {
        [key: string]: ApplicationAuthConfig;
    };
    /** Gets or sets a flag indicating if all projects should be loaded, even the ones
not explicitly listed. */
    AllProjects: boolean;
}
export interface AuthenticationConfig {
    MfaAuthenticationProvider?: string;
    /** Specify which authentication modules are not used. */
    ExcludedAuthentifiers?: string[];
    /** Specify which authentication modules are used for single sign-on. */
    SsoAuthentifiers?: string[];
    /** Specify whether users who are not registered for multi-factor authentication are allowed to access the web application. */
    VI_Common_AccessControl_AllowUnregistered: boolean;
    /** Enter the unique identifier for the secondary authentication provider for WebAuthn two-factor authentication. You can find this identifier in your RSTS configuration. */
    VI_Common_AccessControl_Webauthn_2FAID?: string;
}
export declare enum AuthType {
    Default = 0,
    AllManualModules = 1,
    FixedCredentials = 2
}
export interface CandidateData {
    ParameterName?: string;
    Candidates?: FkCandidateRouteDto;
}
export interface CaptchaCode {
    /** Represents the code entered by the user. */
    Code?: string;
}
export interface CaptchaCodeAndAccount extends CaptchaCode {
    AccountName?: string;
}
/** Represents the result of a shopping cart check. */
export interface CartCheckResult {
    /** Returns the UIDs of shopping cart items that represent duplicates. The values are organized by mutually exclusive groups. */
    Duplicates?: string[][];
    /** Returns the check results for individual items. */
    Items?: CartItemCheckResult[];
    HasWarnings: boolean;
    HasErrors: boolean;
    Submitted: boolean;
    CheckDate: Date;
    CanCommitSilently: boolean;
}
export interface CartItemCheckResult {
    UidShoppingCartItem?: string;
    /** The UID of the request that was created from this cart item. */
    UidPersonWantsOrg?: string;
    Results?: ICartItemCheckResult[];
    Checks?: ICartItemCheck[];
    HasWarnings: boolean;
    HasErrors: boolean;
    CanCommitSilently: boolean;
}
export interface CartItemData {
    UiText?: string;
}
export interface CartItemDataRead {
    CheckResults?: CartItemCheckResult[];
    ItemData?: CartItemData[];
    Parameters?: {
        [key: string]: ParameterData[][];
    };
}
export interface CartSubmitOptions {
    Mode: CheckMode;
}
export interface ChartData {
    ObjectKey?: string;
    Name?: string;
    ObjectDisplay?: string;
    Points?: ChartDataPoint[];
}
export interface ChartDataPoint {
    Percentage: number;
    Value: number;
    ValueZ: number;
    Date: Date;
}
export interface ChartDto {
    NegateThresholds: boolean;
    AggregateFunction: StatisticAggregateFunction;
    AggregateFunctionTotal: StatisticAggregateFunction;
    ErrorThreshold: number;
    WarningThreshold: number;
    TimeScaleUnit: StatisticTimeScaleUnit;
    Unit?: string;
    Name?: string;
    Display?: string;
    Description?: string;
    Data?: ChartData[];
}
export declare enum CheckMode {
    CheckOnly = 0,
    SubmitIfNoWarnings = 1,
    SubmitWithWarnings = 2
}
export interface ConfigData {
    MethodConfig?: {
        [key: string]: ISessionAuthDbConfig;
    };
    ApplicationConfig?: ApplicationMethodConfig;
}
export interface DecisionInput {
    Reason?: string;
    UidJustification?: string;
    Decision: boolean;
}
/** Holds information about a deleted object. */
export interface DeletedObjectInfo {
    /** Gets or sets the object key of the deleted object. */
    DbObjectKey?: string;
    /** Gets or sets the name of the user who deleted the object. */
    DeletedBy?: string;
    /** Gets or sets the display name of the object at the time of its deletion. */
    Display?: string;
    /** Gets or sets the date of deletion. */
    DeletionDate: Date;
    /** Gets or sets detailed information about the deletion operation. */
    ChangeInfo?: IObjectChangeInfo;
}
export interface DenyDecisionInput {
    Reason?: string;
    UidJustification?: string;
}
export interface DeviceConfig {
    /** Specify which properties of devices are displayed in the device overview. */
    VI_Hardware_Person_ResultAttributes?: string[];
    /** Specify which properties of devices of the type Computer can be edited. */
    VI_Hardware_Fields_PC?: string[];
    /** Specify which properties of devices of the type Server can be edited. */
    VI_Hardware_Fields_SRV?: string[];
    /** Specify which properties of devices of the type Mobile phone can be edited. */
    VI_Hardware_Fields_MP?: string[];
    /** Specify which properties of devices of the type Tablet can be edited. */
    VI_Hardware_Fields_TAB?: string[];
    /** Specify which properties of devices of the type Printer can be edited. */
    VI_Hardware_Fields_PR?: string[];
    /** Specify which properties of devices of the type Display can be edited. */
    VI_Hardware_Fields_MO?: string[];
    /** Specify which properties of devices of the type Default can be edited. */
    VI_Hardware_Fields_Default?: string[];
}
export interface DirectDecisionInput {
    Reason?: string;
    Offset: number;
}
export interface EntityWriteDataBulk {
    Keys?: string[][];
    Data?: EntityWriteDataColumn[];
}
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface ExtendedEntityCollectionDataOfCartItemDataRead extends EntityCollectionData {
    ExtendedData?: CartItemDataRead;
}
export interface ExtendedEntityCollectionDataOfIReadOnlyListOfIClientProperty extends EntityCollectionData {
    ExtendedData?: IClientProperty[];
}
export interface ExtendedEntityCollectionDataOfPwoExtendedData extends EntityCollectionData {
    ExtendedData?: PwoExtendedData;
}
export interface ExtendedEntityCollectionDataOfServiceItemsExtendedData extends EntityCollectionData {
    ExtendedData?: ServiceItemsExtendedData;
}
export interface ExtendedEntityCollectionDataOfSqlWizardRead extends EntityCollectionData {
    ExtendedData?: SqlWizardRead;
}
export interface ExtendedEntityCollectionDataOfWebauthnConfig extends EntityCollectionData {
    ExtendedData?: WebauthnConfig;
}
export interface ExtendedEntityWriteDataOfAccProductOwnershipInput extends EntityWriteData {
    ExtendedData?: AccProductOwnershipInput;
}
export interface ExtendedEntityWriteDataOfIDictionaryOfStringAndIReadOnlyListOfIReadOnlyListOfEntityWriteDataColumn extends EntityWriteData {
    ExtendedData?: {
        [key: string]: EntityWriteDataColumn[][];
    };
}
export interface ExtendedEntityWriteDataOfRoleExtendedDataWrite extends EntityWriteData {
    ExtendedData?: RoleExtendedDataWrite;
}
export interface ExtendedInteractiveEntityDataOfCartItemDataRead extends InteractiveEntityData {
    ExtendedData?: CartItemDataRead;
}
export interface ExtendedInteractiveEntityDataOfSqlWizardRead extends InteractiveEntityData {
    ExtendedData?: SqlWizardRead;
}
export interface ExtendedInteractiveEntityWriteDataOfIDictionaryOfStringAndIReadOnlyListOfIReadOnlyListOfEntityWriteDataColumn extends InteractiveEntityWriteData {
    ExtendedData?: {
        [key: string]: EntityWriteDataColumn[][];
    };
}
export interface ExtendedInteractiveEntityWriteDataOfRoleExtendedDataWrite extends InteractiveEntityWriteData {
    ExtendedData?: RoleExtendedDataWrite;
}
export interface ExtendedInteractiveEntityWriteDataOfSqlWizardWrite extends InteractiveEntityWriteData {
    ExtendedData?: SqlWizardWrite;
}
export interface FeatureConfig {
    EnableSetPasswords: boolean;
    EnableSystemStatus: boolean;
}
export interface ForeignWord {
    /** Returns the identifier of the foreign word's culture. */
    Culture?: string;
    /** Returns the foreign word string. */
    Value?: string;
    /** Returns the culture in which this word is considered a foreign word. */
    CultureAppliesTo?: string;
}
export interface GlobalDelegationInput {
    UidPersonFrom?: string;
    UidPersonTo?: string;
    ValidFrom?: Date;
    ValidUntil: Date;
    UseForShop: boolean;
    UseForShopCompliance: boolean;
    UseForAttestation: boolean;
    KeepMeInformed: boolean;
    UseForHeadPerson: boolean;
    UidOrgRoot?: string[];
    OrderReason?: string;
}
export interface HistoryComparisonData {
    CurrentValueDisplay?: string;
    HasChanged: boolean;
    ChangeType?: string;
    HistoryValueDisplay?: string;
    Property?: string;
    TableName?: string;
    Id?: string;
}
export interface HistoryRollbackActionList {
    ActionId?: string[];
}
export interface ICartItemCheck {
    Id: string;
    Status: any;
    Title: string;
    ResultText: string;
    Detail: any;
}
export interface ICartItemCheckResult {
    HasWarnings: boolean;
    HasErrors: boolean;
    CanCommitSilently: boolean;
}
export interface ImxConfig {
    CompanyLogoUrl?: string;
    ProductName?: string;
    ProductVersion?: string;
}
export interface IObjectChangeInfo {
    Id: string;
    ObjectKey: any;
    ChangeTime: any;
    User: string;
    ChangeType: any;
    ProcessId: string;
    Changes: any;
}
export interface IRoleSplitItem {
    Uid: string;
    Display: string;
    ObjectType: string;
    SplitType: any;
}
export interface ISecondaryAuthProvider {
    Key: string;
    Display: any;
}
export interface ISessionAuthDbConfig {
    SsoAuthentifiers: any;
    ManualAuthentifiers: any;
    AdditionalAuthProps: any;
    AuthenticationType: any;
    Product: string;
    ExcludedAuthentifiers: any;
    SecondaryAuth: any;
    AllowUsersWithoutSecondFactor: boolean;
    AllowPersistentAuth: boolean;
    AuthProviders: any;
}
export interface ITShopConfig {
    /** Specify whether the image specified for a service category is inherited by all child service categories where no image is specified. */
    InheritCategoryImagesToCategories: boolean;
    /** Specify whether the image specified for a service category is inherited by all associated service items where no image is specified. */
    InheritCategoryImagesToItems: boolean;
    VI_ITShop_AddOptionalProductsOnInsert: boolean;
    /** Specify whether approvers must provide a reason when denying a request. */
    VI_ITShop_ApproverReasonMandatoryOnDeny: boolean;
    VI_ITShop_ApproverCanSetValidUntil: boolean;
    VI_ITShop_ExpiringOrders_WarningTime: number;
    StepUpAuthenticationProvider?: string;
    VI_ITShop_ApproverCanSetValidFrom: boolean;
    /** Specify whether pending requests can be canceled. */
    VI_ITShop_OrderHistory_CancelOrder: boolean;
    /** Specify whether approval decisions for requests can be undone. */
    VI_ITShop_OrderHistory_CanRecallDecision: boolean;
    /** Specify whether users can request products that a particular identity already owns (as request by reference user). */
    VI_ITShop_ProductSelectionByReferenceUser: boolean;
    ReferenceUserUseRequestedOnly: boolean;
    /** Specify whether the logged in user is always preselected as a recipient of a new request. */
    VI_ITShop_Employee_Preselected: boolean;
    /** Specify whether users can save unsubscriptions and renewals directly without having to add them to the shopping cart first. */
    VI_ITShop_ProlongateOrCancel_Without_ShoppingCartOrder: boolean;
    VI_ITShop_Prolongation_Offset: number;
    VI_ITShop_EnablePWOPriorityChange: boolean;
    VI_ITShop_WantSeeQueryToPerson: boolean;
    /** Specify whether to show the valid until date for requests of multi-request resources. */
    VI_ITShop_ShowValidUntilQERReuse: boolean;
    VI_ITShop_SubmitOrderImmediately: boolean;
    VI_ITShop_ApproverCanSeeShoppingCartOrder: boolean;
    /** Specify whether approvers and requesters can see who is entitled to approve the request after the current workflow step. */
    VI_ITShop_NextApproverCanBeSeen: boolean;
    /** Specify whether approvers and requesters can see who is entitled to approve the request at the current workflow step. */
    VI_ITShop_CurrentApproversCanBeSeen: boolean;
    /** Specify whether to check if the recipient belongs to the same organizational unit as the requested product. */
    VI_ITShop_ForeignOrgCheck: boolean;
    /** Specify whether to check if the recipient belongs to the same functional area as the requested product. */
    VI_ITShop_ForeignFuncCheck: boolean;
    /** Specify whether to allow requests with dependencies even if a depending product is missing from the request because it is already assigned to the recipient of the request. */
    VI_ITShop_AllowRequestWithMissingDependencies: boolean;
    VI_ITShop_CanCloneCartItemsByPerson: boolean;
    VI_ITShop_CanCloneCartItemsByProduct: boolean;
    /** Specify whether request templates can be used. */
    VI_ITShop_ProductSelectionFromTemplate: boolean;
    /** Specify the properties that are displayed in the detail views of products. */
    AccProductProperties?: string[];
    ApprovalThreshold: number;
    ServiceCatalogViewConfiguration?: ViewConfig;
    ApproverViewConfiguration?: ViewConfig;
    HistoryViewConfiguration?: ViewConfig;
}
/** Activates or de-activates an e-mail subscription for the current user. */
export interface MailSubscriptionChange {
    /** Unique identifiers of the e-mail objects to be processed. */
    UidMail?: string[];
    /** Gets or sets a flag indicating whether the user wants to subscribe or unsubscribe. */
    Unsubscribe: boolean;
}
export interface MergeActionList {
    ActionId?: string[];
}
export interface MergeActions {
    MergePreventionReason?: string;
    Actions?: UiActionData[];
}
export interface MultiLanguageConfig {
    ForeignWords?: ForeignWord[];
}
export interface OtherApproverInput {
    Reason?: string;
    UidPerson?: string;
}
export interface OwnershipConfig {
    /** Specify whether system entitlements that do not have a service item assigned are classified as System entitlements without owners. */
    NoAccproductCountAsMissingOwner: boolean;
    /** These are the main properties required for creating an object. */
    PrimaryFields?: {
        [key: string]: string[];
    };
    EditableFields?: {
        [key: string]: string[];
    };
}
export interface OwnershipInformation {
    TableName?: string;
    TableNameDisplay?: string;
    Count: number;
}
export interface PasswordConfig {
    /** Specify whether users can manage their password questions and answers. */
    VI_MyData_MyPassword_Visibility: boolean;
    /** Enter the web address to the password management application in the format https://www.example.com or http://www.example.com. */
    PasswordMgmtUrl?: string;
    /** Enter the identification domain of Password Manager. */
    QpmIdentificationDomain?: string;
    /** Enter the web address to Password Manager in the format https://www.example.com or http://www.example.com. */
    QpmBaseUrl?: string;
}
export interface PasswordData {
    CheckOnly: boolean;
    NewPassword?: string;
    Ids?: string[];
}
export interface PasswordItemData {
    PasswordLastSet?: Date;
    Id?: string;
    PolicyName?: string;
    Display?: string;
    ObjectKey?: string;
    Type: PasswordItemType;
    IsManagedCentrally: boolean;
    IsCentralPassword: boolean;
}
export interface PasswordItemsData {
    IsPwdResetDisallowed: boolean;
    Policies?: PolicyInfo[];
    Items?: PasswordItemData[];
}
export declare enum PasswordItemType {
    Personal = 0,
    Other = 1
}
export interface PasswordQuestion {
    Uid?: string;
    Question?: string;
}
export interface PasswordResetAuthModel {
    EnoughQuestions: boolean;
    Questions?: PasswordQuestion[];
}
export interface PersonConfig {
    /** Specify whether to display organizational charts for identities in the address book. */
    ShowOrgChart: boolean;
    VI_Employee_MasterData_Attributes?: string[];
    VI_Employee_MasterData_LocalityAttributes?: string[];
    VI_Employee_MasterData_OrganizationalAttributes?: string[];
    /** Specify how long passcodes are valid. */
    VI_Employee_MasterData_PassCode_HoursValid: number;
    VI_Employee_MasterData_DoNotMerge?: string[];
    VI_MyData_WhitePages_ResultAttributes?: string[];
    VI_MyData_WhitePages_DetailAttributes?: string[];
    VI_PersonalData_Fields?: string[];
    AddressbookConfig?: ViewConfig;
}
export interface PersonPasscodeResult {
    PassCode?: string;
    UID_PersonManager?: string;
    PasscodeSplit: boolean;
}
export interface PolicyInfo {
    PolicyName?: string;
    Infos?: string[];
}
export interface PolicyValidationResult {
    PolicyName?: string;
    ErrorMessages?: string[];
}
export interface PrimaryAssignmentChange {
    UserUpdated?: string;
    DateUpdated: Date;
    OldValueDisplay?: string;
}
export interface ProcessChain {
    Display?: string;
    ObjectKey?: string;
    JobChainName?: string;
    UidTree?: string;
    ProcessState: ProcessState;
    XDateInserted: Date;
    XDateUpdated: Date;
    Steps?: ProcessStep[];
}
export declare enum ProcessState {
    E = 0,
    F = 1,
    N = 2,
    D = 3,
    L = 4,
    P = 5,
    G = 6
}
export interface ProcessStep {
    Display?: string;
    UidTree?: string;
    UidJob?: string;
    XDateUpdated: Date;
    ProcessState: ProcessState;
}
export interface ProjectConfig {
    CandidateConfig?: {
        [key: string]: CandidateData[];
    };
    /** Enter the instrumentation key required to log metrics to App Insights. */
    AppInsightsKey?: string;
    /** Specify whether the web application sends browser notifications (for example, for pending requests or pending attestations). Users can still deactivate browser notifications. */
    VI_Common_EnableNotifications: boolean;
    /** Specify whether images are resized automatically when uploaded to the server. */
    EnableImageResizing: boolean;
    /** Enter the site key (public key) for reCAPTCHA integration. */
    RecaptchaPublicKey?: string;
    DefaultPageSize: number;
    /** Specify how many of the previous days to take into account by default when generating reports. */
    DefaultHistoryLengthDays: number;
}
export interface ProlongationInput {
    Reason?: string;
    UidJustification?: string;
    ProlongationDate: Date;
}
export interface PwoData {
    WorkflowHistory?: EntityCollectionData;
    WorkflowData?: EntityCollectionData;
    WorkflowSteps?: EntityCollectionData;
    Recommendation?: RecommendationData;
    CanRecallDecision: boolean;
    CanRevokeDelegation: boolean;
    CanAskForHelp: boolean;
}
export interface PwoExtendedData {
    Data?: PwoData[];
    Parameters?: {
        [key: string]: ParameterData[][];
    };
}
export interface PwoQueryInput {
    UidPerson?: string;
    Text?: string;
}
export interface PwoUnsubscribeInput {
    UnsubscribeFrom?: Date;
    Reason?: string;
    UidJustification?: string;
    UidPwo?: string[];
}
export interface PwoUnsubscribeResult {
    UidCartItem?: string[];
}
export interface QerProjectConfig {
    PasswordConfig?: PasswordConfig;
    AuthenticationConfig?: AuthenticationConfig;
    DeviceConfig?: DeviceConfig;
    ITShopConfig?: ITShopConfig;
    PersonConfig?: PersonConfig;
    RoleMgmtConfig?: RoleMgmtConfig;
    OwnershipConfig?: OwnershipConfig;
    /** Specify the risk index threshold above which objects are considered critical. */
    RiskThresholdHigh: number;
}
export interface QpmIntegrationLinks {
    ChangePassword?: string;
    EditProfile?: string;
    ChangeSettings?: string;
}
export interface ReasonInput {
    Reason?: string;
}
export interface RecallDecisionInput {
    Reason?: string;
    UidJustification?: string;
}
export interface RecommendationData {
    Recommendation: RecommendationEnum;
    Items?: RecommendationDataItem[];
}
export interface RecommendationDataItem {
    Display?: string;
    Detail?: string;
    Weight?: number;
    Value?: any;
}
export declare enum RecommendationEnum {
    None = 0,
    Deny = 1,
    Approve = 2
}
export interface RelatedApplication {
    Display?: string;
    DisplayType?: string;
    Description?: string;
    Icon?: string;
    Url?: string;
    ChildApps?: RelatedApplication[];
}
export interface RequestableProductForPerson extends ServiceItemForPerson {
    UidITShopOrg?: string;
    Display?: string;
    DisplayRecipient?: string;
}
export interface RequestStepUpApprovalData {
    UidPwo?: string[];
}
export interface RestoreActionList {
    ActionId?: string[];
}
export interface RestoreActions {
    Actions?: UiActionData[];
}
/** Represents a serializable summary of an action result. */
export interface ResultInfo {
    /** Returns a descriptive text for the action. */
    Display?: string;
    /** Returns a descriptive text for the corresponding object. */
    ObjectDisplay?: string;
    /** Gets or sets the result state. */
    State: ActionState;
    /** Gets or sets the exception message, if any exception occurred during execution. */
    ExceptionText?: string;
}
export interface RiskObject {
    UidQerRiskIndex?: string;
    Display?: string;
    Description?: string;
    SourceValue: number;
    ObjectKeySource?: string;
    TargetDisplay?: string;
    SourceDisplay?: string;
    ObjectKeyTarget?: string;
    /** If ObjectKeyTarget points to an assignment table, and if
ObjectKeySource is empty, then this property contains the object key of the object referenced by
the assignment. */
    ObjectKeyTargetLeaf?: string;
    TypeOfCalculation?: string;
    CalculationBase: number;
    ResultValue: number;
    Weight: number;
    ValueNotWeighted: number;
    Children?: RiskObject[];
}
export interface RoleAssignmentData {
    TableName?: string;
    TableDisplay?: string;
    UnionTableName?: string;
    UnionTableDisplay?: string;
    AssignTable?: string;
    RoleTable?: string;
    RoleFk?: string;
    EntitlementPk?: string;
    EntitlementFk?: string;
}
export interface RoleCompareItem {
    ObjectTypeDisplay?: string;
    Display?: string;
    XOriginRole1: number;
    XOriginRole2: number;
}
export interface RoleCompareItems {
    OriginCaptions?: string[];
    Items?: RoleCompareItem[];
}
export interface RoleExtendedDataWrite {
    NewDynamicRole?: SqlExpression;
    RoleSplit?: RoleSplitActionInput;
}
export interface RoleMgmtConfig {
    /** Specify whether role owners are allowed to copy or move memberships and entitlements from roles to new roles. */
    Allow_Roles_Split_By_Business_Owner: boolean;
    /** Specify whether administrators are allowed to copy or move memberships and entitlements from roles to new roles. */
    Allow_Roles_Split_By_Admin: boolean;
    /** Specify whether memberships and entitlements can be copied or moved from roles to new roles of a different type. */
    Allow_Roles_Split_Different_Organisation_Type: boolean;
    /** Specify whether role owners are allowed to merge memberships and entitlements of roles into other roles. */
    Allow_Roles_Merge_By_Business_Owner: boolean;
    /** Specify whether administrators are allowed to merge memberships and entitlements of roles into other roles. */
    Allow_Roles_Merge_By_Admin: boolean;
    /** Specify whether memberships and entitlements of roles can be merged into other roles of a different type. */
    Allow_Roles_Merge_Different_Organisation_Type: boolean;
    /** Specify whether memberships and entitlements of roles can be merged into other roles of a different role class. */
    Allow_Roles_Merge_Different_Role_Class: boolean;
}
export interface RoleSplitActionInput extends RoleSplitInput {
    SourceRoleObjectKey?: string;
    ActionIds?: string[];
}
export interface RoleSplitInput {
    SplitItems?: RoleSplitInputItem[];
}
export interface RoleSplitInputItem {
    Item?: string;
    Type: RoleSplitItemType;
}
export declare enum RoleSplitItemType {
    Keep = 0,
    Copy = 1,
    Move = 2
}
export interface SearchResultObject {
    Key?: string;
    Display?: string;
}
export interface ServiceItemForPerson {
    UidAccProduct?: string;
    UidAccProductParent?: string;
    UidPerson?: string;
}
export interface ServiceItemHierarchy {
    Display?: string;
    UidAccProduct?: string;
    Optional?: ServiceItemHierarchy[];
    Mandatory?: ServiceItemHierarchy[];
}
export interface ServiceItemsExtendedData {
    PeerGroupSize: number;
}
/** Represents for a single hyperview shape. */
export interface ShapeData {
    /** Returns a flag indicating whether the shape should show that the object is in a deleted state. */
    IsDeleted: boolean;
    /** Returns the title caption of the shape. */
    Caption?: string;
    /** Returns an optional, secondary header text. */
    HeaderText?: string;
    Identifier?: string;
    /** Returns the object key of the associated object. */
    ObjectKey?: string;
    /** Returns the shape color to use, in ARGB hex format. */
    ElementColor?: string;
    Description?: string;
    TableName?: string;
    DbWhereClause?: string;
    /** Returns a list of elements to be displayed inside this shape. */
    Elements?: ShapeListEntry[];
    /** Returns a flag indicating whether the list of element is truncated because
the maximum number of elements was reached. */
    IsLimitReached?: boolean;
    /** Returns the layout type to use for this shape. */
    LayoutType?: string;
    ImageUid?: string;
    DbTableName?: string;
    /** Returns a list of properties to be displayed inside this shape. */
    Properties?: ShapeProperty[];
}
export interface ShapeListEntry {
    /** Returns the object key of the associated object. This property may be null. */
    ObjectKey?: string;
    DisplayValue?: string;
}
export interface ShapeProperty {
    Property?: string;
    DbColumnName?: string;
    EndsSection?: boolean;
    Value?: EntityColumnData;
}
/** Represents a node in the source detective tree. */
export interface SourceNode {
    ObjectKey?: string;
    /** Display of the source object. */
    ObjectDisplay?: string;
    ObjectDisplayParameters?: {
        [key: string]: string;
    };
    /** Type of the source object. */
    ObjectType?: string;
    /** Gets or sets a flag indicating whether this is a primary assignment to the employee. */
    IsPrimaryAssignment: boolean;
    /** If this a primary assignment; contains information about the most recent change of
the primary assignment. */
    LastPrimaryAssignmentChange?: PrimaryAssignmentChange;
    Children?: SourceNode[];
}
export interface SqlWizardRead {
    Expressions?: SqlWizardExpression[];
}
export interface SqlWizardWrite {
    Filters?: SqlExpression[];
}
export declare enum StatisticAggregateFunction {
    None = 0,
    Sum = 1,
    Average = 2
}
export declare enum StatisticTimeScaleUnit {
    Undefined = 0,
    Hour = 1,
    Day = 2,
    Week = 3,
    Month = 4,
    Quarter = 5,
    Year = 6
}
export interface UiActionData {
    Id?: string;
    IsActive: boolean;
    CanExecute: boolean;
    Display?: string;
    ObjectDisplay?: string;
}
export interface UiActionResultData {
    Display?: string;
    ObjectDisplay?: string;
    Exceptions?: ExceptionData[];
    State: ActionState;
}
export interface UiSetting {
    Key?: string;
    Value?: any;
}
export interface UserConfig {
    IsITShopEnabled: boolean;
    Settings?: {
        [key: string]: any;
    };
    CanRequestForSomebodyElse: boolean;
    Ownerships?: OwnershipInformation[];
    IsHistoryActive: boolean;
    HasPasswordAnswer: boolean;
    RequiredPasswordQuestions: number;
    ShowPasswordTile: boolean;
    CountRequestsEndingSoon: number;
    CountPendingRequests: number;
}
export interface UserGroupInfo {
    Uid?: string;
    Name?: string;
}
export interface ViewConfig {
    /** Specify what information per entry users can display in the table. */
    AdditionalListColumns?: string[];
    /** Specify which additional columns users can display in the table. */
    OptionalColumns?: string[];
    /** Specify which additional columns are displayed in the table. */
    AdditionalTableColumns?: string[];
}
export interface WebauthnConfig {
    NewKeyUrl?: string;
}
export declare class TypedClient {
    readonly PasswordresetPasswordquestions: PasswordresetPasswordquestionsWrapper;
    readonly PortalAdminApplicationrole: PortalAdminApplicationroleWrapper;
    readonly PortalAdminApplicationroleMembers: PortalAdminApplicationroleMembersWrapper;
    readonly PortalAdminPerson: PortalAdminPersonWrapper;
    readonly PortalAdminResourcesQerassign: PortalAdminResourcesQerassignWrapper;
    readonly PortalAdminResourcesQerassignInteractive: PortalAdminResourcesQerassignInteractiveWrapper;
    readonly PortalAdminResourcesQerresource: PortalAdminResourcesQerresourceWrapper;
    readonly PortalAdminResourcesQerresourceInteractive: PortalAdminResourcesQerresourceInteractiveWrapper;
    readonly PortalAdminResourcesQerreuse: PortalAdminResourcesQerreuseWrapper;
    readonly PortalAdminResourcesQerreuseInteractive: PortalAdminResourcesQerreuseInteractiveWrapper;
    readonly PortalAdminResourcesQerreuseus: PortalAdminResourcesQerreuseusWrapper;
    readonly PortalAdminResourcesQerreuseusInteractive: PortalAdminResourcesQerreuseusInteractiveWrapper;
    readonly PortalAdminRoleDepartment: PortalAdminRoleDepartmentWrapper;
    readonly PortalAdminRoleDepartmentInteractive: PortalAdminRoleDepartmentInteractiveWrapper;
    readonly PortalAdminRoleLocality: PortalAdminRoleLocalityWrapper;
    readonly PortalAdminRoleLocalityInteractive: PortalAdminRoleLocalityInteractiveWrapper;
    readonly PortalAdminRoleProfitcenter: PortalAdminRoleProfitcenterWrapper;
    readonly PortalAdminRoleProfitcenterInteractive: PortalAdminRoleProfitcenterInteractiveWrapper;
    readonly PortalCandidatesAccproduct: PortalCandidatesAccproductWrapper;
    readonly PortalCandidatesAccproductgroup: PortalCandidatesAccproductgroupWrapper;
    readonly PortalCandidatesAccproductparamcategory: PortalCandidatesAccproductparamcategoryWrapper;
    readonly PortalCandidatesDepartment: PortalCandidatesDepartmentWrapper;
    readonly PortalCandidatesDialoguser: PortalCandidatesDialoguserWrapper;
    readonly PortalCandidatesFirmpartner: PortalCandidatesFirmpartnerWrapper;
    readonly PortalCandidatesHelperheadorg: PortalCandidatesHelperheadorgWrapper;
    readonly PortalCandidatesHelperheadperson: PortalCandidatesHelperheadpersonWrapper;
    readonly PortalCandidatesLocality: PortalCandidatesLocalityWrapper;
    readonly PortalCandidatesPerson: PortalCandidatesPersonWrapper;
    readonly PortalCandidatesPersoninaerole: PortalCandidatesPersoninaeroleWrapper;
    readonly PortalCandidatesPersonindepartment: PortalCandidatesPersonindepartmentWrapper;
    readonly PortalCandidatesPersoninitshoporg: PortalCandidatesPersoninitshoporgWrapper;
    readonly PortalCandidatesPersoninlocality: PortalCandidatesPersoninlocalityWrapper;
    readonly PortalCandidatesPersoninprofitcenter: PortalCandidatesPersoninprofitcenterWrapper;
    readonly PortalCandidatesProfitcenter: PortalCandidatesProfitcenterWrapper;
    readonly PortalCandidatesPwodecisionmethod: PortalCandidatesPwodecisionmethodWrapper;
    readonly PortalCandidatesQbmculture: PortalCandidatesQbmcultureWrapper;
    readonly PortalCandidatesQerjustification: PortalCandidatesQerjustificationWrapper;
    readonly PortalCandidatesQerpickcategory: PortalCandidatesQerpickcategoryWrapper;
    readonly PortalCandidatesWorkdesk: PortalCandidatesWorkdeskWrapper;
    readonly PortalCartitem: PortalCartitemWrapper;
    readonly PortalCartitemInteractive: PortalCartitemInteractiveWrapper;
    readonly PortalCartitemInteractiveParameterCandidates: PortalCartitemInteractiveParameterCandidatesWrapper;
    readonly PortalCartitemParameterCandidates: PortalCartitemParameterCandidatesWrapper;
    readonly PortalDelegable: PortalDelegableWrapper;
    readonly PortalDelegations: PortalDelegationsWrapper;
    readonly PortalDelegationsGlobalRoleclasses: PortalDelegationsGlobalRoleclassesWrapper;
    readonly PortalDynamicgroup: PortalDynamicgroupWrapper;
    readonly PortalDynamicgroupInteractive: PortalDynamicgroupInteractiveWrapper;
    readonly PortalDynamicgroupSqlwizardCandidates: PortalDynamicgroupSqlwizardCandidatesWrapper;
    readonly PortalItshopApproveHistory: PortalItshopApproveHistoryWrapper;
    readonly PortalItshopApproveRequests: PortalItshopApproveRequestsWrapper;
    readonly PortalItshopApproveRequestsParameterCandidates: PortalItshopApproveRequestsParameterCandidatesWrapper;
    readonly PortalItshopCart: PortalItshopCartWrapper;
    readonly PortalItshopPattern: PortalItshopPatternWrapper;
    readonly PortalItshopPatternAdmin: PortalItshopPatternAdminWrapper;
    readonly PortalItshopPatternItem: PortalItshopPatternItemWrapper;
    readonly PortalItshopPatternPrivate: PortalItshopPatternPrivateWrapper;
    readonly PortalItshopPatternRequestable: PortalItshopPatternRequestableWrapper;
    readonly PortalItshopPeergroup: PortalItshopPeergroupWrapper;
    readonly PortalItshopPeergroupMemberships: PortalItshopPeergroupMembershipsWrapper;
    readonly PortalItshopPersondecision: PortalItshopPersondecisionWrapper;
    readonly PortalItshopRequests: PortalItshopRequestsWrapper;
    readonly PortalItshopRequestsParameterCandidates: PortalItshopRequestsParameterCandidatesWrapper;
    readonly PortalJustifications: PortalJustificationsWrapper;
    readonly PortalPasswordquestions: PortalPasswordquestionsWrapper;
    readonly PortalPersonActive: PortalPersonActiveWrapper;
    readonly PortalPersonAll: PortalPersonAllWrapper;
    readonly PortalPersonEmail: PortalPersonEmailWrapper;
    readonly PortalPersonMasterdata: PortalPersonMasterdataWrapper;
    readonly PortalPersonMasterdataInteractive: PortalPersonMasterdataInteractiveWrapper;
    readonly PortalPersonMemberships: PortalPersonMembershipsWrapper;
    readonly PortalPersonOrgdata: PortalPersonOrgdataWrapper;
    readonly PortalPersonOverview: PortalPersonOverviewWrapper;
    readonly PortalPersonReports: PortalPersonReportsWrapper;
    readonly PortalPersonReportsInteractive: PortalPersonReportsInteractiveWrapper;
    readonly PortalPersonRequestmanagerchange: PortalPersonRequestmanagerchangeWrapper;
    readonly PortalPersonRolemembershipsAerole: PortalPersonRolemembershipsAeroleWrapper;
    readonly PortalPersonRolemembershipsDepartment: PortalPersonRolemembershipsDepartmentWrapper;
    readonly PortalPersonRolemembershipsItshoporg: PortalPersonRolemembershipsItshoporgWrapper;
    readonly PortalPersonRolemembershipsLocality: PortalPersonRolemembershipsLocalityWrapper;
    readonly PortalPersonRolemembershipsProfitcenter: PortalPersonRolemembershipsProfitcenterWrapper;
    readonly PortalPersonUid: PortalPersonUidWrapper;
    readonly PortalPickcategory: PortalPickcategoryWrapper;
    readonly PortalPickcategoryItems: PortalPickcategoryItemsWrapper;
    readonly PortalResourcesMembershipQerresource: PortalResourcesMembershipQerresourceWrapper;
    readonly PortalResourcesQerassignServiceitem: PortalResourcesQerassignServiceitemWrapper;
    readonly PortalResourcesQerresourceServiceitem: PortalResourcesQerresourceServiceitemWrapper;
    readonly PortalResourcesQerreuseServiceitem: PortalResourcesQerreuseServiceitemWrapper;
    readonly PortalResourcesQerreuseusServiceitem: PortalResourcesQerreuseusServiceitemWrapper;
    readonly PortalRespAerole: PortalRespAeroleWrapper;
    readonly PortalRespAeroleInteractive: PortalRespAeroleInteractiveWrapper;
    readonly PortalRespDepartment: PortalRespDepartmentWrapper;
    readonly PortalRespDepartmentInteractive: PortalRespDepartmentInteractiveWrapper;
    readonly PortalRespLocality: PortalRespLocalityWrapper;
    readonly PortalRespLocalityInteractive: PortalRespLocalityInteractiveWrapper;
    readonly PortalRespProfitcenter: PortalRespProfitcenterWrapper;
    readonly PortalRespProfitcenterInteractive: PortalRespProfitcenterInteractiveWrapper;
    readonly PortalRiskFunctions: PortalRiskFunctionsWrapper;
    readonly PortalRolesConfigDepartmentPrimarymembers: PortalRolesConfigDepartmentPrimarymembersWrapper;
    readonly PortalRolesConfigLocalityPrimarymembers: PortalRolesConfigLocalityPrimarymembersWrapper;
    readonly PortalRolesConfigProfitcenterPrimarymembers: PortalRolesConfigProfitcenterPrimarymembersWrapper;
    readonly PortalRolesEntitlements: PortalRolesEntitlementsWrapper;
    readonly PortalRolesExclusions: PortalRolesExclusionsWrapper;
    readonly PortalServicecategories: PortalServicecategoriesWrapper;
    readonly PortalServicecategoriesInteractive: PortalServicecategoriesInteractiveWrapper;
    readonly PortalServiceitems: PortalServiceitemsWrapper;
    readonly PortalServiceitemsInteractive: PortalServiceitemsInteractiveWrapper;
    readonly PortalServiceitemsTags: PortalServiceitemsTagsWrapper;
    readonly PortalShopCategories: PortalShopCategoriesWrapper;
    readonly PortalShopConfigEntitlements: PortalShopConfigEntitlementsWrapper;
    readonly PortalShopConfigEntitlementsQerassign: PortalShopConfigEntitlementsQerassignWrapper;
    readonly PortalShopConfigEntitlementsQerresource: PortalShopConfigEntitlementsQerresourceWrapper;
    readonly PortalShopConfigEntitlementsQerreuse: PortalShopConfigEntitlementsQerreuseWrapper;
    readonly PortalShopConfigEntitlementsQerreuseus: PortalShopConfigEntitlementsQerreuseusWrapper;
    readonly PortalShopConfigMembers: PortalShopConfigMembersWrapper;
    readonly PortalShopConfigStructure: PortalShopConfigStructureWrapper;
    readonly PortalShopServiceitems: PortalShopServiceitemsWrapper;
    readonly PortalShopServiceitemsEntitlements: PortalShopServiceitemsEntitlementsWrapper;
    readonly PortalTermsofuse: PortalTermsofuseWrapper;
    readonly PortalView: PortalViewWrapper;
    readonly PortalWebauthnkey: PortalWebauthnkeyWrapper;
    readonly PortalWorkflow: PortalWorkflowWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PasswordresetPasswordquestions extends TypedEntity {
    readonly PasswordQuery: IWriteValue<string>;
    readonly IsLocked: IReadValue<boolean>;
    readonly SortOrder: IWriteValue<number>;
    readonly PasswordAnswer: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'PasswordQuery' | 'IsLocked' | 'SortOrder' | 'PasswordAnswer'>;
}
export declare class PortalAdminApplicationrole extends TypedEntity {
    readonly UID_AERole: IReadValue<string>;
    readonly Description: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly UID_DynamicGroup: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_AERole' | 'Description' | 'XObjectKey' | 'UID_DynamicGroup'>;
}
export declare class PortalAdminApplicationroleMembers extends TypedEntity {
    readonly UID_AERole: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly UID_Person: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_AERole' | 'XOrigin' | 'UID_Person'>;
}
export declare class PortalAdminPerson extends TypedEntity {
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly IdentityType: IReadValue<string>;
    readonly FirstName: IReadValue<string>;
    readonly LastName: IReadValue<string>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly DefaultEmailAddress: IReadValue<string>;
    readonly IsInActive: IWriteValue<boolean>;
    readonly IsSecurityIncident: IWriteValue<boolean>;
    readonly UID_PersonHead: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XMarkedForDeletion' | 'IdentityType' | 'FirstName' | 'LastName' | 'RiskIndexCalculated' | 'DefaultEmailAddress' | 'IsInActive' | 'IsSecurityIncident' | 'UID_PersonHead'>;
}
export declare class PortalAdminResourcesQerassign extends TypedEntity {
    readonly Ident_QERAssign: IReadValue<string>;
    readonly UID_AccProduct: IReadValue<string>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Ident_QERAssign' | 'UID_AccProduct' | 'Requestable' | 'Owned'>;
}
export declare class PortalAdminResourcesQerassignInteractive extends TypedEntity {
    readonly Ident_QERAssign: IReadValue<string>;
    readonly UID_AccProduct: IReadValue<string>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Ident_QERAssign' | 'UID_AccProduct' | 'Requestable' | 'Owned'>;
}
export declare class PortalAdminResourcesQerresource extends TypedEntity {
    readonly Ident_QERResource: IReadValue<string>;
    readonly UID_AccProduct: IReadValue<string>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Ident_QERResource' | 'UID_AccProduct' | 'Requestable' | 'Owned'>;
}
export declare class PortalAdminResourcesQerresourceInteractive extends TypedEntity {
    readonly Ident_QERResource: IReadValue<string>;
    readonly UID_AccProduct: IReadValue<string>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Ident_QERResource' | 'UID_AccProduct' | 'Requestable' | 'Owned'>;
}
export declare class PortalAdminResourcesQerreuse extends TypedEntity {
    readonly Ident_QERReuse: IReadValue<string>;
    readonly UID_AccProduct: IReadValue<string>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Ident_QERReuse' | 'UID_AccProduct' | 'Requestable' | 'Owned'>;
}
export declare class PortalAdminResourcesQerreuseInteractive extends TypedEntity {
    readonly Ident_QERReuse: IReadValue<string>;
    readonly UID_AccProduct: IReadValue<string>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Ident_QERReuse' | 'UID_AccProduct' | 'Requestable' | 'Owned'>;
}
export declare class PortalAdminResourcesQerreuseus extends TypedEntity {
    readonly Ident_QERReuseUS: IReadValue<string>;
    readonly UID_AccProduct: IReadValue<string>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Ident_QERReuseUS' | 'UID_AccProduct' | 'Requestable' | 'Owned'>;
}
export declare class PortalAdminResourcesQerreuseusInteractive extends TypedEntity {
    readonly Ident_QERReuseUS: IReadValue<string>;
    readonly UID_AccProduct: IReadValue<string>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Ident_QERReuseUS' | 'UID_AccProduct' | 'Requestable' | 'Owned'>;
}
export declare class PortalAdminRoleDepartment extends WriteExtTypedEntity<RoleExtendedDataWrite> {
    readonly XObjectKey: IReadValue<string>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly UID_DynamicGroup: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'RiskIndexCalculated' | 'UID_DynamicGroup'>;
}
export declare class PortalAdminRoleDepartmentInteractive extends WriteExtTypedEntity<RoleExtendedDataWrite> {
    readonly XObjectKey: IReadValue<string>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly UID_DynamicGroup: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'RiskIndexCalculated' | 'UID_DynamicGroup'>;
}
export declare class PortalAdminRoleLocality extends WriteExtTypedEntity<RoleExtendedDataWrite> {
    readonly XObjectKey: IReadValue<string>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly UID_DynamicGroup: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'RiskIndexCalculated' | 'UID_DynamicGroup'>;
}
export declare class PortalAdminRoleLocalityInteractive extends WriteExtTypedEntity<RoleExtendedDataWrite> {
    readonly XObjectKey: IReadValue<string>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly UID_DynamicGroup: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'RiskIndexCalculated' | 'UID_DynamicGroup'>;
}
export declare class PortalAdminRoleProfitcenter extends WriteExtTypedEntity<RoleExtendedDataWrite> {
    readonly XObjectKey: IReadValue<string>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly UID_DynamicGroup: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'RiskIndexCalculated' | 'UID_DynamicGroup'>;
}
export declare class PortalAdminRoleProfitcenterInteractive extends WriteExtTypedEntity<RoleExtendedDataWrite> {
    readonly XObjectKey: IReadValue<string>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly UID_DynamicGroup: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'RiskIndexCalculated' | 'UID_DynamicGroup'>;
}
export declare class PortalCandidatesAccproduct extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_AccProduct: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_AccProduct'>;
}
export declare class PortalCandidatesAccproductgroup extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_AccProductGroup: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_AccProductGroup'>;
}
export declare class PortalCandidatesAccproductparamcategory extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_AccProductParamCategory: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_AccProductParamCategory'>;
}
export declare class PortalCandidatesDepartment extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_Department: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_Department'>;
}
export declare class PortalCandidatesDialoguser extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_DialogUser: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_DialogUser'>;
}
export declare class PortalCandidatesFirmpartner extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_FirmPartner: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_FirmPartner'>;
}
export declare class PortalCandidatesHelperheadorg extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_Org: IReadValue<string>;
    readonly UID_PersonHead: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_Org' | 'UID_PersonHead'>;
}
export declare class PortalCandidatesHelperheadperson extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_Person: IReadValue<string>;
    readonly UID_PersonHead: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_Person' | 'UID_PersonHead'>;
}
export declare class PortalCandidatesLocality extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_Locality: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_Locality'>;
}
export declare class PortalCandidatesPerson extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_Person: IReadValue<string>;
    readonly DefaultEmailAddress: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_Person' | 'DefaultEmailAddress'>;
}
export declare class PortalCandidatesPersoninaerole extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_AERole: IReadValue<string>;
    readonly UID_Person: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_AERole' | 'UID_Person'>;
}
export declare class PortalCandidatesPersonindepartment extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_Department: IReadValue<string>;
    readonly UID_Person: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_Department' | 'UID_Person'>;
}
export declare class PortalCandidatesPersoninitshoporg extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_ITShopOrg: IReadValue<string>;
    readonly UID_Person: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_ITShopOrg' | 'UID_Person'>;
}
export declare class PortalCandidatesPersoninlocality extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_Locality: IReadValue<string>;
    readonly UID_Person: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_Locality' | 'UID_Person'>;
}
export declare class PortalCandidatesPersoninprofitcenter extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_Person: IReadValue<string>;
    readonly UID_ProfitCenter: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_Person' | 'UID_ProfitCenter'>;
}
export declare class PortalCandidatesProfitcenter extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_ProfitCenter: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_ProfitCenter'>;
}
export declare class PortalCandidatesPwodecisionmethod extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_PWODecisionMethod: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_PWODecisionMethod'>;
}
export declare class PortalCandidatesQbmculture extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_DialogCulture: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_DialogCulture'>;
}
export declare class PortalCandidatesQerjustification extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_QERJustification: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_QERJustification'>;
}
export declare class PortalCandidatesQerpickcategory extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_QERPickCategory: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_QERPickCategory'>;
}
export declare class PortalCandidatesWorkdesk extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_WorkDesk: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_WorkDesk'>;
}
export declare class PortalCartitem extends WriteExtTypedEntity<{
    [key: string]: EntityWriteDataColumn[][];
}> {
    readonly UID_PersonInserted: IReadValue<string>;
    readonly UID_PersonOrdered: IWriteValue<string>;
    readonly IsOptionalChild: IReadValue<boolean>;
    readonly UID_PersonWantsOrg: IReadValue<string>;
    readonly UID_ShoppingCartOrder: IWriteValue<string>;
    readonly UID_ShoppingCartItemParent: IWriteValue<string>;
    readonly UID_AccProduct: IReadValue<string>;
    readonly CheckResult: IReadValue<number>;
    readonly CustomProperty01: IWriteValue<string>;
    readonly CustomProperty02: IWriteValue<string>;
    readonly CustomProperty03: IWriteValue<string>;
    readonly CustomProperty04: IWriteValue<string>;
    readonly CustomProperty05: IWriteValue<string>;
    readonly CustomProperty06: IWriteValue<string>;
    readonly CustomProperty07: IWriteValue<string>;
    readonly CustomProperty08: IWriteValue<string>;
    readonly CustomProperty09: IWriteValue<string>;
    readonly CustomProperty10: IWriteValue<string>;
    readonly OrderReason: IWriteValue<string>;
    readonly PWOPriority: IWriteValue<number>;
    readonly UID_Department: IWriteValue<string>;
    readonly UID_ITShopOrg: IWriteValue<string>;
    readonly UID_ProfitCenter: IWriteValue<string>;
    readonly UID_QERJustificationOrder: IWriteValue<string>;
    readonly ValidFrom: IWriteValue<Date>;
    readonly ValidUntil: IWriteValue<Date>;
    readonly DisplayType: IReadValue<string>;
    readonly UID_PatternItem: IWriteValue<string>;
    readonly RequestType: IReadValue<string>;
    readonly TableName: IReadValue<string>;
    readonly CanCopy: IReadValue<boolean>;
    readonly UID_QERTermsOfUse: IReadValue<string>;
    readonly MaxValidDays: IReadValue<number>;
    readonly Assignment: IReadValue<string>;
    readonly ElementAssigned: IReadValue<string>;
    readonly ElementAssignedTo: IReadValue<string>;
    readonly CanHaveOptionalProducts: IReadValue<boolean>;
    readonly ValidUntilUnsubscribe: IWriteValue<Date>;
    readonly OrderReasonType: IReadValue<number>;
    readonly ProlongationDate: IWriteValue<Date>;
    readonly RoleMembership: IWriteValue<string>;
    readonly EntitlementData: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_PersonInserted' | 'UID_PersonOrdered' | 'IsOptionalChild' | 'UID_PersonWantsOrg' | 'UID_ShoppingCartOrder' | 'UID_ShoppingCartItemParent' | 'UID_AccProduct' | 'CheckResult' | 'CustomProperty01' | 'CustomProperty02' | 'CustomProperty03' | 'CustomProperty04' | 'CustomProperty05' | 'CustomProperty06' | 'CustomProperty07' | 'CustomProperty08' | 'CustomProperty09' | 'CustomProperty10' | 'OrderReason' | 'PWOPriority' | 'UID_Department' | 'UID_ITShopOrg' | 'UID_ProfitCenter' | 'UID_QERJustificationOrder' | 'ValidFrom' | 'ValidUntil' | 'DisplayType' | 'UID_PatternItem' | 'RequestType' | 'TableName' | 'CanCopy' | 'UID_QERTermsOfUse' | 'MaxValidDays' | 'Assignment' | 'ElementAssigned' | 'ElementAssignedTo' | 'CanHaveOptionalProducts' | 'ValidUntilUnsubscribe' | 'OrderReasonType' | 'ProlongationDate' | 'RoleMembership' | 'EntitlementData'>;
}
export declare class PortalCartitemInteractive extends WriteExtTypedEntity<{
    [key: string]: EntityWriteDataColumn[][];
}> {
    readonly UID_PersonInserted: IReadValue<string>;
    readonly UID_PersonOrdered: IWriteValue<string>;
    readonly IsOptionalChild: IReadValue<boolean>;
    readonly UID_PersonWantsOrg: IReadValue<string>;
    readonly UID_ShoppingCartOrder: IWriteValue<string>;
    readonly UID_ShoppingCartItemParent: IWriteValue<string>;
    readonly UID_AccProduct: IReadValue<string>;
    readonly CheckResult: IReadValue<number>;
    readonly CustomProperty01: IWriteValue<string>;
    readonly CustomProperty02: IWriteValue<string>;
    readonly CustomProperty03: IWriteValue<string>;
    readonly CustomProperty04: IWriteValue<string>;
    readonly CustomProperty05: IWriteValue<string>;
    readonly CustomProperty06: IWriteValue<string>;
    readonly CustomProperty07: IWriteValue<string>;
    readonly CustomProperty08: IWriteValue<string>;
    readonly CustomProperty09: IWriteValue<string>;
    readonly CustomProperty10: IWriteValue<string>;
    readonly OrderReason: IWriteValue<string>;
    readonly PWOPriority: IWriteValue<number>;
    readonly UID_Department: IWriteValue<string>;
    readonly UID_ITShopOrg: IWriteValue<string>;
    readonly UID_ProfitCenter: IWriteValue<string>;
    readonly UID_QERJustificationOrder: IWriteValue<string>;
    readonly ValidFrom: IWriteValue<Date>;
    readonly ValidUntil: IWriteValue<Date>;
    readonly DisplayType: IReadValue<string>;
    readonly UID_PatternItem: IWriteValue<string>;
    readonly RequestType: IReadValue<string>;
    readonly TableName: IReadValue<string>;
    readonly CanCopy: IReadValue<boolean>;
    readonly UID_QERTermsOfUse: IReadValue<string>;
    readonly MaxValidDays: IReadValue<number>;
    readonly Assignment: IReadValue<string>;
    readonly ElementAssigned: IReadValue<string>;
    readonly ElementAssignedTo: IReadValue<string>;
    readonly CanHaveOptionalProducts: IReadValue<boolean>;
    readonly ValidUntilUnsubscribe: IWriteValue<Date>;
    readonly OrderReasonType: IReadValue<number>;
    readonly ProlongationDate: IWriteValue<Date>;
    readonly RoleMembership: IWriteValue<string>;
    readonly EntitlementData: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_PersonInserted' | 'UID_PersonOrdered' | 'IsOptionalChild' | 'UID_PersonWantsOrg' | 'UID_ShoppingCartOrder' | 'UID_ShoppingCartItemParent' | 'UID_AccProduct' | 'CheckResult' | 'CustomProperty01' | 'CustomProperty02' | 'CustomProperty03' | 'CustomProperty04' | 'CustomProperty05' | 'CustomProperty06' | 'CustomProperty07' | 'CustomProperty08' | 'CustomProperty09' | 'CustomProperty10' | 'OrderReason' | 'PWOPriority' | 'UID_Department' | 'UID_ITShopOrg' | 'UID_ProfitCenter' | 'UID_QERJustificationOrder' | 'ValidFrom' | 'ValidUntil' | 'DisplayType' | 'UID_PatternItem' | 'RequestType' | 'TableName' | 'CanCopy' | 'UID_QERTermsOfUse' | 'MaxValidDays' | 'Assignment' | 'ElementAssigned' | 'ElementAssignedTo' | 'CanHaveOptionalProducts' | 'ValidUntilUnsubscribe' | 'OrderReasonType' | 'ProlongationDate' | 'RoleMembership' | 'EntitlementData'>;
}
export declare class PortalCartitemInteractiveParameterCandidates extends TypedEntity {
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<never>;
}
export declare class PortalCartitemParameterCandidates extends TypedEntity {
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<never>;
}
export declare class PortalDelegable extends TypedEntity {
    readonly ObjectKeyToDelegate: IReadValue<string>;
    readonly Criteria: IReadValue<string>;
    readonly TargetObjectKey: IReadValue<string>;
    readonly TargetType: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'ObjectKeyToDelegate' | 'Criteria' | 'TargetObjectKey' | 'TargetType'>;
}
export declare class PortalDelegations extends TypedEntity {
    readonly ObjectKeyDelegated: IWriteValue<string>;
    readonly UID_PersonSender: IReadValue<string>;
    readonly UID_PersonReceiver: IWriteValue<string>;
    readonly UID_PersonWantsOrg: IReadValue<string>;
    readonly IsDelegable: IWriteValue<boolean>;
    readonly KeepMeInformed: IWriteValue<boolean>;
    readonly InsertValidFrom: IWriteValue<Date>;
    readonly InsertValidUntil: IWriteValue<Date>;
    readonly PWOPriority: IWriteValue<number>;
    readonly UID_QERJustification: IWriteValue<string>;
    readonly OrderReason: IWriteValue<string>;
    readonly ValidFrom: IReadValue<Date>;
    readonly ValidUntil: IReadValue<Date>;
    readonly DateActivated: IReadValue<Date>;
    readonly DateDeactivated: IReadValue<Date>;
    readonly PwoOrderState: IReadValue<string>;
    readonly TargetObjectKey: IReadValue<string>;
    readonly TargetType: IReadValue<string>;
    readonly DelegationType: IReadValue<string>;
    readonly Criteria: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'ObjectKeyDelegated' | 'UID_PersonSender' | 'UID_PersonReceiver' | 'UID_PersonWantsOrg' | 'IsDelegable' | 'KeepMeInformed' | 'InsertValidFrom' | 'InsertValidUntil' | 'PWOPriority' | 'UID_QERJustification' | 'OrderReason' | 'ValidFrom' | 'ValidUntil' | 'DateActivated' | 'DateDeactivated' | 'PwoOrderState' | 'TargetObjectKey' | 'TargetType' | 'DelegationType' | 'Criteria'>;
}
export declare class PortalDelegationsGlobalRoleclasses extends TypedEntity {
    readonly CountRolesOwned: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'CountRolesOwned'>;
}
export declare class PortalDynamicgroup extends WriteExtTypedEntity<SqlWizardWrite> {
    readonly UID_DynamicGroup: IReadValue<string>;
    readonly IsCalculateImmediately: IWriteValue<boolean>;
    readonly UID_DialogSchedule: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_DynamicGroup' | 'IsCalculateImmediately' | 'UID_DialogSchedule'>;
}
export declare class PortalDynamicgroupInteractive extends WriteExtTypedEntity<SqlWizardWrite> {
    readonly UID_DynamicGroup: IReadValue<string>;
    readonly IsCalculateImmediately: IWriteValue<boolean>;
    readonly UID_DialogSchedule: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_DynamicGroup' | 'IsCalculateImmediately' | 'UID_DialogSchedule'>;
}
export declare class PortalDynamicgroupSqlwizardCandidates extends TypedEntity {
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<never>;
}
export declare class PortalItshopApproveHistory extends TypedEntity {
    readonly DateHead: IReadValue<Date>;
    readonly DecisionType: IReadValue<string>;
    readonly DisplayPersonHead: IReadValue<string>;
    readonly Ident_PWODecisionStep: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    readonly ValidUntilUnsubscribe: IReadValue<Date>;
    readonly ValidUntilProlongation: IReadValue<Date>;
    readonly IsDecisionBySystem: IReadValue<boolean>;
    readonly IsToHideInHistory: IReadValue<boolean>;
    readonly ReasonHead: IReadValue<string>;
    readonly RulerLevel: IReadValue<number>;
    readonly UID_PersonHead: IReadValue<string>;
    readonly UID_PersonRelated: IReadValue<string>;
    readonly UID_PWODecisionRule: IReadValue<string>;
    readonly UID_QERJustification: IReadValue<string>;
    readonly XDateInserted: IReadValue<Date>;
    readonly IsFromDelegation: IReadValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'DateHead' | 'DecisionType' | 'DisplayPersonHead' | 'Ident_PWODecisionStep' | 'ValidUntil' | 'ValidUntilUnsubscribe' | 'ValidUntilProlongation' | 'IsDecisionBySystem' | 'IsToHideInHistory' | 'ReasonHead' | 'RulerLevel' | 'UID_PersonHead' | 'UID_PersonRelated' | 'UID_PWODecisionRule' | 'UID_QERJustification' | 'XDateInserted' | 'IsFromDelegation'>;
}
export declare class PortalItshopApproveRequests extends WriteExtTypedEntity<{
    [key: string]: EntityWriteDataColumn[][];
}> {
    readonly PeerGroupFactor: IReadValue<number>;
    readonly IsCrossFunctional: IReadValue<boolean>;
    readonly DisplayOrg: IReadValue<string>;
    readonly OrderDate: IReadValue<Date>;
    readonly ValidFrom: IWriteValue<Date>;
    readonly ValidUntil: IWriteValue<Date>;
    readonly IsReserved: IReadValue<boolean>;
    readonly UID_Department: IReadValue<string>;
    readonly UID_ProfitCenter: IReadValue<string>;
    readonly DecisionLevel: IReadValue<number>;
    readonly OrderReason: IReadValue<string>;
    readonly UID_PersonOrdered: IReadValue<string>;
    readonly DisplayPersonOrdered: IReadValue<string>;
    readonly DisplayPersonInserted: IReadValue<string>;
    readonly UID_PersonWantsOrgParent: IReadValue<string>;
    readonly OrderState: IReadValue<string>;
    readonly UiOrderState: IReadValue<string>;
    readonly PWOPriority: IWriteValue<number>;
    readonly UID_ShoppingCartOrder: IReadValue<string>;
    readonly ValidUntilProlongation: IReadValue<Date>;
    readonly ValidUntilUnsubscribe: IReadValue<Date>;
    readonly UID_QERWorkingMethod: IReadValue<string>;
    readonly UID_Org: IReadValue<string>;
    readonly DocumentNumber: IReadValue<string>;
    readonly UID_AccProduct: IReadValue<string>;
    readonly Assignment: IReadValue<string>;
    readonly ElementAssigned: IReadValue<string>;
    readonly ElementAssignedTo: IReadValue<string>;
    readonly TableName: IReadValue<string>;
    readonly UID_QERTermsOfUse: IReadValue<string>;
    readonly IsApproveRequiresMfa: IReadValue<boolean>;
    readonly CanWithdrawAddApprover: IReadValue<boolean>;
    readonly CanAskForHelp: IReadValue<boolean>;
    readonly ApproveReasonType: IReadValue<number>;
    readonly DenyReasonType: IReadValue<number>;
    readonly DisplayType: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'PeerGroupFactor' | 'IsCrossFunctional' | 'DisplayOrg' | 'OrderDate' | 'ValidFrom' | 'ValidUntil' | 'IsReserved' | 'UID_Department' | 'UID_ProfitCenter' | 'DecisionLevel' | 'OrderReason' | 'UID_PersonOrdered' | 'DisplayPersonOrdered' | 'DisplayPersonInserted' | 'UID_PersonWantsOrgParent' | 'OrderState' | 'UiOrderState' | 'PWOPriority' | 'UID_ShoppingCartOrder' | 'ValidUntilProlongation' | 'ValidUntilUnsubscribe' | 'UID_QERWorkingMethod' | 'UID_Org' | 'DocumentNumber' | 'UID_AccProduct' | 'Assignment' | 'ElementAssigned' | 'ElementAssignedTo' | 'TableName' | 'UID_QERTermsOfUse' | 'IsApproveRequiresMfa' | 'CanWithdrawAddApprover' | 'CanAskForHelp' | 'ApproveReasonType' | 'DenyReasonType' | 'DisplayType'>;
}
export declare class PortalItshopApproveRequestsParameterCandidates extends TypedEntity {
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<never>;
}
export declare class PortalItshopCart extends TypedEntity {
    readonly DocumentNumber: IReadValue<string>;
    readonly CheckStatus: IReadValue<number>;
    readonly Description: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'DocumentNumber' | 'CheckStatus' | 'Description'>;
}
export declare class PortalItshopPattern extends TypedEntity {
    readonly UID_AccProduct: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_AccProduct'>;
}
export declare class PortalItshopPatternAdmin extends TypedEntity {
    readonly Ident_ShoppingCartPattern: IReadValue<string>;
    readonly UID_Person: IReadValue<string>;
    readonly Description: IReadValue<string>;
    readonly IsPublicPattern: IWriteValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Ident_ShoppingCartPattern' | 'UID_Person' | 'Description' | 'IsPublicPattern'>;
}
export declare class PortalItshopPatternItem extends TypedEntity {
    readonly UID_AccProduct: IWriteValue<string>;
    readonly UID_ShoppingCartPattern: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_AccProduct' | 'UID_ShoppingCartPattern'>;
}
export declare class PortalItshopPatternPrivate extends TypedEntity {
    readonly IsPublicPattern: IWriteValue<boolean>;
    readonly UID_Person: IReadValue<string>;
    readonly Description: IWriteValue<string>;
    readonly Ident_ShoppingCartPattern: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'IsPublicPattern' | 'UID_Person' | 'Description' | 'Ident_ShoppingCartPattern'>;
}
export declare class PortalItshopPatternRequestable extends TypedEntity {
    readonly UID_ShoppingCartPattern: IReadValue<string>;
    readonly IsPublicPattern: IReadValue<boolean>;
    readonly Description: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_ShoppingCartPattern' | 'IsPublicPattern' | 'Description'>;
}
export declare class PortalItshopPeergroup extends TypedEntity {
    readonly DefaultEmailAddress: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'DefaultEmailAddress'>;
}
export declare class PortalItshopPeergroupMemberships extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly FullPath: IReadValue<string>;
    readonly Description: IReadValue<string>;
    readonly CountInPeerGroup: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'FullPath' | 'Description' | 'CountInPeerGroup'>;
}
export declare class PortalItshopPersondecision extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly OrderNumber: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'OrderNumber'>;
}
export declare class PortalItshopRequests extends WriteExtTypedEntity<{
    [key: string]: EntityWriteDataColumn[][];
}> {
    readonly PeerGroupFactor: IReadValue<number>;
    readonly IsCrossFunctional: IReadValue<boolean>;
    readonly UID_Org: IReadValue<string>;
    readonly DisplayOrg: IReadValue<string>;
    readonly DisplayPersonOrdered: IReadValue<string>;
    readonly DisplayPersonInserted: IReadValue<string>;
    readonly UID_PWOState: IReadValue<string>;
    readonly OrderDate: IReadValue<Date>;
    readonly UiOrderState: IReadValue<string>;
    readonly PWOPriority: IReadValue<number>;
    readonly UID_ShoppingCartOrder: IReadValue<string>;
    readonly ValidFrom: IReadValue<Date>;
    readonly ValidUntil: IReadValue<Date>;
    readonly ValidUntilProlongation: IReadValue<Date>;
    readonly ValidUntilUnsubscribe: IReadValue<Date>;
    readonly OrderReason: IReadValue<string>;
    readonly UID_PersonOrdered: IReadValue<string>;
    readonly UID_PersonInserted: IReadValue<string>;
    readonly UID_PersonWantsOrgParent: IReadValue<string>;
    readonly UID_Department: IReadValue<string>;
    readonly UID_ProfitCenter: IReadValue<string>;
    readonly UID_PersonHead: IReadValue<string>;
    readonly IsOptionalChild: IReadValue<boolean>;
    readonly IsReserved: IReadValue<boolean>;
    readonly DecisionLevel: IReadValue<number>;
    readonly UID_QERWorkingMethod: IReadValue<string>;
    readonly UID_AccProduct: IReadValue<string>;
    readonly DocumentNumber: IReadValue<string>;
    readonly MaxValidDays: IReadValue<number>;
    readonly Assignment: IReadValue<string>;
    readonly ElementAssigned: IReadValue<string>;
    readonly ElementAssignedTo: IReadValue<string>;
    readonly TableName: IReadValue<string>;
    readonly ResendRequestAllowed: IReadValue<boolean>;
    readonly CancelRequestAllowed: IReadValue<boolean>;
    readonly UnsubscribeRequestAllowed: IReadValue<boolean>;
    readonly DisplayType: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'PeerGroupFactor' | 'IsCrossFunctional' | 'UID_Org' | 'DisplayOrg' | 'DisplayPersonOrdered' | 'DisplayPersonInserted' | 'UID_PWOState' | 'OrderDate' | 'UiOrderState' | 'PWOPriority' | 'UID_ShoppingCartOrder' | 'ValidFrom' | 'ValidUntil' | 'ValidUntilProlongation' | 'ValidUntilUnsubscribe' | 'OrderReason' | 'UID_PersonOrdered' | 'UID_PersonInserted' | 'UID_PersonWantsOrgParent' | 'UID_Department' | 'UID_ProfitCenter' | 'UID_PersonHead' | 'IsOptionalChild' | 'IsReserved' | 'DecisionLevel' | 'UID_QERWorkingMethod' | 'UID_AccProduct' | 'DocumentNumber' | 'MaxValidDays' | 'Assignment' | 'ElementAssigned' | 'ElementAssignedTo' | 'TableName' | 'ResendRequestAllowed' | 'CancelRequestAllowed' | 'UnsubscribeRequestAllowed' | 'DisplayType'>;
}
export declare class PortalItshopRequestsParameterCandidates extends TypedEntity {
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<never>;
}
export declare class PortalJustifications extends TypedEntity {
    readonly Ident_QERJustification: IReadValue<string>;
    readonly Description: IReadValue<string>;
    readonly RequiresText: IReadValue<boolean>;
    readonly JustificationType: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Ident_QERJustification' | 'Description' | 'RequiresText' | 'JustificationType'>;
}
export declare class PortalPasswordquestions extends TypedEntity {
    readonly PasswordQuery: IWriteValue<string>;
    readonly IsLocked: IReadValue<boolean>;
    readonly SortOrder: IWriteValue<number>;
    readonly PasswordAnswer: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'PasswordQuery' | 'IsLocked' | 'SortOrder' | 'PasswordAnswer'>;
}
export declare class PortalPersonActive extends TypedEntity {
    readonly DefaultEmailAddress: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'DefaultEmailAddress'>;
}
export declare class PortalPersonAll extends TypedEntity {
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly IdentityType: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly DefaultEmailAddress: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XMarkedForDeletion' | 'IdentityType' | 'XObjectKey' | 'DefaultEmailAddress'>;
}
export declare class PortalPersonEmail extends TypedEntity {
    readonly IsSubscribed: IReadValue<boolean>;
    readonly AllowUnsubscribe: IReadValue<boolean>;
    readonly Description: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'IsSubscribed' | 'AllowUnsubscribe' | 'Description'>;
}
export declare class PortalPersonMasterdata extends TypedEntity {
    readonly DefaultEmailAddress: IReadValue<string>;
    readonly ApprovalState: IWriteValue<number>;
    readonly AuthentifierLogins: IWriteValue<string>;
    readonly BadPasswordAttempts: IWriteValue<number>;
    readonly BadPwdAnswerAttempts: IWriteValue<number>;
    readonly BirthDate: IWriteValue<Date>;
    readonly Building: IWriteValue<string>;
    readonly CanonicalName: IWriteValue<string>;
    readonly CentralAccount: IWriteValue<string>;
    readonly CentralPassword: IWriteValue<string>;
    readonly City: IWriteValue<string>;
    readonly CompanyMember: IWriteValue<string>;
    readonly ContactEmail: IWriteValue<string>;
    readonly CustomProperty01: IWriteValue<string>;
    readonly CustomProperty02: IWriteValue<string>;
    readonly CustomProperty03: IWriteValue<string>;
    readonly CustomProperty04: IWriteValue<string>;
    readonly CustomProperty05: IWriteValue<string>;
    readonly CustomProperty06: IWriteValue<string>;
    readonly CustomProperty07: IWriteValue<string>;
    readonly CustomProperty08: IWriteValue<string>;
    readonly CustomProperty09: IWriteValue<string>;
    readonly CustomProperty10: IWriteValue<string>;
    readonly DateLastWorked: IWriteValue<Date>;
    readonly DeactivationEnd: IWriteValue<Date>;
    readonly DeactivationStart: IWriteValue<Date>;
    readonly DecentralizedIdentifier: IWriteValue<string>;
    readonly Description: IWriteValue<string>;
    readonly DialogUserPassword: IWriteValue<string>;
    readonly DialogUserSalt: IWriteValue<string>;
    readonly DisplayTelephoneBook: IWriteValue<boolean>;
    readonly DistinguishedName: IWriteValue<string>;
    readonly EmployeeType: IWriteValue<string>;
    readonly EntryDate: IWriteValue<Date>;
    readonly ExitDate: IWriteValue<Date>;
    readonly Fax: IWriteValue<string>;
    readonly FaxExtension: IWriteValue<string>;
    readonly FirstName: IReadValue<string>;
    readonly Floor: IWriteValue<string>;
    readonly FormerName: IWriteValue<string>;
    readonly Gender: IWriteValue<number>;
    readonly GenerationalQualifier: IWriteValue<string>;
    readonly IdentityType: IWriteValue<string>;
    readonly ImportSource: IWriteValue<string>;
    readonly Initials: IWriteValue<string>;
    readonly InternalName: IWriteValue<string>;
    readonly IsCar: IWriteValue<boolean>;
    readonly IsDummyPerson: IWriteValue<boolean>;
    readonly IsDuplicateName: IWriteValue<boolean>;
    readonly IsExternal: IWriteValue<boolean>;
    readonly IsInActive: IWriteValue<boolean>;
    readonly IsLockedOut: IWriteValue<boolean>;
    readonly IsLockedPwdAnswer: IWriteValue<boolean>;
    readonly IsNoInherite: IWriteValue<boolean>;
    readonly IsNoteBookUser: IWriteValue<boolean>;
    readonly IsPwdResetByHelpdeskAllowed: IWriteValue<boolean>;
    readonly IsRemoteAccessAllowed: IWriteValue<boolean>;
    readonly IsSecurityIncident: IWriteValue<boolean>;
    readonly IsTemporaryDeactivated: IWriteValue<boolean>;
    readonly IsTerminalServerAllowed: IWriteValue<boolean>;
    readonly IsVIP: IWriteValue<boolean>;
    readonly IsX500Dummy: IWriteValue<boolean>;
    readonly JPegPhoto: IWriteValue<string>;
    readonly LastName: IReadValue<string>;
    readonly MfaUserId: IWriteValue<string>;
    readonly MiddleName: IWriteValue<string>;
    readonly NameAddOn: IWriteValue<string>;
    readonly Passcode: IWriteValue<string>;
    readonly PasscodeExpires: IWriteValue<Date>;
    readonly PasswordLastSet: IWriteValue<Date>;
    readonly PersonalTitle: IWriteValue<string>;
    readonly PersonnelNumber: IWriteValue<string>;
    readonly Phone: IWriteValue<string>;
    readonly PhoneExtension: IWriteValue<string>;
    readonly PhoneMobile: IWriteValue<string>;
    readonly PostalOfficeBox: IWriteValue<string>;
    readonly PreferredName: IWriteValue<string>;
    readonly Remarks: IWriteValue<string>;
    readonly RiskIndexCalculated: IWriteValue<number>;
    readonly Room: IWriteValue<string>;
    readonly Salutation: IWriteValue<string>;
    readonly SecurityIdent: IWriteValue<string>;
    readonly Sponsor: IWriteValue<string>;
    readonly Street: IWriteValue<string>;
    readonly SubCompany: IWriteValue<string>;
    readonly TechnicalEntryDate: IWriteValue<Date>;
    readonly Title: IWriteValue<string>;
    readonly UID_Department: IReadValue<string>;
    readonly UID_DialogCountry: IWriteValue<string>;
    readonly UID_DialogCulture: IWriteValue<string>;
    readonly UID_DialogCultureFormat: IWriteValue<string>;
    readonly UID_DialogState: IWriteValue<string>;
    readonly UID_DialogUser: IWriteValue<string>;
    readonly UID_FirmPartner: IWriteValue<string>;
    readonly UID_Locality: IReadValue<string>;
    readonly UID_Person: IWriteValue<string>;
    readonly UID_PersonHead: IReadValue<string>;
    readonly UID_PersonMasterIdentity: IWriteValue<string>;
    readonly UID_ProfitCenter: IReadValue<string>;
    readonly UID_RealPerson: IWriteValue<string>;
    readonly UID_WorkDesk: IWriteValue<string>;
    readonly UID_X500Person: IWriteValue<string>;
    readonly UserIDTSO: IWriteValue<string>;
    readonly XTouched: IWriteValue<string>;
    readonly ZIPCode: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'DefaultEmailAddress' | 'ApprovalState' | 'AuthentifierLogins' | 'BadPasswordAttempts' | 'BadPwdAnswerAttempts' | 'BirthDate' | 'Building' | 'CanonicalName' | 'CentralAccount' | 'CentralPassword' | 'City' | 'CompanyMember' | 'ContactEmail' | 'CustomProperty01' | 'CustomProperty02' | 'CustomProperty03' | 'CustomProperty04' | 'CustomProperty05' | 'CustomProperty06' | 'CustomProperty07' | 'CustomProperty08' | 'CustomProperty09' | 'CustomProperty10' | 'DateLastWorked' | 'DeactivationEnd' | 'DeactivationStart' | 'DecentralizedIdentifier' | 'Description' | 'DialogUserPassword' | 'DialogUserSalt' | 'DisplayTelephoneBook' | 'DistinguishedName' | 'EmployeeType' | 'EntryDate' | 'ExitDate' | 'Fax' | 'FaxExtension' | 'FirstName' | 'Floor' | 'FormerName' | 'Gender' | 'GenerationalQualifier' | 'IdentityType' | 'ImportSource' | 'Initials' | 'InternalName' | 'IsCar' | 'IsDummyPerson' | 'IsDuplicateName' | 'IsExternal' | 'IsInActive' | 'IsLockedOut' | 'IsLockedPwdAnswer' | 'IsNoInherite' | 'IsNoteBookUser' | 'IsPwdResetByHelpdeskAllowed' | 'IsRemoteAccessAllowed' | 'IsSecurityIncident' | 'IsTemporaryDeactivated' | 'IsTerminalServerAllowed' | 'IsVIP' | 'IsX500Dummy' | 'JPegPhoto' | 'LastName' | 'MfaUserId' | 'MiddleName' | 'NameAddOn' | 'Passcode' | 'PasscodeExpires' | 'PasswordLastSet' | 'PersonalTitle' | 'PersonnelNumber' | 'Phone' | 'PhoneExtension' | 'PhoneMobile' | 'PostalOfficeBox' | 'PreferredName' | 'Remarks' | 'RiskIndexCalculated' | 'Room' | 'Salutation' | 'SecurityIdent' | 'Sponsor' | 'Street' | 'SubCompany' | 'TechnicalEntryDate' | 'Title' | 'UID_Department' | 'UID_DialogCountry' | 'UID_DialogCulture' | 'UID_DialogCultureFormat' | 'UID_DialogState' | 'UID_DialogUser' | 'UID_FirmPartner' | 'UID_Locality' | 'UID_Person' | 'UID_PersonHead' | 'UID_PersonMasterIdentity' | 'UID_ProfitCenter' | 'UID_RealPerson' | 'UID_WorkDesk' | 'UID_X500Person' | 'UserIDTSO' | 'XTouched' | 'ZIPCode'>;
}
export declare class PortalPersonMasterdataInteractive extends TypedEntity {
    readonly DefaultEmailAddress: IReadValue<string>;
    readonly ApprovalState: IWriteValue<number>;
    readonly AuthentifierLogins: IWriteValue<string>;
    readonly BadPasswordAttempts: IWriteValue<number>;
    readonly BadPwdAnswerAttempts: IWriteValue<number>;
    readonly BirthDate: IWriteValue<Date>;
    readonly Building: IWriteValue<string>;
    readonly CanonicalName: IWriteValue<string>;
    readonly CentralAccount: IWriteValue<string>;
    readonly CentralPassword: IWriteValue<string>;
    readonly City: IWriteValue<string>;
    readonly CompanyMember: IWriteValue<string>;
    readonly ContactEmail: IWriteValue<string>;
    readonly CustomProperty01: IWriteValue<string>;
    readonly CustomProperty02: IWriteValue<string>;
    readonly CustomProperty03: IWriteValue<string>;
    readonly CustomProperty04: IWriteValue<string>;
    readonly CustomProperty05: IWriteValue<string>;
    readonly CustomProperty06: IWriteValue<string>;
    readonly CustomProperty07: IWriteValue<string>;
    readonly CustomProperty08: IWriteValue<string>;
    readonly CustomProperty09: IWriteValue<string>;
    readonly CustomProperty10: IWriteValue<string>;
    readonly DateLastWorked: IWriteValue<Date>;
    readonly DeactivationEnd: IWriteValue<Date>;
    readonly DeactivationStart: IWriteValue<Date>;
    readonly DecentralizedIdentifier: IWriteValue<string>;
    readonly Description: IWriteValue<string>;
    readonly DialogUserPassword: IWriteValue<string>;
    readonly DialogUserSalt: IWriteValue<string>;
    readonly DisplayTelephoneBook: IWriteValue<boolean>;
    readonly DistinguishedName: IWriteValue<string>;
    readonly EmployeeType: IWriteValue<string>;
    readonly EntryDate: IWriteValue<Date>;
    readonly ExitDate: IWriteValue<Date>;
    readonly Fax: IWriteValue<string>;
    readonly FaxExtension: IWriteValue<string>;
    readonly FirstName: IReadValue<string>;
    readonly Floor: IWriteValue<string>;
    readonly FormerName: IWriteValue<string>;
    readonly Gender: IWriteValue<number>;
    readonly GenerationalQualifier: IWriteValue<string>;
    readonly IdentityType: IWriteValue<string>;
    readonly ImportSource: IWriteValue<string>;
    readonly Initials: IWriteValue<string>;
    readonly InternalName: IWriteValue<string>;
    readonly IsCar: IWriteValue<boolean>;
    readonly IsDummyPerson: IWriteValue<boolean>;
    readonly IsDuplicateName: IWriteValue<boolean>;
    readonly IsExternal: IWriteValue<boolean>;
    readonly IsInActive: IWriteValue<boolean>;
    readonly IsLockedOut: IWriteValue<boolean>;
    readonly IsLockedPwdAnswer: IWriteValue<boolean>;
    readonly IsNoInherite: IWriteValue<boolean>;
    readonly IsNoteBookUser: IWriteValue<boolean>;
    readonly IsPwdResetByHelpdeskAllowed: IWriteValue<boolean>;
    readonly IsRemoteAccessAllowed: IWriteValue<boolean>;
    readonly IsSecurityIncident: IWriteValue<boolean>;
    readonly IsTemporaryDeactivated: IWriteValue<boolean>;
    readonly IsTerminalServerAllowed: IWriteValue<boolean>;
    readonly IsVIP: IWriteValue<boolean>;
    readonly IsX500Dummy: IWriteValue<boolean>;
    readonly JPegPhoto: IWriteValue<string>;
    readonly LastName: IReadValue<string>;
    readonly MfaUserId: IWriteValue<string>;
    readonly MiddleName: IWriteValue<string>;
    readonly NameAddOn: IWriteValue<string>;
    readonly Passcode: IWriteValue<string>;
    readonly PasscodeExpires: IWriteValue<Date>;
    readonly PasswordLastSet: IWriteValue<Date>;
    readonly PersonalTitle: IWriteValue<string>;
    readonly PersonnelNumber: IWriteValue<string>;
    readonly Phone: IWriteValue<string>;
    readonly PhoneExtension: IWriteValue<string>;
    readonly PhoneMobile: IWriteValue<string>;
    readonly PostalOfficeBox: IWriteValue<string>;
    readonly PreferredName: IWriteValue<string>;
    readonly Remarks: IWriteValue<string>;
    readonly RiskIndexCalculated: IWriteValue<number>;
    readonly Room: IWriteValue<string>;
    readonly Salutation: IWriteValue<string>;
    readonly SecurityIdent: IWriteValue<string>;
    readonly Sponsor: IWriteValue<string>;
    readonly Street: IWriteValue<string>;
    readonly SubCompany: IWriteValue<string>;
    readonly TechnicalEntryDate: IWriteValue<Date>;
    readonly Title: IWriteValue<string>;
    readonly UID_Department: IReadValue<string>;
    readonly UID_DialogCountry: IWriteValue<string>;
    readonly UID_DialogCulture: IWriteValue<string>;
    readonly UID_DialogCultureFormat: IWriteValue<string>;
    readonly UID_DialogState: IWriteValue<string>;
    readonly UID_DialogUser: IWriteValue<string>;
    readonly UID_FirmPartner: IWriteValue<string>;
    readonly UID_Locality: IReadValue<string>;
    readonly UID_Person: IWriteValue<string>;
    readonly UID_PersonHead: IReadValue<string>;
    readonly UID_PersonMasterIdentity: IWriteValue<string>;
    readonly UID_ProfitCenter: IReadValue<string>;
    readonly UID_RealPerson: IWriteValue<string>;
    readonly UID_WorkDesk: IWriteValue<string>;
    readonly UID_X500Person: IWriteValue<string>;
    readonly UserIDTSO: IWriteValue<string>;
    readonly XTouched: IWriteValue<string>;
    readonly ZIPCode: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'DefaultEmailAddress' | 'ApprovalState' | 'AuthentifierLogins' | 'BadPasswordAttempts' | 'BadPwdAnswerAttempts' | 'BirthDate' | 'Building' | 'CanonicalName' | 'CentralAccount' | 'CentralPassword' | 'City' | 'CompanyMember' | 'ContactEmail' | 'CustomProperty01' | 'CustomProperty02' | 'CustomProperty03' | 'CustomProperty04' | 'CustomProperty05' | 'CustomProperty06' | 'CustomProperty07' | 'CustomProperty08' | 'CustomProperty09' | 'CustomProperty10' | 'DateLastWorked' | 'DeactivationEnd' | 'DeactivationStart' | 'DecentralizedIdentifier' | 'Description' | 'DialogUserPassword' | 'DialogUserSalt' | 'DisplayTelephoneBook' | 'DistinguishedName' | 'EmployeeType' | 'EntryDate' | 'ExitDate' | 'Fax' | 'FaxExtension' | 'FirstName' | 'Floor' | 'FormerName' | 'Gender' | 'GenerationalQualifier' | 'IdentityType' | 'ImportSource' | 'Initials' | 'InternalName' | 'IsCar' | 'IsDummyPerson' | 'IsDuplicateName' | 'IsExternal' | 'IsInActive' | 'IsLockedOut' | 'IsLockedPwdAnswer' | 'IsNoInherite' | 'IsNoteBookUser' | 'IsPwdResetByHelpdeskAllowed' | 'IsRemoteAccessAllowed' | 'IsSecurityIncident' | 'IsTemporaryDeactivated' | 'IsTerminalServerAllowed' | 'IsVIP' | 'IsX500Dummy' | 'JPegPhoto' | 'LastName' | 'MfaUserId' | 'MiddleName' | 'NameAddOn' | 'Passcode' | 'PasscodeExpires' | 'PasswordLastSet' | 'PersonalTitle' | 'PersonnelNumber' | 'Phone' | 'PhoneExtension' | 'PhoneMobile' | 'PostalOfficeBox' | 'PreferredName' | 'Remarks' | 'RiskIndexCalculated' | 'Room' | 'Salutation' | 'SecurityIdent' | 'Sponsor' | 'Street' | 'SubCompany' | 'TechnicalEntryDate' | 'Title' | 'UID_Department' | 'UID_DialogCountry' | 'UID_DialogCulture' | 'UID_DialogCultureFormat' | 'UID_DialogState' | 'UID_DialogUser' | 'UID_FirmPartner' | 'UID_Locality' | 'UID_Person' | 'UID_PersonHead' | 'UID_PersonMasterIdentity' | 'UID_ProfitCenter' | 'UID_RealPerson' | 'UID_WorkDesk' | 'UID_X500Person' | 'UserIDTSO' | 'XTouched' | 'ZIPCode'>;
}
export declare class PortalPersonMemberships extends TypedEntity {
    readonly ObjectKeyTarget: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly IsPending: IReadValue<boolean>;
    readonly IsPrimary: IReadValue<boolean>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'ObjectKeyTarget' | 'ObjectKeyAssignment' | 'XOrigin' | 'IsPending' | 'IsPrimary' | 'OrderState' | 'ValidUntil'>;
}
export declare class PortalPersonOrgdata extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly DefaultEmailAddress: IReadValue<string>;
    readonly CompanyMember: IReadValue<string>;
    readonly IsExternal: IReadValue<boolean>;
    readonly Title: IReadValue<string>;
    readonly IdentityType: IReadValue<string>;
    readonly EmployeeType: IReadValue<string>;
    readonly PersonalTitle: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'DefaultEmailAddress' | 'CompanyMember' | 'IsExternal' | 'Title' | 'IdentityType' | 'EmployeeType' | 'PersonalTitle' | 'XOrigin'>;
}
export declare class PortalPersonOverview extends TypedEntity {
    readonly DefaultEmailAddress: IReadValue<string>;
    readonly CountDelegations: IReadValue<number>;
    readonly CountLastPWOs: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'DefaultEmailAddress' | 'CountDelegations' | 'CountLastPWOs'>;
}
export declare class PortalPersonReports extends TypedEntity {
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly IdentityType: IReadValue<string>;
    readonly UID_PersonHead: IWriteValue<string>;
    readonly EmployeeType: IReadValue<string>;
    readonly IsExternal: IReadValue<boolean>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly DefaultEmailAddress: IReadValue<string>;
    readonly IsInActive: IWriteValue<boolean>;
    readonly IsSecurityIncident: IWriteValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XMarkedForDeletion' | 'IdentityType' | 'UID_PersonHead' | 'EmployeeType' | 'IsExternal' | 'RiskIndexCalculated' | 'DefaultEmailAddress' | 'IsInActive' | 'IsSecurityIncident'>;
}
export declare class PortalPersonReportsInteractive extends TypedEntity {
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly IdentityType: IReadValue<string>;
    readonly UID_PersonHead: IWriteValue<string>;
    readonly EmployeeType: IReadValue<string>;
    readonly IsExternal: IReadValue<boolean>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly DefaultEmailAddress: IReadValue<string>;
    readonly IsInActive: IWriteValue<boolean>;
    readonly IsSecurityIncident: IWriteValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XMarkedForDeletion' | 'IdentityType' | 'UID_PersonHead' | 'EmployeeType' | 'IsExternal' | 'RiskIndexCalculated' | 'DefaultEmailAddress' | 'IsInActive' | 'IsSecurityIncident'>;
}
export declare class PortalPersonRequestmanagerchange extends TypedEntity {
    readonly UID_PersonOrdered: IWriteValue<string>;
    readonly UID_ShoppingCartOrder: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_PersonOrdered' | 'UID_ShoppingCartOrder'>;
}
export declare class PortalPersonRolemembershipsAerole extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly UID_AERole: IReadValue<string>;
    readonly RoleFullPath: IReadValue<string>;
    readonly UID_PersonWantsOrg: IReadValue<string>;
    readonly OrderState: IReadValue<string>;
    readonly IsRequestCancellable: IReadValue<boolean>;
    readonly ValidUntil: IReadValue<Date>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'XObjectKey' | 'XOrigin' | 'XDateInserted' | 'UID_AERole' | 'RoleFullPath' | 'UID_PersonWantsOrg' | 'OrderState' | 'IsRequestCancellable' | 'ValidUntil'>;
}
export declare class PortalPersonRolemembershipsDepartment extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly UID_Department: IReadValue<string>;
    readonly RoleFullPath: IReadValue<string>;
    readonly UID_PersonWantsOrg: IReadValue<string>;
    readonly OrderState: IReadValue<string>;
    readonly IsRequestCancellable: IReadValue<boolean>;
    readonly ValidUntil: IReadValue<Date>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'XObjectKey' | 'XOrigin' | 'XDateInserted' | 'UID_Department' | 'RoleFullPath' | 'UID_PersonWantsOrg' | 'OrderState' | 'IsRequestCancellable' | 'ValidUntil'>;
}
export declare class PortalPersonRolemembershipsItshoporg extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly UID_ITShopOrg: IReadValue<string>;
    readonly RoleFullPath: IReadValue<string>;
    readonly UID_PersonWantsOrg: IReadValue<string>;
    readonly OrderState: IReadValue<string>;
    readonly IsRequestCancellable: IReadValue<boolean>;
    readonly ValidUntil: IReadValue<Date>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'XObjectKey' | 'XOrigin' | 'XDateInserted' | 'UID_ITShopOrg' | 'RoleFullPath' | 'UID_PersonWantsOrg' | 'OrderState' | 'IsRequestCancellable' | 'ValidUntil'>;
}
export declare class PortalPersonRolemembershipsLocality extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly UID_Locality: IReadValue<string>;
    readonly RoleFullPath: IReadValue<string>;
    readonly UID_PersonWantsOrg: IReadValue<string>;
    readonly OrderState: IReadValue<string>;
    readonly IsRequestCancellable: IReadValue<boolean>;
    readonly ValidUntil: IReadValue<Date>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'XObjectKey' | 'XOrigin' | 'XDateInserted' | 'UID_Locality' | 'RoleFullPath' | 'UID_PersonWantsOrg' | 'OrderState' | 'IsRequestCancellable' | 'ValidUntil'>;
}
export declare class PortalPersonRolemembershipsProfitcenter extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly UID_ProfitCenter: IReadValue<string>;
    readonly RoleFullPath: IReadValue<string>;
    readonly UID_PersonWantsOrg: IReadValue<string>;
    readonly OrderState: IReadValue<string>;
    readonly IsRequestCancellable: IReadValue<boolean>;
    readonly ValidUntil: IReadValue<Date>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'XObjectKey' | 'XOrigin' | 'XDateInserted' | 'UID_ProfitCenter' | 'RoleFullPath' | 'UID_PersonWantsOrg' | 'OrderState' | 'IsRequestCancellable' | 'ValidUntil'>;
}
export declare class PortalPersonUid extends TypedEntity {
    readonly UID_Department: IReadValue<string>;
    readonly UID_ProfitCenter: IReadValue<string>;
    readonly UID_Locality: IReadValue<string>;
    readonly UID_PersonHead: IReadValue<string>;
    readonly Phone: IReadValue<string>;
    readonly PhoneMobile: IReadValue<string>;
    readonly Building: IReadValue<string>;
    readonly Floor: IReadValue<string>;
    readonly Room: IReadValue<string>;
    readonly Street: IReadValue<string>;
    readonly ZIPCode: IReadValue<string>;
    readonly City: IReadValue<string>;
    readonly UID_DialogCountry: IReadValue<string>;
    readonly DefaultEmailAddress: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_Department' | 'UID_ProfitCenter' | 'UID_Locality' | 'UID_PersonHead' | 'Phone' | 'PhoneMobile' | 'Building' | 'Floor' | 'Room' | 'Street' | 'ZIPCode' | 'City' | 'UID_DialogCountry' | 'DefaultEmailAddress'>;
}
export declare class PortalPickcategory extends TypedEntity {
    readonly IsManual: IReadValue<boolean>;
    readonly DisplayName: IWriteValue<string>;
    readonly RemoveAfterAttestationRun: IWriteValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'IsManual' | 'DisplayName' | 'RemoveAfterAttestationRun'>;
}
export declare class PortalPickcategoryItems extends TypedEntity {
    readonly UID_QERPickCategory: IWriteValue<string>;
    readonly ObjectKeyItem: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_QERPickCategory' | 'ObjectKeyItem'>;
}
export declare class PortalResourcesMembershipQerresource extends TypedEntity {
    readonly UID_QERResource: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly UID_Person: IWriteValue<string>;
    readonly UID_PersonWantsOrg: IReadValue<string>;
    readonly OrderState: IReadValue<string>;
    readonly IsRequestCancellable: IReadValue<boolean>;
    readonly ValidUntil: IReadValue<Date>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_QERResource' | 'XObjectKey' | 'XOrigin' | 'XDateInserted' | 'UID_Person' | 'UID_PersonWantsOrg' | 'OrderState' | 'IsRequestCancellable' | 'ValidUntil'>;
}
export declare class PortalResourcesQerassignServiceitem extends WriteExtTypedEntity<AccProductOwnershipInput> {
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<never>;
}
export declare class PortalResourcesQerresourceServiceitem extends WriteExtTypedEntity<AccProductOwnershipInput> {
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<never>;
}
export declare class PortalResourcesQerreuseServiceitem extends WriteExtTypedEntity<AccProductOwnershipInput> {
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<never>;
}
export declare class PortalResourcesQerreuseusServiceitem extends WriteExtTypedEntity<AccProductOwnershipInput> {
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<never>;
}
export declare class PortalRespAerole extends WriteExtTypedEntity<RoleExtendedDataWrite> {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_DynamicGroup: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_DynamicGroup'>;
}
export declare class PortalRespAeroleInteractive extends WriteExtTypedEntity<RoleExtendedDataWrite> {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_DynamicGroup: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_DynamicGroup'>;
}
export declare class PortalRespDepartment extends WriteExtTypedEntity<RoleExtendedDataWrite> {
    readonly XObjectKey: IReadValue<string>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly UID_DynamicGroup: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'RiskIndexCalculated' | 'UID_DynamicGroup'>;
}
export declare class PortalRespDepartmentInteractive extends WriteExtTypedEntity<RoleExtendedDataWrite> {
    readonly XObjectKey: IReadValue<string>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly UID_DynamicGroup: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'RiskIndexCalculated' | 'UID_DynamicGroup'>;
}
export declare class PortalRespLocality extends WriteExtTypedEntity<RoleExtendedDataWrite> {
    readonly XObjectKey: IReadValue<string>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly UID_DynamicGroup: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'RiskIndexCalculated' | 'UID_DynamicGroup'>;
}
export declare class PortalRespLocalityInteractive extends WriteExtTypedEntity<RoleExtendedDataWrite> {
    readonly XObjectKey: IReadValue<string>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly UID_DynamicGroup: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'RiskIndexCalculated' | 'UID_DynamicGroup'>;
}
export declare class PortalRespProfitcenter extends WriteExtTypedEntity<RoleExtendedDataWrite> {
    readonly XObjectKey: IReadValue<string>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly UID_DynamicGroup: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'RiskIndexCalculated' | 'UID_DynamicGroup'>;
}
export declare class PortalRespProfitcenterInteractive extends WriteExtTypedEntity<RoleExtendedDataWrite> {
    readonly XObjectKey: IReadValue<string>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly UID_DynamicGroup: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'RiskIndexCalculated' | 'UID_DynamicGroup'>;
}
export declare class PortalRiskFunctions extends TypedEntity {
    readonly Description: IReadValue<string>;
    readonly DisplayValue: IReadValue<string>;
    readonly IsExecuteImmediate: IReadValue<boolean>;
    readonly IsInActive: IReadValue<boolean>;
    readonly QueryString: IReadValue<string>;
    readonly TypeOfCalculation: IReadValue<string>;
    readonly UID_DialogColumn: IReadValue<string>;
    readonly UID_QERRiskIndex: IReadValue<string>;
    readonly Weight: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XDateUpdated: IReadValue<Date>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XObjectKey: IReadValue<string>;
    readonly XTouched: IReadValue<string>;
    readonly XUserInserted: IReadValue<string>;
    readonly XUserUpdated: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Description' | 'DisplayValue' | 'IsExecuteImmediate' | 'IsInActive' | 'QueryString' | 'TypeOfCalculation' | 'UID_DialogColumn' | 'UID_QERRiskIndex' | 'Weight' | 'XDateInserted' | 'XDateUpdated' | 'XMarkedForDeletion' | 'XObjectKey' | 'XTouched' | 'XUserInserted' | 'XUserUpdated'>;
}
export declare class PortalRolesConfigDepartmentPrimarymembers extends TypedEntity {
    readonly DefaultEmailAddress: IReadValue<string>;
    readonly PrimaryMemberSince: IReadValue<Date>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'DefaultEmailAddress' | 'PrimaryMemberSince'>;
}
export declare class PortalRolesConfigLocalityPrimarymembers extends TypedEntity {
    readonly DefaultEmailAddress: IReadValue<string>;
    readonly PrimaryMemberSince: IReadValue<Date>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'DefaultEmailAddress' | 'PrimaryMemberSince'>;
}
export declare class PortalRolesConfigProfitcenterPrimarymembers extends TypedEntity {
    readonly DefaultEmailAddress: IReadValue<string>;
    readonly PrimaryMemberSince: IReadValue<Date>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'DefaultEmailAddress' | 'PrimaryMemberSince'>;
}
export declare class PortalRolesEntitlements extends TypedEntity {
    readonly ObjectKeyElement: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XOrigin: IReadValue<number>;
    readonly UID_PersonWantsOrg: IReadValue<string>;
    readonly OrderState: IReadValue<string>;
    readonly IsRequestCancellable: IReadValue<boolean>;
    readonly ValidUntil: IReadValue<Date>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'ObjectKeyElement' | 'ObjectKeyAssignment' | 'XDateInserted' | 'XMarkedForDeletion' | 'XOrigin' | 'UID_PersonWantsOrg' | 'OrderState' | 'IsRequestCancellable' | 'ValidUntil'>;
}
export declare class PortalRolesExclusions extends TypedEntity {
    readonly IsNotMatched: IReadValue<boolean>;
    readonly IsAssignedByOthers: IReadValue<boolean>;
    readonly UID_DynamicGroup: IReadValue<string>;
    readonly Description: IWriteValue<string>;
    readonly UID_Person: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'IsNotMatched' | 'IsAssignedByOthers' | 'UID_DynamicGroup' | 'Description' | 'UID_Person'>;
}
export declare class PortalServicecategories extends TypedEntity {
    readonly ApproveReasonType: IWriteValue<number>;
    readonly Currency: IWriteValue<string>;
    readonly CustomProperty01: IWriteValue<string>;
    readonly CustomProperty02: IWriteValue<string>;
    readonly CustomProperty03: IWriteValue<string>;
    readonly CustomProperty04: IWriteValue<string>;
    readonly CustomProperty05: IWriteValue<string>;
    readonly CustomProperty06: IWriteValue<string>;
    readonly CustomProperty07: IWriteValue<string>;
    readonly CustomProperty08: IWriteValue<string>;
    readonly CustomProperty09: IWriteValue<string>;
    readonly CustomProperty10: IWriteValue<string>;
    readonly DenyReasonType: IWriteValue<number>;
    readonly Description: IWriteValue<string>;
    readonly FullPath: IWriteValue<string>;
    readonly Ident_AccProductGroup: IWriteValue<string>;
    readonly InternalPrice: IWriteValue<number>;
    readonly IsSpecialGroup: IWriteValue<boolean>;
    readonly JPegPhoto: IWriteValue<string>;
    readonly OrderReasonType: IWriteValue<number>;
    readonly PurchasePrice: IWriteValue<number>;
    readonly Remarks: IWriteValue<string>;
    readonly SalesPrice: IWriteValue<number>;
    readonly SortOrder: IWriteValue<string>;
    readonly UID_AccProductGroup: IWriteValue<string>;
    readonly UID_AccProductGroupParent: IWriteValue<string>;
    readonly UID_AccProductParamCategory: IWriteValue<string>;
    readonly UID_OrgAttestator: IWriteValue<string>;
    readonly UID_OrgRuler: IWriteValue<string>;
    readonly UID_PWODecisionMethod: IWriteValue<string>;
    readonly XTouched: IWriteValue<string>;
    readonly ImageRef: IReadValue<string>;
    readonly HasChildren: IReadValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'ApproveReasonType' | 'Currency' | 'CustomProperty01' | 'CustomProperty02' | 'CustomProperty03' | 'CustomProperty04' | 'CustomProperty05' | 'CustomProperty06' | 'CustomProperty07' | 'CustomProperty08' | 'CustomProperty09' | 'CustomProperty10' | 'DenyReasonType' | 'Description' | 'FullPath' | 'Ident_AccProductGroup' | 'InternalPrice' | 'IsSpecialGroup' | 'JPegPhoto' | 'OrderReasonType' | 'PurchasePrice' | 'Remarks' | 'SalesPrice' | 'SortOrder' | 'UID_AccProductGroup' | 'UID_AccProductGroupParent' | 'UID_AccProductParamCategory' | 'UID_OrgAttestator' | 'UID_OrgRuler' | 'UID_PWODecisionMethod' | 'XTouched' | 'ImageRef' | 'HasChildren'>;
}
export declare class PortalServicecategoriesInteractive extends TypedEntity {
    readonly ApproveReasonType: IWriteValue<number>;
    readonly Currency: IWriteValue<string>;
    readonly CustomProperty01: IWriteValue<string>;
    readonly CustomProperty02: IWriteValue<string>;
    readonly CustomProperty03: IWriteValue<string>;
    readonly CustomProperty04: IWriteValue<string>;
    readonly CustomProperty05: IWriteValue<string>;
    readonly CustomProperty06: IWriteValue<string>;
    readonly CustomProperty07: IWriteValue<string>;
    readonly CustomProperty08: IWriteValue<string>;
    readonly CustomProperty09: IWriteValue<string>;
    readonly CustomProperty10: IWriteValue<string>;
    readonly DenyReasonType: IWriteValue<number>;
    readonly Description: IWriteValue<string>;
    readonly FullPath: IWriteValue<string>;
    readonly Ident_AccProductGroup: IWriteValue<string>;
    readonly InternalPrice: IWriteValue<number>;
    readonly IsSpecialGroup: IWriteValue<boolean>;
    readonly JPegPhoto: IWriteValue<string>;
    readonly OrderReasonType: IWriteValue<number>;
    readonly PurchasePrice: IWriteValue<number>;
    readonly Remarks: IWriteValue<string>;
    readonly SalesPrice: IWriteValue<number>;
    readonly SortOrder: IWriteValue<string>;
    readonly UID_AccProductGroup: IWriteValue<string>;
    readonly UID_AccProductGroupParent: IWriteValue<string>;
    readonly UID_AccProductParamCategory: IWriteValue<string>;
    readonly UID_OrgAttestator: IWriteValue<string>;
    readonly UID_OrgRuler: IWriteValue<string>;
    readonly UID_PWODecisionMethod: IWriteValue<string>;
    readonly XTouched: IWriteValue<string>;
    readonly ImageRef: IReadValue<string>;
    readonly HasChildren: IReadValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'ApproveReasonType' | 'Currency' | 'CustomProperty01' | 'CustomProperty02' | 'CustomProperty03' | 'CustomProperty04' | 'CustomProperty05' | 'CustomProperty06' | 'CustomProperty07' | 'CustomProperty08' | 'CustomProperty09' | 'CustomProperty10' | 'DenyReasonType' | 'Description' | 'FullPath' | 'Ident_AccProductGroup' | 'InternalPrice' | 'IsSpecialGroup' | 'JPegPhoto' | 'OrderReasonType' | 'PurchasePrice' | 'Remarks' | 'SalesPrice' | 'SortOrder' | 'UID_AccProductGroup' | 'UID_AccProductGroupParent' | 'UID_AccProductParamCategory' | 'UID_OrgAttestator' | 'UID_OrgRuler' | 'UID_PWODecisionMethod' | 'XTouched' | 'ImageRef' | 'HasChildren'>;
}
export declare class PortalServiceitems extends TypedEntity {
    readonly UID_OrgRuler: IReadValue<string>;
    readonly IsInActive: IWriteValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_OrgRuler' | 'IsInActive'>;
}
export declare class PortalServiceitemsInteractive extends TypedEntity {
    readonly UID_OrgRuler: IReadValue<string>;
    readonly IsInActive: IWriteValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_OrgRuler' | 'IsInActive'>;
}
export declare class PortalServiceitemsTags extends TypedEntity {
    readonly Ident_DialogTag: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Ident_DialogTag'>;
}
export declare class PortalShopCategories extends TypedEntity {
    readonly Ident_AccProductGroup: IReadValue<string>;
    readonly UID_AccProductGroup: IReadValue<string>;
    readonly UID_AccProductGroupParent: IReadValue<string>;
    readonly Description: IReadValue<string>;
    readonly SortOrder: IReadValue<string>;
    readonly FullPath: IReadValue<string>;
    readonly ImageRef: IReadValue<string>;
    readonly HasChildren: IReadValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Ident_AccProductGroup' | 'UID_AccProductGroup' | 'UID_AccProductGroupParent' | 'Description' | 'SortOrder' | 'FullPath' | 'ImageRef' | 'HasChildren'>;
}
export declare class PortalShopConfigEntitlements extends TypedEntity {
    readonly IsInActive: IReadValue<boolean>;
    readonly UID_AccProductGroup: IReadValue<string>;
    readonly UID_PWODecisionMethod: IReadValue<string>;
    readonly TableName: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'IsInActive' | 'UID_AccProductGroup' | 'UID_PWODecisionMethod' | 'TableName'>;
}
export declare class PortalShopConfigEntitlementsQerassign extends TypedEntity {
    readonly UID_ITShopOrg: IReadValue<string>;
    readonly UID_QERAssign: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_ITShopOrg' | 'UID_QERAssign'>;
}
export declare class PortalShopConfigEntitlementsQerresource extends TypedEntity {
    readonly UID_ITShopOrg: IReadValue<string>;
    readonly UID_QERResource: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_ITShopOrg' | 'UID_QERResource'>;
}
export declare class PortalShopConfigEntitlementsQerreuse extends TypedEntity {
    readonly UID_ITShopOrg: IReadValue<string>;
    readonly UID_QERReuse: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_ITShopOrg' | 'UID_QERReuse'>;
}
export declare class PortalShopConfigEntitlementsQerreuseus extends TypedEntity {
    readonly UID_ITShopOrg: IReadValue<string>;
    readonly UID_QERReuseUS: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_ITShopOrg' | 'UID_QERReuseUS'>;
}
export declare class PortalShopConfigMembers extends TypedEntity {
    readonly UID_ITShopOrg: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly UID_Person: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_ITShopOrg' | 'XOrigin' | 'UID_Person'>;
}
export declare class PortalShopConfigStructure extends TypedEntity {
    readonly Description: IWriteValue<string>;
    readonly Ident_Org: IWriteValue<string>;
    readonly ITShopInfo: IWriteValue<string>;
    readonly UID_OrgAttestator: IWriteValue<string>;
    readonly UID_ParentITShopOrg: IWriteValue<string>;
    readonly UID_PersonHead: IWriteValue<string>;
    readonly UID_PersonHeadSecond: IWriteValue<string>;
    readonly UID_PWODecisionMethod: IWriteValue<string>;
    readonly DecisionMethods: IWriteValue<string>;
    readonly UID_CustomerNode: IReadValue<string>;
    readonly UID_DynamicGroup: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Description' | 'Ident_Org' | 'ITShopInfo' | 'UID_OrgAttestator' | 'UID_ParentITShopOrg' | 'UID_PersonHead' | 'UID_PersonHeadSecond' | 'UID_PWODecisionMethod' | 'DecisionMethods' | 'UID_CustomerNode' | 'UID_DynamicGroup'>;
}
export declare class PortalShopServiceitems extends TypedEntity {
    readonly UID_AccProductGroup: IReadValue<string>;
    readonly UID_AccProductParamCategory: IReadValue<string>;
    readonly ServiceCategoryFullPath: IReadValue<string>;
    readonly IsRequestable: IReadValue<boolean>;
    readonly OrderableStatus: IReadValue<string>;
    readonly TableName: IReadValue<string>;
    readonly ImageRef: IReadValue<string>;
    readonly Tags: IReadValue<string>;
    readonly CountInPeerGroup: IReadValue<number>;
    readonly IsReusable: IReadValue<boolean>;
    readonly IsReusableWithUnsubscribe: IReadValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_AccProductGroup' | 'UID_AccProductParamCategory' | 'ServiceCategoryFullPath' | 'IsRequestable' | 'OrderableStatus' | 'TableName' | 'ImageRef' | 'Tags' | 'CountInPeerGroup' | 'IsReusable' | 'IsReusableWithUnsubscribe'>;
}
export declare class PortalShopServiceitemsEntitlements extends TypedEntity {
    readonly TargetEntitlement: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'TargetEntitlement'>;
}
export declare class PortalTermsofuse extends TypedEntity {
    readonly DisplayContent: IReadValue<string>;
    readonly HasFile: IReadValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'DisplayContent' | 'HasFile'>;
}
export declare class PortalView extends TypedEntity {
    readonly IsOwner: IReadValue<boolean>;
    readonly IsAdmin: IReadValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'IsOwner' | 'IsAdmin'>;
}
export declare class PortalWebauthnkey extends TypedEntity {
    readonly DateRegistered: IReadValue<Date>;
    readonly DateLastUsed: IReadValue<Date>;
    readonly SignatureCount: IReadValue<number>;
    readonly DisplayName: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'DateRegistered' | 'DateLastUsed' | 'SignatureCount' | 'DisplayName'>;
}
export declare class PortalWorkflow extends TypedEntity {
    readonly LevelNumber: IReadValue<number>;
    readonly LevelDisplay: IReadValue<string>;
    readonly Ident_PWODecisionStep: IReadValue<string>;
    readonly SubLevelNumber: IReadValue<number>;
    readonly DirectSteps: IReadValue<string>;
    readonly PositiveSteps: IReadValue<number>;
    readonly NegativeSteps: IReadValue<number>;
    readonly CountApprover: IReadValue<number>;
    readonly EscalationSteps: IReadValue<number>;
    readonly UID_PWODecisionRule: IReadValue<string>;
    readonly IsAdditionalAllowed: IReadValue<boolean>;
    readonly IsInsteadOfAllowed: IReadValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'LevelNumber' | 'LevelDisplay' | 'Ident_PWODecisionStep' | 'SubLevelNumber' | 'DirectSteps' | 'PositiveSteps' | 'NegativeSteps' | 'CountApprover' | 'EscalationSteps' | 'UID_PWODecisionRule' | 'IsAdditionalAllowed' | 'IsInsteadOfAllowed'>;
}
export declare class PasswordresetPasswordquestionsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PasswordresetPasswordquestions;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PasswordresetPasswordquestions, unknown>>;
    Put(inputParameterName: PasswordresetPasswordquestions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PasswordresetPasswordquestions, unknown>>;
    Post(inputParameterName: PasswordresetPasswordquestions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PasswordresetPasswordquestions, unknown>>;
    Delete(UID_QERPasswordQueryAndAnswer: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PasswordresetPasswordquestions, unknown>>;
}
export declare class PortalAdminApplicationroleWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_AERole: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminApplicationrole, unknown>>;
}
export declare class PortalAdminApplicationroleMembersWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalAdminApplicationroleMembers;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_AERole: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminApplicationroleMembers, unknown>>;
    Post(UID_AERole: string, inputParameterName: PortalAdminApplicationroleMembers): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminApplicationroleMembers, unknown>>;
    Delete(UID_AERole: string, UID_Person: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminApplicationroleMembers, unknown>>;
}
export declare class PortalAdminPersonWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalAdminPerson;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        withmanager?: string;
        orphaned?: string;
        deletedintarget?: string;
        isinactive?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminPerson, unknown>>;
    Put(inputParameterName: PortalAdminPerson): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminPerson, unknown>>;
    Post(inputParameterName: PortalAdminPerson): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminPerson, unknown>>;
    Delete(UID_Person: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminPerson, unknown>>;
}
export declare class PortalAdminResourcesQerassignWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        published?: string;
        withowner?: string;
        risk?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminResourcesQerassign, unknown>>;
    Put(inputParameterName: PortalAdminResourcesQerassign): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminResourcesQerassign, unknown>>;
}
export declare class PortalAdminResourcesQerassignInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalAdminResourcesQerassignInteractive): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminResourcesQerassignInteractive, unknown>>;
    Get_byid(UID_QERAssign: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminResourcesQerassignInteractive, unknown>>;
}
export declare class PortalAdminResourcesQerresourceWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        published?: string;
        withowner?: string;
        risk?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminResourcesQerresource, unknown>>;
    Put(inputParameterName: PortalAdminResourcesQerresource): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminResourcesQerresource, unknown>>;
}
export declare class PortalAdminResourcesQerresourceInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalAdminResourcesQerresourceInteractive): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminResourcesQerresourceInteractive, unknown>>;
    Get_byid(UID_QERResource: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminResourcesQerresourceInteractive, unknown>>;
}
export declare class PortalAdminResourcesQerreuseWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        published?: string;
        withowner?: string;
        risk?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminResourcesQerreuse, unknown>>;
    Put(inputParameterName: PortalAdminResourcesQerreuse): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminResourcesQerreuse, unknown>>;
}
export declare class PortalAdminResourcesQerreuseInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalAdminResourcesQerreuseInteractive): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminResourcesQerreuseInteractive, unknown>>;
    Get_byid(UID_QERReuse: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminResourcesQerreuseInteractive, unknown>>;
}
export declare class PortalAdminResourcesQerreuseusWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        published?: string;
        withowner?: string;
        risk?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminResourcesQerreuseus, unknown>>;
    Put(inputParameterName: PortalAdminResourcesQerreuseus): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminResourcesQerreuseus, unknown>>;
}
export declare class PortalAdminResourcesQerreuseusInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalAdminResourcesQerreuseusInteractive): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminResourcesQerreuseusInteractive, unknown>>;
    Get_byid(UID_QERReuseUS: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminResourcesQerreuseusInteractive, unknown>>;
}
export declare class PortalAdminRoleDepartmentWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalAdminRoleDepartment;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
        risk?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleDepartment, unknown>>;
    Put(inputParameterName: PortalAdminRoleDepartment): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleDepartment, unknown>>;
    Post(inputParameterName: PortalAdminRoleDepartment): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleDepartment, unknown>>;
}
export declare class PortalAdminRoleDepartmentInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalAdminRoleDepartmentInteractive): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleDepartmentInteractive, unknown>>;
    Get_byid(UID_Department: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleDepartmentInteractive, unknown>>;
    Get(): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleDepartmentInteractive, unknown>>;
}
export declare class PortalAdminRoleLocalityWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalAdminRoleLocality;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
        risk?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleLocality, unknown>>;
    Put(inputParameterName: PortalAdminRoleLocality): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleLocality, unknown>>;
    Post(inputParameterName: PortalAdminRoleLocality): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleLocality, unknown>>;
}
export declare class PortalAdminRoleLocalityInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalAdminRoleLocalityInteractive): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleLocalityInteractive, unknown>>;
    Get_byid(UID_Locality: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleLocalityInteractive, unknown>>;
    Get(): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleLocalityInteractive, unknown>>;
}
export declare class PortalAdminRoleProfitcenterWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalAdminRoleProfitcenter;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
        risk?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleProfitcenter, unknown>>;
    Put(inputParameterName: PortalAdminRoleProfitcenter): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleProfitcenter, unknown>>;
    Post(inputParameterName: PortalAdminRoleProfitcenter): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleProfitcenter, unknown>>;
}
export declare class PortalAdminRoleProfitcenterInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalAdminRoleProfitcenterInteractive): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleProfitcenterInteractive, unknown>>;
    Get_byid(UID_ProfitCenter: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleProfitcenterInteractive, unknown>>;
    Get(): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleProfitcenterInteractive, unknown>>;
}
export declare class PortalCandidatesAccproductWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesAccproduct, unknown>>;
}
export declare class PortalCandidatesAccproductgroupWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesAccproductgroup, unknown>>;
}
export declare class PortalCandidatesAccproductparamcategoryWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesAccproductparamcategory, unknown>>;
}
export declare class PortalCandidatesDepartmentWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesDepartment, unknown>>;
}
export declare class PortalCandidatesDialoguserWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesDialoguser, unknown>>;
}
export declare class PortalCandidatesFirmpartnerWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesFirmpartner, unknown>>;
}
export declare class PortalCandidatesHelperheadorgWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesHelperheadorg, unknown>>;
}
export declare class PortalCandidatesHelperheadpersonWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesHelperheadperson, unknown>>;
}
export declare class PortalCandidatesLocalityWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesLocality, unknown>>;
}
export declare class PortalCandidatesPersonWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesPerson, unknown>>;
}
export declare class PortalCandidatesPersoninaeroleWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesPersoninaerole, unknown>>;
}
export declare class PortalCandidatesPersonindepartmentWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesPersonindepartment, unknown>>;
}
export declare class PortalCandidatesPersoninitshoporgWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesPersoninitshoporg, unknown>>;
}
export declare class PortalCandidatesPersoninlocalityWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesPersoninlocality, unknown>>;
}
export declare class PortalCandidatesPersoninprofitcenterWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesPersoninprofitcenter, unknown>>;
}
export declare class PortalCandidatesProfitcenterWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesProfitcenter, unknown>>;
}
export declare class PortalCandidatesPwodecisionmethodWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesPwodecisionmethod, unknown>>;
}
export declare class PortalCandidatesQbmcultureWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesQbmculture, unknown>>;
}
export declare class PortalCandidatesQerjustificationWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesQerjustification, unknown>>;
}
export declare class PortalCandidatesQerpickcategoryWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesQerpickcategory, unknown>>;
}
export declare class PortalCandidatesWorkdeskWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesWorkdesk, unknown>>;
}
export declare class PortalCartitemWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalCartitem;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCartitem, CartItemDataRead>>;
    Put(inputParameterName: PortalCartitem): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCartitem, CartItemDataRead>>;
    Post(inputParameterName: PortalCartitem): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCartitem, CartItemDataRead>>;
    Delete(UID_ShoppingCartItem: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCartitem, CartItemDataRead>>;
}
export declare class PortalCartitemInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalCartitemInteractive): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCartitemInteractive, CartItemDataRead>>;
    Delete(inputParameterName: PortalCartitemInteractive): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCartitemInteractive, CartItemDataRead>>;
    Get_byid(UID_ShoppingCartItem: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCartitemInteractive, CartItemDataRead>>;
    Get(): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCartitemInteractive, CartItemDataRead>>;
}
export declare class PortalCartitemInteractiveParameterCandidatesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Post(name: string, parenttable: string, inputParameterName: PortalCartitemInteractiveParameterCandidates, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCartitemInteractiveParameterCandidates, unknown>>;
}
export declare class PortalCartitemParameterCandidatesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Post(name: string, parenttable: string, inputParameterName: PortalCartitemParameterCandidates, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCartitemParameterCandidates, unknown>>;
}
export declare class PortalDelegableWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidpersonsender: string, uidpersonreceiver: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalDelegable, unknown>>;
}
export declare class PortalDelegationsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalDelegations;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        uidperson?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalDelegations, unknown>>;
    Post(inputParameterName: PortalDelegations): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalDelegations, unknown>>;
}
export declare class PortalDelegationsGlobalRoleclassesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidperson: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalDelegationsGlobalRoleclasses, unknown>>;
}
export declare class PortalDynamicgroupWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_DynamicGroup: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalDynamicgroup, SqlWizardRead>>;
    Delete(UID_DynamicGroup: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalDynamicgroup, SqlWizardRead>>;
}
export declare class PortalDynamicgroupInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(UID_DynamicGroup: string, inputParameterName: PortalDynamicgroupInteractive): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalDynamicgroupInteractive, SqlWizardRead>>;
    Delete(UID_DynamicGroup: string, inputParameterName: PortalDynamicgroupInteractive): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalDynamicgroupInteractive, SqlWizardRead>>;
    Get(UID_DynamicGroup: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalDynamicgroupInteractive, SqlWizardRead>>;
}
export declare class PortalDynamicgroupSqlwizardCandidatesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(table: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalDynamicgroupSqlwizardCandidates, unknown>>;
}
export declare class PortalItshopApproveHistoryWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidpwo: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopApproveHistory, unknown>>;
}
export declare class PortalItshopApproveRequestsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        Escalation?: boolean;
        uid_personwantsorg?: string;
        uid_pwohelperpwo?: string;
        forinquiry?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopApproveRequests, PwoExtendedData>>;
    Put(inputParameterName: PortalItshopApproveRequests): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopApproveRequests, PwoExtendedData>>;
}
export declare class PortalItshopApproveRequestsParameterCandidatesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Post(name: string, parenttable: string, inputParameterName: PortalItshopApproveRequestsParameterCandidates, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopApproveRequestsParameterCandidates, unknown>>;
}
export declare class PortalItshopCartWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        IncludeSubmitted?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopCart, unknown>>;
    Put(inputParameterName: PortalItshopCart): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopCart, unknown>>;
    Delete(UID_ShoppingCartOrder: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopCart, unknown>>;
}
export declare class PortalItshopPatternWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidpattern: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopPattern, unknown>>;
}
export declare class PortalItshopPatternAdminWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopPatternAdmin, unknown>>;
    Put(inputParameterName: PortalItshopPatternAdmin): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopPatternAdmin, unknown>>;
}
export declare class PortalItshopPatternItemWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalItshopPatternItem;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopPatternItem, unknown>>;
    Post(inputParameterName: PortalItshopPatternItem): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopPatternItem, unknown>>;
    Delete(UID_ShoppingCartPatternItem: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopPatternItem, unknown>>;
}
export declare class PortalItshopPatternPrivateWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalItshopPatternPrivate;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopPatternPrivate, unknown>>;
    Put(inputParameterName: PortalItshopPatternPrivate): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopPatternPrivate, unknown>>;
    Post(inputParameterName: PortalItshopPatternPrivate): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopPatternPrivate, unknown>>;
    Delete(UID_ShoppingCartPattern: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopPatternPrivate, unknown>>;
}
export declare class PortalItshopPatternRequestableWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        UID_Person?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopPatternRequestable, unknown>>;
}
export declare class PortalItshopPeergroupWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidperson: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopPeergroup, unknown>>;
}
export declare class PortalItshopPeergroupMembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        UID_Person?: string;
        UID_PersonReference?: string;
        UID_PersonPeerGroup?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopPeergroupMemberships, ServiceItemsExtendedData>>;
}
export declare class PortalItshopPersondecisionWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidpersonwantsorg: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopPersondecision, unknown>>;
}
export declare class PortalItshopRequestsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        uidpwo?: string;
        DocumentNumber?: string;
        UID_Person?: string;
        UID_PersonDecision?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ShowMyDecisions?: string;
        ShowMyPending?: string;
        ShowEndingSoon?: string;
        MyDelegations?: string;
        status?: string;
        person?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopRequests, PwoExtendedData>>;
}
export declare class PortalItshopRequestsParameterCandidatesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Post(name: string, parenttable: string, inputParameterName: PortalItshopRequestsParameterCandidates, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalItshopRequestsParameterCandidates, unknown>>;
}
export declare class PortalJustificationsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalJustifications, unknown>>;
}
export declare class PortalPasswordquestionsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalPasswordquestions;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPasswordquestions, unknown>>;
    Put(inputParameterName: PortalPasswordquestions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPasswordquestions, unknown>>;
    Post(inputParameterName: PortalPasswordquestions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPasswordquestions, unknown>>;
    Delete(UID_QERPasswordQueryAndAnswer: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPasswordquestions, unknown>>;
}
export declare class PortalPersonActiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonActive, unknown>>;
}
export declare class PortalPersonAllWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        isinactive?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonAll, unknown>>;
}
export declare class PortalPersonEmailWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidperson: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonEmail, unknown>>;
}
export declare class PortalPersonMasterdataWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonMasterdata, unknown>>;
}
export declare class PortalPersonMasterdataInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalPersonMasterdataInteractive): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonMasterdataInteractive, unknown>>;
    Get_byid(UID_Person: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonMasterdataInteractive, unknown>>;
}
export declare class PortalPersonMembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonMemberships, unknown>>;
}
export declare class PortalPersonOrgdataWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(type: string, uidperson: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonOrgdata, unknown>>;
}
export declare class PortalPersonOverviewWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidperson: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonOverview, unknown>>;
}
export declare class PortalPersonReportsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OnlyDirect?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        isinactive?: string;
        reports?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonReports, unknown>>;
}
export declare class PortalPersonReportsInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalPersonReportsInteractive): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonReportsInteractive, unknown>>;
    Get_byid(UID_Person: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonReportsInteractive, unknown>>;
    Get(): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonReportsInteractive, unknown>>;
}
export declare class PortalPersonRequestmanagerchangeWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalPersonRequestmanagerchange;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Post(UID_PersonOrdered: string, inputParameterName: PortalPersonRequestmanagerchange): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonRequestmanagerchange, unknown>>;
}
export declare class PortalPersonRolemembershipsAeroleWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_Person: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonRolemembershipsAerole, unknown>>;
}
export declare class PortalPersonRolemembershipsDepartmentWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_Person: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonRolemembershipsDepartment, unknown>>;
}
export declare class PortalPersonRolemembershipsItshoporgWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_Person: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        type?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonRolemembershipsItshoporg, unknown>>;
}
export declare class PortalPersonRolemembershipsLocalityWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_Person: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonRolemembershipsLocality, unknown>>;
}
export declare class PortalPersonRolemembershipsProfitcenterWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_Person: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonRolemembershipsProfitcenter, unknown>>;
}
export declare class PortalPersonUidWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidperson: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonUid, unknown>>;
}
export declare class PortalPickcategoryWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalPickcategory;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPickcategory, unknown>>;
    Put(inputParameterName: PortalPickcategory): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPickcategory, unknown>>;
    Post(inputParameterName: PortalPickcategory): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPickcategory, unknown>>;
    Delete(UID_QERPickCategory: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPickcategory, unknown>>;
}
export declare class PortalPickcategoryItemsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalPickcategoryItems;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_QERPickCategory: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPickcategoryItems, unknown>>;
    Post(UID_QERPickCategory: string, inputParameterName: PortalPickcategoryItems): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPickcategoryItems, unknown>>;
    Delete(UID_QERPickCategory: string, UID_QERPickedItem: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPickcategoryItems, unknown>>;
}
export declare class PortalResourcesMembershipQerresourceWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalResourcesMembershipQerresource;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_QERResource: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalResourcesMembershipQerresource, unknown>>;
    Post(UID_QERResource: string, inputParameterName: PortalResourcesMembershipQerresource): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalResourcesMembershipQerresource, unknown>>;
    Delete(UID_QERResource: string, UID_Person: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalResourcesMembershipQerresource, unknown>>;
}
export declare class PortalResourcesQerassignServiceitemWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalResourcesQerassignServiceitem, unknown>>;
    Put(inputParameterName: PortalResourcesQerassignServiceitem): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalResourcesQerassignServiceitem, unknown>>;
}
export declare class PortalResourcesQerresourceServiceitemWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalResourcesQerresourceServiceitem, unknown>>;
    Put(inputParameterName: PortalResourcesQerresourceServiceitem): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalResourcesQerresourceServiceitem, unknown>>;
}
export declare class PortalResourcesQerreuseServiceitemWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalResourcesQerreuseServiceitem, unknown>>;
    Put(inputParameterName: PortalResourcesQerreuseServiceitem): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalResourcesQerreuseServiceitem, unknown>>;
}
export declare class PortalResourcesQerreuseusServiceitemWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalResourcesQerreuseusServiceitem, unknown>>;
    Put(inputParameterName: PortalResourcesQerreuseusServiceitem): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalResourcesQerreuseusServiceitem, unknown>>;
}
export declare class PortalRespAeroleWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespAerole, unknown>>;
}
export declare class PortalRespAeroleInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalRespAeroleInteractive): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespAeroleInteractive, unknown>>;
    Get_byid(UID_AERole: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespAeroleInteractive, unknown>>;
    Get(): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespAeroleInteractive, unknown>>;
}
export declare class PortalRespDepartmentWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespDepartment, unknown>>;
}
export declare class PortalRespDepartmentInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalRespDepartmentInteractive): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespDepartmentInteractive, unknown>>;
    Get_byid(UID_Department: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespDepartmentInteractive, unknown>>;
    Get(): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespDepartmentInteractive, unknown>>;
}
export declare class PortalRespLocalityWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespLocality, unknown>>;
}
export declare class PortalRespLocalityInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalRespLocalityInteractive): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespLocalityInteractive, unknown>>;
    Get_byid(UID_Locality: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespLocalityInteractive, unknown>>;
    Get(): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespLocalityInteractive, unknown>>;
}
export declare class PortalRespProfitcenterWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespProfitcenter, unknown>>;
}
export declare class PortalRespProfitcenterInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalRespProfitcenterInteractive): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespProfitcenterInteractive, unknown>>;
    Get_byid(UID_ProfitCenter: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespProfitcenterInteractive, unknown>>;
    Get(): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespProfitcenterInteractive, unknown>>;
}
export declare class PortalRiskFunctionsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRiskFunctions, unknown>>;
    Put(inputParameterName: PortalRiskFunctions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRiskFunctions, unknown>>;
}
export declare class PortalRolesConfigDepartmentPrimarymembersWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_Department: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRolesConfigDepartmentPrimarymembers, unknown>>;
}
export declare class PortalRolesConfigLocalityPrimarymembersWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_Locality: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRolesConfigLocalityPrimarymembers, unknown>>;
}
export declare class PortalRolesConfigProfitcenterPrimarymembersWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ProfitCenter: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRolesConfigProfitcenterPrimarymembers, unknown>>;
}
export declare class PortalRolesEntitlementsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(roletype: string, uidrole: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRolesEntitlements, unknown>>;
}
export declare class PortalRolesExclusionsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalRolesExclusions;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_DynamicGroup: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRolesExclusions, unknown>>;
    Put(UID_DynamicGroup: string, inputParameterName: PortalRolesExclusions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRolesExclusions, unknown>>;
    Post(UID_DynamicGroup: string, inputParameterName: PortalRolesExclusions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRolesExclusions, unknown>>;
    Delete(UID_DynamicGroup: string, UID_Person: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRolesExclusions, unknown>>;
}
export declare class PortalServicecategoriesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalServicecategories;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalServicecategories, unknown>>;
    Put(inputParameterName: PortalServicecategories): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalServicecategories, unknown>>;
    Post(inputParameterName: PortalServicecategories): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalServicecategories, unknown>>;
    Delete(UID_AccProductGroup: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalServicecategories, unknown>>;
}
export declare class PortalServicecategoriesInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalServicecategoriesInteractive): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalServicecategoriesInteractive, unknown>>;
    Delete(inputParameterName: PortalServicecategoriesInteractive): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalServicecategoriesInteractive, unknown>>;
    Get_byid(UID_AccProductGroup: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalServicecategoriesInteractive, unknown>>;
    Get(): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalServicecategoriesInteractive, unknown>>;
}
export declare class PortalServiceitemsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalServiceitems;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalServiceitems, unknown>>;
    Put(inputParameterName: PortalServiceitems): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalServiceitems, unknown>>;
    Post(inputParameterName: PortalServiceitems): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalServiceitems, unknown>>;
    Delete(UID_AccProduct: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalServiceitems, unknown>>;
}
export declare class PortalServiceitemsInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalServiceitemsInteractive): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalServiceitemsInteractive, unknown>>;
    Delete(inputParameterName: PortalServiceitemsInteractive): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalServiceitemsInteractive, unknown>>;
    Get_byid(UID_AccProduct: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalServiceitemsInteractive, unknown>>;
    Get(): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalServiceitemsInteractive, unknown>>;
}
export declare class PortalServiceitemsTagsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_AccProduct: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalServiceitemsTags, unknown>>;
}
export declare class PortalShopCategoriesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        UID_Person?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopCategories, unknown>>;
}
export declare class PortalShopConfigEntitlementsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidshelf: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlements, unknown>>;
}
export declare class PortalShopConfigEntitlementsQerassignWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalShopConfigEntitlementsQerassign;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ITShopOrg: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsQerassign, unknown>>;
    Post(UID_ITShopOrg: string, inputParameterName: PortalShopConfigEntitlementsQerassign): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsQerassign, unknown>>;
    Delete(UID_ITShopOrg: string, UID_QERAssign: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsQerassign, unknown>>;
}
export declare class PortalShopConfigEntitlementsQerresourceWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalShopConfigEntitlementsQerresource;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ITShopOrg: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsQerresource, unknown>>;
    Post(UID_ITShopOrg: string, inputParameterName: PortalShopConfigEntitlementsQerresource): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsQerresource, unknown>>;
    Delete(UID_ITShopOrg: string, UID_QERResource: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsQerresource, unknown>>;
}
export declare class PortalShopConfigEntitlementsQerreuseWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalShopConfigEntitlementsQerreuse;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ITShopOrg: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsQerreuse, unknown>>;
    Post(UID_ITShopOrg: string, inputParameterName: PortalShopConfigEntitlementsQerreuse): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsQerreuse, unknown>>;
    Delete(UID_ITShopOrg: string, UID_QERReuse: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsQerreuse, unknown>>;
}
export declare class PortalShopConfigEntitlementsQerreuseusWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalShopConfigEntitlementsQerreuseus;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ITShopOrg: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsQerreuseus, unknown>>;
    Post(UID_ITShopOrg: string, inputParameterName: PortalShopConfigEntitlementsQerreuseus): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsQerreuseus, unknown>>;
    Delete(UID_ITShopOrg: string, UID_QERReuseUS: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsQerreuseus, unknown>>;
}
export declare class PortalShopConfigMembersWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalShopConfigMembers;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ITShopOrg: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigMembers, unknown>>;
    Put(UID_ITShopOrg: string, inputParameterName: PortalShopConfigMembers): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigMembers, unknown>>;
    Post(UID_ITShopOrg: string, inputParameterName: PortalShopConfigMembers): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigMembers, unknown>>;
    Delete(UID_ITShopOrg: string, UID_Person: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigMembers, unknown>>;
}
export declare class PortalShopConfigStructureWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalShopConfigStructure;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigStructure, unknown>>;
    Put(inputParameterName: PortalShopConfigStructure): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigStructure, unknown>>;
    Post(inputParameterName: PortalShopConfigStructure): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigStructure, unknown>>;
    Delete(UID_ITShopOrg: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigStructure, unknown>>;
}
export declare class PortalShopServiceitemsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        UID_Person?: string;
        UID_AccProductGroup?: string;
        IncludeChildCategories?: boolean;
        UID_AccProductParent?: string;
        UID_PersonReference?: string;
        UID_PersonPeerGroup?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopServiceitems, ServiceItemsExtendedData>>;
}
export declare class PortalShopServiceitemsEntitlementsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_AccProduct: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopServiceitemsEntitlements, unknown>>;
}
export declare class PortalTermsofuseWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTermsofuse, unknown>>;
}
export declare class PortalViewWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(tablename: string, uid: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalView, IClientProperty[]>>;
}
export declare class PortalWebauthnkeyWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalWebauthnkey, WebauthnConfig>>;
    Put(inputParameterName: PortalWebauthnkey): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalWebauthnkey, WebauthnConfig>>;
    Delete(UID_QERWebAuthnKey: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalWebauthnkey, WebauthnConfig>>;
}
export declare class PortalWorkflowWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidpwo: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalWorkflow, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    admin_config_get(): MethodDescriptor<ConfigData>;
    admin_config_post(inputParameterName: ApplicationMethodConfig): MethodDescriptor<ApplicationMethodConfig>;
    imx_config_get(): MethodDescriptor<ImxConfig>;
    opsupport_config_get(): MethodDescriptor<ProjectConfig>;
    opsupport_featureconfig_get(): MethodDescriptor<FeatureConfig>;
    opsupport_passwords_get(uidperson: string): MethodDescriptor<PasswordItemsData>;
    opsupport_passwords_post(uidperson: string, inputParameterName: PasswordData): MethodDescriptor<PolicyValidationResult[]>;
    opsupport_person_passcode_post(uid: string): MethodDescriptor<PersonPasscodeResult>;
    passwordreset_passwordquestions_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    passwordreset_passwordquestions_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    passwordreset_passwordquestions_post(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    passwordreset_passwordquestions_delete(UID_QERPasswordQueryAndAnswer: string): MethodDescriptor<EntityCollectionData>;
    passwordreset_passwordquestions_account_post(inputParameterName: CaptchaCodeAndAccount): MethodDescriptor<PasswordResetAuthModel>;
    passwordreset_passwordquestions_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    passwordreset_passwordquestions_unlock_post(uid: string): MethodDescriptor<void>;
    passwordreset_passwords_get(): MethodDescriptor<PasswordItemsData>;
    passwordreset_passwords_post(inputParameterName: PasswordData): MethodDescriptor<PolicyValidationResult[]>;
    portal_admin_applicationrole_get(UID_AERole: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_admin_applicationrole_members_get(UID_AERole: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_admin_applicationrole_members_post(UID_AERole: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_admin_applicationrole_members_delete(UID_AERole: string, UID_Person: string): MethodDescriptor<EntityCollectionData>;
    portal_admin_applicationrole_members_UID_Person_candidates_get(UID_AERole: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_admin_applicationrole_members_UID_Person_candidates_datamodel_get(UID_AERole: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_admin_applicationrole_members_UID_Person_candidates_filtertree_post(UID_AERole: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_admin_person_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, withmanager: string, orphaned: string, deletedintarget: string, isinactive: string): MethodDescriptor<EntityCollectionData>;
    portal_admin_person_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_admin_person_post(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_admin_person_delete(UID_Person: string): MethodDescriptor<EntityCollectionData>;
    portal_admin_person_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_admin_person_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_admin_person_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, withmanager: string, orphaned: string, deletedintarget: string, isinactive: string): MethodDescriptor<GroupInfo[]>;
    portal_admin_person_UID_PersonHead_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_admin_person_UID_PersonHead_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_admin_person_UID_PersonHead_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_admin_resources_qerassign_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_admin_resources_qerassign_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_admin_resources_qerassign_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_admin_resources_qerassign_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_admin_resources_qerassign_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_admin_resources_qerassign_interactive_byid_get(UID_QERAssign: string): MethodDescriptor<InteractiveEntityData>;
    portal_admin_resources_qerresource_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_admin_resources_qerresource_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_admin_resources_qerresource_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_admin_resources_qerresource_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_admin_resources_qerresource_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_admin_resources_qerresource_interactive_byid_get(UID_QERResource: string): MethodDescriptor<InteractiveEntityData>;
    portal_admin_resources_qerreuse_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_admin_resources_qerreuse_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_admin_resources_qerreuse_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_admin_resources_qerreuse_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_admin_resources_qerreuse_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_admin_resources_qerreuse_interactive_byid_get(UID_QERReuse: string): MethodDescriptor<InteractiveEntityData>;
    portal_admin_resources_qerreuseus_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_admin_resources_qerreuseus_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_admin_resources_qerreuseus_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_admin_resources_qerreuseus_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_admin_resources_qerreuseus_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_admin_resources_qerreuseus_interactive_byid_get(UID_QERReuseUS: string): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_department_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_department_put(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_department_post(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_department_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_admin_role_department_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_admin_role_department_interactive_get(): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_department_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_department_interactive_byid_get(UID_Department: string): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_locality_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_locality_put(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_locality_post(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_locality_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_admin_role_locality_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_admin_role_locality_interactive_get(): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_locality_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_locality_interactive_byid_get(UID_Locality: string): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_profitcenter_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_profitcenter_put(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_profitcenter_post(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_profitcenter_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_admin_role_profitcenter_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_admin_role_profitcenter_interactive_get(): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_profitcenter_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_profitcenter_interactive_byid_get(UID_ProfitCenter: string): MethodDescriptor<InteractiveEntityData>;
    portal_assignment_get(tableName: string, uid: string): MethodDescriptor<EntityData[]>;
    portal_candidates_AccProduct_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AccProduct_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_AccProduct_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_AccProductGroup_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AccProductGroup_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_AccProductGroup_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_AccProductParamCategory_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AccProductParamCategory_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_AccProductParamCategory_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_Department_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Department_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_Department_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_DialogUser_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_DialogUser_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_DialogUser_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_FirmPartner_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_FirmPartner_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_FirmPartner_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_HelperHeadOrg_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_HelperHeadOrg_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_HelperHeadOrg_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_HelperHeadPerson_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_HelperHeadPerson_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_HelperHeadPerson_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_Locality_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Locality_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_Locality_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_Person_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Person_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_Person_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_PersonInAERole_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_PersonInAERole_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_PersonInAERole_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_PersonInDepartment_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_PersonInDepartment_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_PersonInDepartment_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_PersonInITShopOrg_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_PersonInITShopOrg_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_PersonInITShopOrg_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_PersonInLocality_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_PersonInLocality_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_PersonInLocality_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_PersonInProfitCenter_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_PersonInProfitCenter_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_PersonInProfitCenter_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_ProfitCenter_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_ProfitCenter_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_ProfitCenter_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_PWODecisionMethod_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_PWODecisionMethod_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_PWODecisionMethod_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_QBMCulture_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QBMCulture_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_QBMCulture_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERJustification_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERJustification_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_QERJustification_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERPickCategory_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERPickCategory_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_QERPickCategory_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_WorkDesk_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_WorkDesk_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_WorkDesk_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_captchaimage_get(t: string): MethodDescriptor<Blob>;
    portal_cart_submit_post(uidcart: string, inputParameterName: CartSubmitOptions): MethodDescriptor<CartCheckResult>;
    portal_cartitem_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<ExtendedEntityCollectionData<CartItemDataRead>>;
    portal_cartitem_put(inputParameterName: ExtendedEntityWriteData<{
        [key: string]: EntityWriteDataColumn[][];
    }>): MethodDescriptor<ExtendedEntityCollectionData<CartItemDataRead>>;
    portal_cartitem_post(inputParameterName: ExtendedEntityWriteData<{
        [key: string]: EntityWriteDataColumn[][];
    }>): MethodDescriptor<ExtendedEntityCollectionData<CartItemDataRead>>;
    portal_cartitem_delete(UID_ShoppingCartItem: string): MethodDescriptor<ExtendedEntityCollectionData<CartItemDataRead>>;
    portal_cartitem_move_post(uidcartitem: string, tocart: boolean): MethodDescriptor<void>;
    portal_cartitem_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_cartitem_interactive_get(): MethodDescriptor<ExtendedInteractiveEntityDataOfCartItemDataRead>;
    portal_cartitem_interactive_put(inputParameterName: any): MethodDescriptor<ExtendedInteractiveEntityDataOfCartItemDataRead>;
    portal_cartitem_interactive_delete(inputParameterName: InteractiveEntityDeleteData): MethodDescriptor<ExtendedInteractiveEntityDataOfCartItemDataRead>;
    portal_cartitem_interactive_byid_get(UID_ShoppingCartItem: string): MethodDescriptor<ExtendedInteractiveEntityDataOfCartItemDataRead>;
    portal_cartitem_interactive_parameter_candidates_post(name: string, parenttable: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, inputParameterName: InteractiveEntityStateData): MethodDescriptor<EntityCollectionData>;
    portal_cartitem_interactive_parameter_candidates_filtertree_post(name: string, parenttable: string, filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_cartitem_interactive_UID_PersonOrdered_candidates_post(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ownsubidentities: string, inputParameterName: InteractiveEntityStateData): MethodDescriptor<EntityCollectionData>;
    portal_cartitem_interactive_UID_PersonOrdered_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_cartitem_interactive_UID_PersonOrdered_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_cartitem_interactive_UID_QERJustificationOrder_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_cartitem_interactive_UID_QERJustificationOrder_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_cartitem_interactive_UID_QERJustificationOrder_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_cartitem_interactive_UID_ShoppingCartOrder_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_cartitem_interactive_UID_ShoppingCartOrder_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_cartitem_interactive_UID_ShoppingCartOrder_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_cartitem_parameter_candidates_post(name: string, parenttable: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, inputParameterName: EntityKeysData): MethodDescriptor<EntityCollectionData>;
    portal_cartitem_parameter_candidates_filtertree_post(name: string, parenttable: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_cartitem_UID_PersonOrdered_candidates_post(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ownsubidentities: string, inputParameterName: EntityKeysData): MethodDescriptor<EntityCollectionData>;
    portal_cartitem_UID_PersonOrdered_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_cartitem_UID_PersonOrdered_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_cartitem_UID_QERJustificationOrder_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_cartitem_UID_QERJustificationOrder_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_cartitem_UID_QERJustificationOrder_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_cartitem_UID_ShoppingCartOrder_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_cartitem_UID_ShoppingCartOrder_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_cartitem_UID_ShoppingCartOrder_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_config_get(): MethodDescriptor<ProjectConfig>;
    portal_dbobject_get(tableName: string, uid: string): MethodDescriptor<EntityData>;
    portal_delegable_get(uidpersonsender: string, uidpersonreceiver: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_delegation_enabled_get(uidperson: string): MethodDescriptor<boolean>;
    portal_delegations_get(uidperson: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_delegations_post(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_delegations_global_post(inputParameterName: GlobalDelegationInput): MethodDescriptor<void>;
    portal_delegations_global_roleclasses_get(uidperson: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_delegations_UID_PersonReceiver_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_delegations_UID_PersonReceiver_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_delegations_UID_PersonReceiver_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_detective_get(uidperson: string, tablename: string, uid: string): MethodDescriptor<SourceNode[]>;
    portal_dynamicgroup_get(UID_DynamicGroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<ExtendedEntityCollectionData<SqlWizardRead>>;
    portal_dynamicgroup_delete(UID_DynamicGroup: string): MethodDescriptor<ExtendedEntityCollectionData<SqlWizardRead>>;
    portal_dynamicgroup_interactive_get(UID_DynamicGroup: string): MethodDescriptor<ExtendedInteractiveEntityDataOfSqlWizardRead>;
    portal_dynamicgroup_interactive_put(UID_DynamicGroup: string, inputParameterName: any): MethodDescriptor<ExtendedInteractiveEntityDataOfSqlWizardRead>;
    portal_dynamicgroup_interactive_delete(UID_DynamicGroup: string, inputParameterName: InteractiveEntityDeleteData): MethodDescriptor<ExtendedInteractiveEntityDataOfSqlWizardRead>;
    portal_dynamicgroup_interactive_UID_DialogSchedule_candidates_get(UID_DynamicGroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_dynamicgroup_interactive_UID_DialogSchedule_candidates_datamodel_get(UID_DynamicGroup: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_dynamicgroup_interactive_UID_DialogSchedule_candidates_filtertree_post(UID_DynamicGroup: string, filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_dynamicgroup_sqlwizard_candidates_get(table: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_dynamicgroup_sqlwizard_tables_columns_get(table: string): MethodDescriptor<FilterPropertyList>;
    portal_featureconfig_get(): MethodDescriptor<FeatureConfig>;
    portal_history_get(table: string, uid: string): MethodDescriptor<HistoryData[]>;
    portal_history_comparison_get(table: string, uid: string, CompareDate: Date): MethodDescriptor<HistoryComparisonData[]>;
    portal_history_rollback_get(CompareDate: Date, CompareId: string, table: string, uid: string): MethodDescriptor<UiActionData[]>;
    portal_history_rollback_post(CompareDate: Date, CompareId: string, table: string, uid: string, inputParameterName: HistoryRollbackActionList): MethodDescriptor<UiActionResultData[]>;
    portal_hyperview_get(table: string, uid: string): MethodDescriptor<ShapeData[]>;
    portal_itshop_additional_post(uidpwo: string, inputParameterName: OtherApproverInput): MethodDescriptor<void>;
    portal_itshop_answerquery_post(uidpwo: string, inputParameterName: ReasonInput): MethodDescriptor<void>;
    portal_itshop_approve_history_get(uidpwo: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_itshop_approve_requests_get(Escalation: boolean, uid_personwantsorg: string, uid_pwohelperpwo: string, forinquiry: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<ExtendedEntityCollectionData<PwoExtendedData>>;
    portal_itshop_approve_requests_put(inputParameterName: ExtendedEntityWriteData<{
        [key: string]: EntityWriteDataColumn[][];
    }>): MethodDescriptor<ExtendedEntityCollectionData<PwoExtendedData>>;
    portal_itshop_approve_requests_accept_post(uidpwo: string): MethodDescriptor<void>;
    portal_itshop_approve_requests_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_itshop_approve_requests_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_itshop_approve_requests_parameter_candidates_post(name: string, parenttable: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, inputParameterName: EntityKeysData): MethodDescriptor<EntityCollectionData>;
    portal_itshop_approve_requests_parameter_candidates_filtertree_post(name: string, parenttable: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_itshop_approve_requests_stepup_post(inputParameterName: RequestStepUpApprovalData): MethodDescriptor<string>;
    portal_itshop_cancel_post(uidpwo: string, inputParameterName: ReasonInput): MethodDescriptor<void>;
    portal_itshop_cart_get(IncludeSubmitted: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_itshop_cart_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_itshop_cart_delete(UID_ShoppingCartOrder: string): MethodDescriptor<EntityCollectionData>;
    portal_itshop_cart_accept_post(uidcartitem: string): MethodDescriptor<void>;
    portal_itshop_cart_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_itshop_decide_post(uidpwo: string, inputParameterName: DecisionInput): MethodDescriptor<void>;
    portal_itshop_denydecision_post(uidpwo: string, inputParameterName: DenyDecisionInput): MethodDescriptor<void>;
    portal_itshop_directdecision_post(uidpwo: string, inputParameterName: DirectDecisionInput): MethodDescriptor<void>;
    portal_itshop_escalate_post(uidpwo: string, inputParameterName: ReasonInput): MethodDescriptor<void>;
    portal_itshop_findproducts_post(inputParameterName: ServiceItemForPerson[]): MethodDescriptor<RequestableProductForPerson[]>;
    portal_itshop_history_requests_get(uidpersonordered: string, uidpersoninserted: string, backto: Date): MethodDescriptor<EntityCollectionData>;
    portal_itshop_history_workflow_get(uidpwo: string, backto: Date): MethodDescriptor<EntityCollectionData>;
    portal_itshop_insteadof_post(uidpwo: string, inputParameterName: OtherApproverInput): MethodDescriptor<void>;
    portal_itshop_pattern_get(uidpattern: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_itshop_pattern_admin_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_itshop_pattern_admin_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_itshop_pattern_admin_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_itshop_pattern_copy_post(uidpattern: string): MethodDescriptor<string>;
    portal_itshop_pattern_item_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_itshop_pattern_item_post(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_itshop_pattern_item_delete(UID_ShoppingCartPatternItem: string): MethodDescriptor<EntityCollectionData>;
    portal_itshop_pattern_item_UID_ShoppingCartPattern_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_itshop_pattern_item_UID_ShoppingCartPattern_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_itshop_pattern_item_UID_ShoppingCartPattern_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_itshop_pattern_private_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_itshop_pattern_private_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_itshop_pattern_private_post(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_itshop_pattern_private_delete(UID_ShoppingCartPattern: string): MethodDescriptor<EntityCollectionData>;
    portal_itshop_pattern_private_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_itshop_pattern_requestable_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_itshop_peergroup_get(uidperson: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_itshop_peergroup_memberships_get(UID_Person: string, UID_PersonReference: string, UID_PersonPeerGroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<ExtendedEntityCollectionData<ServiceItemsExtendedData>>;
    portal_itshop_persondecision_get(uidpersonwantsorg: string): MethodDescriptor<EntityCollectionData>;
    portal_itshop_prolongate_post(uidpwo: string, inputParameterName: ProlongationInput): MethodDescriptor<void>;
    portal_itshop_query_post(uidpwo: string, inputParameterName: PwoQueryInput): MethodDescriptor<void>;
    portal_itshop_recalldecision_post(uidpwo: string, inputParameterName: RecallDecisionInput): MethodDescriptor<void>;
    portal_itshop_recallquery_post(uidpwo: string, inputParameterName: ReasonInput): MethodDescriptor<void>;
    portal_itshop_requests_get(uidpwo: string, DocumentNumber: string, UID_Person: string, UID_PersonDecision: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ShowMyDecisions: string, ShowMyPending: string, ShowEndingSoon: string, MyDelegations: string, status: string, person: string): MethodDescriptor<ExtendedEntityCollectionData<PwoExtendedData>>;
    portal_itshop_requests_datamodel_get(UID_Person: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_itshop_requests_parameter_candidates_post(name: string, parenttable: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, inputParameterName: EntityKeysData): MethodDescriptor<EntityCollectionData>;
    portal_itshop_requests_parameter_candidates_filtertree_post(name: string, parenttable: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_itshop_resetreservation_post(uidpwo: string, inputParameterName: ReasonInput): MethodDescriptor<void>;
    portal_itshop_revokedelegation_post(uidpwo: string, inputParameterName: RecallDecisionInput): MethodDescriptor<void>;
    portal_itshop_unsubscribe_post(inputParameterName: PwoUnsubscribeInput): MethodDescriptor<PwoUnsubscribeResult>;
    portal_justifications_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_multilanguage_config_get(cultureName: string): MethodDescriptor<MultiLanguageConfig>;
    portal_password_qpmlinks_get(): MethodDescriptor<QpmIntegrationLinks>;
    portal_passwordquestions_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_passwordquestions_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_passwordquestions_post(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_passwordquestions_delete(UID_QERPasswordQueryAndAnswer: string): MethodDescriptor<EntityCollectionData>;
    portal_passwordquestions_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_passwordquestions_unlock_post(uid: string): MethodDescriptor<void>;
    portal_pendingitems_get(): MethodDescriptor<{
        [key: string]: number;
    }>;
    portal_person_rolememberships_AERole_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_person_rolememberships_Department_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_person_rolememberships_ITShopOrg_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, type: string): MethodDescriptor<EntityCollectionData>;
    portal_person_rolememberships_Locality_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_person_rolememberships_ProfitCenter_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_person_requestmanagerchange_post(UID_PersonOrdered: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_person_requestmanagerchange_UID_PersonOrdered_candidates_post(UID_PersonOrdered: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, inputParameterName: EntityKeysData): MethodDescriptor<EntityCollectionData>;
    portal_person_requestmanagerchange_UID_PersonOrdered_candidates_datamodel_get(UID_PersonOrdered: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_person_requestmanagerchange_UID_PersonOrdered_candidates_filtertree_post(UID_PersonOrdered: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_person_requestmanagerchange_UID_ShoppingCartOrder_candidates_get(UID_PersonOrdered: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_person_requestmanagerchange_UID_ShoppingCartOrder_candidates_datamodel_get(UID_PersonOrdered: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_person_requestmanagerchange_UID_ShoppingCartOrder_candidates_filtertree_post(UID_PersonOrdered: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_person_memberships_get(uid: string): MethodDescriptor<EntityCollectionData>;
    portal_person_active_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_person_all_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, isinactive: string): MethodDescriptor<EntityCollectionData>;
    portal_person_all_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_person_all_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, isinactive: string): MethodDescriptor<GroupInfo[]>;
    portal_person_config_get(): MethodDescriptor<UserConfig>;
    portal_person_email_get(uidperson: string): MethodDescriptor<EntityCollectionData>;
    portal_person_email_post(uidperson: string, inputParameterName: MailSubscriptionChange): MethodDescriptor<void>;
    portal_person_image_get(uidperson: string): MethodDescriptor<Blob>;
    portal_person_masterdata_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_person_masterdata_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_person_masterdata_interactive_byid_get(UID_Person: string): MethodDescriptor<InteractiveEntityData>;
    portal_person_masterdata_interactive_UID_DialogCountry_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_person_masterdata_interactive_UID_DialogCountry_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_person_masterdata_interactive_UID_DialogCountry_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_person_masterdata_interactive_UID_DialogCulture_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_person_masterdata_interactive_UID_DialogCulture_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_person_masterdata_interactive_UID_DialogCulture_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_person_masterdata_interactive_UID_DialogState_candidates_post(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, inputParameterName: InteractiveEntityStateData): MethodDescriptor<EntityCollectionData>;
    portal_person_masterdata_interactive_UID_DialogState_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_person_masterdata_interactive_UID_DialogState_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_person_masterdata_interactive_UID_PersonMasterIdentity_candidates_post(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, inputParameterName: InteractiveEntityStateData): MethodDescriptor<EntityCollectionData>;
    portal_person_masterdata_interactive_UID_PersonMasterIdentity_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_person_masterdata_interactive_UID_PersonMasterIdentity_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_person_masterdata_interactive_UID_RealPerson_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_person_masterdata_interactive_UID_RealPerson_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_person_masterdata_interactive_UID_RealPerson_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_person_orgdata_get(type: string, uidperson: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_person_overview_get(uidperson: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_person_passcode_post(uid: string): MethodDescriptor<PersonPasscodeResult>;
    portal_person_reports_get(OnlyDirect: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, isinactive: string, reports: string): MethodDescriptor<EntityCollectionData>;
    portal_person_reports_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_person_reports_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, isinactive: string, reports: string): MethodDescriptor<GroupInfo[]>;
    portal_person_reports_interactive_get(): MethodDescriptor<InteractiveEntityData>;
    portal_person_reports_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_person_reports_interactive_byid_get(UID_Person: string): MethodDescriptor<InteractiveEntityData>;
    portal_person_reports_interactive_UID_PersonHead_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_person_reports_interactive_UID_PersonHead_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_person_reports_interactive_UID_PersonHead_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_person_uid_get(uidperson: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_pickcategory_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_pickcategory_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_pickcategory_post(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_pickcategory_delete(UID_QERPickCategory: string): MethodDescriptor<EntityCollectionData>;
    portal_pickcategory_items_get(UID_QERPickCategory: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_pickcategory_items_post(UID_QERPickCategory: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_pickcategory_items_delete(UID_QERPickCategory: string, UID_QERPickedItem: string): MethodDescriptor<EntityCollectionData>;
    portal_pickcategory_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_qer_kpi_get(): MethodDescriptor<ChartDto[]>;
    portal_qer_projectconfig_get(): MethodDescriptor<QerProjectConfig>;
    portal_relatedapplications_get(): MethodDescriptor<RelatedApplication[]>;
    portal_resources_membership_QERResource_get(UID_QERResource: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_resources_membership_QERResource_post(UID_QERResource: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_resources_membership_QERResource_delete(UID_QERResource: string, UID_Person: string): MethodDescriptor<EntityCollectionData>;
    portal_resources_membership_QERResource_UID_Person_candidates_get(UID_QERResource: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_resources_membership_QERResource_UID_Person_candidates_datamodel_get(UID_QERResource: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_resources_membership_QERResource_UID_Person_candidates_filtertree_post(UID_QERResource: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_resources_qerassign_serviceitem_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_resources_qerassign_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>): MethodDescriptor<EntityCollectionData>;
    portal_resources_qerassign_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_resources_qerassign_serviceitem_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_resources_qerresource_serviceitem_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_resources_qerresource_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>): MethodDescriptor<EntityCollectionData>;
    portal_resources_qerresource_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_resources_qerresource_serviceitem_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_resources_qerreuse_serviceitem_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_resources_qerreuse_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>): MethodDescriptor<EntityCollectionData>;
    portal_resources_qerreuse_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_resources_qerreuse_serviceitem_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_resources_qerreuseus_serviceitem_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_resources_qerreuseus_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>): MethodDescriptor<EntityCollectionData>;
    portal_resources_qerreuseus_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_resources_qerreuseus_serviceitem_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_resp_aerole_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_resp_aerole_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_resp_aerole_interactive_get(): MethodDescriptor<InteractiveEntityData>;
    portal_resp_aerole_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_resp_aerole_interactive_byid_get(UID_AERole: string): MethodDescriptor<InteractiveEntityData>;
    portal_resp_department_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_resp_department_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_resp_department_interactive_get(): MethodDescriptor<InteractiveEntityData>;
    portal_resp_department_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_resp_department_interactive_byid_get(UID_Department: string): MethodDescriptor<InteractiveEntityData>;
    portal_resp_Department_restore_get(backto: Date): MethodDescriptor<DeletedObjectInfo[]>;
    portal_resp_Department_restore_byid_get(backto: Date, uid: string): MethodDescriptor<RestoreActions>;
    portal_resp_Department_restore_byid_post(backto: Date, uid: string, inputParameterName: RestoreActionList): MethodDescriptor<UiActionResultData[]>;
    portal_resp_locality_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_resp_locality_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_resp_locality_interactive_get(): MethodDescriptor<InteractiveEntityData>;
    portal_resp_locality_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_resp_locality_interactive_byid_get(UID_Locality: string): MethodDescriptor<InteractiveEntityData>;
    portal_resp_Locality_restore_get(backto: Date): MethodDescriptor<DeletedObjectInfo[]>;
    portal_resp_Locality_restore_byid_get(backto: Date, uid: string): MethodDescriptor<RestoreActions>;
    portal_resp_Locality_restore_byid_post(backto: Date, uid: string, inputParameterName: RestoreActionList): MethodDescriptor<UiActionResultData[]>;
    portal_resp_profitcenter_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_resp_profitcenter_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_resp_profitcenter_interactive_get(): MethodDescriptor<InteractiveEntityData>;
    portal_resp_profitcenter_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_resp_profitcenter_interactive_byid_get(UID_ProfitCenter: string): MethodDescriptor<InteractiveEntityData>;
    portal_resp_ProfitCenter_restore_get(backto: Date): MethodDescriptor<DeletedObjectInfo[]>;
    portal_resp_ProfitCenter_restore_byid_get(backto: Date, uid: string): MethodDescriptor<RestoreActions>;
    portal_resp_ProfitCenter_restore_byid_post(backto: Date, uid: string, inputParameterName: RestoreActionList): MethodDescriptor<UiActionResultData[]>;
    portal_risk_analyze_get(tablename: string, pk: string, IncludeZeroRisk: boolean): MethodDescriptor<RiskObject[]>;
    portal_risk_functions_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_risk_functions_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_risk_functions_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_roles_compare_get(roletype: string, uidrole: string, compareroletype: string, uidcomparerole: string): MethodDescriptor<RoleCompareItems>;
    portal_roles_merge_get(roletype: string, uidrole: string, mergeroletype: string, uidmergerole: string): MethodDescriptor<MergeActions>;
    portal_roles_merge_post(roletype: string, uidrole: string, mergeroletype: string, uidmergerole: string, inputParameterName: MergeActionList): MethodDescriptor<UiActionResultData[]>;
    portal_roles_split_get(roletype: string, uidrole: string, newroletype: string, newroleid: string): MethodDescriptor<IRoleSplitItem[]>;
    portal_roles_split_post(roletype: string, uidrole: string, newroletype: string, newroleid: string, inputParameterName: RoleSplitInput): MethodDescriptor<UiActionData[]>;
    portal_roles_config_classes_get(uidorgroot: string): MethodDescriptor<RoleAssignmentData[]>;
    portal_roles_config_Department_primarymembers_get(UID_Department: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_Locality_primarymembers_get(UID_Locality: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_AERole_get(UID_AERole: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_AERole_post(UID_AERole: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_AERole_delete(UID_AERole: string, UID_Person: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_AERole_UID_Person_candidates_get(UID_AERole: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_AERole_UID_Person_candidates_datamodel_get(UID_AERole: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_roles_config_membership_AERole_UID_Person_candidates_filtertree_post(UID_AERole: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_roles_config_membership_Department_get(UID_Department: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Department_post(UID_Department: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Department_delete(UID_Department: string, UID_Person: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Department_UID_Person_candidates_get(UID_Department: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Department_UID_Person_candidates_datamodel_get(UID_Department: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_roles_config_membership_Department_UID_Person_candidates_filtertree_post(UID_Department: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_roles_config_membership_Locality_get(UID_Locality: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Locality_post(UID_Locality: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Locality_delete(UID_Locality: string, UID_Person: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Locality_UID_Person_candidates_get(UID_Locality: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Locality_UID_Person_candidates_datamodel_get(UID_Locality: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_roles_config_membership_Locality_UID_Person_candidates_filtertree_post(UID_Locality: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_roles_config_membership_ProfitCenter_get(UID_ProfitCenter: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ProfitCenter_post(UID_ProfitCenter: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ProfitCenter_delete(UID_ProfitCenter: string, UID_Person: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ProfitCenter_UID_Person_candidates_get(UID_ProfitCenter: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ProfitCenter_UID_Person_candidates_datamodel_get(UID_ProfitCenter: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_roles_config_membership_ProfitCenter_UID_Person_candidates_filtertree_post(UID_ProfitCenter: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_roles_config_ProfitCenter_primarymembers_get(UID_ProfitCenter: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_Department_restore_get(backto: Date): MethodDescriptor<DeletedObjectInfo[]>;
    portal_roles_Department_restore_byid_get(backto: Date, uid: string): MethodDescriptor<RestoreActions>;
    portal_roles_Department_restore_byid_post(backto: Date, uid: string, inputParameterName: RestoreActionList): MethodDescriptor<UiActionResultData[]>;
    portal_roles_entitlements_get(roletype: string, uidrole: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_exclusions_get(UID_DynamicGroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_exclusions_put(UID_DynamicGroup: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_roles_exclusions_post(UID_DynamicGroup: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_roles_exclusions_delete(UID_DynamicGroup: string, UID_Person: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_exclusions_bulk_put(UID_DynamicGroup: string, inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_roles_Locality_restore_get(backto: Date): MethodDescriptor<DeletedObjectInfo[]>;
    portal_roles_Locality_restore_byid_get(backto: Date, uid: string): MethodDescriptor<RestoreActions>;
    portal_roles_Locality_restore_byid_post(backto: Date, uid: string, inputParameterName: RestoreActionList): MethodDescriptor<UiActionResultData[]>;
    portal_roles_ProfitCenter_restore_get(backto: Date): MethodDescriptor<DeletedObjectInfo[]>;
    portal_roles_ProfitCenter_restore_byid_get(backto: Date, uid: string): MethodDescriptor<RestoreActions>;
    portal_roles_ProfitCenter_restore_byid_post(backto: Date, uid: string, inputParameterName: RestoreActionList): MethodDescriptor<UiActionResultData[]>;
    portal_search_get(term: string, tables: string): MethodDescriptor<SearchResultObject[]>;
    portal_servicecategories_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_servicecategories_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_servicecategories_post(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_servicecategories_delete(UID_AccProductGroup: string): MethodDescriptor<EntityCollectionData>;
    portal_servicecategories_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_servicecategories_interactive_get(): MethodDescriptor<InteractiveEntityData>;
    portal_servicecategories_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_servicecategories_interactive_delete(inputParameterName: InteractiveEntityDeleteData): MethodDescriptor<InteractiveEntityData>;
    portal_servicecategories_interactive_byid_get(UID_AccProductGroup: string): MethodDescriptor<InteractiveEntityData>;
    portal_servicecategories_interactive_UID_OrgAttestator_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_servicecategories_interactive_UID_OrgAttestator_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_servicecategories_interactive_UID_OrgAttestator_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_servicecategories_interactive_UID_OrgRuler_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_servicecategories_interactive_UID_OrgRuler_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_servicecategories_interactive_UID_OrgRuler_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_servicecategories_interactive_UID_PWODecisionMethod_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_servicecategories_interactive_UID_PWODecisionMethod_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_servicecategories_interactive_UID_PWODecisionMethod_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_servicecategories_UID_OrgAttestator_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_servicecategories_UID_OrgAttestator_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_servicecategories_UID_OrgAttestator_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_servicecategories_UID_OrgRuler_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_servicecategories_UID_OrgRuler_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_servicecategories_UID_OrgRuler_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_servicecategories_UID_PWODecisionMethod_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_servicecategories_UID_PWODecisionMethod_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_servicecategories_UID_PWODecisionMethod_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_serviceitems_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_serviceitems_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_serviceitems_post(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_serviceitems_delete(UID_AccProduct: string): MethodDescriptor<EntityCollectionData>;
    portal_serviceitems_tags_get(UID_AccProduct: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_serviceitems_tags_delete(UID_AccProduct: string, UID_Tag: string): MethodDescriptor<void>;
    portal_serviceitems_tags_add_post(UID_AccProduct: string, inputParameterName: string): MethodDescriptor<void>;
    portal_serviceitems_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_serviceitems_interactive_get(): MethodDescriptor<InteractiveEntityData>;
    portal_serviceitems_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_serviceitems_interactive_delete(inputParameterName: InteractiveEntityDeleteData): MethodDescriptor<InteractiveEntityData>;
    portal_serviceitems_interactive_byid_get(UID_AccProduct: string): MethodDescriptor<InteractiveEntityData>;
    portal_shop_categories_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_categoryimage_get(uidcategory: string): MethodDescriptor<Blob>;
    portal_shop_config_members_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_members_put(UID_ITShopOrg: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_members_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_members_delete(UID_ITShopOrg: string, UID_Person: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_members_bulk_put(UID_ITShopOrg: string, inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_shop_config_members_UID_Person_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_members_UID_Person_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_members_UID_Person_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_QERAssign_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERAssign_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERAssign_delete(UID_ITShopOrg: string, UID_QERAssign: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERAssign_UID_QERAssign_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERAssign_UID_QERAssign_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_QERAssign_UID_QERAssign_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_QERResource_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERResource_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERResource_delete(UID_ITShopOrg: string, UID_QERResource: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERResource_UID_QERResource_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERResource_UID_QERResource_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_QERResource_UID_QERResource_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_QERReuse_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuse_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuse_delete(UID_ITShopOrg: string, UID_QERReuse: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuse_UID_QERReuse_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuse_UID_QERReuse_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_QERReuse_UID_QERReuse_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_QERReuseUS_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuseUS_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuseUS_delete(UID_ITShopOrg: string, UID_QERReuseUS: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuseUS_UID_QERReuseUS_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuseUS_UID_QERReuseUS_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_QERReuseUS_UID_QERReuseUS_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_get(uidshelf: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_structure_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_structure_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_structure_post(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_structure_delete(UID_ITShopOrg: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_structure_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_shop_config_structure_DecisionMethods_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_structure_DecisionMethods_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_structure_DecisionMethods_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_structure_UID_OrgAttestator_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_structure_UID_OrgAttestator_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_structure_UID_OrgAttestator_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_serviceitemimage_get(uidserviceitem: string): MethodDescriptor<Blob>;
    portal_shop_serviceitems_get(UID_Person: string, UID_AccProductGroup: string, IncludeChildCategories: boolean, UID_AccProductParent: string, UID_PersonReference: string, UID_PersonPeerGroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<ExtendedEntityCollectionData<ServiceItemsExtendedData>>;
    portal_shop_serviceitems_entitlements_get(UID_AccProduct: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_serviceitems_dependencies_get(UID_Person: string, uid: string): MethodDescriptor<ServiceItemHierarchy>;
    portal_shop_serviceitems_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_termsofuse_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_termsofuse_download_get(uid: string): MethodDescriptor<Blob>;
    portal_usergroups_get(): MethodDescriptor<UserGroupInfo[]>;
    portal_userprocess_get(): MethodDescriptor<ProcessChain[]>;
    portal_userprocess_result_get(uidtree: string, uidjobs: string): MethodDescriptor<ResultInfo[]>;
    portal_usersettings_get(): MethodDescriptor<UiSetting[]>;
    portal_usersettings_post(inputParameterName: UiSetting[]): MethodDescriptor<void>;
    portal_view_get(tablename: string, uid: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<ExtendedEntityCollectionData<IClientProperty[]>>;
    portal_webauthnkey_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<ExtendedEntityCollectionData<WebauthnConfig>>;
    portal_webauthnkey_put(inputParameterName: EntityWriteData): MethodDescriptor<ExtendedEntityCollectionData<WebauthnConfig>>;
    portal_webauthnkey_delete(UID_QERWebAuthnKey: string): MethodDescriptor<ExtendedEntityCollectionData<WebauthnConfig>>;
    portal_webauthnkey_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_workflow_get(uidpwo: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    admin_config_get(): Promise<ConfigData>;
    admin_config_post(inputParameterName: ApplicationMethodConfig): Promise<ApplicationMethodConfig>;
    imx_config_get(): Promise<ImxConfig>;
    opsupport_config_get(): Promise<ProjectConfig>;
    opsupport_featureconfig_get(): Promise<FeatureConfig>;
    /** Returns password items for the specified user, if the user has been activated for password reset. */
    opsupport_passwords_get(uidperson: string): Promise<PasswordItemsData>;
    /** Sets a new password for the specified password items. */
    opsupport_passwords_post(uidperson: string, inputParameterName: PasswordData): Promise<PolicyValidationResult[]>;
    opsupport_person_passcode_post(uid: string): Promise<PersonPasscodeResult>;
    /** Manages the person's password questions. */
    passwordreset_passwordquestions_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Manages the person's password questions. */
    passwordreset_passwordquestions_put(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    /** Manages the person's password questions. */
    passwordreset_passwordquestions_post(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    /** Manages the person's password questions. */
    passwordreset_passwordquestions_delete(UID_QERPasswordQueryAndAnswer: string): Promise<EntityCollectionData>;
    /** Returns password recovery questions for the specified account. */
    passwordreset_passwordquestions_account_post(inputParameterName: CaptchaCodeAndAccount): Promise<PasswordResetAuthModel>;
    /** Manages the person's password questions. */
    passwordreset_passwordquestions_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Unlocks a specific password question if it has been locked. */
    passwordreset_passwordquestions_unlock_post(uid: string): Promise<void>;
    /** Returns password items for the current user. */
    passwordreset_passwords_get(): Promise<PasswordItemsData>;
    /** Sets a new password for the specified password items. */
    passwordreset_passwords_post(inputParameterName: PasswordData): Promise<PolicyValidationResult[]>;
    portal_admin_applicationrole_get(UID_AERole: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): Promise<EntityCollectionData>;
    portal_admin_applicationrole_members_get(UID_AERole: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_admin_applicationrole_members_post(UID_AERole: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_admin_applicationrole_members_delete(UID_AERole: string, UID_Person: string): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    portal_admin_applicationrole_members_UID_Person_candidates_get(UID_AERole: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the admin/applicationrole/{UID_AERole}/members/UID_Person/candidates endpoint. */
    portal_admin_applicationrole_members_UID_Person_candidates_datamodel_get(UID_AERole: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the admin/applicationrole/{UID_AERole}/members/UID_Person/candidates endpoint. */
    portal_admin_applicationrole_members_UID_Person_candidates_filtertree_post(UID_AERole: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Identity administration */
    portal_admin_person_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, withmanager: string, orphaned: string, deletedintarget: string, isinactive: string): Promise<EntityCollectionData>;
    /** Identity administration */
    portal_admin_person_put(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    /** Identity administration */
    portal_admin_person_post(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    /** Identity administration */
    portal_admin_person_delete(UID_Person: string): Promise<EntityCollectionData>;
    /** Identity administration */
    portal_admin_person_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Returns data model information about query options for the admin/person endpoint. */
    portal_admin_person_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Identity administration */
    portal_admin_person_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, withmanager: string, orphaned: string, deletedintarget: string, isinactive: string): Promise<GroupInfo[]>;
    /** Returns a list of objects that can be assigned to the property UID_PersonHead. */
    portal_admin_person_UID_PersonHead_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the admin/person/UID_PersonHead/candidates endpoint. */
    portal_admin_person_UID_PersonHead_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the admin/person/UID_PersonHead/candidates endpoint. */
    portal_admin_person_UID_PersonHead_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    portal_admin_resources_qerassign_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, risk: string): Promise<EntityCollectionData>;
    portal_admin_resources_qerassign_put(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_admin_resources_qerassign_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Returns data model information about query options for the admin/resources/qerassign endpoint. */
    portal_admin_resources_qerassign_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    portal_admin_resources_qerassign_interactive_put(inputParameterName: InteractiveEntityWriteData): Promise<InteractiveEntityData>;
    portal_admin_resources_qerassign_interactive_byid_get(UID_QERAssign: string): Promise<InteractiveEntityData>;
    portal_admin_resources_qerresource_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, risk: string): Promise<EntityCollectionData>;
    portal_admin_resources_qerresource_put(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_admin_resources_qerresource_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Returns data model information about query options for the admin/resources/qerresource endpoint. */
    portal_admin_resources_qerresource_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    portal_admin_resources_qerresource_interactive_put(inputParameterName: InteractiveEntityWriteData): Promise<InteractiveEntityData>;
    portal_admin_resources_qerresource_interactive_byid_get(UID_QERResource: string): Promise<InteractiveEntityData>;
    portal_admin_resources_qerreuse_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, risk: string): Promise<EntityCollectionData>;
    portal_admin_resources_qerreuse_put(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_admin_resources_qerreuse_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Returns data model information about query options for the admin/resources/qerreuse endpoint. */
    portal_admin_resources_qerreuse_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    portal_admin_resources_qerreuse_interactive_put(inputParameterName: InteractiveEntityWriteData): Promise<InteractiveEntityData>;
    portal_admin_resources_qerreuse_interactive_byid_get(UID_QERReuse: string): Promise<InteractiveEntityData>;
    portal_admin_resources_qerreuseus_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, risk: string): Promise<EntityCollectionData>;
    portal_admin_resources_qerreuseus_put(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_admin_resources_qerreuseus_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Returns data model information about query options for the admin/resources/qerreuseus endpoint. */
    portal_admin_resources_qerreuseus_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    portal_admin_resources_qerreuseus_interactive_put(inputParameterName: InteractiveEntityWriteData): Promise<InteractiveEntityData>;
    portal_admin_resources_qerreuseus_interactive_byid_get(UID_QERReuseUS: string): Promise<InteractiveEntityData>;
    portal_admin_role_department_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, risk: string): Promise<EntityCollectionData>;
    portal_admin_role_department_put(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>): Promise<EntityCollectionData>;
    portal_admin_role_department_post(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>): Promise<EntityCollectionData>;
    portal_admin_role_department_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Returns data model information about query options for the admin/role/department endpoint. */
    portal_admin_role_department_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    portal_admin_role_department_interactive_get(): Promise<InteractiveEntityData>;
    portal_admin_role_department_interactive_put(inputParameterName: any): Promise<InteractiveEntityData>;
    portal_admin_role_department_interactive_byid_get(UID_Department: string): Promise<InteractiveEntityData>;
    portal_admin_role_locality_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, risk: string): Promise<EntityCollectionData>;
    portal_admin_role_locality_put(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>): Promise<EntityCollectionData>;
    portal_admin_role_locality_post(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>): Promise<EntityCollectionData>;
    portal_admin_role_locality_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Returns data model information about query options for the admin/role/locality endpoint. */
    portal_admin_role_locality_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    portal_admin_role_locality_interactive_get(): Promise<InteractiveEntityData>;
    portal_admin_role_locality_interactive_put(inputParameterName: any): Promise<InteractiveEntityData>;
    portal_admin_role_locality_interactive_byid_get(UID_Locality: string): Promise<InteractiveEntityData>;
    portal_admin_role_profitcenter_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, risk: string): Promise<EntityCollectionData>;
    portal_admin_role_profitcenter_put(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>): Promise<EntityCollectionData>;
    portal_admin_role_profitcenter_post(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>): Promise<EntityCollectionData>;
    portal_admin_role_profitcenter_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Returns data model information about query options for the admin/role/profitcenter endpoint. */
    portal_admin_role_profitcenter_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    portal_admin_role_profitcenter_interactive_get(): Promise<InteractiveEntityData>;
    portal_admin_role_profitcenter_interactive_put(inputParameterName: any): Promise<InteractiveEntityData>;
    portal_admin_role_profitcenter_interactive_byid_get(UID_ProfitCenter: string): Promise<InteractiveEntityData>;
    /** Returns the objects that are part of assignment, specified by the assignment's 'table name and the uid. */
    portal_assignment_get(tableName: string, uid: string): Promise<EntityData[]>;
    /** Returns a list of candidate objects from the table AccProduct. */
    portal_candidates_AccProduct_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/AccProduct endpoint. */
    portal_candidates_AccProduct_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the candidates/AccProduct endpoint. */
    portal_candidates_AccProduct_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table AccProductGroup. */
    portal_candidates_AccProductGroup_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/AccProductGroup endpoint. */
    portal_candidates_AccProductGroup_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the candidates/AccProductGroup endpoint. */
    portal_candidates_AccProductGroup_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table AccProductParamCategory. */
    portal_candidates_AccProductParamCategory_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/AccProductParamCategory endpoint. */
    portal_candidates_AccProductParamCategory_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the candidates/AccProductParamCategory endpoint. */
    portal_candidates_AccProductParamCategory_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table Department. */
    portal_candidates_Department_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/Department endpoint. */
    portal_candidates_Department_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the candidates/Department endpoint. */
    portal_candidates_Department_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table DialogUser. */
    portal_candidates_DialogUser_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/DialogUser endpoint. */
    portal_candidates_DialogUser_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the candidates/DialogUser endpoint. */
    portal_candidates_DialogUser_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table FirmPartner. */
    portal_candidates_FirmPartner_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/FirmPartner endpoint. */
    portal_candidates_FirmPartner_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the candidates/FirmPartner endpoint. */
    portal_candidates_FirmPartner_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table HelperHeadOrg. */
    portal_candidates_HelperHeadOrg_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/HelperHeadOrg endpoint. */
    portal_candidates_HelperHeadOrg_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the candidates/HelperHeadOrg endpoint. */
    portal_candidates_HelperHeadOrg_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table HelperHeadPerson. */
    portal_candidates_HelperHeadPerson_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/HelperHeadPerson endpoint. */
    portal_candidates_HelperHeadPerson_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the candidates/HelperHeadPerson endpoint. */
    portal_candidates_HelperHeadPerson_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table Locality. */
    portal_candidates_Locality_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/Locality endpoint. */
    portal_candidates_Locality_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the candidates/Locality endpoint. */
    portal_candidates_Locality_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table Person. */
    portal_candidates_Person_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/Person endpoint. */
    portal_candidates_Person_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the candidates/Person endpoint. */
    portal_candidates_Person_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table PersonInAERole. */
    portal_candidates_PersonInAERole_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/PersonInAERole endpoint. */
    portal_candidates_PersonInAERole_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the candidates/PersonInAERole endpoint. */
    portal_candidates_PersonInAERole_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table PersonInDepartment. */
    portal_candidates_PersonInDepartment_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/PersonInDepartment endpoint. */
    portal_candidates_PersonInDepartment_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the candidates/PersonInDepartment endpoint. */
    portal_candidates_PersonInDepartment_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table PersonInITShopOrg. */
    portal_candidates_PersonInITShopOrg_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/PersonInITShopOrg endpoint. */
    portal_candidates_PersonInITShopOrg_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the candidates/PersonInITShopOrg endpoint. */
    portal_candidates_PersonInITShopOrg_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table PersonInLocality. */
    portal_candidates_PersonInLocality_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/PersonInLocality endpoint. */
    portal_candidates_PersonInLocality_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the candidates/PersonInLocality endpoint. */
    portal_candidates_PersonInLocality_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table PersonInProfitCenter. */
    portal_candidates_PersonInProfitCenter_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/PersonInProfitCenter endpoint. */
    portal_candidates_PersonInProfitCenter_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the candidates/PersonInProfitCenter endpoint. */
    portal_candidates_PersonInProfitCenter_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table ProfitCenter. */
    portal_candidates_ProfitCenter_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/ProfitCenter endpoint. */
    portal_candidates_ProfitCenter_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the candidates/ProfitCenter endpoint. */
    portal_candidates_ProfitCenter_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table PWODecisionMethod. */
    portal_candidates_PWODecisionMethod_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/PWODecisionMethod endpoint. */
    portal_candidates_PWODecisionMethod_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the candidates/PWODecisionMethod endpoint. */
    portal_candidates_PWODecisionMethod_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QBMCulture. */
    portal_candidates_QBMCulture_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/QBMCulture endpoint. */
    portal_candidates_QBMCulture_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the candidates/QBMCulture endpoint. */
    portal_candidates_QBMCulture_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERJustification. */
    portal_candidates_QERJustification_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/QERJustification endpoint. */
    portal_candidates_QERJustification_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the candidates/QERJustification endpoint. */
    portal_candidates_QERJustification_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERPickCategory. */
    portal_candidates_QERPickCategory_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/QERPickCategory endpoint. */
    portal_candidates_QERPickCategory_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the candidates/QERPickCategory endpoint. */
    portal_candidates_QERPickCategory_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table WorkDesk. */
    portal_candidates_WorkDesk_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/WorkDesk endpoint. */
    portal_candidates_WorkDesk_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the candidates/WorkDesk endpoint. */
    portal_candidates_WorkDesk_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    portal_captchaimage_get(t: string): Promise<Blob>;
    /** Submit the specified shopping cart */
    portal_cart_submit_post(uidcart: string, inputParameterName: CartSubmitOptions): Promise<CartCheckResult>;
    /** Manages shopping cart items for the current user. */
    portal_cartitem_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<ExtendedEntityCollectionData<CartItemDataRead>>;
    /** Manages shopping cart items for the current user. */
    portal_cartitem_put(inputParameterName: ExtendedEntityWriteData<{
        [key: string]: EntityWriteDataColumn[][];
    }>): Promise<ExtendedEntityCollectionData<CartItemDataRead>>;
    /** Manages shopping cart items for the current user. */
    portal_cartitem_post(inputParameterName: ExtendedEntityWriteData<{
        [key: string]: EntityWriteDataColumn[][];
    }>): Promise<ExtendedEntityCollectionData<CartItemDataRead>>;
    /** Manages shopping cart items for the current user. */
    portal_cartitem_delete(UID_ShoppingCartItem: string): Promise<ExtendedEntityCollectionData<CartItemDataRead>>;
    /** Moves a shopping cart item and its child items to the for-later list or to the current shopping cart for the user. */
    portal_cartitem_move_post(uidcartitem: string, tocart: boolean): Promise<void>;
    /** Manages shopping cart items for the current user. */
    portal_cartitem_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Manages shopping cart items for the current user. */
    portal_cartitem_interactive_get(): Promise<ExtendedInteractiveEntityDataOfCartItemDataRead>;
    /** Manages shopping cart items for the current user. */
    portal_cartitem_interactive_put(inputParameterName: any): Promise<ExtendedInteractiveEntityDataOfCartItemDataRead>;
    /** Manages shopping cart items for the current user. */
    portal_cartitem_interactive_delete(inputParameterName: InteractiveEntityDeleteData): Promise<ExtendedInteractiveEntityDataOfCartItemDataRead>;
    /** Manages shopping cart items for the current user. */
    portal_cartitem_interactive_byid_get(UID_ShoppingCartItem: string): Promise<ExtendedInteractiveEntityDataOfCartItemDataRead>;
    /** Returns a list of objects that can be assigned as a parameter value. */
    portal_cartitem_interactive_parameter_candidates_post(name: string, parenttable: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, inputParameterName: InteractiveEntityStateData): Promise<EntityCollectionData>;
    /** Returns filter tree information for the cartitem/interactive/parameter/{name}/candidates/{parenttable} endpoint. */
    portal_cartitem_interactive_parameter_candidates_filtertree_post(name: string, parenttable: string, filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_PersonOrdered. */
    portal_cartitem_interactive_UID_PersonOrdered_candidates_post(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ownsubidentities: string, inputParameterName: InteractiveEntityStateData): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the cartitem/interactive/UID_PersonOrdered/candidates endpoint. */
    portal_cartitem_interactive_UID_PersonOrdered_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the cartitem/interactive/UID_PersonOrdered/candidates endpoint. */
    portal_cartitem_interactive_UID_PersonOrdered_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_QERJustificationOrder. */
    portal_cartitem_interactive_UID_QERJustificationOrder_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the cartitem/interactive/UID_QERJustificationOrder/candidates endpoint. */
    portal_cartitem_interactive_UID_QERJustificationOrder_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the cartitem/interactive/UID_QERJustificationOrder/candidates endpoint. */
    portal_cartitem_interactive_UID_QERJustificationOrder_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_ShoppingCartOrder. */
    portal_cartitem_interactive_UID_ShoppingCartOrder_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the cartitem/interactive/UID_ShoppingCartOrder/candidates endpoint. */
    portal_cartitem_interactive_UID_ShoppingCartOrder_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the cartitem/interactive/UID_ShoppingCartOrder/candidates endpoint. */
    portal_cartitem_interactive_UID_ShoppingCartOrder_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned as a parameter value. */
    portal_cartitem_parameter_candidates_post(name: string, parenttable: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, inputParameterName: EntityKeysData): Promise<EntityCollectionData>;
    /** Returns filter tree information for the cartitem/parameter/{name}/candidates/{parenttable} endpoint. */
    portal_cartitem_parameter_candidates_filtertree_post(name: string, parenttable: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_PersonOrdered. */
    portal_cartitem_UID_PersonOrdered_candidates_post(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ownsubidentities: string, inputParameterName: EntityKeysData): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the cartitem/UID_PersonOrdered/candidates endpoint. */
    portal_cartitem_UID_PersonOrdered_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the cartitem/UID_PersonOrdered/candidates endpoint. */
    portal_cartitem_UID_PersonOrdered_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_QERJustificationOrder. */
    portal_cartitem_UID_QERJustificationOrder_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the cartitem/UID_QERJustificationOrder/candidates endpoint. */
    portal_cartitem_UID_QERJustificationOrder_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the cartitem/UID_QERJustificationOrder/candidates endpoint. */
    portal_cartitem_UID_QERJustificationOrder_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_ShoppingCartOrder. */
    portal_cartitem_UID_ShoppingCartOrder_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the cartitem/UID_ShoppingCartOrder/candidates endpoint. */
    portal_cartitem_UID_ShoppingCartOrder_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the cartitem/UID_ShoppingCartOrder/candidates endpoint. */
    portal_cartitem_UID_ShoppingCartOrder_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    portal_config_get(): Promise<ProjectConfig>;
    /** Returns basic information about an object specified by the table name and the uid. */
    portal_dbobject_get(tableName: string, uid: string): Promise<EntityData>;
    portal_delegable_get(uidpersonsender: string, uidpersonreceiver: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_delegation_enabled_get(uidperson: string): Promise<boolean>;
    /** Returns a list of delegations. */
    portal_delegations_get(uidperson: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns a list of delegations. */
    portal_delegations_post(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_delegations_global_post(inputParameterName: GlobalDelegationInput): Promise<void>;
    /** Returns the role classes along with the number of roles that the specified identity is an owner of. */
    portal_delegations_global_roleclasses_get(uidperson: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_PersonReceiver. */
    portal_delegations_UID_PersonReceiver_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the delegations/UID_PersonReceiver/candidates endpoint. */
    portal_delegations_UID_PersonReceiver_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the delegations/UID_PersonReceiver/candidates endpoint. */
    portal_delegations_UID_PersonReceiver_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    portal_detective_get(uidperson: string, tablename: string, uid: string): Promise<SourceNode[]>;
    portal_dynamicgroup_get(UID_DynamicGroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<ExtendedEntityCollectionData<SqlWizardRead>>;
    portal_dynamicgroup_delete(UID_DynamicGroup: string): Promise<ExtendedEntityCollectionData<SqlWizardRead>>;
    portal_dynamicgroup_interactive_get(UID_DynamicGroup: string): Promise<ExtendedInteractiveEntityDataOfSqlWizardRead>;
    portal_dynamicgroup_interactive_put(UID_DynamicGroup: string, inputParameterName: any): Promise<ExtendedInteractiveEntityDataOfSqlWizardRead>;
    portal_dynamicgroup_interactive_delete(UID_DynamicGroup: string, inputParameterName: InteractiveEntityDeleteData): Promise<ExtendedInteractiveEntityDataOfSqlWizardRead>;
    /** Returns a list of objects that can be assigned to the property UID_DialogSchedule. */
    portal_dynamicgroup_interactive_UID_DialogSchedule_candidates_get(UID_DynamicGroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the dynamicgroup/{UID_DynamicGroup}/interactive/UID_DialogSchedule/candidates endpoint. */
    portal_dynamicgroup_interactive_UID_DialogSchedule_candidates_datamodel_get(UID_DynamicGroup: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the dynamicgroup/{UID_DynamicGroup}/interactive/UID_DialogSchedule/candidates endpoint. */
    portal_dynamicgroup_interactive_UID_DialogSchedule_candidates_filtertree_post(UID_DynamicGroup: string, filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned as a filter parameter. */
    portal_dynamicgroup_sqlwizard_candidates_get(table: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): Promise<EntityCollectionData>;
    /** Returns the filterable properties for the specified table. */
    portal_dynamicgroup_sqlwizard_tables_columns_get(table: string): Promise<FilterPropertyList>;
    portal_featureconfig_get(): Promise<FeatureConfig>;
    portal_history_get(table: string, uid: string): Promise<HistoryData[]>;
    portal_history_comparison_get(table: string, uid: string, CompareDate: Date): Promise<HistoryComparisonData[]>;
    portal_history_rollback_get(CompareDate: Date, CompareId: string, table: string, uid: string): Promise<UiActionData[]>;
    portal_history_rollback_post(CompareDate: Date, CompareId: string, table: string, uid: string, inputParameterName: HistoryRollbackActionList): Promise<UiActionResultData[]>;
    portal_hyperview_get(table: string, uid: string): Promise<ShapeData[]>;
    portal_itshop_additional_post(uidpwo: string, inputParameterName: OtherApproverInput): Promise<void>;
    portal_itshop_answerquery_post(uidpwo: string, inputParameterName: ReasonInput): Promise<void>;
    /** Returns the workflow history for the specified request. */
    portal_itshop_approve_history_get(uidpwo: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_itshop_approve_requests_get(Escalation: boolean, uid_personwantsorg: string, uid_pwohelperpwo: string, forinquiry: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<ExtendedEntityCollectionData<PwoExtendedData>>;
    portal_itshop_approve_requests_put(inputParameterName: ExtendedEntityWriteData<{
        [key: string]: EntityWriteDataColumn[][];
    }>): Promise<ExtendedEntityCollectionData<PwoExtendedData>>;
    /** Accepts the terms of use for the specified request. */
    portal_itshop_approve_requests_accept_post(uidpwo: string): Promise<void>;
    portal_itshop_approve_requests_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Returns data model information about query options for the itshop/approve/requests endpoint. */
    portal_itshop_approve_requests_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns a list of objects that can be assigned as a parameter value. */
    portal_itshop_approve_requests_parameter_candidates_post(name: string, parenttable: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, inputParameterName: EntityKeysData): Promise<EntityCollectionData>;
    /** Returns filter tree information for the itshop/approve/requests/parameter/{name}/candidates/{parenttable} endpoint. */
    portal_itshop_approve_requests_parameter_candidates_filtertree_post(name: string, parenttable: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Initiates step-up authentication for the specified request. */
    portal_itshop_approve_requests_stepup_post(inputParameterName: RequestStepUpApprovalData): Promise<string>;
    /** Cancels the specified request. */
    portal_itshop_cancel_post(uidpwo: string, inputParameterName: ReasonInput): Promise<void>;
    /** Returns all shopping carts for the current user. */
    portal_itshop_cart_get(IncludeSubmitted: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns all shopping carts for the current user. */
    portal_itshop_cart_put(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    /** Returns all shopping carts for the current user. */
    portal_itshop_cart_delete(UID_ShoppingCartOrder: string): Promise<EntityCollectionData>;
    /** Accepts the terms of use for the specified shopping cart item. */
    portal_itshop_cart_accept_post(uidcartitem: string): Promise<void>;
    /** Returns all shopping carts for the current user. */
    portal_itshop_cart_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    portal_itshop_decide_post(uidpwo: string, inputParameterName: DecisionInput): Promise<void>;
    portal_itshop_denydecision_post(uidpwo: string, inputParameterName: DenyDecisionInput): Promise<void>;
    portal_itshop_directdecision_post(uidpwo: string, inputParameterName: DirectDecisionInput): Promise<void>;
    portal_itshop_escalate_post(uidpwo: string, inputParameterName: ReasonInput): Promise<void>;
    /** Finds requestable IT shop products for combinations of a person and a service item. */
    portal_itshop_findproducts_post(inputParameterName: ServiceItemForPerson[]): Promise<RequestableProductForPerson[]>;
    /** Returns historical IT shop requests. */
    portal_itshop_history_requests_get(uidpersonordered: string, uidpersoninserted: string, backto: Date): Promise<EntityCollectionData>;
    /** Returns historical IT shop workflow data. */
    portal_itshop_history_workflow_get(uidpwo: string, backto: Date): Promise<EntityCollectionData>;
    portal_itshop_insteadof_post(uidpwo: string, inputParameterName: OtherApproverInput): Promise<void>;
    /** Returns all items in the IT shop pattern. */
    portal_itshop_pattern_get(uidpattern: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns all IT shop patterns. */
    portal_itshop_pattern_admin_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns all IT shop patterns. */
    portal_itshop_pattern_admin_put(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    /** Returns all IT shop patterns. */
    portal_itshop_pattern_admin_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Creates a copy of a pattern and returns the unique identifier of the new pattern. */
    portal_itshop_pattern_copy_post(uidpattern: string): Promise<string>;
    /** Manages IT shop template items for the current user. */
    portal_itshop_pattern_item_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Manages IT shop template items for the current user. */
    portal_itshop_pattern_item_post(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    /** Manages IT shop template items for the current user. */
    portal_itshop_pattern_item_delete(UID_ShoppingCartPatternItem: string): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_ShoppingCartPattern. */
    portal_itshop_pattern_item_UID_ShoppingCartPattern_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the itshop/pattern/item/UID_ShoppingCartPattern/candidates endpoint. */
    portal_itshop_pattern_item_UID_ShoppingCartPattern_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the itshop/pattern/item/UID_ShoppingCartPattern/candidates endpoint. */
    portal_itshop_pattern_item_UID_ShoppingCartPattern_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Manages IT shop templates for the current user. */
    portal_itshop_pattern_private_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Manages IT shop templates for the current user. */
    portal_itshop_pattern_private_put(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    /** Manages IT shop templates for the current user. */
    portal_itshop_pattern_private_post(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    /** Manages IT shop templates for the current user. */
    portal_itshop_pattern_private_delete(UID_ShoppingCartPattern: string): Promise<EntityCollectionData>;
    /** Manages IT shop templates for the current user. */
    portal_itshop_pattern_private_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Returns requestable IT shop patterns. */
    portal_itshop_pattern_requestable_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns the identities that form the peer group for the specified identity. */
    portal_itshop_peergroup_get(uidperson: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns the role memberships for the peer group of the specified identities. */
    portal_itshop_peergroup_memberships_get(UID_Person: string, UID_PersonReference: string, UID_PersonPeerGroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): Promise<ExtendedEntityCollectionData<ServiceItemsExtendedData>>;
    /** Returns employees allowed to make approvals for the specified request. */
    portal_itshop_persondecision_get(uidpersonwantsorg: string): Promise<EntityCollectionData>;
    /** Prolongates a request. */
    portal_itshop_prolongate_post(uidpwo: string, inputParameterName: ProlongationInput): Promise<void>;
    portal_itshop_query_post(uidpwo: string, inputParameterName: PwoQueryInput): Promise<void>;
    portal_itshop_recalldecision_post(uidpwo: string, inputParameterName: RecallDecisionInput): Promise<void>;
    portal_itshop_recallquery_post(uidpwo: string, inputParameterName: ReasonInput): Promise<void>;
    /** Returns existing IT shop requests. */
    portal_itshop_requests_get(uidpwo: string, DocumentNumber: string, UID_Person: string, UID_PersonDecision: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ShowMyDecisions: string, ShowMyPending: string, ShowEndingSoon: string, MyDelegations: string, status: string, person: string): Promise<ExtendedEntityCollectionData<PwoExtendedData>>;
    /** Returns data model information about query options for the itshop/requests endpoint. */
    portal_itshop_requests_datamodel_get(UID_Person: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns a list of objects that can be assigned as a parameter value. */
    portal_itshop_requests_parameter_candidates_post(name: string, parenttable: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, inputParameterName: EntityKeysData): Promise<EntityCollectionData>;
    /** Returns filter tree information for the itshop/requests/parameter/{name}/candidates/{parenttable} endpoint. */
    portal_itshop_requests_parameter_candidates_filtertree_post(name: string, parenttable: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    portal_itshop_resetreservation_post(uidpwo: string, inputParameterName: ReasonInput): Promise<void>;
    /** Revokes an approval delegation. */
    portal_itshop_revokedelegation_post(uidpwo: string, inputParameterName: RecallDecisionInput): Promise<void>;
    portal_itshop_unsubscribe_post(inputParameterName: PwoUnsubscribeInput): Promise<PwoUnsubscribeResult>;
    portal_justifications_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns multi-language configuration. */
    portal_multilanguage_config_get(cultureName: string): Promise<MultiLanguageConfig>;
    /** Returns links to Password Manager. */
    portal_password_qpmlinks_get(): Promise<QpmIntegrationLinks>;
    /** Manages the person's password questions. */
    portal_passwordquestions_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Manages the person's password questions. */
    portal_passwordquestions_put(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    /** Manages the person's password questions. */
    portal_passwordquestions_post(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    /** Manages the person's password questions. */
    portal_passwordquestions_delete(UID_QERPasswordQueryAndAnswer: string): Promise<EntityCollectionData>;
    /** Manages the person's password questions. */
    portal_passwordquestions_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Unlocks a specific password question if it has been locked. */
    portal_passwordquestions_unlock_post(uid: string): Promise<void>;
    portal_pendingitems_get(): Promise<{
        [key: string]: number;
    }>;
    portal_person_rolememberships_AERole_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_person_rolememberships_Department_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_person_rolememberships_ITShopOrg_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, type: string): Promise<EntityCollectionData>;
    portal_person_rolememberships_Locality_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_person_rolememberships_ProfitCenter_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_person_requestmanagerchange_post(UID_PersonOrdered: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_PersonOrdered. */
    portal_person_requestmanagerchange_UID_PersonOrdered_candidates_post(UID_PersonOrdered: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, inputParameterName: EntityKeysData): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the person/{UID_PersonOrdered}/requestmanagerchange/UID_PersonOrdered/candidates endpoint. */
    portal_person_requestmanagerchange_UID_PersonOrdered_candidates_datamodel_get(UID_PersonOrdered: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the person/{UID_PersonOrdered}/requestmanagerchange/UID_PersonOrdered/candidates endpoint. */
    portal_person_requestmanagerchange_UID_PersonOrdered_candidates_filtertree_post(UID_PersonOrdered: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_ShoppingCartOrder. */
    portal_person_requestmanagerchange_UID_ShoppingCartOrder_candidates_get(UID_PersonOrdered: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the person/{UID_PersonOrdered}/requestmanagerchange/UID_ShoppingCartOrder/candidates endpoint. */
    portal_person_requestmanagerchange_UID_ShoppingCartOrder_candidates_datamodel_get(UID_PersonOrdered: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the person/{UID_PersonOrdered}/requestmanagerchange/UID_ShoppingCartOrder/candidates endpoint. */
    portal_person_requestmanagerchange_UID_ShoppingCartOrder_candidates_filtertree_post(UID_PersonOrdered: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    portal_person_memberships_get(uid: string): Promise<EntityCollectionData>;
    /** Returns all active identities. */
    portal_person_active_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_person_all_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, isinactive: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the person/all endpoint. */
    portal_person_all_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    portal_person_all_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, isinactive: string): Promise<GroupInfo[]>;
    /** Returns the current user's permission model. */
    portal_person_config_get(): Promise<UserConfig>;
    portal_person_email_get(uidperson: string): Promise<EntityCollectionData>;
    portal_person_email_post(uidperson: string, inputParameterName: MailSubscriptionChange): Promise<void>;
    portal_person_image_get(uidperson: string): Promise<Blob>;
    /** Gets or sets the master data for the authenticated identity. */
    portal_person_masterdata_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Gets or sets the master data for the authenticated identity. */
    portal_person_masterdata_interactive_put(inputParameterName: InteractiveEntityWriteData): Promise<InteractiveEntityData>;
    /** Gets or sets the master data for the authenticated identity. */
    portal_person_masterdata_interactive_byid_get(UID_Person: string): Promise<InteractiveEntityData>;
    /** Returns a list of objects that can be assigned to the property UID_DialogCountry. */
    portal_person_masterdata_interactive_UID_DialogCountry_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the person/masterdata/interactive/UID_DialogCountry/candidates endpoint. */
    portal_person_masterdata_interactive_UID_DialogCountry_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the person/masterdata/interactive/UID_DialogCountry/candidates endpoint. */
    portal_person_masterdata_interactive_UID_DialogCountry_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_DialogCulture. */
    portal_person_masterdata_interactive_UID_DialogCulture_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the person/masterdata/interactive/UID_DialogCulture/candidates endpoint. */
    portal_person_masterdata_interactive_UID_DialogCulture_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the person/masterdata/interactive/UID_DialogCulture/candidates endpoint. */
    portal_person_masterdata_interactive_UID_DialogCulture_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_DialogState. */
    portal_person_masterdata_interactive_UID_DialogState_candidates_post(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, inputParameterName: InteractiveEntityStateData): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the person/masterdata/interactive/UID_DialogState/candidates endpoint. */
    portal_person_masterdata_interactive_UID_DialogState_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the person/masterdata/interactive/UID_DialogState/candidates endpoint. */
    portal_person_masterdata_interactive_UID_DialogState_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_PersonMasterIdentity. */
    portal_person_masterdata_interactive_UID_PersonMasterIdentity_candidates_post(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, inputParameterName: InteractiveEntityStateData): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the person/masterdata/interactive/UID_PersonMasterIdentity/candidates endpoint. */
    portal_person_masterdata_interactive_UID_PersonMasterIdentity_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the person/masterdata/interactive/UID_PersonMasterIdentity/candidates endpoint. */
    portal_person_masterdata_interactive_UID_PersonMasterIdentity_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_RealPerson. */
    portal_person_masterdata_interactive_UID_RealPerson_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the person/masterdata/interactive/UID_RealPerson/candidates endpoint. */
    portal_person_masterdata_interactive_UID_RealPerson_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the person/masterdata/interactive/UID_RealPerson/candidates endpoint. */
    portal_person_masterdata_interactive_UID_RealPerson_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): Promise<FilterTreeData>;
    /** Returns organizational data for the specified person */
    portal_person_orgdata_get(type: string, uidperson: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns overview data for the specified person */
    portal_person_overview_get(uidperson: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_person_passcode_post(uid: string): Promise<PersonPasscodeResult>;
    /** Returns the direct reports for the current user. */
    portal_person_reports_get(OnlyDirect: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, isinactive: string, reports: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the person/reports endpoint. */
    portal_person_reports_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns the direct reports for the current user. */
    portal_person_reports_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, isinactive: string, reports: string): Promise<GroupInfo[]>;
    /** Returns the direct reports for the current user. */
    portal_person_reports_interactive_get(): Promise<InteractiveEntityData>;
    /** Returns the direct reports for the current user. */
    portal_person_reports_interactive_put(inputParameterName: InteractiveEntityWriteData): Promise<InteractiveEntityData>;
    /** Returns the direct reports for the current user. */
    portal_person_reports_interactive_byid_get(UID_Person: string): Promise<InteractiveEntityData>;
    /** Returns a list of objects that can be assigned to the property UID_PersonHead. */
    portal_person_reports_interactive_UID_PersonHead_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the person/reports/interactive/UID_PersonHead/candidates endpoint. */
    portal_person_reports_interactive_UID_PersonHead_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the person/reports/interactive/UID_PersonHead/candidates endpoint. */
    portal_person_reports_interactive_UID_PersonHead_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): Promise<FilterTreeData>;
    portal_person_uid_get(uidperson: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_pickcategory_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_pickcategory_put(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_pickcategory_post(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_pickcategory_delete(UID_QERPickCategory: string): Promise<EntityCollectionData>;
    portal_pickcategory_items_get(UID_QERPickCategory: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_pickcategory_items_post(UID_QERPickCategory: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_pickcategory_items_delete(UID_QERPickCategory: string, UID_QERPickedItem: string): Promise<EntityCollectionData>;
    portal_pickcategory_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Returns global KPI information. */
    portal_qer_kpi_get(): Promise<ChartDto[]>;
    portal_qer_projectconfig_get(): Promise<QerProjectConfig>;
    /** Returns the related applications to show for the current user. */
    portal_relatedapplications_get(): Promise<RelatedApplication[]>;
    portal_resources_membership_QERResource_get(UID_QERResource: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_resources_membership_QERResource_post(UID_QERResource: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_resources_membership_QERResource_delete(UID_QERResource: string, UID_Person: string): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    portal_resources_membership_QERResource_UID_Person_candidates_get(UID_QERResource: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resources/membership/QERResource/{UID_QERResource}/UID_Person/candidates endpoint. */
    portal_resources_membership_QERResource_UID_Person_candidates_datamodel_get(UID_QERResource: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the resources/membership/QERResource/{UID_QERResource}/UID_Person/candidates endpoint. */
    portal_resources_membership_QERResource_UID_Person_candidates_filtertree_post(UID_QERResource: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    portal_resources_qerassign_serviceitem_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_resources_qerassign_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>): Promise<EntityCollectionData>;
    portal_resources_qerassign_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Returns data model information about query options for the resources/qerassign/serviceitem endpoint. */
    portal_resources_qerassign_serviceitem_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    portal_resources_qerresource_serviceitem_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_resources_qerresource_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>): Promise<EntityCollectionData>;
    portal_resources_qerresource_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Returns data model information about query options for the resources/qerresource/serviceitem endpoint. */
    portal_resources_qerresource_serviceitem_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    portal_resources_qerreuse_serviceitem_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_resources_qerreuse_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>): Promise<EntityCollectionData>;
    portal_resources_qerreuse_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Returns data model information about query options for the resources/qerreuse/serviceitem endpoint. */
    portal_resources_qerreuse_serviceitem_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    portal_resources_qerreuseus_serviceitem_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_resources_qerreuseus_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>): Promise<EntityCollectionData>;
    portal_resources_qerreuseus_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Returns data model information about query options for the resources/qerreuseus/serviceitem endpoint. */
    portal_resources_qerreuseus_serviceitem_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    portal_resp_aerole_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/aerole endpoint. */
    portal_resp_aerole_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    portal_resp_aerole_interactive_get(): Promise<InteractiveEntityData>;
    portal_resp_aerole_interactive_put(inputParameterName: any): Promise<InteractiveEntityData>;
    portal_resp_aerole_interactive_byid_get(UID_AERole: string): Promise<InteractiveEntityData>;
    portal_resp_department_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/department endpoint. */
    portal_resp_department_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    portal_resp_department_interactive_get(): Promise<InteractiveEntityData>;
    portal_resp_department_interactive_put(inputParameterName: any): Promise<InteractiveEntityData>;
    portal_resp_department_interactive_byid_get(UID_Department: string): Promise<InteractiveEntityData>;
    portal_resp_Department_restore_get(backto: Date): Promise<DeletedObjectInfo[]>;
    portal_resp_Department_restore_byid_get(backto: Date, uid: string): Promise<RestoreActions>;
    portal_resp_Department_restore_byid_post(backto: Date, uid: string, inputParameterName: RestoreActionList): Promise<UiActionResultData[]>;
    portal_resp_locality_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/locality endpoint. */
    portal_resp_locality_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    portal_resp_locality_interactive_get(): Promise<InteractiveEntityData>;
    portal_resp_locality_interactive_put(inputParameterName: any): Promise<InteractiveEntityData>;
    portal_resp_locality_interactive_byid_get(UID_Locality: string): Promise<InteractiveEntityData>;
    portal_resp_Locality_restore_get(backto: Date): Promise<DeletedObjectInfo[]>;
    portal_resp_Locality_restore_byid_get(backto: Date, uid: string): Promise<RestoreActions>;
    portal_resp_Locality_restore_byid_post(backto: Date, uid: string, inputParameterName: RestoreActionList): Promise<UiActionResultData[]>;
    portal_resp_profitcenter_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/profitcenter endpoint. */
    portal_resp_profitcenter_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    portal_resp_profitcenter_interactive_get(): Promise<InteractiveEntityData>;
    portal_resp_profitcenter_interactive_put(inputParameterName: any): Promise<InteractiveEntityData>;
    portal_resp_profitcenter_interactive_byid_get(UID_ProfitCenter: string): Promise<InteractiveEntityData>;
    portal_resp_ProfitCenter_restore_get(backto: Date): Promise<DeletedObjectInfo[]>;
    portal_resp_ProfitCenter_restore_byid_get(backto: Date, uid: string): Promise<RestoreActions>;
    portal_resp_ProfitCenter_restore_byid_post(backto: Date, uid: string, inputParameterName: RestoreActionList): Promise<UiActionResultData[]>;
    portal_risk_analyze_get(tablename: string, pk: string, IncludeZeroRisk: boolean): Promise<RiskObject[]>;
    portal_risk_functions_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_risk_functions_put(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_risk_functions_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    portal_roles_compare_get(roletype: string, uidrole: string, compareroletype: string, uidcomparerole: string): Promise<RoleCompareItems>;
    portal_roles_merge_get(roletype: string, uidrole: string, mergeroletype: string, uidmergerole: string): Promise<MergeActions>;
    portal_roles_merge_post(roletype: string, uidrole: string, mergeroletype: string, uidmergerole: string, inputParameterName: MergeActionList): Promise<UiActionResultData[]>;
    portal_roles_split_get(roletype: string, uidrole: string, newroletype: string, newroleid: string): Promise<IRoleSplitItem[]>;
    portal_roles_split_post(roletype: string, uidrole: string, newroletype: string, newroleid: string, inputParameterName: RoleSplitInput): Promise<UiActionData[]>;
    portal_roles_config_classes_get(uidorgroot: string): Promise<RoleAssignmentData[]>;
    /** Returns identities who are primary members of a role. */
    portal_roles_config_Department_primarymembers_get(UID_Department: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns identities who are primary members of a role. */
    portal_roles_config_Locality_primarymembers_get(UID_Locality: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_roles_config_membership_AERole_get(UID_AERole: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_roles_config_membership_AERole_post(UID_AERole: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_roles_config_membership_AERole_delete(UID_AERole: string, UID_Person: string): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    portal_roles_config_membership_AERole_UID_Person_candidates_get(UID_AERole: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the roles/config/membership/AERole/{UID_AERole}/UID_Person/candidates endpoint. */
    portal_roles_config_membership_AERole_UID_Person_candidates_datamodel_get(UID_AERole: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the roles/config/membership/AERole/{UID_AERole}/UID_Person/candidates endpoint. */
    portal_roles_config_membership_AERole_UID_Person_candidates_filtertree_post(UID_AERole: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    portal_roles_config_membership_Department_get(UID_Department: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_roles_config_membership_Department_post(UID_Department: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_roles_config_membership_Department_delete(UID_Department: string, UID_Person: string): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    portal_roles_config_membership_Department_UID_Person_candidates_get(UID_Department: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the roles/config/membership/Department/{UID_Department}/UID_Person/candidates endpoint. */
    portal_roles_config_membership_Department_UID_Person_candidates_datamodel_get(UID_Department: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the roles/config/membership/Department/{UID_Department}/UID_Person/candidates endpoint. */
    portal_roles_config_membership_Department_UID_Person_candidates_filtertree_post(UID_Department: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    portal_roles_config_membership_Locality_get(UID_Locality: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_roles_config_membership_Locality_post(UID_Locality: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_roles_config_membership_Locality_delete(UID_Locality: string, UID_Person: string): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    portal_roles_config_membership_Locality_UID_Person_candidates_get(UID_Locality: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the roles/config/membership/Locality/{UID_Locality}/UID_Person/candidates endpoint. */
    portal_roles_config_membership_Locality_UID_Person_candidates_datamodel_get(UID_Locality: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the roles/config/membership/Locality/{UID_Locality}/UID_Person/candidates endpoint. */
    portal_roles_config_membership_Locality_UID_Person_candidates_filtertree_post(UID_Locality: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    portal_roles_config_membership_ProfitCenter_get(UID_ProfitCenter: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_roles_config_membership_ProfitCenter_post(UID_ProfitCenter: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_roles_config_membership_ProfitCenter_delete(UID_ProfitCenter: string, UID_Person: string): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    portal_roles_config_membership_ProfitCenter_UID_Person_candidates_get(UID_ProfitCenter: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the roles/config/membership/ProfitCenter/{UID_ProfitCenter}/UID_Person/candidates endpoint. */
    portal_roles_config_membership_ProfitCenter_UID_Person_candidates_datamodel_get(UID_ProfitCenter: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the roles/config/membership/ProfitCenter/{UID_ProfitCenter}/UID_Person/candidates endpoint. */
    portal_roles_config_membership_ProfitCenter_UID_Person_candidates_filtertree_post(UID_ProfitCenter: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns identities who are primary members of a role. */
    portal_roles_config_ProfitCenter_primarymembers_get(UID_ProfitCenter: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_roles_Department_restore_get(backto: Date): Promise<DeletedObjectInfo[]>;
    portal_roles_Department_restore_byid_get(backto: Date, uid: string): Promise<RestoreActions>;
    portal_roles_Department_restore_byid_post(backto: Date, uid: string, inputParameterName: RestoreActionList): Promise<UiActionResultData[]>;
    /** Returns the entitlements assigned to the role. */
    portal_roles_entitlements_get(roletype: string, uidrole: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_roles_exclusions_get(UID_DynamicGroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_roles_exclusions_put(UID_DynamicGroup: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_roles_exclusions_post(UID_DynamicGroup: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_roles_exclusions_delete(UID_DynamicGroup: string, UID_Person: string): Promise<EntityCollectionData>;
    portal_roles_exclusions_bulk_put(UID_DynamicGroup: string, inputParameterName: EntityWriteDataBulk): Promise<void>;
    portal_roles_Locality_restore_get(backto: Date): Promise<DeletedObjectInfo[]>;
    portal_roles_Locality_restore_byid_get(backto: Date, uid: string): Promise<RestoreActions>;
    portal_roles_Locality_restore_byid_post(backto: Date, uid: string, inputParameterName: RestoreActionList): Promise<UiActionResultData[]>;
    portal_roles_ProfitCenter_restore_get(backto: Date): Promise<DeletedObjectInfo[]>;
    portal_roles_ProfitCenter_restore_byid_get(backto: Date, uid: string): Promise<RestoreActions>;
    portal_roles_ProfitCenter_restore_byid_post(backto: Date, uid: string, inputParameterName: RestoreActionList): Promise<UiActionResultData[]>;
    portal_search_get(term: string, tables: string): Promise<SearchResultObject[]>;
    /** Obtains a list of available service categories. */
    portal_servicecategories_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): Promise<EntityCollectionData>;
    /** Obtains a list of available service categories. */
    portal_servicecategories_put(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    /** Obtains a list of available service categories. */
    portal_servicecategories_post(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    /** Obtains a list of available service categories. */
    portal_servicecategories_delete(UID_AccProductGroup: string): Promise<EntityCollectionData>;
    /** Obtains a list of available service categories. */
    portal_servicecategories_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Obtains a list of available service categories. */
    portal_servicecategories_interactive_get(): Promise<InteractiveEntityData>;
    /** Obtains a list of available service categories. */
    portal_servicecategories_interactive_put(inputParameterName: InteractiveEntityWriteData): Promise<InteractiveEntityData>;
    /** Obtains a list of available service categories. */
    portal_servicecategories_interactive_delete(inputParameterName: InteractiveEntityDeleteData): Promise<InteractiveEntityData>;
    /** Obtains a list of available service categories. */
    portal_servicecategories_interactive_byid_get(UID_AccProductGroup: string): Promise<InteractiveEntityData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgAttestator. */
    portal_servicecategories_interactive_UID_OrgAttestator_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the servicecategories/interactive/UID_OrgAttestator/candidates endpoint. */
    portal_servicecategories_interactive_UID_OrgAttestator_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the servicecategories/interactive/UID_OrgAttestator/candidates endpoint. */
    portal_servicecategories_interactive_UID_OrgAttestator_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgRuler. */
    portal_servicecategories_interactive_UID_OrgRuler_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the servicecategories/interactive/UID_OrgRuler/candidates endpoint. */
    portal_servicecategories_interactive_UID_OrgRuler_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the servicecategories/interactive/UID_OrgRuler/candidates endpoint. */
    portal_servicecategories_interactive_UID_OrgRuler_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_PWODecisionMethod. */
    portal_servicecategories_interactive_UID_PWODecisionMethod_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the servicecategories/interactive/UID_PWODecisionMethod/candidates endpoint. */
    portal_servicecategories_interactive_UID_PWODecisionMethod_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the servicecategories/interactive/UID_PWODecisionMethod/candidates endpoint. */
    portal_servicecategories_interactive_UID_PWODecisionMethod_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgAttestator. */
    portal_servicecategories_UID_OrgAttestator_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the servicecategories/UID_OrgAttestator/candidates endpoint. */
    portal_servicecategories_UID_OrgAttestator_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the servicecategories/UID_OrgAttestator/candidates endpoint. */
    portal_servicecategories_UID_OrgAttestator_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgRuler. */
    portal_servicecategories_UID_OrgRuler_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the servicecategories/UID_OrgRuler/candidates endpoint. */
    portal_servicecategories_UID_OrgRuler_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the servicecategories/UID_OrgRuler/candidates endpoint. */
    portal_servicecategories_UID_OrgRuler_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_PWODecisionMethod. */
    portal_servicecategories_UID_PWODecisionMethod_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the servicecategories/UID_PWODecisionMethod/candidates endpoint. */
    portal_servicecategories_UID_PWODecisionMethod_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the servicecategories/UID_PWODecisionMethod/candidates endpoint. */
    portal_servicecategories_UID_PWODecisionMethod_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Obtains a list of available service items. */
    portal_serviceitems_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Obtains a list of available service items. */
    portal_serviceitems_put(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    /** Obtains a list of available service items. */
    portal_serviceitems_post(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    /** Obtains a list of available service items. */
    portal_serviceitems_delete(UID_AccProduct: string): Promise<EntityCollectionData>;
    /** Obtains the tags associated with a service item. */
    portal_serviceitems_tags_get(UID_AccProduct: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Deletes a tag associated with a service item. */
    portal_serviceitems_tags_delete(UID_AccProduct: string, UID_Tag: string): Promise<void>;
    /** Adds a new tag to a service item. */
    portal_serviceitems_tags_add_post(UID_AccProduct: string, inputParameterName: string): Promise<void>;
    /** Obtains a list of available service items. */
    portal_serviceitems_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Obtains a list of available service items. */
    portal_serviceitems_interactive_get(): Promise<InteractiveEntityData>;
    /** Obtains a list of available service items. */
    portal_serviceitems_interactive_put(inputParameterName: InteractiveEntityWriteData): Promise<InteractiveEntityData>;
    /** Obtains a list of available service items. */
    portal_serviceitems_interactive_delete(inputParameterName: InteractiveEntityDeleteData): Promise<InteractiveEntityData>;
    /** Obtains a list of available service items. */
    portal_serviceitems_interactive_byid_get(UID_AccProduct: string): Promise<InteractiveEntityData>;
    /** Returns the hierarchy of service categories for the available service items for the specified recipient(s). */
    portal_shop_categories_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): Promise<EntityCollectionData>;
    portal_shop_categoryimage_get(uidcategory: string): Promise<Blob>;
    portal_shop_config_members_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_shop_config_members_put(UID_ITShopOrg: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_shop_config_members_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_shop_config_members_delete(UID_ITShopOrg: string, UID_Person: string): Promise<EntityCollectionData>;
    portal_shop_config_members_bulk_put(UID_ITShopOrg: string, inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    portal_shop_config_members_UID_Person_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/{UID_ITShopOrg}/members/UID_Person/candidates endpoint. */
    portal_shop_config_members_UID_Person_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/{UID_ITShopOrg}/members/UID_Person/candidates endpoint. */
    portal_shop_config_members_UID_Person_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    portal_shop_config_entitlements_QERAssign_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_QERAssign_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_QERAssign_delete(UID_ITShopOrg: string, UID_QERAssign: string): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_QERAssign. */
    portal_shop_config_entitlements_QERAssign_UID_QERAssign_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/QERAssign/UID_QERAssign/candidates endpoint. */
    portal_shop_config_entitlements_QERAssign_UID_QERAssign_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/QERAssign/UID_QERAssign/candidates endpoint. */
    portal_shop_config_entitlements_QERAssign_UID_QERAssign_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    portal_shop_config_entitlements_QERResource_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_QERResource_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_QERResource_delete(UID_ITShopOrg: string, UID_QERResource: string): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_QERResource. */
    portal_shop_config_entitlements_QERResource_UID_QERResource_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/QERResource/UID_QERResource/candidates endpoint. */
    portal_shop_config_entitlements_QERResource_UID_QERResource_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/QERResource/UID_QERResource/candidates endpoint. */
    portal_shop_config_entitlements_QERResource_UID_QERResource_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    portal_shop_config_entitlements_QERReuse_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuse_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuse_delete(UID_ITShopOrg: string, UID_QERReuse: string): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_QERReuse. */
    portal_shop_config_entitlements_QERReuse_UID_QERReuse_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/QERReuse/UID_QERReuse/candidates endpoint. */
    portal_shop_config_entitlements_QERReuse_UID_QERReuse_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/QERReuse/UID_QERReuse/candidates endpoint. */
    portal_shop_config_entitlements_QERReuse_UID_QERReuse_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    portal_shop_config_entitlements_QERReuseUS_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuseUS_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuseUS_delete(UID_ITShopOrg: string, UID_QERReuseUS: string): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_QERReuseUS. */
    portal_shop_config_entitlements_QERReuseUS_UID_QERReuseUS_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/QERReuseUS/UID_QERReuseUS/candidates endpoint. */
    portal_shop_config_entitlements_QERReuseUS_UID_QERReuseUS_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/QERReuseUS/UID_QERReuseUS/candidates endpoint. */
    portal_shop_config_entitlements_QERReuseUS_UID_QERReuseUS_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns the entitlements assigned to the shelf. */
    portal_shop_config_entitlements_get(uidshelf: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Manages shop and shelf objects in the IT shop. */
    portal_shop_config_structure_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): Promise<EntityCollectionData>;
    /** Manages shop and shelf objects in the IT shop. */
    portal_shop_config_structure_put(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    /** Manages shop and shelf objects in the IT shop. */
    portal_shop_config_structure_post(inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    /** Manages shop and shelf objects in the IT shop. */
    portal_shop_config_structure_delete(UID_ITShopOrg: string): Promise<EntityCollectionData>;
    /** Manages shop and shelf objects in the IT shop. */
    portal_shop_config_structure_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Returns a list of objects that can be assigned to the property DecisionMethods. */
    portal_shop_config_structure_DecisionMethods_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/structure/DecisionMethods/candidates endpoint. */
    portal_shop_config_structure_DecisionMethods_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/structure/DecisionMethods/candidates endpoint. */
    portal_shop_config_structure_DecisionMethods_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgAttestator. */
    portal_shop_config_structure_UID_OrgAttestator_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/structure/UID_OrgAttestator/candidates endpoint. */
    portal_shop_config_structure_UID_OrgAttestator_candidates_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/structure/UID_OrgAttestator/candidates endpoint. */
    portal_shop_config_structure_UID_OrgAttestator_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    portal_shop_serviceitemimage_get(uidserviceitem: string): Promise<Blob>;
    /** Returns requestable service items. */
    portal_shop_serviceitems_get(UID_Person: string, UID_AccProductGroup: string, IncludeChildCategories: boolean, UID_AccProductParent: string, UID_PersonReference: string, UID_PersonPeerGroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<ExtendedEntityCollectionData<ServiceItemsExtendedData>>;
    /** Returns the entitlements associated with the service item's role. */
    portal_shop_serviceitems_entitlements_get(UID_AccProduct: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): Promise<EntityCollectionData>;
    /** Returns the dependency hierarchy of a service item. If the service item has no dependencies, an empty object is returned. */
    portal_shop_serviceitems_dependencies_get(UID_Person: string, uid: string): Promise<ServiceItemHierarchy>;
    /** Returns data model information about query options for the shop/serviceitems endpoint. */
    portal_shop_serviceitems_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    portal_termsofuse_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_termsofuse_download_get(uid: string): Promise<Blob>;
    /** Returns the list of permissions groups that the current user is assigned to. */
    portal_usergroups_get(): Promise<UserGroupInfo[]>;
    portal_userprocess_get(): Promise<ProcessChain[]>;
    portal_userprocess_result_get(uidtree: string, uidjobs: string): Promise<ResultInfo[]>;
    /** Returns the list of user-specific UI settings. */
    portal_usersettings_get(): Promise<UiSetting[]>;
    /** Stores the specified list of user-specific UI settings. */
    portal_usersettings_post(inputParameterName: UiSetting[]): Promise<void>;
    portal_view_get(tablename: string, uid: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): Promise<ExtendedEntityCollectionData<IClientProperty[]>>;
    /** Manages Webauthn keys for the current user. */
    portal_webauthnkey_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<ExtendedEntityCollectionData<WebauthnConfig>>;
    /** Manages Webauthn keys for the current user. */
    portal_webauthnkey_put(inputParameterName: EntityWriteData): Promise<ExtendedEntityCollectionData<WebauthnConfig>>;
    /** Manages Webauthn keys for the current user. */
    portal_webauthnkey_delete(UID_QERWebAuthnKey: string): Promise<ExtendedEntityCollectionData<WebauthnConfig>>;
    /** Manages Webauthn keys for the current user. */
    portal_webauthnkey_bulk_put(inputParameterName: EntityWriteDataBulk): Promise<void>;
    portal_workflow_get(uidpwo: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
}
export declare class V2ApiClientMethodFactory {
    admin_config_get(options?: {}): MethodDescriptor<ConfigData>;
    admin_config_post(inputParameterName: ApplicationMethodConfig, options?: {}): MethodDescriptor<ApplicationMethodConfig>;
    imx_config_get(options?: {}): MethodDescriptor<ImxConfig>;
    opsupport_config_get(options?: {}): MethodDescriptor<ProjectConfig>;
    opsupport_featureconfig_get(options?: {}): MethodDescriptor<FeatureConfig>;
    opsupport_passwords_get(uidperson: string, options?: {}): MethodDescriptor<PasswordItemsData>;
    opsupport_passwords_post(uidperson: string, inputParameterName: PasswordData, options?: {}): MethodDescriptor<PolicyValidationResult[]>;
    opsupport_person_passcode_post(uid: string, options?: {}): MethodDescriptor<PersonPasscodeResult>;
    passwordreset_passwordquestions_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    passwordreset_passwordquestions_put(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    passwordreset_passwordquestions_post(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    passwordreset_passwordquestions_delete(UID_QERPasswordQueryAndAnswer: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    passwordreset_passwordquestions_account_post(inputParameterName: CaptchaCodeAndAccount, options?: {}): MethodDescriptor<PasswordResetAuthModel>;
    passwordreset_passwordquestions_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    passwordreset_passwordquestions_unlock_post(uid: string, options?: {}): MethodDescriptor<void>;
    passwordreset_passwords_get(options?: {}): MethodDescriptor<PasswordItemsData>;
    passwordreset_passwords_post(inputParameterName: PasswordData, options?: {}): MethodDescriptor<PolicyValidationResult[]>;
    portal_admin_applicationrole_get(UID_AERole: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_admin_applicationrole_members_get(UID_AERole: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_admin_applicationrole_members_post(UID_AERole: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_admin_applicationrole_members_delete(UID_AERole: string, UID_Person: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_admin_applicationrole_members_UID_Person_candidates_get(UID_AERole: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_admin_applicationrole_members_UID_Person_candidates_datamodel_get(UID_AERole: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_admin_applicationrole_members_UID_Person_candidates_filtertree_post(UID_AERole: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_admin_person_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        withmanager?: string;
        orphaned?: string;
        deletedintarget?: string;
        isinactive?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_admin_person_put(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_admin_person_post(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_admin_person_delete(UID_Person: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_admin_person_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_admin_person_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_admin_person_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
        withmanager?: string;
        orphaned?: string;
        deletedintarget?: string;
        isinactive?: string;
    }): MethodDescriptor<GroupInfo[]>;
    portal_admin_person_UID_PersonHead_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_admin_person_UID_PersonHead_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_admin_person_UID_PersonHead_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_admin_resources_qerassign_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        published?: string;
        withowner?: string;
        risk?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_admin_resources_qerassign_put(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_admin_resources_qerassign_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_admin_resources_qerassign_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_admin_resources_qerassign_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_admin_resources_qerassign_interactive_byid_get(UID_QERAssign: string, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_admin_resources_qerresource_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        published?: string;
        withowner?: string;
        risk?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_admin_resources_qerresource_put(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_admin_resources_qerresource_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_admin_resources_qerresource_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_admin_resources_qerresource_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_admin_resources_qerresource_interactive_byid_get(UID_QERResource: string, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_admin_resources_qerreuse_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        published?: string;
        withowner?: string;
        risk?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_admin_resources_qerreuse_put(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_admin_resources_qerreuse_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_admin_resources_qerreuse_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_admin_resources_qerreuse_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_admin_resources_qerreuse_interactive_byid_get(UID_QERReuse: string, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_admin_resources_qerreuseus_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        published?: string;
        withowner?: string;
        risk?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_admin_resources_qerreuseus_put(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_admin_resources_qerreuseus_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_admin_resources_qerreuseus_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_admin_resources_qerreuseus_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_admin_resources_qerreuseus_interactive_byid_get(UID_QERReuseUS: string, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_department_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
        risk?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_department_put(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_department_post(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_department_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_admin_role_department_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_admin_role_department_interactive_get(options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_department_interactive_put(inputParameterName: any, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_department_interactive_byid_get(UID_Department: string, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_locality_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
        risk?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_locality_put(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_locality_post(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_locality_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_admin_role_locality_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_admin_role_locality_interactive_get(options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_locality_interactive_put(inputParameterName: any, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_locality_interactive_byid_get(UID_Locality: string, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_profitcenter_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
        risk?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_profitcenter_put(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_profitcenter_post(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_profitcenter_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_admin_role_profitcenter_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_admin_role_profitcenter_interactive_get(options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_profitcenter_interactive_put(inputParameterName: any, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_profitcenter_interactive_byid_get(UID_ProfitCenter: string, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_assignment_get(tableName: string, uid: string, options?: {}): MethodDescriptor<EntityData[]>;
    portal_candidates_AccProduct_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AccProduct_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_candidates_AccProduct_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_candidates_AccProductGroup_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AccProductGroup_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_candidates_AccProductGroup_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_candidates_AccProductParamCategory_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AccProductParamCategory_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_candidates_AccProductParamCategory_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_candidates_Department_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Department_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_candidates_Department_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_candidates_DialogUser_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_candidates_DialogUser_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_candidates_DialogUser_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_candidates_FirmPartner_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_candidates_FirmPartner_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_candidates_FirmPartner_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_candidates_HelperHeadOrg_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_candidates_HelperHeadOrg_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_candidates_HelperHeadOrg_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_candidates_HelperHeadPerson_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_candidates_HelperHeadPerson_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_candidates_HelperHeadPerson_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_candidates_Locality_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Locality_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_candidates_Locality_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_candidates_Person_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Person_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_candidates_Person_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_candidates_PersonInAERole_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_candidates_PersonInAERole_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_candidates_PersonInAERole_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_candidates_PersonInDepartment_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_candidates_PersonInDepartment_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_candidates_PersonInDepartment_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_candidates_PersonInITShopOrg_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_candidates_PersonInITShopOrg_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_candidates_PersonInITShopOrg_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_candidates_PersonInLocality_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_candidates_PersonInLocality_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_candidates_PersonInLocality_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_candidates_PersonInProfitCenter_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_candidates_PersonInProfitCenter_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_candidates_PersonInProfitCenter_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_candidates_ProfitCenter_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_candidates_ProfitCenter_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_candidates_ProfitCenter_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_candidates_PWODecisionMethod_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_candidates_PWODecisionMethod_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_candidates_PWODecisionMethod_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_candidates_QBMCulture_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QBMCulture_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_candidates_QBMCulture_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERJustification_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERJustification_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_candidates_QERJustification_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_candidates_QERPickCategory_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_candidates_QERPickCategory_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_candidates_QERPickCategory_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_candidates_WorkDesk_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_candidates_WorkDesk_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_candidates_WorkDesk_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_captchaimage_get(options?: {
        t?: string;
    }): MethodDescriptor<Blob>;
    portal_cart_submit_post(uidcart: string, inputParameterName: CartSubmitOptions, options?: {}): MethodDescriptor<CartCheckResult>;
    portal_cartitem_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<ExtendedEntityCollectionData<CartItemDataRead>>;
    portal_cartitem_put(inputParameterName: ExtendedEntityWriteData<{
        [key: string]: EntityWriteDataColumn[][];
    }>, options?: {}): MethodDescriptor<ExtendedEntityCollectionData<CartItemDataRead>>;
    portal_cartitem_post(inputParameterName: ExtendedEntityWriteData<{
        [key: string]: EntityWriteDataColumn[][];
    }>, options?: {}): MethodDescriptor<ExtendedEntityCollectionData<CartItemDataRead>>;
    portal_cartitem_delete(UID_ShoppingCartItem: string, options?: {}): MethodDescriptor<ExtendedEntityCollectionData<CartItemDataRead>>;
    portal_cartitem_move_post(uidcartitem: string, options?: {
        tocart?: boolean;
    }): MethodDescriptor<void>;
    portal_cartitem_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_cartitem_interactive_get(options?: {}): MethodDescriptor<ExtendedInteractiveEntityDataOfCartItemDataRead>;
    portal_cartitem_interactive_put(inputParameterName: any, options?: {}): MethodDescriptor<ExtendedInteractiveEntityDataOfCartItemDataRead>;
    portal_cartitem_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}): MethodDescriptor<ExtendedInteractiveEntityDataOfCartItemDataRead>;
    portal_cartitem_interactive_byid_get(UID_ShoppingCartItem: string, options?: {}): MethodDescriptor<ExtendedInteractiveEntityDataOfCartItemDataRead>;
    portal_cartitem_interactive_parameter_candidates_post(name: string, parenttable: string, inputParameterName: InteractiveEntityStateData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_cartitem_interactive_parameter_candidates_filtertree_post(name: string, parenttable: string, inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_cartitem_interactive_UID_PersonOrdered_candidates_post(inputParameterName: InteractiveEntityStateData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ownsubidentities?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_cartitem_interactive_UID_PersonOrdered_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_cartitem_interactive_UID_PersonOrdered_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_cartitem_interactive_UID_QERJustificationOrder_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_cartitem_interactive_UID_QERJustificationOrder_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_cartitem_interactive_UID_QERJustificationOrder_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_cartitem_interactive_UID_ShoppingCartOrder_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_cartitem_interactive_UID_ShoppingCartOrder_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_cartitem_interactive_UID_ShoppingCartOrder_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_cartitem_parameter_candidates_post(name: string, parenttable: string, inputParameterName: EntityKeysData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_cartitem_parameter_candidates_filtertree_post(name: string, parenttable: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_cartitem_UID_PersonOrdered_candidates_post(inputParameterName: EntityKeysData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ownsubidentities?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_cartitem_UID_PersonOrdered_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_cartitem_UID_PersonOrdered_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_cartitem_UID_QERJustificationOrder_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_cartitem_UID_QERJustificationOrder_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_cartitem_UID_QERJustificationOrder_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_cartitem_UID_ShoppingCartOrder_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_cartitem_UID_ShoppingCartOrder_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_cartitem_UID_ShoppingCartOrder_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_config_get(options?: {}): MethodDescriptor<ProjectConfig>;
    portal_dbobject_get(tableName: string, uid: string, options?: {}): MethodDescriptor<EntityData>;
    portal_delegable_get(uidpersonsender: string, uidpersonreceiver: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_delegation_enabled_get(uidperson: string, options?: {}): MethodDescriptor<boolean>;
    portal_delegations_get(options?: {
        uidperson?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_delegations_post(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_delegations_global_post(inputParameterName: GlobalDelegationInput, options?: {}): MethodDescriptor<void>;
    portal_delegations_global_roleclasses_get(uidperson: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_delegations_UID_PersonReceiver_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_delegations_UID_PersonReceiver_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_delegations_UID_PersonReceiver_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_detective_get(uidperson: string, tablename: string, uid: string, options?: {}): MethodDescriptor<SourceNode[]>;
    portal_dynamicgroup_get(UID_DynamicGroup: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<ExtendedEntityCollectionData<SqlWizardRead>>;
    portal_dynamicgroup_delete(UID_DynamicGroup: string, options?: {}): MethodDescriptor<ExtendedEntityCollectionData<SqlWizardRead>>;
    portal_dynamicgroup_interactive_get(UID_DynamicGroup: string, options?: {}): MethodDescriptor<ExtendedInteractiveEntityDataOfSqlWizardRead>;
    portal_dynamicgroup_interactive_put(UID_DynamicGroup: string, inputParameterName: any, options?: {}): MethodDescriptor<ExtendedInteractiveEntityDataOfSqlWizardRead>;
    portal_dynamicgroup_interactive_delete(UID_DynamicGroup: string, inputParameterName: InteractiveEntityDeleteData, options?: {}): MethodDescriptor<ExtendedInteractiveEntityDataOfSqlWizardRead>;
    portal_dynamicgroup_interactive_UID_DialogSchedule_candidates_get(UID_DynamicGroup: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_dynamicgroup_interactive_UID_DialogSchedule_candidates_datamodel_get(UID_DynamicGroup: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_dynamicgroup_interactive_UID_DialogSchedule_candidates_filtertree_post(UID_DynamicGroup: string, inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_dynamicgroup_sqlwizard_candidates_get(table: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_dynamicgroup_sqlwizard_tables_columns_get(table: string, options?: {}): MethodDescriptor<FilterPropertyList>;
    portal_featureconfig_get(options?: {}): MethodDescriptor<FeatureConfig>;
    portal_history_get(table: string, uid: string, options?: {}): MethodDescriptor<HistoryData[]>;
    portal_history_comparison_get(table: string, uid: string, options?: {
        CompareDate?: Date;
    }): MethodDescriptor<HistoryComparisonData[]>;
    portal_history_rollback_get(table: string, uid: string, options?: {
        CompareDate?: Date;
        CompareId?: string;
    }): MethodDescriptor<UiActionData[]>;
    portal_history_rollback_post(table: string, uid: string, inputParameterName: HistoryRollbackActionList, options?: {
        CompareDate?: Date;
        CompareId?: string;
    }): MethodDescriptor<UiActionResultData[]>;
    portal_hyperview_get(table: string, uid: string, options?: {}): MethodDescriptor<ShapeData[]>;
    portal_itshop_additional_post(uidpwo: string, inputParameterName: OtherApproverInput, options?: {}): MethodDescriptor<void>;
    portal_itshop_answerquery_post(uidpwo: string, inputParameterName: ReasonInput, options?: {}): MethodDescriptor<void>;
    portal_itshop_approve_history_get(uidpwo: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_itshop_approve_requests_get(options?: {
        Escalation?: boolean;
        uid_personwantsorg?: string;
        uid_pwohelperpwo?: string;
        forinquiry?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<ExtendedEntityCollectionData<PwoExtendedData>>;
    portal_itshop_approve_requests_put(inputParameterName: ExtendedEntityWriteData<{
        [key: string]: EntityWriteDataColumn[][];
    }>, options?: {}): MethodDescriptor<ExtendedEntityCollectionData<PwoExtendedData>>;
    portal_itshop_approve_requests_accept_post(uidpwo: string, options?: {}): MethodDescriptor<void>;
    portal_itshop_approve_requests_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_itshop_approve_requests_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_itshop_approve_requests_parameter_candidates_post(name: string, parenttable: string, inputParameterName: EntityKeysData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_itshop_approve_requests_parameter_candidates_filtertree_post(name: string, parenttable: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_itshop_approve_requests_stepup_post(inputParameterName: RequestStepUpApprovalData, options?: {}): MethodDescriptor<string>;
    portal_itshop_cancel_post(uidpwo: string, inputParameterName: ReasonInput, options?: {}): MethodDescriptor<void>;
    portal_itshop_cart_get(options?: {
        IncludeSubmitted?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_itshop_cart_put(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_itshop_cart_delete(UID_ShoppingCartOrder: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_itshop_cart_accept_post(uidcartitem: string, options?: {}): MethodDescriptor<void>;
    portal_itshop_cart_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_itshop_decide_post(uidpwo: string, inputParameterName: DecisionInput, options?: {}): MethodDescriptor<void>;
    portal_itshop_denydecision_post(uidpwo: string, inputParameterName: DenyDecisionInput, options?: {}): MethodDescriptor<void>;
    portal_itshop_directdecision_post(uidpwo: string, inputParameterName: DirectDecisionInput, options?: {}): MethodDescriptor<void>;
    portal_itshop_escalate_post(uidpwo: string, inputParameterName: ReasonInput, options?: {}): MethodDescriptor<void>;
    portal_itshop_findproducts_post(inputParameterName: ServiceItemForPerson[], options?: {}): MethodDescriptor<RequestableProductForPerson[]>;
    portal_itshop_history_requests_get(backto: Date, options?: {
        uidpersonordered?: string;
        uidpersoninserted?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_itshop_history_workflow_get(uidpwo: string, backto: Date, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_itshop_insteadof_post(uidpwo: string, inputParameterName: OtherApproverInput, options?: {}): MethodDescriptor<void>;
    portal_itshop_pattern_get(uidpattern: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_itshop_pattern_admin_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_itshop_pattern_admin_put(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_itshop_pattern_admin_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_itshop_pattern_copy_post(uidpattern: string, options?: {}): MethodDescriptor<string>;
    portal_itshop_pattern_item_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_itshop_pattern_item_post(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_itshop_pattern_item_delete(UID_ShoppingCartPatternItem: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_itshop_pattern_item_UID_ShoppingCartPattern_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_itshop_pattern_item_UID_ShoppingCartPattern_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_itshop_pattern_item_UID_ShoppingCartPattern_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_itshop_pattern_private_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_itshop_pattern_private_put(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_itshop_pattern_private_post(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_itshop_pattern_private_delete(UID_ShoppingCartPattern: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_itshop_pattern_private_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_itshop_pattern_requestable_get(options?: {
        UID_Person?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_itshop_peergroup_get(uidperson: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_itshop_peergroup_memberships_get(options?: {
        UID_Person?: string;
        UID_PersonReference?: string;
        UID_PersonPeerGroup?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<ExtendedEntityCollectionData<ServiceItemsExtendedData>>;
    portal_itshop_persondecision_get(uidpersonwantsorg: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_itshop_prolongate_post(uidpwo: string, inputParameterName: ProlongationInput, options?: {}): MethodDescriptor<void>;
    portal_itshop_query_post(uidpwo: string, inputParameterName: PwoQueryInput, options?: {}): MethodDescriptor<void>;
    portal_itshop_recalldecision_post(uidpwo: string, inputParameterName: RecallDecisionInput, options?: {}): MethodDescriptor<void>;
    portal_itshop_recallquery_post(uidpwo: string, inputParameterName: ReasonInput, options?: {}): MethodDescriptor<void>;
    portal_itshop_requests_get(options?: {
        uidpwo?: string;
        DocumentNumber?: string;
        UID_Person?: string;
        UID_PersonDecision?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ShowMyDecisions?: string;
        ShowMyPending?: string;
        ShowEndingSoon?: string;
        MyDelegations?: string;
        status?: string;
        person?: string;
    }): MethodDescriptor<ExtendedEntityCollectionData<PwoExtendedData>>;
    portal_itshop_requests_datamodel_get(options?: {
        UID_Person?: string;
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_itshop_requests_parameter_candidates_post(name: string, parenttable: string, inputParameterName: EntityKeysData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_itshop_requests_parameter_candidates_filtertree_post(name: string, parenttable: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_itshop_resetreservation_post(uidpwo: string, inputParameterName: ReasonInput, options?: {}): MethodDescriptor<void>;
    portal_itshop_revokedelegation_post(uidpwo: string, inputParameterName: RecallDecisionInput, options?: {}): MethodDescriptor<void>;
    portal_itshop_unsubscribe_post(inputParameterName: PwoUnsubscribeInput, options?: {}): MethodDescriptor<PwoUnsubscribeResult>;
    portal_justifications_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_multilanguage_config_get(options?: {
        cultureName?: string;
    }): MethodDescriptor<MultiLanguageConfig>;
    portal_password_qpmlinks_get(options?: {}): MethodDescriptor<QpmIntegrationLinks>;
    portal_passwordquestions_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_passwordquestions_put(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_passwordquestions_post(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_passwordquestions_delete(UID_QERPasswordQueryAndAnswer: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_passwordquestions_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_passwordquestions_unlock_post(uid: string, options?: {}): MethodDescriptor<void>;
    portal_pendingitems_get(options?: {}): MethodDescriptor<{
        [key: string]: number;
    }>;
    portal_person_rolememberships_AERole_get(UID_Person: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_person_rolememberships_Department_get(UID_Person: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_person_rolememberships_ITShopOrg_get(UID_Person: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        type?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_person_rolememberships_Locality_get(UID_Person: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_person_rolememberships_ProfitCenter_get(UID_Person: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_person_requestmanagerchange_post(UID_PersonOrdered: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_person_requestmanagerchange_UID_PersonOrdered_candidates_post(UID_PersonOrdered: string, inputParameterName: EntityKeysData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_person_requestmanagerchange_UID_PersonOrdered_candidates_datamodel_get(UID_PersonOrdered: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_person_requestmanagerchange_UID_PersonOrdered_candidates_filtertree_post(UID_PersonOrdered: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_person_requestmanagerchange_UID_ShoppingCartOrder_candidates_get(UID_PersonOrdered: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_person_requestmanagerchange_UID_ShoppingCartOrder_candidates_datamodel_get(UID_PersonOrdered: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_person_requestmanagerchange_UID_ShoppingCartOrder_candidates_filtertree_post(UID_PersonOrdered: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_person_memberships_get(uid: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_person_active_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_person_all_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        isinactive?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_person_all_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_person_all_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
        isinactive?: string;
    }): MethodDescriptor<GroupInfo[]>;
    portal_person_config_get(options?: {}): MethodDescriptor<UserConfig>;
    portal_person_email_get(uidperson: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_person_email_post(uidperson: string, inputParameterName: MailSubscriptionChange, options?: {}): MethodDescriptor<void>;
    portal_person_image_get(uidperson: string, options?: {}): MethodDescriptor<Blob>;
    portal_person_masterdata_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_person_masterdata_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_person_masterdata_interactive_byid_get(UID_Person: string, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_person_masterdata_interactive_UID_DialogCountry_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_person_masterdata_interactive_UID_DialogCountry_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_person_masterdata_interactive_UID_DialogCountry_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_person_masterdata_interactive_UID_DialogCulture_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_person_masterdata_interactive_UID_DialogCulture_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_person_masterdata_interactive_UID_DialogCulture_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_person_masterdata_interactive_UID_DialogState_candidates_post(inputParameterName: InteractiveEntityStateData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_person_masterdata_interactive_UID_DialogState_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_person_masterdata_interactive_UID_DialogState_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_person_masterdata_interactive_UID_PersonMasterIdentity_candidates_post(inputParameterName: InteractiveEntityStateData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_person_masterdata_interactive_UID_PersonMasterIdentity_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_person_masterdata_interactive_UID_PersonMasterIdentity_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_person_masterdata_interactive_UID_RealPerson_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_person_masterdata_interactive_UID_RealPerson_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_person_masterdata_interactive_UID_RealPerson_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_person_orgdata_get(type: string, uidperson: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_person_overview_get(uidperson: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_person_passcode_post(uid: string, options?: {}): MethodDescriptor<PersonPasscodeResult>;
    portal_person_reports_get(options?: {
        OnlyDirect?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        isinactive?: string;
        reports?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_person_reports_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_person_reports_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
        isinactive?: string;
        reports?: string;
    }): MethodDescriptor<GroupInfo[]>;
    portal_person_reports_interactive_get(options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_person_reports_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_person_reports_interactive_byid_get(UID_Person: string, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_person_reports_interactive_UID_PersonHead_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_person_reports_interactive_UID_PersonHead_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_person_reports_interactive_UID_PersonHead_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_person_uid_get(uidperson: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_pickcategory_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_pickcategory_put(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_pickcategory_post(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_pickcategory_delete(UID_QERPickCategory: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_pickcategory_items_get(UID_QERPickCategory: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_pickcategory_items_post(UID_QERPickCategory: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_pickcategory_items_delete(UID_QERPickCategory: string, UID_QERPickedItem: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_pickcategory_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_qer_kpi_get(options?: {}): MethodDescriptor<ChartDto[]>;
    portal_qer_projectconfig_get(options?: {}): MethodDescriptor<QerProjectConfig>;
    portal_relatedapplications_get(options?: {}): MethodDescriptor<RelatedApplication[]>;
    portal_resources_membership_QERResource_get(UID_QERResource: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_resources_membership_QERResource_post(UID_QERResource: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_resources_membership_QERResource_delete(UID_QERResource: string, UID_Person: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_resources_membership_QERResource_UID_Person_candidates_get(UID_QERResource: string, options?: {
        xorigin?: number;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_resources_membership_QERResource_UID_Person_candidates_datamodel_get(UID_QERResource: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_resources_membership_QERResource_UID_Person_candidates_filtertree_post(UID_QERResource: string, inputParameterName: EntityWriteDataSingle, options?: {
        xorigin?: number;
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_resources_qerassign_serviceitem_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_resources_qerassign_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_resources_qerassign_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_resources_qerassign_serviceitem_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_resources_qerresource_serviceitem_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_resources_qerresource_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_resources_qerresource_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_resources_qerresource_serviceitem_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_resources_qerreuse_serviceitem_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_resources_qerreuse_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_resources_qerreuse_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_resources_qerreuse_serviceitem_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_resources_qerreuseus_serviceitem_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_resources_qerreuseus_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_resources_qerreuseus_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_resources_qerreuseus_serviceitem_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_resp_aerole_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_resp_aerole_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_resp_aerole_interactive_get(options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_resp_aerole_interactive_put(inputParameterName: any, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_resp_aerole_interactive_byid_get(UID_AERole: string, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_resp_department_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_resp_department_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_resp_department_interactive_get(options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_resp_department_interactive_put(inputParameterName: any, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_resp_department_interactive_byid_get(UID_Department: string, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_resp_Department_restore_get(options?: {
        backto?: Date;
    }): MethodDescriptor<DeletedObjectInfo[]>;
    portal_resp_Department_restore_byid_get(uid: string, options?: {
        backto?: Date;
    }): MethodDescriptor<RestoreActions>;
    portal_resp_Department_restore_byid_post(uid: string, inputParameterName: RestoreActionList, options?: {
        backto?: Date;
    }): MethodDescriptor<UiActionResultData[]>;
    portal_resp_locality_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_resp_locality_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_resp_locality_interactive_get(options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_resp_locality_interactive_put(inputParameterName: any, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_resp_locality_interactive_byid_get(UID_Locality: string, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_resp_Locality_restore_get(options?: {
        backto?: Date;
    }): MethodDescriptor<DeletedObjectInfo[]>;
    portal_resp_Locality_restore_byid_get(uid: string, options?: {
        backto?: Date;
    }): MethodDescriptor<RestoreActions>;
    portal_resp_Locality_restore_byid_post(uid: string, inputParameterName: RestoreActionList, options?: {
        backto?: Date;
    }): MethodDescriptor<UiActionResultData[]>;
    portal_resp_profitcenter_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_resp_profitcenter_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_resp_profitcenter_interactive_get(options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_resp_profitcenter_interactive_put(inputParameterName: any, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_resp_profitcenter_interactive_byid_get(UID_ProfitCenter: string, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_resp_ProfitCenter_restore_get(options?: {
        backto?: Date;
    }): MethodDescriptor<DeletedObjectInfo[]>;
    portal_resp_ProfitCenter_restore_byid_get(uid: string, options?: {
        backto?: Date;
    }): MethodDescriptor<RestoreActions>;
    portal_resp_ProfitCenter_restore_byid_post(uid: string, inputParameterName: RestoreActionList, options?: {
        backto?: Date;
    }): MethodDescriptor<UiActionResultData[]>;
    portal_risk_analyze_get(tablename: string, pk: string, options?: {
        IncludeZeroRisk?: boolean;
    }): MethodDescriptor<RiskObject[]>;
    portal_risk_functions_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_risk_functions_put(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_risk_functions_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_roles_compare_get(roletype: string, uidrole: string, compareroletype: string, uidcomparerole: string, options?: {}): MethodDescriptor<RoleCompareItems>;
    portal_roles_merge_get(roletype: string, uidrole: string, mergeroletype: string, uidmergerole: string, options?: {}): MethodDescriptor<MergeActions>;
    portal_roles_merge_post(roletype: string, uidrole: string, mergeroletype: string, uidmergerole: string, inputParameterName: MergeActionList, options?: {}): MethodDescriptor<UiActionResultData[]>;
    portal_roles_split_get(roletype: string, uidrole: string, newroletype: string, newroleid: string, options?: {}): MethodDescriptor<IRoleSplitItem[]>;
    portal_roles_split_post(roletype: string, uidrole: string, newroletype: string, newroleid: string, inputParameterName: RoleSplitInput, options?: {}): MethodDescriptor<UiActionData[]>;
    portal_roles_config_classes_get(uidorgroot: string, options?: {}): MethodDescriptor<RoleAssignmentData[]>;
    portal_roles_config_Department_primarymembers_get(UID_Department: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_Locality_primarymembers_get(UID_Locality: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_AERole_get(UID_AERole: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_AERole_post(UID_AERole: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_AERole_delete(UID_AERole: string, UID_Person: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_AERole_UID_Person_candidates_get(UID_AERole: string, options?: {
        xorigin?: number;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_AERole_UID_Person_candidates_datamodel_get(UID_AERole: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_roles_config_membership_AERole_UID_Person_candidates_filtertree_post(UID_AERole: string, inputParameterName: EntityWriteDataSingle, options?: {
        xorigin?: number;
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_roles_config_membership_Department_get(UID_Department: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Department_post(UID_Department: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Department_delete(UID_Department: string, UID_Person: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Department_UID_Person_candidates_get(UID_Department: string, options?: {
        xorigin?: number;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Department_UID_Person_candidates_datamodel_get(UID_Department: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_roles_config_membership_Department_UID_Person_candidates_filtertree_post(UID_Department: string, inputParameterName: EntityWriteDataSingle, options?: {
        xorigin?: number;
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_roles_config_membership_Locality_get(UID_Locality: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Locality_post(UID_Locality: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Locality_delete(UID_Locality: string, UID_Person: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Locality_UID_Person_candidates_get(UID_Locality: string, options?: {
        xorigin?: number;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Locality_UID_Person_candidates_datamodel_get(UID_Locality: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_roles_config_membership_Locality_UID_Person_candidates_filtertree_post(UID_Locality: string, inputParameterName: EntityWriteDataSingle, options?: {
        xorigin?: number;
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_roles_config_membership_ProfitCenter_get(UID_ProfitCenter: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ProfitCenter_post(UID_ProfitCenter: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ProfitCenter_delete(UID_ProfitCenter: string, UID_Person: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ProfitCenter_UID_Person_candidates_get(UID_ProfitCenter: string, options?: {
        xorigin?: number;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_ProfitCenter_UID_Person_candidates_datamodel_get(UID_ProfitCenter: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_roles_config_membership_ProfitCenter_UID_Person_candidates_filtertree_post(UID_ProfitCenter: string, inputParameterName: EntityWriteDataSingle, options?: {
        xorigin?: number;
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_roles_config_ProfitCenter_primarymembers_get(UID_ProfitCenter: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_roles_Department_restore_get(options?: {
        backto?: Date;
    }): MethodDescriptor<DeletedObjectInfo[]>;
    portal_roles_Department_restore_byid_get(uid: string, options?: {
        backto?: Date;
    }): MethodDescriptor<RestoreActions>;
    portal_roles_Department_restore_byid_post(uid: string, inputParameterName: RestoreActionList, options?: {
        backto?: Date;
    }): MethodDescriptor<UiActionResultData[]>;
    portal_roles_entitlements_get(roletype: string, uidrole: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_roles_exclusions_get(UID_DynamicGroup: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_roles_exclusions_put(UID_DynamicGroup: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_roles_exclusions_post(UID_DynamicGroup: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_roles_exclusions_delete(UID_DynamicGroup: string, UID_Person: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_roles_exclusions_bulk_put(UID_DynamicGroup: string, inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_roles_Locality_restore_get(options?: {
        backto?: Date;
    }): MethodDescriptor<DeletedObjectInfo[]>;
    portal_roles_Locality_restore_byid_get(uid: string, options?: {
        backto?: Date;
    }): MethodDescriptor<RestoreActions>;
    portal_roles_Locality_restore_byid_post(uid: string, inputParameterName: RestoreActionList, options?: {
        backto?: Date;
    }): MethodDescriptor<UiActionResultData[]>;
    portal_roles_ProfitCenter_restore_get(options?: {
        backto?: Date;
    }): MethodDescriptor<DeletedObjectInfo[]>;
    portal_roles_ProfitCenter_restore_byid_get(uid: string, options?: {
        backto?: Date;
    }): MethodDescriptor<RestoreActions>;
    portal_roles_ProfitCenter_restore_byid_post(uid: string, inputParameterName: RestoreActionList, options?: {
        backto?: Date;
    }): MethodDescriptor<UiActionResultData[]>;
    portal_search_get(options?: {
        term?: string;
        tables?: string;
    }): MethodDescriptor<SearchResultObject[]>;
    portal_servicecategories_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_servicecategories_put(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_servicecategories_post(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_servicecategories_delete(UID_AccProductGroup: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_servicecategories_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_servicecategories_interactive_get(options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_servicecategories_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_servicecategories_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_servicecategories_interactive_byid_get(UID_AccProductGroup: string, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_servicecategories_interactive_UID_OrgAttestator_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_servicecategories_interactive_UID_OrgAttestator_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_servicecategories_interactive_UID_OrgAttestator_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_servicecategories_interactive_UID_OrgRuler_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_servicecategories_interactive_UID_OrgRuler_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_servicecategories_interactive_UID_OrgRuler_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_servicecategories_interactive_UID_PWODecisionMethod_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_servicecategories_interactive_UID_PWODecisionMethod_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_servicecategories_interactive_UID_PWODecisionMethod_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_servicecategories_UID_OrgAttestator_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_servicecategories_UID_OrgAttestator_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_servicecategories_UID_OrgAttestator_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_servicecategories_UID_OrgRuler_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_servicecategories_UID_OrgRuler_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_servicecategories_UID_OrgRuler_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_servicecategories_UID_PWODecisionMethod_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_servicecategories_UID_PWODecisionMethod_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_servicecategories_UID_PWODecisionMethod_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_serviceitems_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_serviceitems_put(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_serviceitems_post(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_serviceitems_delete(UID_AccProduct: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_serviceitems_tags_get(UID_AccProduct: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_serviceitems_tags_delete(UID_AccProduct: string, UID_Tag: string, options?: {}): MethodDescriptor<void>;
    portal_serviceitems_tags_add_post(UID_AccProduct: string, inputParameterName: string, options?: {}): MethodDescriptor<void>;
    portal_serviceitems_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_serviceitems_interactive_get(options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_serviceitems_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_serviceitems_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_serviceitems_interactive_byid_get(UID_AccProduct: string, options?: {}): MethodDescriptor<InteractiveEntityData>;
    portal_shop_categories_get(options?: {
        UID_Person?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_categoryimage_get(uidcategory: string, options?: {}): MethodDescriptor<Blob>;
    portal_shop_config_members_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_members_put(UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_members_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_members_delete(UID_ITShopOrg: string, UID_Person: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_members_bulk_put(UID_ITShopOrg: string, inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_shop_config_members_UID_Person_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_members_UID_Person_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_shop_config_members_UID_Person_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_QERAssign_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERAssign_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERAssign_delete(UID_ITShopOrg: string, UID_QERAssign: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERAssign_UID_QERAssign_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERAssign_UID_QERAssign_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_QERAssign_UID_QERAssign_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_QERResource_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERResource_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERResource_delete(UID_ITShopOrg: string, UID_QERResource: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERResource_UID_QERResource_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERResource_UID_QERResource_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_QERResource_UID_QERResource_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_QERReuse_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuse_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuse_delete(UID_ITShopOrg: string, UID_QERReuse: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuse_UID_QERReuse_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuse_UID_QERReuse_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_QERReuse_UID_QERReuse_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_QERReuseUS_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuseUS_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuseUS_delete(UID_ITShopOrg: string, UID_QERReuseUS: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuseUS_UID_QERReuseUS_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuseUS_UID_QERReuseUS_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_QERReuseUS_UID_QERReuseUS_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_get(uidshelf: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_structure_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_structure_put(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_structure_post(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_structure_delete(UID_ITShopOrg: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_structure_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_shop_config_structure_DecisionMethods_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_structure_DecisionMethods_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_shop_config_structure_DecisionMethods_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_shop_config_structure_UID_OrgAttestator_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_structure_UID_OrgAttestator_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_shop_config_structure_UID_OrgAttestator_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_shop_serviceitemimage_get(uidserviceitem: string, options?: {}): MethodDescriptor<Blob>;
    portal_shop_serviceitems_get(options?: {
        UID_Person?: string;
        UID_AccProductGroup?: string;
        IncludeChildCategories?: boolean;
        UID_AccProductParent?: string;
        UID_PersonReference?: string;
        UID_PersonPeerGroup?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<ExtendedEntityCollectionData<ServiceItemsExtendedData>>;
    portal_shop_serviceitems_entitlements_get(UID_AccProduct: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_serviceitems_dependencies_get(uid: string, options?: {
        UID_Person?: string;
    }): MethodDescriptor<ServiceItemHierarchy>;
    portal_shop_serviceitems_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_termsofuse_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_termsofuse_download_get(uid: string, options?: {}): MethodDescriptor<Blob>;
    portal_usergroups_get(options?: {}): MethodDescriptor<UserGroupInfo[]>;
    portal_userprocess_get(options?: {}): MethodDescriptor<ProcessChain[]>;
    portal_userprocess_result_get(uidtree: string, uidjobs: string, options?: {}): MethodDescriptor<ResultInfo[]>;
    portal_usersettings_get(options?: {}): MethodDescriptor<UiSetting[]>;
    portal_usersettings_post(inputParameterName: UiSetting[], options?: {}): MethodDescriptor<void>;
    portal_view_get(tablename: string, uid: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): MethodDescriptor<ExtendedEntityCollectionData<IClientProperty[]>>;
    portal_webauthnkey_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<ExtendedEntityCollectionData<WebauthnConfig>>;
    portal_webauthnkey_put(inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<ExtendedEntityCollectionData<WebauthnConfig>>;
    portal_webauthnkey_delete(UID_QERWebAuthnKey: string, options?: {}): MethodDescriptor<ExtendedEntityCollectionData<WebauthnConfig>>;
    portal_webauthnkey_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_workflow_get(uidpwo: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    admin_config_get(options?: {}): Promise<ConfigData>;
    admin_config_post(inputParameterName: ApplicationMethodConfig, options?: {}): Promise<ApplicationMethodConfig>;
    imx_config_get(options?: {}): Promise<ImxConfig>;
    opsupport_config_get(options?: {}): Promise<ProjectConfig>;
    opsupport_featureconfig_get(options?: {}): Promise<FeatureConfig>;
    /** Returns password items for the specified user, if the user has been activated for password reset. */
    opsupport_passwords_get(uidperson: string, options?: {}): Promise<PasswordItemsData>;
    /** Sets a new password for the specified password items. */
    opsupport_passwords_post(uidperson: string, inputParameterName: PasswordData, options?: {}): Promise<PolicyValidationResult[]>;
    opsupport_person_passcode_post(uid: string, options?: {}): Promise<PersonPasscodeResult>;
    /** Manages the person's password questions. */
    passwordreset_passwordquestions_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Manages the person's password questions. */
    passwordreset_passwordquestions_put(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    /** Manages the person's password questions. */
    passwordreset_passwordquestions_post(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    /** Manages the person's password questions. */
    passwordreset_passwordquestions_delete(UID_QERPasswordQueryAndAnswer: string, options?: {}): Promise<EntityCollectionData>;
    /** Returns password recovery questions for the specified account. */
    passwordreset_passwordquestions_account_post(inputParameterName: CaptchaCodeAndAccount, options?: {}): Promise<PasswordResetAuthModel>;
    /** Manages the person's password questions. */
    passwordreset_passwordquestions_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Unlocks a specific password question if it has been locked. */
    passwordreset_passwordquestions_unlock_post(uid: string, options?: {}): Promise<void>;
    /** Returns password items for the current user. */
    passwordreset_passwords_get(options?: {}): Promise<PasswordItemsData>;
    /** Sets a new password for the specified password items. */
    passwordreset_passwords_post(inputParameterName: PasswordData, options?: {}): Promise<PolicyValidationResult[]>;
    portal_admin_applicationrole_get(UID_AERole: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    portal_admin_applicationrole_members_get(UID_AERole: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_admin_applicationrole_members_post(UID_AERole: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_admin_applicationrole_members_delete(UID_AERole: string, UID_Person: string, options?: {}): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    portal_admin_applicationrole_members_UID_Person_candidates_get(UID_AERole: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the admin/applicationrole/{UID_AERole}/members/UID_Person/candidates endpoint. */
    portal_admin_applicationrole_members_UID_Person_candidates_datamodel_get(UID_AERole: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the admin/applicationrole/{UID_AERole}/members/UID_Person/candidates endpoint. */
    portal_admin_applicationrole_members_UID_Person_candidates_filtertree_post(UID_AERole: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Identity administration */
    portal_admin_person_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        withmanager?: string;
        orphaned?: string;
        deletedintarget?: string;
        isinactive?: string;
    }): Promise<EntityCollectionData>;
    /** Identity administration */
    portal_admin_person_put(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    /** Identity administration */
    portal_admin_person_post(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    /** Identity administration */
    portal_admin_person_delete(UID_Person: string, options?: {}): Promise<EntityCollectionData>;
    /** Identity administration */
    portal_admin_person_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Returns data model information about query options for the admin/person endpoint. */
    portal_admin_person_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Identity administration */
    portal_admin_person_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
        withmanager?: string;
        orphaned?: string;
        deletedintarget?: string;
        isinactive?: string;
    }): Promise<GroupInfo[]>;
    /** Returns a list of objects that can be assigned to the property UID_PersonHead. */
    portal_admin_person_UID_PersonHead_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the admin/person/UID_PersonHead/candidates endpoint. */
    portal_admin_person_UID_PersonHead_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the admin/person/UID_PersonHead/candidates endpoint. */
    portal_admin_person_UID_PersonHead_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    portal_admin_resources_qerassign_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        published?: string;
        withowner?: string;
        risk?: string;
    }): Promise<EntityCollectionData>;
    portal_admin_resources_qerassign_put(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_admin_resources_qerassign_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Returns data model information about query options for the admin/resources/qerassign endpoint. */
    portal_admin_resources_qerassign_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    portal_admin_resources_qerassign_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}): Promise<InteractiveEntityData>;
    portal_admin_resources_qerassign_interactive_byid_get(UID_QERAssign: string, options?: {}): Promise<InteractiveEntityData>;
    portal_admin_resources_qerresource_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        published?: string;
        withowner?: string;
        risk?: string;
    }): Promise<EntityCollectionData>;
    portal_admin_resources_qerresource_put(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_admin_resources_qerresource_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Returns data model information about query options for the admin/resources/qerresource endpoint. */
    portal_admin_resources_qerresource_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    portal_admin_resources_qerresource_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}): Promise<InteractiveEntityData>;
    portal_admin_resources_qerresource_interactive_byid_get(UID_QERResource: string, options?: {}): Promise<InteractiveEntityData>;
    portal_admin_resources_qerreuse_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        published?: string;
        withowner?: string;
        risk?: string;
    }): Promise<EntityCollectionData>;
    portal_admin_resources_qerreuse_put(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_admin_resources_qerreuse_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Returns data model information about query options for the admin/resources/qerreuse endpoint. */
    portal_admin_resources_qerreuse_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    portal_admin_resources_qerreuse_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}): Promise<InteractiveEntityData>;
    portal_admin_resources_qerreuse_interactive_byid_get(UID_QERReuse: string, options?: {}): Promise<InteractiveEntityData>;
    portal_admin_resources_qerreuseus_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        published?: string;
        withowner?: string;
        risk?: string;
    }): Promise<EntityCollectionData>;
    portal_admin_resources_qerreuseus_put(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_admin_resources_qerreuseus_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Returns data model information about query options for the admin/resources/qerreuseus endpoint. */
    portal_admin_resources_qerreuseus_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    portal_admin_resources_qerreuseus_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}): Promise<InteractiveEntityData>;
    portal_admin_resources_qerreuseus_interactive_byid_get(UID_QERReuseUS: string, options?: {}): Promise<InteractiveEntityData>;
    portal_admin_role_department_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
        risk?: string;
    }): Promise<EntityCollectionData>;
    portal_admin_role_department_put(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>, options?: {}): Promise<EntityCollectionData>;
    portal_admin_role_department_post(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>, options?: {}): Promise<EntityCollectionData>;
    portal_admin_role_department_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Returns data model information about query options for the admin/role/department endpoint. */
    portal_admin_role_department_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    portal_admin_role_department_interactive_get(options?: {}): Promise<InteractiveEntityData>;
    portal_admin_role_department_interactive_put(inputParameterName: any, options?: {}): Promise<InteractiveEntityData>;
    portal_admin_role_department_interactive_byid_get(UID_Department: string, options?: {}): Promise<InteractiveEntityData>;
    portal_admin_role_locality_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
        risk?: string;
    }): Promise<EntityCollectionData>;
    portal_admin_role_locality_put(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>, options?: {}): Promise<EntityCollectionData>;
    portal_admin_role_locality_post(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>, options?: {}): Promise<EntityCollectionData>;
    portal_admin_role_locality_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Returns data model information about query options for the admin/role/locality endpoint. */
    portal_admin_role_locality_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    portal_admin_role_locality_interactive_get(options?: {}): Promise<InteractiveEntityData>;
    portal_admin_role_locality_interactive_put(inputParameterName: any, options?: {}): Promise<InteractiveEntityData>;
    portal_admin_role_locality_interactive_byid_get(UID_Locality: string, options?: {}): Promise<InteractiveEntityData>;
    portal_admin_role_profitcenter_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
        risk?: string;
    }): Promise<EntityCollectionData>;
    portal_admin_role_profitcenter_put(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>, options?: {}): Promise<EntityCollectionData>;
    portal_admin_role_profitcenter_post(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>, options?: {}): Promise<EntityCollectionData>;
    portal_admin_role_profitcenter_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Returns data model information about query options for the admin/role/profitcenter endpoint. */
    portal_admin_role_profitcenter_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    portal_admin_role_profitcenter_interactive_get(options?: {}): Promise<InteractiveEntityData>;
    portal_admin_role_profitcenter_interactive_put(inputParameterName: any, options?: {}): Promise<InteractiveEntityData>;
    portal_admin_role_profitcenter_interactive_byid_get(UID_ProfitCenter: string, options?: {}): Promise<InteractiveEntityData>;
    /** Returns the objects that are part of assignment, specified by the assignment's 'table name and the uid. */
    portal_assignment_get(tableName: string, uid: string, options?: {}): Promise<EntityData[]>;
    /** Returns a list of candidate objects from the table AccProduct. */
    portal_candidates_AccProduct_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/AccProduct endpoint. */
    portal_candidates_AccProduct_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the candidates/AccProduct endpoint. */
    portal_candidates_AccProduct_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table AccProductGroup. */
    portal_candidates_AccProductGroup_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/AccProductGroup endpoint. */
    portal_candidates_AccProductGroup_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the candidates/AccProductGroup endpoint. */
    portal_candidates_AccProductGroup_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table AccProductParamCategory. */
    portal_candidates_AccProductParamCategory_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/AccProductParamCategory endpoint. */
    portal_candidates_AccProductParamCategory_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the candidates/AccProductParamCategory endpoint. */
    portal_candidates_AccProductParamCategory_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table Department. */
    portal_candidates_Department_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/Department endpoint. */
    portal_candidates_Department_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the candidates/Department endpoint. */
    portal_candidates_Department_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table DialogUser. */
    portal_candidates_DialogUser_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/DialogUser endpoint. */
    portal_candidates_DialogUser_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the candidates/DialogUser endpoint. */
    portal_candidates_DialogUser_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table FirmPartner. */
    portal_candidates_FirmPartner_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/FirmPartner endpoint. */
    portal_candidates_FirmPartner_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the candidates/FirmPartner endpoint. */
    portal_candidates_FirmPartner_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table HelperHeadOrg. */
    portal_candidates_HelperHeadOrg_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/HelperHeadOrg endpoint. */
    portal_candidates_HelperHeadOrg_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the candidates/HelperHeadOrg endpoint. */
    portal_candidates_HelperHeadOrg_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table HelperHeadPerson. */
    portal_candidates_HelperHeadPerson_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/HelperHeadPerson endpoint. */
    portal_candidates_HelperHeadPerson_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the candidates/HelperHeadPerson endpoint. */
    portal_candidates_HelperHeadPerson_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table Locality. */
    portal_candidates_Locality_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/Locality endpoint. */
    portal_candidates_Locality_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the candidates/Locality endpoint. */
    portal_candidates_Locality_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table Person. */
    portal_candidates_Person_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/Person endpoint. */
    portal_candidates_Person_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the candidates/Person endpoint. */
    portal_candidates_Person_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table PersonInAERole. */
    portal_candidates_PersonInAERole_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/PersonInAERole endpoint. */
    portal_candidates_PersonInAERole_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the candidates/PersonInAERole endpoint. */
    portal_candidates_PersonInAERole_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table PersonInDepartment. */
    portal_candidates_PersonInDepartment_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/PersonInDepartment endpoint. */
    portal_candidates_PersonInDepartment_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the candidates/PersonInDepartment endpoint. */
    portal_candidates_PersonInDepartment_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table PersonInITShopOrg. */
    portal_candidates_PersonInITShopOrg_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/PersonInITShopOrg endpoint. */
    portal_candidates_PersonInITShopOrg_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the candidates/PersonInITShopOrg endpoint. */
    portal_candidates_PersonInITShopOrg_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table PersonInLocality. */
    portal_candidates_PersonInLocality_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/PersonInLocality endpoint. */
    portal_candidates_PersonInLocality_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the candidates/PersonInLocality endpoint. */
    portal_candidates_PersonInLocality_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table PersonInProfitCenter. */
    portal_candidates_PersonInProfitCenter_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/PersonInProfitCenter endpoint. */
    portal_candidates_PersonInProfitCenter_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the candidates/PersonInProfitCenter endpoint. */
    portal_candidates_PersonInProfitCenter_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table ProfitCenter. */
    portal_candidates_ProfitCenter_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/ProfitCenter endpoint. */
    portal_candidates_ProfitCenter_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the candidates/ProfitCenter endpoint. */
    portal_candidates_ProfitCenter_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table PWODecisionMethod. */
    portal_candidates_PWODecisionMethod_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/PWODecisionMethod endpoint. */
    portal_candidates_PWODecisionMethod_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the candidates/PWODecisionMethod endpoint. */
    portal_candidates_PWODecisionMethod_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QBMCulture. */
    portal_candidates_QBMCulture_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/QBMCulture endpoint. */
    portal_candidates_QBMCulture_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the candidates/QBMCulture endpoint. */
    portal_candidates_QBMCulture_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERJustification. */
    portal_candidates_QERJustification_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/QERJustification endpoint. */
    portal_candidates_QERJustification_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the candidates/QERJustification endpoint. */
    portal_candidates_QERJustification_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table QERPickCategory. */
    portal_candidates_QERPickCategory_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/QERPickCategory endpoint. */
    portal_candidates_QERPickCategory_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the candidates/QERPickCategory endpoint. */
    portal_candidates_QERPickCategory_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table WorkDesk. */
    portal_candidates_WorkDesk_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/WorkDesk endpoint. */
    portal_candidates_WorkDesk_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the candidates/WorkDesk endpoint. */
    portal_candidates_WorkDesk_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    portal_captchaimage_get(options?: {
        t?: string;
    }): Promise<Blob>;
    /** Submit the specified shopping cart */
    portal_cart_submit_post(uidcart: string, inputParameterName: CartSubmitOptions, options?: {}): Promise<CartCheckResult>;
    /** Manages shopping cart items for the current user. */
    portal_cartitem_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<ExtendedEntityCollectionData<CartItemDataRead>>;
    /** Manages shopping cart items for the current user. */
    portal_cartitem_put(inputParameterName: ExtendedEntityWriteData<{
        [key: string]: EntityWriteDataColumn[][];
    }>, options?: {}): Promise<ExtendedEntityCollectionData<CartItemDataRead>>;
    /** Manages shopping cart items for the current user. */
    portal_cartitem_post(inputParameterName: ExtendedEntityWriteData<{
        [key: string]: EntityWriteDataColumn[][];
    }>, options?: {}): Promise<ExtendedEntityCollectionData<CartItemDataRead>>;
    /** Manages shopping cart items for the current user. */
    portal_cartitem_delete(UID_ShoppingCartItem: string, options?: {}): Promise<ExtendedEntityCollectionData<CartItemDataRead>>;
    /** Moves a shopping cart item and its child items to the for-later list or to the current shopping cart for the user. */
    portal_cartitem_move_post(uidcartitem: string, options?: {
        tocart?: boolean;
    }): Promise<void>;
    /** Manages shopping cart items for the current user. */
    portal_cartitem_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Manages shopping cart items for the current user. */
    portal_cartitem_interactive_get(options?: {}): Promise<ExtendedInteractiveEntityDataOfCartItemDataRead>;
    /** Manages shopping cart items for the current user. */
    portal_cartitem_interactive_put(inputParameterName: any, options?: {}): Promise<ExtendedInteractiveEntityDataOfCartItemDataRead>;
    /** Manages shopping cart items for the current user. */
    portal_cartitem_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}): Promise<ExtendedInteractiveEntityDataOfCartItemDataRead>;
    /** Manages shopping cart items for the current user. */
    portal_cartitem_interactive_byid_get(UID_ShoppingCartItem: string, options?: {}): Promise<ExtendedInteractiveEntityDataOfCartItemDataRead>;
    /** Returns a list of objects that can be assigned as a parameter value. */
    portal_cartitem_interactive_parameter_candidates_post(name: string, parenttable: string, inputParameterName: InteractiveEntityStateData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    /** Returns filter tree information for the cartitem/interactive/parameter/{name}/candidates/{parenttable} endpoint. */
    portal_cartitem_interactive_parameter_candidates_filtertree_post(name: string, parenttable: string, inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_PersonOrdered. */
    portal_cartitem_interactive_UID_PersonOrdered_candidates_post(inputParameterName: InteractiveEntityStateData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ownsubidentities?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the cartitem/interactive/UID_PersonOrdered/candidates endpoint. */
    portal_cartitem_interactive_UID_PersonOrdered_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the cartitem/interactive/UID_PersonOrdered/candidates endpoint. */
    portal_cartitem_interactive_UID_PersonOrdered_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_QERJustificationOrder. */
    portal_cartitem_interactive_UID_QERJustificationOrder_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the cartitem/interactive/UID_QERJustificationOrder/candidates endpoint. */
    portal_cartitem_interactive_UID_QERJustificationOrder_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the cartitem/interactive/UID_QERJustificationOrder/candidates endpoint. */
    portal_cartitem_interactive_UID_QERJustificationOrder_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_ShoppingCartOrder. */
    portal_cartitem_interactive_UID_ShoppingCartOrder_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the cartitem/interactive/UID_ShoppingCartOrder/candidates endpoint. */
    portal_cartitem_interactive_UID_ShoppingCartOrder_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the cartitem/interactive/UID_ShoppingCartOrder/candidates endpoint. */
    portal_cartitem_interactive_UID_ShoppingCartOrder_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned as a parameter value. */
    portal_cartitem_parameter_candidates_post(name: string, parenttable: string, inputParameterName: EntityKeysData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    /** Returns filter tree information for the cartitem/parameter/{name}/candidates/{parenttable} endpoint. */
    portal_cartitem_parameter_candidates_filtertree_post(name: string, parenttable: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_PersonOrdered. */
    portal_cartitem_UID_PersonOrdered_candidates_post(inputParameterName: EntityKeysData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ownsubidentities?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the cartitem/UID_PersonOrdered/candidates endpoint. */
    portal_cartitem_UID_PersonOrdered_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the cartitem/UID_PersonOrdered/candidates endpoint. */
    portal_cartitem_UID_PersonOrdered_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_QERJustificationOrder. */
    portal_cartitem_UID_QERJustificationOrder_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the cartitem/UID_QERJustificationOrder/candidates endpoint. */
    portal_cartitem_UID_QERJustificationOrder_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the cartitem/UID_QERJustificationOrder/candidates endpoint. */
    portal_cartitem_UID_QERJustificationOrder_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_ShoppingCartOrder. */
    portal_cartitem_UID_ShoppingCartOrder_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the cartitem/UID_ShoppingCartOrder/candidates endpoint. */
    portal_cartitem_UID_ShoppingCartOrder_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the cartitem/UID_ShoppingCartOrder/candidates endpoint. */
    portal_cartitem_UID_ShoppingCartOrder_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    portal_config_get(options?: {}): Promise<ProjectConfig>;
    /** Returns basic information about an object specified by the table name and the uid. */
    portal_dbobject_get(tableName: string, uid: string, options?: {}): Promise<EntityData>;
    portal_delegable_get(uidpersonsender: string, uidpersonreceiver: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_delegation_enabled_get(uidperson: string, options?: {}): Promise<boolean>;
    /** Returns a list of delegations. */
    portal_delegations_get(options?: {
        uidperson?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns a list of delegations. */
    portal_delegations_post(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_delegations_global_post(inputParameterName: GlobalDelegationInput, options?: {}): Promise<void>;
    /** Returns the role classes along with the number of roles that the specified identity is an owner of. */
    portal_delegations_global_roleclasses_get(uidperson: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_PersonReceiver. */
    portal_delegations_UID_PersonReceiver_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the delegations/UID_PersonReceiver/candidates endpoint. */
    portal_delegations_UID_PersonReceiver_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the delegations/UID_PersonReceiver/candidates endpoint. */
    portal_delegations_UID_PersonReceiver_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    portal_detective_get(uidperson: string, tablename: string, uid: string, options?: {}): Promise<SourceNode[]>;
    portal_dynamicgroup_get(UID_DynamicGroup: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<ExtendedEntityCollectionData<SqlWizardRead>>;
    portal_dynamicgroup_delete(UID_DynamicGroup: string, options?: {}): Promise<ExtendedEntityCollectionData<SqlWizardRead>>;
    portal_dynamicgroup_interactive_get(UID_DynamicGroup: string, options?: {}): Promise<ExtendedInteractiveEntityDataOfSqlWizardRead>;
    portal_dynamicgroup_interactive_put(UID_DynamicGroup: string, inputParameterName: any, options?: {}): Promise<ExtendedInteractiveEntityDataOfSqlWizardRead>;
    portal_dynamicgroup_interactive_delete(UID_DynamicGroup: string, inputParameterName: InteractiveEntityDeleteData, options?: {}): Promise<ExtendedInteractiveEntityDataOfSqlWizardRead>;
    /** Returns a list of objects that can be assigned to the property UID_DialogSchedule. */
    portal_dynamicgroup_interactive_UID_DialogSchedule_candidates_get(UID_DynamicGroup: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the dynamicgroup/{UID_DynamicGroup}/interactive/UID_DialogSchedule/candidates endpoint. */
    portal_dynamicgroup_interactive_UID_DialogSchedule_candidates_datamodel_get(UID_DynamicGroup: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the dynamicgroup/{UID_DynamicGroup}/interactive/UID_DialogSchedule/candidates endpoint. */
    portal_dynamicgroup_interactive_UID_DialogSchedule_candidates_filtertree_post(UID_DynamicGroup: string, inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned as a filter parameter. */
    portal_dynamicgroup_sqlwizard_candidates_get(table: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    /** Returns the filterable properties for the specified table. */
    portal_dynamicgroup_sqlwizard_tables_columns_get(table: string, options?: {}): Promise<FilterPropertyList>;
    portal_featureconfig_get(options?: {}): Promise<FeatureConfig>;
    portal_history_get(table: string, uid: string, options?: {}): Promise<HistoryData[]>;
    portal_history_comparison_get(table: string, uid: string, options?: {
        CompareDate?: Date;
    }): Promise<HistoryComparisonData[]>;
    portal_history_rollback_get(table: string, uid: string, options?: {
        CompareDate?: Date;
        CompareId?: string;
    }): Promise<UiActionData[]>;
    portal_history_rollback_post(table: string, uid: string, inputParameterName: HistoryRollbackActionList, options?: {
        CompareDate?: Date;
        CompareId?: string;
    }): Promise<UiActionResultData[]>;
    portal_hyperview_get(table: string, uid: string, options?: {}): Promise<ShapeData[]>;
    portal_itshop_additional_post(uidpwo: string, inputParameterName: OtherApproverInput, options?: {}): Promise<void>;
    portal_itshop_answerquery_post(uidpwo: string, inputParameterName: ReasonInput, options?: {}): Promise<void>;
    /** Returns the workflow history for the specified request. */
    portal_itshop_approve_history_get(uidpwo: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_itshop_approve_requests_get(options?: {
        Escalation?: boolean;
        uid_personwantsorg?: string;
        uid_pwohelperpwo?: string;
        forinquiry?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<ExtendedEntityCollectionData<PwoExtendedData>>;
    portal_itshop_approve_requests_put(inputParameterName: ExtendedEntityWriteData<{
        [key: string]: EntityWriteDataColumn[][];
    }>, options?: {}): Promise<ExtendedEntityCollectionData<PwoExtendedData>>;
    /** Accepts the terms of use for the specified request. */
    portal_itshop_approve_requests_accept_post(uidpwo: string, options?: {}): Promise<void>;
    portal_itshop_approve_requests_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Returns data model information about query options for the itshop/approve/requests endpoint. */
    portal_itshop_approve_requests_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns a list of objects that can be assigned as a parameter value. */
    portal_itshop_approve_requests_parameter_candidates_post(name: string, parenttable: string, inputParameterName: EntityKeysData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    /** Returns filter tree information for the itshop/approve/requests/parameter/{name}/candidates/{parenttable} endpoint. */
    portal_itshop_approve_requests_parameter_candidates_filtertree_post(name: string, parenttable: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Initiates step-up authentication for the specified request. */
    portal_itshop_approve_requests_stepup_post(inputParameterName: RequestStepUpApprovalData, options?: {}): Promise<string>;
    /** Cancels the specified request. */
    portal_itshop_cancel_post(uidpwo: string, inputParameterName: ReasonInput, options?: {}): Promise<void>;
    /** Returns all shopping carts for the current user. */
    portal_itshop_cart_get(options?: {
        IncludeSubmitted?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns all shopping carts for the current user. */
    portal_itshop_cart_put(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    /** Returns all shopping carts for the current user. */
    portal_itshop_cart_delete(UID_ShoppingCartOrder: string, options?: {}): Promise<EntityCollectionData>;
    /** Accepts the terms of use for the specified shopping cart item. */
    portal_itshop_cart_accept_post(uidcartitem: string, options?: {}): Promise<void>;
    /** Returns all shopping carts for the current user. */
    portal_itshop_cart_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    portal_itshop_decide_post(uidpwo: string, inputParameterName: DecisionInput, options?: {}): Promise<void>;
    portal_itshop_denydecision_post(uidpwo: string, inputParameterName: DenyDecisionInput, options?: {}): Promise<void>;
    portal_itshop_directdecision_post(uidpwo: string, inputParameterName: DirectDecisionInput, options?: {}): Promise<void>;
    portal_itshop_escalate_post(uidpwo: string, inputParameterName: ReasonInput, options?: {}): Promise<void>;
    /** Finds requestable IT shop products for combinations of a person and a service item. */
    portal_itshop_findproducts_post(inputParameterName: ServiceItemForPerson[], options?: {}): Promise<RequestableProductForPerson[]>;
    /** Returns historical IT shop requests. */
    portal_itshop_history_requests_get(backto: Date, options?: {
        uidpersonordered?: string;
        uidpersoninserted?: string;
    }): Promise<EntityCollectionData>;
    /** Returns historical IT shop workflow data. */
    portal_itshop_history_workflow_get(uidpwo: string, backto: Date, options?: {}): Promise<EntityCollectionData>;
    portal_itshop_insteadof_post(uidpwo: string, inputParameterName: OtherApproverInput, options?: {}): Promise<void>;
    /** Returns all items in the IT shop pattern. */
    portal_itshop_pattern_get(uidpattern: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns all IT shop patterns. */
    portal_itshop_pattern_admin_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns all IT shop patterns. */
    portal_itshop_pattern_admin_put(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    /** Returns all IT shop patterns. */
    portal_itshop_pattern_admin_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Creates a copy of a pattern and returns the unique identifier of the new pattern. */
    portal_itshop_pattern_copy_post(uidpattern: string, options?: {}): Promise<string>;
    /** Manages IT shop template items for the current user. */
    portal_itshop_pattern_item_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Manages IT shop template items for the current user. */
    portal_itshop_pattern_item_post(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    /** Manages IT shop template items for the current user. */
    portal_itshop_pattern_item_delete(UID_ShoppingCartPatternItem: string, options?: {}): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_ShoppingCartPattern. */
    portal_itshop_pattern_item_UID_ShoppingCartPattern_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the itshop/pattern/item/UID_ShoppingCartPattern/candidates endpoint. */
    portal_itshop_pattern_item_UID_ShoppingCartPattern_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the itshop/pattern/item/UID_ShoppingCartPattern/candidates endpoint. */
    portal_itshop_pattern_item_UID_ShoppingCartPattern_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Manages IT shop templates for the current user. */
    portal_itshop_pattern_private_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Manages IT shop templates for the current user. */
    portal_itshop_pattern_private_put(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    /** Manages IT shop templates for the current user. */
    portal_itshop_pattern_private_post(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    /** Manages IT shop templates for the current user. */
    portal_itshop_pattern_private_delete(UID_ShoppingCartPattern: string, options?: {}): Promise<EntityCollectionData>;
    /** Manages IT shop templates for the current user. */
    portal_itshop_pattern_private_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Returns requestable IT shop patterns. */
    portal_itshop_pattern_requestable_get(options?: {
        UID_Person?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns the identities that form the peer group for the specified identity. */
    portal_itshop_peergroup_get(uidperson: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns the role memberships for the peer group of the specified identities. */
    portal_itshop_peergroup_memberships_get(options?: {
        UID_Person?: string;
        UID_PersonReference?: string;
        UID_PersonPeerGroup?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<ExtendedEntityCollectionData<ServiceItemsExtendedData>>;
    /** Returns employees allowed to make approvals for the specified request. */
    portal_itshop_persondecision_get(uidpersonwantsorg: string, options?: {}): Promise<EntityCollectionData>;
    /** Prolongates a request. */
    portal_itshop_prolongate_post(uidpwo: string, inputParameterName: ProlongationInput, options?: {}): Promise<void>;
    portal_itshop_query_post(uidpwo: string, inputParameterName: PwoQueryInput, options?: {}): Promise<void>;
    portal_itshop_recalldecision_post(uidpwo: string, inputParameterName: RecallDecisionInput, options?: {}): Promise<void>;
    portal_itshop_recallquery_post(uidpwo: string, inputParameterName: ReasonInput, options?: {}): Promise<void>;
    /** Returns existing IT shop requests. */
    portal_itshop_requests_get(options?: {
        uidpwo?: string;
        DocumentNumber?: string;
        UID_Person?: string;
        UID_PersonDecision?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ShowMyDecisions?: string;
        ShowMyPending?: string;
        ShowEndingSoon?: string;
        MyDelegations?: string;
        status?: string;
        person?: string;
    }): Promise<ExtendedEntityCollectionData<PwoExtendedData>>;
    /** Returns data model information about query options for the itshop/requests endpoint. */
    portal_itshop_requests_datamodel_get(options?: {
        UID_Person?: string;
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns a list of objects that can be assigned as a parameter value. */
    portal_itshop_requests_parameter_candidates_post(name: string, parenttable: string, inputParameterName: EntityKeysData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    /** Returns filter tree information for the itshop/requests/parameter/{name}/candidates/{parenttable} endpoint. */
    portal_itshop_requests_parameter_candidates_filtertree_post(name: string, parenttable: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    portal_itshop_resetreservation_post(uidpwo: string, inputParameterName: ReasonInput, options?: {}): Promise<void>;
    /** Revokes an approval delegation. */
    portal_itshop_revokedelegation_post(uidpwo: string, inputParameterName: RecallDecisionInput, options?: {}): Promise<void>;
    portal_itshop_unsubscribe_post(inputParameterName: PwoUnsubscribeInput, options?: {}): Promise<PwoUnsubscribeResult>;
    portal_justifications_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns multi-language configuration. */
    portal_multilanguage_config_get(options?: {
        cultureName?: string;
    }): Promise<MultiLanguageConfig>;
    /** Returns links to Password Manager. */
    portal_password_qpmlinks_get(options?: {}): Promise<QpmIntegrationLinks>;
    /** Manages the person's password questions. */
    portal_passwordquestions_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Manages the person's password questions. */
    portal_passwordquestions_put(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    /** Manages the person's password questions. */
    portal_passwordquestions_post(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    /** Manages the person's password questions. */
    portal_passwordquestions_delete(UID_QERPasswordQueryAndAnswer: string, options?: {}): Promise<EntityCollectionData>;
    /** Manages the person's password questions. */
    portal_passwordquestions_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Unlocks a specific password question if it has been locked. */
    portal_passwordquestions_unlock_post(uid: string, options?: {}): Promise<void>;
    portal_pendingitems_get(options?: {}): Promise<{
        [key: string]: number;
    }>;
    portal_person_rolememberships_AERole_get(UID_Person: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_person_rolememberships_Department_get(UID_Person: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_person_rolememberships_ITShopOrg_get(UID_Person: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        type?: string;
    }): Promise<EntityCollectionData>;
    portal_person_rolememberships_Locality_get(UID_Person: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_person_rolememberships_ProfitCenter_get(UID_Person: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_person_requestmanagerchange_post(UID_PersonOrdered: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_PersonOrdered. */
    portal_person_requestmanagerchange_UID_PersonOrdered_candidates_post(UID_PersonOrdered: string, inputParameterName: EntityKeysData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the person/{UID_PersonOrdered}/requestmanagerchange/UID_PersonOrdered/candidates endpoint. */
    portal_person_requestmanagerchange_UID_PersonOrdered_candidates_datamodel_get(UID_PersonOrdered: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the person/{UID_PersonOrdered}/requestmanagerchange/UID_PersonOrdered/candidates endpoint. */
    portal_person_requestmanagerchange_UID_PersonOrdered_candidates_filtertree_post(UID_PersonOrdered: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_ShoppingCartOrder. */
    portal_person_requestmanagerchange_UID_ShoppingCartOrder_candidates_get(UID_PersonOrdered: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the person/{UID_PersonOrdered}/requestmanagerchange/UID_ShoppingCartOrder/candidates endpoint. */
    portal_person_requestmanagerchange_UID_ShoppingCartOrder_candidates_datamodel_get(UID_PersonOrdered: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the person/{UID_PersonOrdered}/requestmanagerchange/UID_ShoppingCartOrder/candidates endpoint. */
    portal_person_requestmanagerchange_UID_ShoppingCartOrder_candidates_filtertree_post(UID_PersonOrdered: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    portal_person_memberships_get(uid: string, options?: {}): Promise<EntityCollectionData>;
    /** Returns all active identities. */
    portal_person_active_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_person_all_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        isinactive?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the person/all endpoint. */
    portal_person_all_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    portal_person_all_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
        isinactive?: string;
    }): Promise<GroupInfo[]>;
    /** Returns the current user's permission model. */
    portal_person_config_get(options?: {}): Promise<UserConfig>;
    portal_person_email_get(uidperson: string, options?: {}): Promise<EntityCollectionData>;
    portal_person_email_post(uidperson: string, inputParameterName: MailSubscriptionChange, options?: {}): Promise<void>;
    portal_person_image_get(uidperson: string, options?: {}): Promise<Blob>;
    /** Gets or sets the master data for the authenticated identity. */
    portal_person_masterdata_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Gets or sets the master data for the authenticated identity. */
    portal_person_masterdata_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}): Promise<InteractiveEntityData>;
    /** Gets or sets the master data for the authenticated identity. */
    portal_person_masterdata_interactive_byid_get(UID_Person: string, options?: {}): Promise<InteractiveEntityData>;
    /** Returns a list of objects that can be assigned to the property UID_DialogCountry. */
    portal_person_masterdata_interactive_UID_DialogCountry_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the person/masterdata/interactive/UID_DialogCountry/candidates endpoint. */
    portal_person_masterdata_interactive_UID_DialogCountry_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the person/masterdata/interactive/UID_DialogCountry/candidates endpoint. */
    portal_person_masterdata_interactive_UID_DialogCountry_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_DialogCulture. */
    portal_person_masterdata_interactive_UID_DialogCulture_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the person/masterdata/interactive/UID_DialogCulture/candidates endpoint. */
    portal_person_masterdata_interactive_UID_DialogCulture_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the person/masterdata/interactive/UID_DialogCulture/candidates endpoint. */
    portal_person_masterdata_interactive_UID_DialogCulture_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_DialogState. */
    portal_person_masterdata_interactive_UID_DialogState_candidates_post(inputParameterName: InteractiveEntityStateData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the person/masterdata/interactive/UID_DialogState/candidates endpoint. */
    portal_person_masterdata_interactive_UID_DialogState_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the person/masterdata/interactive/UID_DialogState/candidates endpoint. */
    portal_person_masterdata_interactive_UID_DialogState_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_PersonMasterIdentity. */
    portal_person_masterdata_interactive_UID_PersonMasterIdentity_candidates_post(inputParameterName: InteractiveEntityStateData, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the person/masterdata/interactive/UID_PersonMasterIdentity/candidates endpoint. */
    portal_person_masterdata_interactive_UID_PersonMasterIdentity_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the person/masterdata/interactive/UID_PersonMasterIdentity/candidates endpoint. */
    portal_person_masterdata_interactive_UID_PersonMasterIdentity_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_RealPerson. */
    portal_person_masterdata_interactive_UID_RealPerson_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the person/masterdata/interactive/UID_RealPerson/candidates endpoint. */
    portal_person_masterdata_interactive_UID_RealPerson_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the person/masterdata/interactive/UID_RealPerson/candidates endpoint. */
    portal_person_masterdata_interactive_UID_RealPerson_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns organizational data for the specified person */
    portal_person_orgdata_get(type: string, uidperson: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns overview data for the specified person */
    portal_person_overview_get(uidperson: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_person_passcode_post(uid: string, options?: {}): Promise<PersonPasscodeResult>;
    /** Returns the direct reports for the current user. */
    portal_person_reports_get(options?: {
        OnlyDirect?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        isinactive?: string;
        reports?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the person/reports endpoint. */
    portal_person_reports_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns the direct reports for the current user. */
    portal_person_reports_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
        isinactive?: string;
        reports?: string;
    }): Promise<GroupInfo[]>;
    /** Returns the direct reports for the current user. */
    portal_person_reports_interactive_get(options?: {}): Promise<InteractiveEntityData>;
    /** Returns the direct reports for the current user. */
    portal_person_reports_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}): Promise<InteractiveEntityData>;
    /** Returns the direct reports for the current user. */
    portal_person_reports_interactive_byid_get(UID_Person: string, options?: {}): Promise<InteractiveEntityData>;
    /** Returns a list of objects that can be assigned to the property UID_PersonHead. */
    portal_person_reports_interactive_UID_PersonHead_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the person/reports/interactive/UID_PersonHead/candidates endpoint. */
    portal_person_reports_interactive_UID_PersonHead_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the person/reports/interactive/UID_PersonHead/candidates endpoint. */
    portal_person_reports_interactive_UID_PersonHead_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    portal_person_uid_get(uidperson: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_pickcategory_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_pickcategory_put(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_pickcategory_post(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_pickcategory_delete(UID_QERPickCategory: string, options?: {}): Promise<EntityCollectionData>;
    portal_pickcategory_items_get(UID_QERPickCategory: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_pickcategory_items_post(UID_QERPickCategory: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_pickcategory_items_delete(UID_QERPickCategory: string, UID_QERPickedItem: string, options?: {}): Promise<EntityCollectionData>;
    portal_pickcategory_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Returns global KPI information. */
    portal_qer_kpi_get(options?: {}): Promise<ChartDto[]>;
    portal_qer_projectconfig_get(options?: {}): Promise<QerProjectConfig>;
    /** Returns the related applications to show for the current user. */
    portal_relatedapplications_get(options?: {}): Promise<RelatedApplication[]>;
    portal_resources_membership_QERResource_get(UID_QERResource: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_resources_membership_QERResource_post(UID_QERResource: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_resources_membership_QERResource_delete(UID_QERResource: string, UID_Person: string, options?: {}): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    portal_resources_membership_QERResource_UID_Person_candidates_get(UID_QERResource: string, options?: {
        xorigin?: number;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resources/membership/QERResource/{UID_QERResource}/UID_Person/candidates endpoint. */
    portal_resources_membership_QERResource_UID_Person_candidates_datamodel_get(UID_QERResource: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the resources/membership/QERResource/{UID_QERResource}/UID_Person/candidates endpoint. */
    portal_resources_membership_QERResource_UID_Person_candidates_filtertree_post(UID_QERResource: string, inputParameterName: EntityWriteDataSingle, options?: {
        xorigin?: number;
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    portal_resources_qerassign_serviceitem_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_resources_qerassign_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>, options?: {}): Promise<EntityCollectionData>;
    portal_resources_qerassign_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Returns data model information about query options for the resources/qerassign/serviceitem endpoint. */
    portal_resources_qerassign_serviceitem_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    portal_resources_qerresource_serviceitem_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_resources_qerresource_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>, options?: {}): Promise<EntityCollectionData>;
    portal_resources_qerresource_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Returns data model information about query options for the resources/qerresource/serviceitem endpoint. */
    portal_resources_qerresource_serviceitem_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    portal_resources_qerreuse_serviceitem_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_resources_qerreuse_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>, options?: {}): Promise<EntityCollectionData>;
    portal_resources_qerreuse_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Returns data model information about query options for the resources/qerreuse/serviceitem endpoint. */
    portal_resources_qerreuse_serviceitem_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    portal_resources_qerreuseus_serviceitem_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_resources_qerreuseus_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>, options?: {}): Promise<EntityCollectionData>;
    portal_resources_qerreuseus_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Returns data model information about query options for the resources/qerreuseus/serviceitem endpoint. */
    portal_resources_qerreuseus_serviceitem_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    portal_resp_aerole_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/aerole endpoint. */
    portal_resp_aerole_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    portal_resp_aerole_interactive_get(options?: {}): Promise<InteractiveEntityData>;
    portal_resp_aerole_interactive_put(inputParameterName: any, options?: {}): Promise<InteractiveEntityData>;
    portal_resp_aerole_interactive_byid_get(UID_AERole: string, options?: {}): Promise<InteractiveEntityData>;
    portal_resp_department_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/department endpoint. */
    portal_resp_department_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    portal_resp_department_interactive_get(options?: {}): Promise<InteractiveEntityData>;
    portal_resp_department_interactive_put(inputParameterName: any, options?: {}): Promise<InteractiveEntityData>;
    portal_resp_department_interactive_byid_get(UID_Department: string, options?: {}): Promise<InteractiveEntityData>;
    portal_resp_Department_restore_get(options?: {
        backto?: Date;
    }): Promise<DeletedObjectInfo[]>;
    portal_resp_Department_restore_byid_get(uid: string, options?: {
        backto?: Date;
    }): Promise<RestoreActions>;
    portal_resp_Department_restore_byid_post(uid: string, inputParameterName: RestoreActionList, options?: {
        backto?: Date;
    }): Promise<UiActionResultData[]>;
    portal_resp_locality_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/locality endpoint. */
    portal_resp_locality_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    portal_resp_locality_interactive_get(options?: {}): Promise<InteractiveEntityData>;
    portal_resp_locality_interactive_put(inputParameterName: any, options?: {}): Promise<InteractiveEntityData>;
    portal_resp_locality_interactive_byid_get(UID_Locality: string, options?: {}): Promise<InteractiveEntityData>;
    portal_resp_Locality_restore_get(options?: {
        backto?: Date;
    }): Promise<DeletedObjectInfo[]>;
    portal_resp_Locality_restore_byid_get(uid: string, options?: {
        backto?: Date;
    }): Promise<RestoreActions>;
    portal_resp_Locality_restore_byid_post(uid: string, inputParameterName: RestoreActionList, options?: {
        backto?: Date;
    }): Promise<UiActionResultData[]>;
    portal_resp_profitcenter_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/profitcenter endpoint. */
    portal_resp_profitcenter_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    portal_resp_profitcenter_interactive_get(options?: {}): Promise<InteractiveEntityData>;
    portal_resp_profitcenter_interactive_put(inputParameterName: any, options?: {}): Promise<InteractiveEntityData>;
    portal_resp_profitcenter_interactive_byid_get(UID_ProfitCenter: string, options?: {}): Promise<InteractiveEntityData>;
    portal_resp_ProfitCenter_restore_get(options?: {
        backto?: Date;
    }): Promise<DeletedObjectInfo[]>;
    portal_resp_ProfitCenter_restore_byid_get(uid: string, options?: {
        backto?: Date;
    }): Promise<RestoreActions>;
    portal_resp_ProfitCenter_restore_byid_post(uid: string, inputParameterName: RestoreActionList, options?: {
        backto?: Date;
    }): Promise<UiActionResultData[]>;
    portal_risk_analyze_get(tablename: string, pk: string, options?: {
        IncludeZeroRisk?: boolean;
    }): Promise<RiskObject[]>;
    portal_risk_functions_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_risk_functions_put(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_risk_functions_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    portal_roles_compare_get(roletype: string, uidrole: string, compareroletype: string, uidcomparerole: string, options?: {}): Promise<RoleCompareItems>;
    portal_roles_merge_get(roletype: string, uidrole: string, mergeroletype: string, uidmergerole: string, options?: {}): Promise<MergeActions>;
    portal_roles_merge_post(roletype: string, uidrole: string, mergeroletype: string, uidmergerole: string, inputParameterName: MergeActionList, options?: {}): Promise<UiActionResultData[]>;
    portal_roles_split_get(roletype: string, uidrole: string, newroletype: string, newroleid: string, options?: {}): Promise<IRoleSplitItem[]>;
    portal_roles_split_post(roletype: string, uidrole: string, newroletype: string, newroleid: string, inputParameterName: RoleSplitInput, options?: {}): Promise<UiActionData[]>;
    portal_roles_config_classes_get(uidorgroot: string, options?: {}): Promise<RoleAssignmentData[]>;
    /** Returns identities who are primary members of a role. */
    portal_roles_config_Department_primarymembers_get(UID_Department: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns identities who are primary members of a role. */
    portal_roles_config_Locality_primarymembers_get(UID_Locality: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_roles_config_membership_AERole_get(UID_AERole: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_roles_config_membership_AERole_post(UID_AERole: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_roles_config_membership_AERole_delete(UID_AERole: string, UID_Person: string, options?: {}): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    portal_roles_config_membership_AERole_UID_Person_candidates_get(UID_AERole: string, options?: {
        xorigin?: number;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the roles/config/membership/AERole/{UID_AERole}/UID_Person/candidates endpoint. */
    portal_roles_config_membership_AERole_UID_Person_candidates_datamodel_get(UID_AERole: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the roles/config/membership/AERole/{UID_AERole}/UID_Person/candidates endpoint. */
    portal_roles_config_membership_AERole_UID_Person_candidates_filtertree_post(UID_AERole: string, inputParameterName: EntityWriteDataSingle, options?: {
        xorigin?: number;
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    portal_roles_config_membership_Department_get(UID_Department: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_roles_config_membership_Department_post(UID_Department: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_roles_config_membership_Department_delete(UID_Department: string, UID_Person: string, options?: {}): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    portal_roles_config_membership_Department_UID_Person_candidates_get(UID_Department: string, options?: {
        xorigin?: number;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the roles/config/membership/Department/{UID_Department}/UID_Person/candidates endpoint. */
    portal_roles_config_membership_Department_UID_Person_candidates_datamodel_get(UID_Department: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the roles/config/membership/Department/{UID_Department}/UID_Person/candidates endpoint. */
    portal_roles_config_membership_Department_UID_Person_candidates_filtertree_post(UID_Department: string, inputParameterName: EntityWriteDataSingle, options?: {
        xorigin?: number;
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    portal_roles_config_membership_Locality_get(UID_Locality: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_roles_config_membership_Locality_post(UID_Locality: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_roles_config_membership_Locality_delete(UID_Locality: string, UID_Person: string, options?: {}): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    portal_roles_config_membership_Locality_UID_Person_candidates_get(UID_Locality: string, options?: {
        xorigin?: number;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the roles/config/membership/Locality/{UID_Locality}/UID_Person/candidates endpoint. */
    portal_roles_config_membership_Locality_UID_Person_candidates_datamodel_get(UID_Locality: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the roles/config/membership/Locality/{UID_Locality}/UID_Person/candidates endpoint. */
    portal_roles_config_membership_Locality_UID_Person_candidates_filtertree_post(UID_Locality: string, inputParameterName: EntityWriteDataSingle, options?: {
        xorigin?: number;
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    portal_roles_config_membership_ProfitCenter_get(UID_ProfitCenter: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_roles_config_membership_ProfitCenter_post(UID_ProfitCenter: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_roles_config_membership_ProfitCenter_delete(UID_ProfitCenter: string, UID_Person: string, options?: {}): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    portal_roles_config_membership_ProfitCenter_UID_Person_candidates_get(UID_ProfitCenter: string, options?: {
        xorigin?: number;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the roles/config/membership/ProfitCenter/{UID_ProfitCenter}/UID_Person/candidates endpoint. */
    portal_roles_config_membership_ProfitCenter_UID_Person_candidates_datamodel_get(UID_ProfitCenter: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the roles/config/membership/ProfitCenter/{UID_ProfitCenter}/UID_Person/candidates endpoint. */
    portal_roles_config_membership_ProfitCenter_UID_Person_candidates_filtertree_post(UID_ProfitCenter: string, inputParameterName: EntityWriteDataSingle, options?: {
        xorigin?: number;
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns identities who are primary members of a role. */
    portal_roles_config_ProfitCenter_primarymembers_get(UID_ProfitCenter: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_roles_Department_restore_get(options?: {
        backto?: Date;
    }): Promise<DeletedObjectInfo[]>;
    portal_roles_Department_restore_byid_get(uid: string, options?: {
        backto?: Date;
    }): Promise<RestoreActions>;
    portal_roles_Department_restore_byid_post(uid: string, inputParameterName: RestoreActionList, options?: {
        backto?: Date;
    }): Promise<UiActionResultData[]>;
    /** Returns the entitlements assigned to the role. */
    portal_roles_entitlements_get(roletype: string, uidrole: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_roles_exclusions_get(UID_DynamicGroup: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_roles_exclusions_put(UID_DynamicGroup: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_roles_exclusions_post(UID_DynamicGroup: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_roles_exclusions_delete(UID_DynamicGroup: string, UID_Person: string, options?: {}): Promise<EntityCollectionData>;
    portal_roles_exclusions_bulk_put(UID_DynamicGroup: string, inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    portal_roles_Locality_restore_get(options?: {
        backto?: Date;
    }): Promise<DeletedObjectInfo[]>;
    portal_roles_Locality_restore_byid_get(uid: string, options?: {
        backto?: Date;
    }): Promise<RestoreActions>;
    portal_roles_Locality_restore_byid_post(uid: string, inputParameterName: RestoreActionList, options?: {
        backto?: Date;
    }): Promise<UiActionResultData[]>;
    portal_roles_ProfitCenter_restore_get(options?: {
        backto?: Date;
    }): Promise<DeletedObjectInfo[]>;
    portal_roles_ProfitCenter_restore_byid_get(uid: string, options?: {
        backto?: Date;
    }): Promise<RestoreActions>;
    portal_roles_ProfitCenter_restore_byid_post(uid: string, inputParameterName: RestoreActionList, options?: {
        backto?: Date;
    }): Promise<UiActionResultData[]>;
    portal_search_get(options?: {
        term?: string;
        tables?: string;
    }): Promise<SearchResultObject[]>;
    /** Obtains a list of available service categories. */
    portal_servicecategories_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    /** Obtains a list of available service categories. */
    portal_servicecategories_put(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    /** Obtains a list of available service categories. */
    portal_servicecategories_post(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    /** Obtains a list of available service categories. */
    portal_servicecategories_delete(UID_AccProductGroup: string, options?: {}): Promise<EntityCollectionData>;
    /** Obtains a list of available service categories. */
    portal_servicecategories_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Obtains a list of available service categories. */
    portal_servicecategories_interactive_get(options?: {}): Promise<InteractiveEntityData>;
    /** Obtains a list of available service categories. */
    portal_servicecategories_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}): Promise<InteractiveEntityData>;
    /** Obtains a list of available service categories. */
    portal_servicecategories_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}): Promise<InteractiveEntityData>;
    /** Obtains a list of available service categories. */
    portal_servicecategories_interactive_byid_get(UID_AccProductGroup: string, options?: {}): Promise<InteractiveEntityData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgAttestator. */
    portal_servicecategories_interactive_UID_OrgAttestator_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the servicecategories/interactive/UID_OrgAttestator/candidates endpoint. */
    portal_servicecategories_interactive_UID_OrgAttestator_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the servicecategories/interactive/UID_OrgAttestator/candidates endpoint. */
    portal_servicecategories_interactive_UID_OrgAttestator_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgRuler. */
    portal_servicecategories_interactive_UID_OrgRuler_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the servicecategories/interactive/UID_OrgRuler/candidates endpoint. */
    portal_servicecategories_interactive_UID_OrgRuler_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the servicecategories/interactive/UID_OrgRuler/candidates endpoint. */
    portal_servicecategories_interactive_UID_OrgRuler_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_PWODecisionMethod. */
    portal_servicecategories_interactive_UID_PWODecisionMethod_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the servicecategories/interactive/UID_PWODecisionMethod/candidates endpoint. */
    portal_servicecategories_interactive_UID_PWODecisionMethod_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the servicecategories/interactive/UID_PWODecisionMethod/candidates endpoint. */
    portal_servicecategories_interactive_UID_PWODecisionMethod_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgAttestator. */
    portal_servicecategories_UID_OrgAttestator_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the servicecategories/UID_OrgAttestator/candidates endpoint. */
    portal_servicecategories_UID_OrgAttestator_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the servicecategories/UID_OrgAttestator/candidates endpoint. */
    portal_servicecategories_UID_OrgAttestator_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgRuler. */
    portal_servicecategories_UID_OrgRuler_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the servicecategories/UID_OrgRuler/candidates endpoint. */
    portal_servicecategories_UID_OrgRuler_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the servicecategories/UID_OrgRuler/candidates endpoint. */
    portal_servicecategories_UID_OrgRuler_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_PWODecisionMethod. */
    portal_servicecategories_UID_PWODecisionMethod_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the servicecategories/UID_PWODecisionMethod/candidates endpoint. */
    portal_servicecategories_UID_PWODecisionMethod_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the servicecategories/UID_PWODecisionMethod/candidates endpoint. */
    portal_servicecategories_UID_PWODecisionMethod_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Obtains a list of available service items. */
    portal_serviceitems_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Obtains a list of available service items. */
    portal_serviceitems_put(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    /** Obtains a list of available service items. */
    portal_serviceitems_post(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    /** Obtains a list of available service items. */
    portal_serviceitems_delete(UID_AccProduct: string, options?: {}): Promise<EntityCollectionData>;
    /** Obtains the tags associated with a service item. */
    portal_serviceitems_tags_get(UID_AccProduct: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Deletes a tag associated with a service item. */
    portal_serviceitems_tags_delete(UID_AccProduct: string, UID_Tag: string, options?: {}): Promise<void>;
    /** Adds a new tag to a service item. */
    portal_serviceitems_tags_add_post(UID_AccProduct: string, inputParameterName: string, options?: {}): Promise<void>;
    /** Obtains a list of available service items. */
    portal_serviceitems_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Obtains a list of available service items. */
    portal_serviceitems_interactive_get(options?: {}): Promise<InteractiveEntityData>;
    /** Obtains a list of available service items. */
    portal_serviceitems_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}): Promise<InteractiveEntityData>;
    /** Obtains a list of available service items. */
    portal_serviceitems_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}): Promise<InteractiveEntityData>;
    /** Obtains a list of available service items. */
    portal_serviceitems_interactive_byid_get(UID_AccProduct: string, options?: {}): Promise<InteractiveEntityData>;
    /** Returns the hierarchy of service categories for the available service items for the specified recipient(s). */
    portal_shop_categories_get(options?: {
        UID_Person?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    portal_shop_categoryimage_get(uidcategory: string, options?: {}): Promise<Blob>;
    portal_shop_config_members_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_shop_config_members_put(UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_shop_config_members_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_shop_config_members_delete(UID_ITShopOrg: string, UID_Person: string, options?: {}): Promise<EntityCollectionData>;
    portal_shop_config_members_bulk_put(UID_ITShopOrg: string, inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    portal_shop_config_members_UID_Person_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/{UID_ITShopOrg}/members/UID_Person/candidates endpoint. */
    portal_shop_config_members_UID_Person_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/{UID_ITShopOrg}/members/UID_Person/candidates endpoint. */
    portal_shop_config_members_UID_Person_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    portal_shop_config_entitlements_QERAssign_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_QERAssign_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_QERAssign_delete(UID_ITShopOrg: string, UID_QERAssign: string, options?: {}): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_QERAssign. */
    portal_shop_config_entitlements_QERAssign_UID_QERAssign_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/QERAssign/UID_QERAssign/candidates endpoint. */
    portal_shop_config_entitlements_QERAssign_UID_QERAssign_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/QERAssign/UID_QERAssign/candidates endpoint. */
    portal_shop_config_entitlements_QERAssign_UID_QERAssign_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    portal_shop_config_entitlements_QERResource_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_QERResource_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_QERResource_delete(UID_ITShopOrg: string, UID_QERResource: string, options?: {}): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_QERResource. */
    portal_shop_config_entitlements_QERResource_UID_QERResource_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/QERResource/UID_QERResource/candidates endpoint. */
    portal_shop_config_entitlements_QERResource_UID_QERResource_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/QERResource/UID_QERResource/candidates endpoint. */
    portal_shop_config_entitlements_QERResource_UID_QERResource_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    portal_shop_config_entitlements_QERReuse_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuse_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuse_delete(UID_ITShopOrg: string, UID_QERReuse: string, options?: {}): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_QERReuse. */
    portal_shop_config_entitlements_QERReuse_UID_QERReuse_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/QERReuse/UID_QERReuse/candidates endpoint. */
    portal_shop_config_entitlements_QERReuse_UID_QERReuse_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/QERReuse/UID_QERReuse/candidates endpoint. */
    portal_shop_config_entitlements_QERReuse_UID_QERReuse_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    portal_shop_config_entitlements_QERReuseUS_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuseUS_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_QERReuseUS_delete(UID_ITShopOrg: string, UID_QERReuseUS: string, options?: {}): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_QERReuseUS. */
    portal_shop_config_entitlements_QERReuseUS_UID_QERReuseUS_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/QERReuseUS/UID_QERReuseUS/candidates endpoint. */
    portal_shop_config_entitlements_QERReuseUS_UID_QERReuseUS_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/QERReuseUS/UID_QERReuseUS/candidates endpoint. */
    portal_shop_config_entitlements_QERReuseUS_UID_QERReuseUS_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns the entitlements assigned to the shelf. */
    portal_shop_config_entitlements_get(uidshelf: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Manages shop and shelf objects in the IT shop. */
    portal_shop_config_structure_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    /** Manages shop and shelf objects in the IT shop. */
    portal_shop_config_structure_put(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    /** Manages shop and shelf objects in the IT shop. */
    portal_shop_config_structure_post(inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    /** Manages shop and shelf objects in the IT shop. */
    portal_shop_config_structure_delete(UID_ITShopOrg: string, options?: {}): Promise<EntityCollectionData>;
    /** Manages shop and shelf objects in the IT shop. */
    portal_shop_config_structure_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Returns a list of objects that can be assigned to the property DecisionMethods. */
    portal_shop_config_structure_DecisionMethods_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/structure/DecisionMethods/candidates endpoint. */
    portal_shop_config_structure_DecisionMethods_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/structure/DecisionMethods/candidates endpoint. */
    portal_shop_config_structure_DecisionMethods_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgAttestator. */
    portal_shop_config_structure_UID_OrgAttestator_candidates_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/structure/UID_OrgAttestator/candidates endpoint. */
    portal_shop_config_structure_UID_OrgAttestator_candidates_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/structure/UID_OrgAttestator/candidates endpoint. */
    portal_shop_config_structure_UID_OrgAttestator_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    portal_shop_serviceitemimage_get(uidserviceitem: string, options?: {}): Promise<Blob>;
    /** Returns requestable service items. */
    portal_shop_serviceitems_get(options?: {
        UID_Person?: string;
        UID_AccProductGroup?: string;
        IncludeChildCategories?: boolean;
        UID_AccProductParent?: string;
        UID_PersonReference?: string;
        UID_PersonPeerGroup?: string;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<ExtendedEntityCollectionData<ServiceItemsExtendedData>>;
    /** Returns the entitlements associated with the service item's role. */
    portal_shop_serviceitems_entitlements_get(UID_AccProduct: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<EntityCollectionData>;
    /** Returns the dependency hierarchy of a service item. If the service item has no dependencies, an empty object is returned. */
    portal_shop_serviceitems_dependencies_get(uid: string, options?: {
        UID_Person?: string;
    }): Promise<ServiceItemHierarchy>;
    /** Returns data model information about query options for the shop/serviceitems endpoint. */
    portal_shop_serviceitems_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    portal_termsofuse_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_termsofuse_download_get(uid: string, options?: {}): Promise<Blob>;
    /** Returns the list of permissions groups that the current user is assigned to. */
    portal_usergroups_get(options?: {}): Promise<UserGroupInfo[]>;
    portal_userprocess_get(options?: {}): Promise<ProcessChain[]>;
    portal_userprocess_result_get(uidtree: string, uidjobs: string, options?: {}): Promise<ResultInfo[]>;
    /** Returns the list of user-specific UI settings. */
    portal_usersettings_get(options?: {}): Promise<UiSetting[]>;
    /** Stores the specified list of user-specific UI settings. */
    portal_usersettings_post(inputParameterName: UiSetting[], options?: {}): Promise<void>;
    portal_view_get(tablename: string, uid: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        ParentKey?: string;
    }): Promise<ExtendedEntityCollectionData<IClientProperty[]>>;
    /** Manages Webauthn keys for the current user. */
    portal_webauthnkey_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<ExtendedEntityCollectionData<WebauthnConfig>>;
    /** Manages Webauthn keys for the current user. */
    portal_webauthnkey_put(inputParameterName: EntityWriteData, options?: {}): Promise<ExtendedEntityCollectionData<WebauthnConfig>>;
    /** Manages Webauthn keys for the current user. */
    portal_webauthnkey_delete(UID_QERWebAuthnKey: string, options?: {}): Promise<ExtendedEntityCollectionData<WebauthnConfig>>;
    /** Manages Webauthn keys for the current user. */
    portal_webauthnkey_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    portal_workflow_get(uidpwo: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
}
