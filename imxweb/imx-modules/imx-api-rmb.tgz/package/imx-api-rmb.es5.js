import { ValType, DisplayColumns, WriteExtTypedEntity, TypedEntity, EntityState, TypedEntityBuilder, InteractiveTypedEntityBuilder, TimeZoneInfo, DisplayPattern, FkCandidateBuilder, MethodDefinition } from 'imx-qbm-dbts';

var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
/** Represents the state of an action execution. */
var ActionState;
(function (ActionState) {
    ActionState[ActionState["NotExecuted"] = 0] = "NotExecuted";
    ActionState[ActionState["Succeeded"] = 1] = "Succeeded";
    ActionState[ActionState["RolledBack"] = 2] = "RolledBack";
    ActionState[ActionState["Failed"] = 3] = "Failed";
})(ActionState || (ActionState = {}));
var RoleSplitItemType;
(function (RoleSplitItemType) {
    RoleSplitItemType[RoleSplitItemType["Keep"] = 0] = "Keep";
    RoleSplitItemType[RoleSplitItemType["Copy"] = 1] = "Copy";
    RoleSplitItemType[RoleSplitItemType["Move"] = 2] = "Move";
})(RoleSplitItemType || (RoleSplitItemType = {}));
var TypedClient = /** @class */ (function () {
    function TypedClient(client, translationProvider) {
        this.PortalAdminRoleOrg = new PortalAdminRoleOrgWrapper(client, translationProvider);
        this.PortalAdminRoleOrgInteractive = new PortalAdminRoleOrgInteractiveWrapper(client, translationProvider);
        this.PortalCandidatesOrg = new PortalCandidatesOrgWrapper(client, translationProvider);
        this.PortalCandidatesPersoninorg = new PortalCandidatesPersoninorgWrapper(client, translationProvider);
        this.PortalPersonRolemembershipsOrg = new PortalPersonRolemembershipsOrgWrapper(client, translationProvider);
        this.PortalRespOrg = new PortalRespOrgWrapper(client, translationProvider);
        this.PortalRespOrgInteractive = new PortalRespOrgInteractiveWrapper(client, translationProvider);
        this.PortalRolesConfigOrgPrimarymembers = new PortalRolesConfigOrgPrimarymembersWrapper(client, translationProvider);
    }
    return TypedClient;
}());
var PortalAdminRoleOrg = /** @class */ (function (_super) {
    __extends(PortalAdminRoleOrg, _super);
    function PortalAdminRoleOrg() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.RiskIndexCalculated = _this.GetEntityValue('RiskIndexCalculated');
        _this.UID_OrgRoot = _this.GetEntityValue('UID_OrgRoot');
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_DynamicGroup = _this.GetEntityValue('UID_DynamicGroup');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    PortalAdminRoleOrg.GetEntitySchema = function () {
        var columns = {
            'RiskIndexCalculated': {
                ColumnName: 'RiskIndexCalculated',
                Type: ValType.Double,
                IsReadOnly: true,
            },
            'UID_OrgRoot': {
                ColumnName: 'UID_OrgRoot',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_DynamicGroup': {
                ColumnName: 'UID_DynamicGroup',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'Org', Columns: columns };
    };
    return PortalAdminRoleOrg;
}(WriteExtTypedEntity));
var PortalAdminRoleOrgInteractive = /** @class */ (function (_super) {
    __extends(PortalAdminRoleOrgInteractive, _super);
    function PortalAdminRoleOrgInteractive() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.RiskIndexCalculated = _this.GetEntityValue('RiskIndexCalculated');
        _this.UID_OrgRoot = _this.GetEntityValue('UID_OrgRoot');
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_DynamicGroup = _this.GetEntityValue('UID_DynamicGroup');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    PortalAdminRoleOrgInteractive.GetEntitySchema = function () {
        var columns = {
            'RiskIndexCalculated': {
                ColumnName: 'RiskIndexCalculated',
                Type: ValType.Double,
                IsReadOnly: true,
            },
            'UID_OrgRoot': {
                ColumnName: 'UID_OrgRoot',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_DynamicGroup': {
                ColumnName: 'UID_DynamicGroup',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'Org', Columns: columns };
    };
    return PortalAdminRoleOrgInteractive;
}(WriteExtTypedEntity));
var PortalCandidatesOrg = /** @class */ (function (_super) {
    __extends(PortalCandidatesOrg, _super);
    function PortalCandidatesOrg() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_Org = _this.GetEntityValue('UID_Org');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    PortalCandidatesOrg.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_Org': {
                ColumnName: 'UID_Org',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'Org', Columns: columns };
    };
    return PortalCandidatesOrg;
}(TypedEntity));
var PortalCandidatesPersoninorg = /** @class */ (function (_super) {
    __extends(PortalCandidatesPersoninorg, _super);
    function PortalCandidatesPersoninorg() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_Org = _this.GetEntityValue('UID_Org');
        _this.UID_Person = _this.GetEntityValue('UID_Person');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    PortalCandidatesPersoninorg.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_Org': {
                ColumnName: 'UID_Org',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_Person': {
                ColumnName: 'UID_Person',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'PersonInOrg', Columns: columns };
    };
    return PortalCandidatesPersoninorg;
}(TypedEntity));
var PortalPersonRolemembershipsOrg = /** @class */ (function (_super) {
    __extends(PortalPersonRolemembershipsOrg, _super);
    function PortalPersonRolemembershipsOrg() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_Person = _this.GetEntityValue('UID_Person');
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.XOrigin = _this.GetEntityValue('XOrigin');
        _this.XDateInserted = _this.GetEntityValue('XDateInserted');
        _this.UID_Org = _this.GetEntityValue('UID_Org');
        _this.RoleFullPath = _this.GetEntityValue('RoleFullPath');
        _this.UID_PersonWantsOrg = _this.GetEntityValue('UID_PersonWantsOrg');
        _this.OrderState = _this.GetEntityValue('OrderState');
        _this.IsRequestCancellable = _this.GetEntityValue('IsRequestCancellable');
        _this.ValidUntil = _this.GetEntityValue('ValidUntil');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    PortalPersonRolemembershipsOrg.GetEntitySchema = function () {
        var columns = {
            'UID_Person': {
                ColumnName: 'UID_Person',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XOrigin': {
                ColumnName: 'XOrigin',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'XDateInserted': {
                ColumnName: 'XDateInserted',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'UID_Org': {
                ColumnName: 'UID_Org',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'RoleFullPath': {
                ColumnName: 'RoleFullPath',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_PersonWantsOrg': {
                ColumnName: 'UID_PersonWantsOrg',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'OrderState': {
                ColumnName: 'OrderState',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'IsRequestCancellable': {
                ColumnName: 'IsRequestCancellable',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'ValidUntil': {
                ColumnName: 'ValidUntil',
                Type: ValType.Date,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'PersonInOrg', Columns: columns };
    };
    return PortalPersonRolemembershipsOrg;
}(TypedEntity));
var PortalRespOrg = /** @class */ (function (_super) {
    __extends(PortalRespOrg, _super);
    function PortalRespOrg() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.RiskIndexCalculated = _this.GetEntityValue('RiskIndexCalculated');
        _this.UID_DynamicGroup = _this.GetEntityValue('UID_DynamicGroup');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    PortalRespOrg.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'RiskIndexCalculated': {
                ColumnName: 'RiskIndexCalculated',
                Type: ValType.Double,
                IsReadOnly: true,
            },
            'UID_DynamicGroup': {
                ColumnName: 'UID_DynamicGroup',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'Org', Columns: columns };
    };
    return PortalRespOrg;
}(WriteExtTypedEntity));
var PortalRespOrgInteractive = /** @class */ (function (_super) {
    __extends(PortalRespOrgInteractive, _super);
    function PortalRespOrgInteractive() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.RiskIndexCalculated = _this.GetEntityValue('RiskIndexCalculated');
        _this.UID_DynamicGroup = _this.GetEntityValue('UID_DynamicGroup');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    PortalRespOrgInteractive.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'RiskIndexCalculated': {
                ColumnName: 'RiskIndexCalculated',
                Type: ValType.Double,
                IsReadOnly: true,
            },
            'UID_DynamicGroup': {
                ColumnName: 'UID_DynamicGroup',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'Org', Columns: columns };
    };
    return PortalRespOrgInteractive;
}(WriteExtTypedEntity));
var PortalRolesConfigOrgPrimarymembers = /** @class */ (function (_super) {
    __extends(PortalRolesConfigOrgPrimarymembers, _super);
    function PortalRolesConfigOrgPrimarymembers() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.DefaultEmailAddress = _this.GetEntityValue('DefaultEmailAddress');
        _this.PrimaryMemberSince = _this.GetEntityValue('PrimaryMemberSince');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    PortalRolesConfigOrgPrimarymembers.GetEntitySchema = function () {
        var columns = {
            'DefaultEmailAddress': {
                ColumnName: 'DefaultEmailAddress',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'PrimaryMemberSince': {
                ColumnName: 'PrimaryMemberSince',
                Type: ValType.Date,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'Person', Columns: columns };
    };
    return PortalRolesConfigOrgPrimarymembers;
}(TypedEntity));
var PortalAdminRoleOrgWrapper = /** @class */ (function () {
    function PortalAdminRoleOrgWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            if (entity.GetState() == EntityState.Created) {
                return _this.client.portal_admin_role_org_post(writeData);
            }
            return _this.client.portal_admin_role_org_put(writeData);
        };
    }
    PortalAdminRoleOrgWrapper.prototype.createEntity = function (initialData) {
        this.buildBuilderIfNeeded();
        return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, EntityState.Created);
    };
    /** Returns the runtime schema for this method. */
    PortalAdminRoleOrgWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/admin/role/org');
    };
    PortalAdminRoleOrgWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/admin/role/org');
            this.builder = new TypedEntityBuilder(PortalAdminRoleOrg, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalAdminRoleOrgWrapper.prototype.Get = function (parametersOptional) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_admin_role_org_get(parametersOptional)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalAdminRoleOrgWrapper.prototype.Put = function (inputParameterName) {
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_admin_role_org_put(inputParameterName.ExtendedEntityWriteData)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalAdminRoleOrgWrapper.prototype.Post = function (inputParameterName) {
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_admin_role_org_post(inputParameterName.ExtendedEntityWriteData)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalAdminRoleOrgWrapper;
}());
var PortalAdminRoleOrgInteractiveWrapper = /** @class */ (function () {
    function PortalAdminRoleOrgInteractiveWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_admin_role_org_interactive_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalAdminRoleOrgInteractiveWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/admin/role/org/interactive');
    };
    PortalAdminRoleOrgInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/admin/role/org/interactive');
            this.builder = new InteractiveTypedEntityBuilder(PortalAdminRoleOrgInteractive, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalAdminRoleOrgInteractiveWrapper.prototype.Put = function (inputParameterName) {
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_admin_role_org_interactive_put(inputParameterName.ExtendedInteractiveEntityWriteData)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalAdminRoleOrgInteractiveWrapper.prototype.Get_byid = function (UID_Org) {
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_admin_role_org_interactive_byid_get(UID_Org)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalAdminRoleOrgInteractiveWrapper.prototype.Get = function () {
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_admin_role_org_interactive_get()];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalAdminRoleOrgInteractiveWrapper;
}());
var PortalCandidatesOrgWrapper = /** @class */ (function () {
    function PortalCandidatesOrgWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCandidatesOrgWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/candidates/Org');
    };
    PortalCandidatesOrgWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/candidates/Org');
            this.builder = new TypedEntityBuilder(PortalCandidatesOrg, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCandidatesOrgWrapper.prototype.Get = function (parametersOptional) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_candidates_Org_get(parametersOptional)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCandidatesOrgWrapper;
}());
var PortalCandidatesPersoninorgWrapper = /** @class */ (function () {
    function PortalCandidatesPersoninorgWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCandidatesPersoninorgWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/candidates/PersonInOrg');
    };
    PortalCandidatesPersoninorgWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/candidates/PersonInOrg');
            this.builder = new TypedEntityBuilder(PortalCandidatesPersoninorg, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCandidatesPersoninorgWrapper.prototype.Get = function (parametersOptional) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_candidates_PersonInOrg_get(parametersOptional)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCandidatesPersoninorgWrapper;
}());
var PortalPersonRolemembershipsOrgWrapper = /** @class */ (function () {
    function PortalPersonRolemembershipsOrgWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalPersonRolemembershipsOrgWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/person/{UID_Person}/rolememberships/Org');
    };
    PortalPersonRolemembershipsOrgWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/person/{UID_Person}/rolememberships/Org');
            this.builder = new TypedEntityBuilder(PortalPersonRolemembershipsOrg, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalPersonRolemembershipsOrgWrapper.prototype.Get = function (UID_Person, parametersOptional) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_person_rolememberships_Org_get(UID_Person, parametersOptional)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalPersonRolemembershipsOrgWrapper;
}());
var PortalRespOrgWrapper = /** @class */ (function () {
    function PortalRespOrgWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalRespOrgWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/resp/org');
    };
    PortalRespOrgWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/resp/org');
            this.builder = new TypedEntityBuilder(PortalRespOrg, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalRespOrgWrapper.prototype.Get = function (parametersOptional) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_resp_org_get(parametersOptional)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalRespOrgWrapper;
}());
var PortalRespOrgInteractiveWrapper = /** @class */ (function () {
    function PortalRespOrgInteractiveWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_resp_org_interactive_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalRespOrgInteractiveWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/resp/org/interactive');
    };
    PortalRespOrgInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/resp/org/interactive');
            this.builder = new InteractiveTypedEntityBuilder(PortalRespOrgInteractive, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalRespOrgInteractiveWrapper.prototype.Put = function (inputParameterName) {
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_resp_org_interactive_put(inputParameterName.ExtendedInteractiveEntityWriteData)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalRespOrgInteractiveWrapper.prototype.Get_byid = function (UID_Org) {
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_resp_org_interactive_byid_get(UID_Org)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalRespOrgInteractiveWrapper.prototype.Get = function () {
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_resp_org_interactive_get()];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalRespOrgInteractiveWrapper;
}());
var PortalRolesConfigOrgPrimarymembersWrapper = /** @class */ (function () {
    function PortalRolesConfigOrgPrimarymembersWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalRolesConfigOrgPrimarymembersWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/roles/config/Org/{UID_Org}/primarymembers');
    };
    PortalRolesConfigOrgPrimarymembersWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/roles/config/Org/{UID_Org}/primarymembers');
            this.builder = new TypedEntityBuilder(PortalRolesConfigOrgPrimarymembers, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalRolesConfigOrgPrimarymembersWrapper.prototype.Get = function (UID_Org, parametersOptional) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_roles_config_Org_primarymembers_get(UID_Org, parametersOptional)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalRolesConfigOrgPrimarymembersWrapper;
}());
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
var ApiClientMethodFactory = /** @class */ (function () {
    function ApiClientMethodFactory() {
    }
    ApiClientMethodFactory.prototype.portal_admin_role_org_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, risk, orgroot) {
        return {
            path: '/portal/admin/role/org',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
                {
                    name: 'risk',
                    value: risk,
                    in: 'query'
                },
                {
                    name: 'orgroot',
                    value: orgroot,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_admin_role_org_put = function (inputParameterName) {
        return {
            path: '/portal/admin/role/org',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_admin_role_org_post = function (inputParameterName) {
        return {
            path: '/portal/admin/role/org',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_admin_role_org_bulk_put = function (inputParameterName) {
        return {
            path: '/portal/admin/role/org/bulk',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_admin_role_org_datamodel_get = function (filter) {
        return {
            path: '/portal/admin/role/org/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_admin_role_org_interactive_get = function () {
        return {
            path: '/portal/admin/role/org/interactive',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_admin_role_org_interactive_put = function (inputParameterName) {
        return {
            path: '/portal/admin/role/org/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_admin_role_org_interactive_byid_get = function (UID_Org) {
        return {
            path: '/portal/admin/role/org/interactive/{UID_Org}',
            parameters: [
                {
                    name: 'UID_Org',
                    value: UID_Org,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_Org_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
        return {
            path: '/portal/candidates/Org',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_Org_datamodel_get = function (filter) {
        return {
            path: '/portal/candidates/Org/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_Org_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/candidates/Org/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_PersonInOrg_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/candidates/PersonInOrg',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_PersonInOrg_datamodel_get = function (filter) {
        return {
            path: '/portal/candidates/PersonInOrg/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_PersonInOrg_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/candidates/PersonInOrg/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_person_rolememberships_Org_get = function (UID_Person, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/person/{UID_Person}/rolememberships/Org',
            parameters: [
                {
                    name: 'UID_Person',
                    value: UID_Person,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_resp_org_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, orgroot) {
        return {
            path: '/portal/resp/org',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
                {
                    name: 'orgroot',
                    value: orgroot,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_resp_org_datamodel_get = function (filter) {
        return {
            path: '/portal/resp/org/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_resp_org_interactive_get = function () {
        return {
            path: '/portal/resp/org/interactive',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_resp_org_interactive_put = function (inputParameterName) {
        return {
            path: '/portal/resp/org/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_resp_org_interactive_byid_get = function (UID_Org) {
        return {
            path: '/portal/resp/org/interactive/{UID_Org}',
            parameters: [
                {
                    name: 'UID_Org',
                    value: UID_Org,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_resp_Org_restore_get = function (backto) {
        return {
            path: '/portal/resp/Org/restore',
            parameters: [
                {
                    name: 'backto',
                    value: backto,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_resp_Org_restore_byid_get = function (backto, uid) {
        return {
            path: '/portal/resp/Org/restore/{uid}',
            parameters: [
                {
                    name: 'backto',
                    value: backto,
                    in: 'query'
                },
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_resp_Org_restore_byid_post = function (backto, uid, inputParameterName) {
        return {
            path: '/portal/resp/Org/restore/{uid}',
            parameters: [
                {
                    name: 'backto',
                    value: backto,
                    in: 'query'
                },
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_roles_config_membership_Org_get = function (UID_Org, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/roles/config/membership/Org/{UID_Org}',
            parameters: [
                {
                    name: 'UID_Org',
                    value: UID_Org,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_roles_config_membership_Org_post = function (UID_Org, inputParameterName) {
        return {
            path: '/portal/roles/config/membership/Org/{UID_Org}',
            parameters: [
                {
                    name: 'UID_Org',
                    value: UID_Org,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_roles_config_membership_Org_delete = function (UID_Org, UID_Person) {
        return {
            path: '/portal/roles/config/membership/Org/{UID_Org}/{UID_Person}',
            parameters: [
                {
                    name: 'UID_Org',
                    value: UID_Org,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_Person',
                    value: UID_Person,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_roles_config_membership_Org_UID_Person_candidates_get = function (UID_Org, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/roles/config/membership/Org/{UID_Org}/UID_Person/candidates',
            parameters: [
                {
                    name: 'UID_Org',
                    value: UID_Org,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'xorigin',
                    value: xorigin,
                    in: 'query'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_roles_config_membership_Org_UID_Person_candidates_filtertree_post = function (UID_Org, xorigin, filter, parentkey, inputParameterName) {
        return {
            path: '/portal/roles/config/membership/Org/{UID_Org}/UID_Person/candidates/filtertree',
            parameters: [
                {
                    name: 'UID_Org',
                    value: UID_Org,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'xorigin',
                    value: xorigin,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_roles_config_Org_primarymembers_get = function (UID_Org, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/roles/config/Org/{UID_Org}/primarymembers',
            parameters: [
                {
                    name: 'UID_Org',
                    value: UID_Org,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_roles_Org_restore_get = function (backto) {
        return {
            path: '/portal/roles/Org/restore',
            parameters: [
                {
                    name: 'backto',
                    value: backto,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_roles_Org_restore_byid_get = function (backto, uid) {
        return {
            path: '/portal/roles/Org/restore/{uid}',
            parameters: [
                {
                    name: 'backto',
                    value: backto,
                    in: 'query'
                },
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_roles_Org_restore_byid_post = function (backto, uid, inputParameterName) {
        return {
            path: '/portal/roles/Org/restore/{uid}',
            parameters: [
                {
                    name: 'backto',
                    value: backto,
                    in: 'query'
                },
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    return ApiClientMethodFactory;
}());
/** @deprecated Use the V2Client class for a stable method interface. */
var Client = /** @class */ (function () {
    function Client(apiClient, schemaProvider) {
        this.apiClient = apiClient;
        this.schemaProvider = schemaProvider;
        this.methodFactory = new ApiClientMethodFactory();
        if (!apiClient) {
            throw new Error("The value for the apiClient parameter is undefined.");
        }
    }
    Object.defineProperty(Client.prototype, "schemas", {
        get: function () {
            if (!this.schemaProvider) {
                throw new Error("The schema has not been loaded.");
            }
            return this.schemaProvider.schemas;
        },
        enumerable: false,
        configurable: true
    });
    Client.prototype.loadSchema = function (language) {
        return __awaiter(this, void 0, void 0, function () {
            var headers, dtos, schemas, key, dto, columns;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        headers = {};
                        if (language)
                            headers['Accept-Language'] = language;
                        return [4 /*yield*/, this.apiClient.processRequest({
                                path: '/imx/entityschema',
                                parameters: [],
                                method: 'GET',
                                headers: headers,
                                credentials: 'include',
                                observe: 'response',
                                responseType: 'json'
                            })];
                    case 1:
                        dtos = _a.sent();
                        schemas = {};
                        for (key in dtos) {
                            dto = dtos[key];
                            columns = dto.Properties;
                            columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
                            columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
                            schemas[key] = {
                                TypeName: dto.TypeName,
                                DisplayPattern: new DisplayPattern(dto.DisplayPattern),
                                Display: dto.Display,
                                DisplaySingular: dto.DisplaySingular,
                                FkCandidateRoutes: dto.FkCandidateRoutes,
                                Columns: columns
                            };
                        }
                        this.schemaProvider = { schemas: schemas };
                        return [2 /*return*/];
                }
            });
        });
    };
    Client.prototype.getFkProviderItems = function (methodKey) {
        var _a;
        return new FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
    };
    /** Returns the runtime schema for the named method. */
    Client.prototype.getSchema = function (methodKey) {
        var result = this.schemas[methodKey];
        if (!result)
            throw new Error('Unknown method: ' + methodKey);
        return result;
    };
    Client.prototype.portal_admin_role_org_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, risk, orgroot) {
        return this.apiClient.processRequest(this.methodFactory.portal_admin_role_org_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, risk, orgroot));
    };
    Client.prototype.portal_admin_role_org_put = function (inputParameterName) {
        return this.apiClient.processRequest(this.methodFactory.portal_admin_role_org_put(inputParameterName));
    };
    Client.prototype.portal_admin_role_org_post = function (inputParameterName) {
        return this.apiClient.processRequest(this.methodFactory.portal_admin_role_org_post(inputParameterName));
    };
    Client.prototype.portal_admin_role_org_bulk_put = function (inputParameterName) {
        return this.apiClient.processRequest(this.methodFactory.portal_admin_role_org_bulk_put(inputParameterName));
    };
    /** Returns data model information about query options for the admin/role/org endpoint. */
    Client.prototype.portal_admin_role_org_datamodel_get = function (filter) {
        return this.apiClient.processRequest(this.methodFactory.portal_admin_role_org_datamodel_get(filter));
    };
    Client.prototype.portal_admin_role_org_interactive_get = function () {
        return this.apiClient.processRequest(this.methodFactory.portal_admin_role_org_interactive_get());
    };
    Client.prototype.portal_admin_role_org_interactive_put = function (inputParameterName) {
        return this.apiClient.processRequest(this.methodFactory.portal_admin_role_org_interactive_put(inputParameterName));
    };
    Client.prototype.portal_admin_role_org_interactive_byid_get = function (UID_Org) {
        return this.apiClient.processRequest(this.methodFactory.portal_admin_role_org_interactive_byid_get(UID_Org));
    };
    /** Returns a list of candidate objects from the table Org. */
    Client.prototype.portal_candidates_Org_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_Org_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey));
    };
    /** Returns data model information about query options for the candidates/Org endpoint. */
    Client.prototype.portal_candidates_Org_datamodel_get = function (filter) {
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_Org_datamodel_get(filter));
    };
    /** Returns filter tree information for the candidates/Org endpoint. */
    Client.prototype.portal_candidates_Org_filtertree_post = function (filter, parentkey, inputParameterName) {
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_Org_filtertree_post(filter, parentkey, inputParameterName));
    };
    /** Returns a list of candidate objects from the table PersonInOrg. */
    Client.prototype.portal_candidates_PersonInOrg_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_PersonInOrg_get(OrderBy, StartIndex, PageSize, filter, withProperties, search));
    };
    /** Returns data model information about query options for the candidates/PersonInOrg endpoint. */
    Client.prototype.portal_candidates_PersonInOrg_datamodel_get = function (filter) {
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_PersonInOrg_datamodel_get(filter));
    };
    /** Returns filter tree information for the candidates/PersonInOrg endpoint. */
    Client.prototype.portal_candidates_PersonInOrg_filtertree_post = function (filter, parentkey, inputParameterName) {
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_PersonInOrg_filtertree_post(filter, parentkey, inputParameterName));
    };
    Client.prototype.portal_person_rolememberships_Org_get = function (UID_Person, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return this.apiClient.processRequest(this.methodFactory.portal_person_rolememberships_Org_get(UID_Person, OrderBy, StartIndex, PageSize, filter, withProperties, search));
    };
    Client.prototype.portal_resp_org_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, orgroot) {
        return this.apiClient.processRequest(this.methodFactory.portal_resp_org_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, orgroot));
    };
    /** Returns data model information about query options for the resp/org endpoint. */
    Client.prototype.portal_resp_org_datamodel_get = function (filter) {
        return this.apiClient.processRequest(this.methodFactory.portal_resp_org_datamodel_get(filter));
    };
    Client.prototype.portal_resp_org_interactive_get = function () {
        return this.apiClient.processRequest(this.methodFactory.portal_resp_org_interactive_get());
    };
    Client.prototype.portal_resp_org_interactive_put = function (inputParameterName) {
        return this.apiClient.processRequest(this.methodFactory.portal_resp_org_interactive_put(inputParameterName));
    };
    Client.prototype.portal_resp_org_interactive_byid_get = function (UID_Org) {
        return this.apiClient.processRequest(this.methodFactory.portal_resp_org_interactive_byid_get(UID_Org));
    };
    Client.prototype.portal_resp_Org_restore_get = function (backto) {
        return this.apiClient.processRequest(this.methodFactory.portal_resp_Org_restore_get(backto));
    };
    Client.prototype.portal_resp_Org_restore_byid_get = function (backto, uid) {
        return this.apiClient.processRequest(this.methodFactory.portal_resp_Org_restore_byid_get(backto, uid));
    };
    Client.prototype.portal_resp_Org_restore_byid_post = function (backto, uid, inputParameterName) {
        return this.apiClient.processRequest(this.methodFactory.portal_resp_Org_restore_byid_post(backto, uid, inputParameterName));
    };
    Client.prototype.portal_roles_config_membership_Org_get = function (UID_Org, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return this.apiClient.processRequest(this.methodFactory.portal_roles_config_membership_Org_get(UID_Org, OrderBy, StartIndex, PageSize, filter, withProperties, search));
    };
    Client.prototype.portal_roles_config_membership_Org_post = function (UID_Org, inputParameterName) {
        return this.apiClient.processRequest(this.methodFactory.portal_roles_config_membership_Org_post(UID_Org, inputParameterName));
    };
    Client.prototype.portal_roles_config_membership_Org_delete = function (UID_Org, UID_Person) {
        return this.apiClient.processRequest(this.methodFactory.portal_roles_config_membership_Org_delete(UID_Org, UID_Person));
    };
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    Client.prototype.portal_roles_config_membership_Org_UID_Person_candidates_get = function (UID_Org, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return this.apiClient.processRequest(this.methodFactory.portal_roles_config_membership_Org_UID_Person_candidates_get(UID_Org, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search));
    };
    /** Returns filter tree information for the roles/config/membership/Org/{UID_Org}/UID_Person/candidates endpoint. */
    Client.prototype.portal_roles_config_membership_Org_UID_Person_candidates_filtertree_post = function (UID_Org, xorigin, filter, parentkey, inputParameterName) {
        return this.apiClient.processRequest(this.methodFactory.portal_roles_config_membership_Org_UID_Person_candidates_filtertree_post(UID_Org, xorigin, filter, parentkey, inputParameterName));
    };
    /** Returns identities who are primary members of a role. */
    Client.prototype.portal_roles_config_Org_primarymembers_get = function (UID_Org, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return this.apiClient.processRequest(this.methodFactory.portal_roles_config_Org_primarymembers_get(UID_Org, OrderBy, StartIndex, PageSize, filter, withProperties, search));
    };
    Client.prototype.portal_roles_Org_restore_get = function (backto) {
        return this.apiClient.processRequest(this.methodFactory.portal_roles_Org_restore_get(backto));
    };
    Client.prototype.portal_roles_Org_restore_byid_get = function (backto, uid) {
        return this.apiClient.processRequest(this.methodFactory.portal_roles_Org_restore_byid_get(backto, uid));
    };
    Client.prototype.portal_roles_Org_restore_byid_post = function (backto, uid, inputParameterName) {
        return this.apiClient.processRequest(this.methodFactory.portal_roles_Org_restore_byid_post(backto, uid, inputParameterName));
    };
    return Client;
}());
var V2ApiClientMethodFactory = /** @class */ (function () {
    function V2ApiClientMethodFactory() {
    }
    V2ApiClientMethodFactory.prototype.portal_admin_role_org_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/admin/role/org',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_admin_role_org_put = function (inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/admin/role/org',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_admin_role_org_post = function (inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/admin/role/org',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_admin_role_org_bulk_put = function (inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/admin/role/org/bulk',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_admin_role_org_datamodel_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/admin/role/org/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_admin_role_org_interactive_get = function (options) {
        return {
            path: '/portal/admin/role/org/interactive',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_admin_role_org_interactive_put = function (inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/admin/role/org/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_admin_role_org_interactive_byid_get = function (UID_Org, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/admin/role/org/interactive/{UID_Org}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_Org',
                    value: UID_Org,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_Org_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/Org',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_Org_datamodel_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/Org/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_Org_filtertree_post = function (inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/Org/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_PersonInOrg_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/PersonInOrg',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_PersonInOrg_datamodel_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/PersonInOrg/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_PersonInOrg_filtertree_post = function (inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/PersonInOrg/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_person_rolememberships_Org_get = function (UID_Person, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/person/{UID_Person}/rolememberships/Org',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_Person',
                    value: UID_Person,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_resp_org_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/resp/org',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_resp_org_datamodel_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/resp/org/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_resp_org_interactive_get = function (options) {
        return {
            path: '/portal/resp/org/interactive',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_resp_org_interactive_put = function (inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/resp/org/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_resp_org_interactive_byid_get = function (UID_Org, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/resp/org/interactive/{UID_Org}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_Org',
                    value: UID_Org,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_resp_Org_restore_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/resp/Org/restore',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_resp_Org_restore_byid_get = function (uid, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/resp/Org/restore/{uid}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_resp_Org_restore_byid_post = function (uid, inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/resp/Org/restore/{uid}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_roles_config_membership_Org_get = function (UID_Org, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/roles/config/membership/Org/{UID_Org}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_Org',
                    value: UID_Org,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_roles_config_membership_Org_post = function (UID_Org, inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/roles/config/membership/Org/{UID_Org}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_Org',
                    value: UID_Org,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_roles_config_membership_Org_delete = function (UID_Org, UID_Person, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/roles/config/membership/Org/{UID_Org}/{UID_Person}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_Org',
                    value: UID_Org,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_Person',
                    value: UID_Person,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_roles_config_membership_Org_UID_Person_candidates_get = function (UID_Org, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/roles/config/membership/Org/{UID_Org}/UID_Person/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_Org',
                    value: UID_Org,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_roles_config_membership_Org_UID_Person_candidates_filtertree_post = function (UID_Org, inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/roles/config/membership/Org/{UID_Org}/UID_Person/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_Org',
                    value: UID_Org,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_roles_config_Org_primarymembers_get = function (UID_Org, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/roles/config/Org/{UID_Org}/primarymembers',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_Org',
                    value: UID_Org,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_roles_Org_restore_get = function (options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/roles/Org/restore',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_roles_Org_restore_byid_get = function (uid, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/roles/Org/restore/{uid}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_roles_Org_restore_byid_post = function (uid, inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/roles/Org/restore/{uid}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    return V2ApiClientMethodFactory;
}());
var V2Client = /** @class */ (function () {
    function V2Client(apiClient, schemaProvider) {
        this.apiClient = apiClient;
        this.schemaProvider = schemaProvider;
        this.methodFactory = new V2ApiClientMethodFactory();
        if (!apiClient) {
            throw new Error("The value for the apiClient parameter is undefined.");
        }
    }
    Object.defineProperty(V2Client.prototype, "schemas", {
        get: function () {
            if (!this.schemaProvider) {
                throw new Error("The schema has not been loaded.");
            }
            return this.schemaProvider.schemas;
        },
        enumerable: false,
        configurable: true
    });
    V2Client.prototype.loadSchema = function (language) {
        return __awaiter(this, void 0, void 0, function () {
            var headers, dtos, schemas, key, dto, columns;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        headers = {};
                        if (language)
                            headers['Accept-Language'] = language;
                        return [4 /*yield*/, this.apiClient.processRequest({
                                path: '/imx/entityschema',
                                parameters: [],
                                method: 'GET',
                                headers: headers,
                                credentials: 'include',
                                observe: 'response',
                                responseType: 'json'
                            })];
                    case 1:
                        dtos = _a.sent();
                        schemas = {};
                        for (key in dtos) {
                            dto = dtos[key];
                            columns = dto.Properties;
                            columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
                            columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
                            schemas[key] = {
                                TypeName: dto.TypeName,
                                DisplayPattern: new DisplayPattern(dto.DisplayPattern),
                                Display: dto.Display,
                                DisplaySingular: dto.DisplaySingular,
                                FkCandidateRoutes: dto.FkCandidateRoutes,
                                Columns: columns
                            };
                        }
                        this.schemaProvider = { schemas: schemas };
                        return [2 /*return*/];
                }
            });
        });
    };
    V2Client.prototype.getFkProviderItems = function (methodKey) {
        var _a;
        return new FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
    };
    /** Returns the runtime schema for the named method. */
    V2Client.prototype.getSchema = function (methodKey) {
        var result = this.schemas[methodKey];
        if (!result)
            throw new Error('Unknown method: ' + methodKey);
        return result;
    };
    V2Client.prototype.portal_admin_role_org_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_admin_role_org_get(options));
    };
    V2Client.prototype.portal_admin_role_org_put = function (inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_admin_role_org_put(inputParameterName, options));
    };
    V2Client.prototype.portal_admin_role_org_post = function (inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_admin_role_org_post(inputParameterName, options));
    };
    V2Client.prototype.portal_admin_role_org_bulk_put = function (inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_admin_role_org_bulk_put(inputParameterName, options));
    };
    /** Returns data model information about query options for the admin/role/org endpoint. */
    V2Client.prototype.portal_admin_role_org_datamodel_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_admin_role_org_datamodel_get(options));
    };
    V2Client.prototype.portal_admin_role_org_interactive_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_admin_role_org_interactive_get(options));
    };
    V2Client.prototype.portal_admin_role_org_interactive_put = function (inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_admin_role_org_interactive_put(inputParameterName, options));
    };
    V2Client.prototype.portal_admin_role_org_interactive_byid_get = function (UID_Org, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_admin_role_org_interactive_byid_get(UID_Org, options));
    };
    /** Returns a list of candidate objects from the table Org. */
    V2Client.prototype.portal_candidates_Org_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_Org_get(options));
    };
    /** Returns data model information about query options for the candidates/Org endpoint. */
    V2Client.prototype.portal_candidates_Org_datamodel_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_Org_datamodel_get(options));
    };
    /** Returns filter tree information for the candidates/Org endpoint. */
    V2Client.prototype.portal_candidates_Org_filtertree_post = function (inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_Org_filtertree_post(inputParameterName, options));
    };
    /** Returns a list of candidate objects from the table PersonInOrg. */
    V2Client.prototype.portal_candidates_PersonInOrg_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_PersonInOrg_get(options));
    };
    /** Returns data model information about query options for the candidates/PersonInOrg endpoint. */
    V2Client.prototype.portal_candidates_PersonInOrg_datamodel_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_PersonInOrg_datamodel_get(options));
    };
    /** Returns filter tree information for the candidates/PersonInOrg endpoint. */
    V2Client.prototype.portal_candidates_PersonInOrg_filtertree_post = function (inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_PersonInOrg_filtertree_post(inputParameterName, options));
    };
    V2Client.prototype.portal_person_rolememberships_Org_get = function (UID_Person, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_person_rolememberships_Org_get(UID_Person, options));
    };
    V2Client.prototype.portal_resp_org_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resp_org_get(options));
    };
    /** Returns data model information about query options for the resp/org endpoint. */
    V2Client.prototype.portal_resp_org_datamodel_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resp_org_datamodel_get(options));
    };
    V2Client.prototype.portal_resp_org_interactive_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resp_org_interactive_get(options));
    };
    V2Client.prototype.portal_resp_org_interactive_put = function (inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resp_org_interactive_put(inputParameterName, options));
    };
    V2Client.prototype.portal_resp_org_interactive_byid_get = function (UID_Org, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resp_org_interactive_byid_get(UID_Org, options));
    };
    V2Client.prototype.portal_resp_Org_restore_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resp_Org_restore_get(options));
    };
    V2Client.prototype.portal_resp_Org_restore_byid_get = function (uid, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resp_Org_restore_byid_get(uid, options));
    };
    V2Client.prototype.portal_resp_Org_restore_byid_post = function (uid, inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resp_Org_restore_byid_post(uid, inputParameterName, options));
    };
    V2Client.prototype.portal_roles_config_membership_Org_get = function (UID_Org, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_roles_config_membership_Org_get(UID_Org, options));
    };
    V2Client.prototype.portal_roles_config_membership_Org_post = function (UID_Org, inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_roles_config_membership_Org_post(UID_Org, inputParameterName, options));
    };
    V2Client.prototype.portal_roles_config_membership_Org_delete = function (UID_Org, UID_Person, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_roles_config_membership_Org_delete(UID_Org, UID_Person, options));
    };
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    V2Client.prototype.portal_roles_config_membership_Org_UID_Person_candidates_get = function (UID_Org, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_roles_config_membership_Org_UID_Person_candidates_get(UID_Org, options));
    };
    /** Returns filter tree information for the roles/config/membership/Org/{UID_Org}/UID_Person/candidates endpoint. */
    V2Client.prototype.portal_roles_config_membership_Org_UID_Person_candidates_filtertree_post = function (UID_Org, inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_roles_config_membership_Org_UID_Person_candidates_filtertree_post(UID_Org, inputParameterName, options));
    };
    /** Returns identities who are primary members of a role. */
    V2Client.prototype.portal_roles_config_Org_primarymembers_get = function (UID_Org, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_roles_config_Org_primarymembers_get(UID_Org, options));
    };
    V2Client.prototype.portal_roles_Org_restore_get = function (options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_roles_Org_restore_get(options));
    };
    V2Client.prototype.portal_roles_Org_restore_byid_get = function (uid, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_roles_Org_restore_byid_get(uid, options));
    };
    V2Client.prototype.portal_roles_Org_restore_byid_post = function (uid, inputParameterName, options) {
        if (options === void 0) { options = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_roles_Org_restore_byid_post(uid, inputParameterName, options));
    };
    return V2Client;
}());

export { ActionState, ApiClientMethodFactory, Client, PortalAdminRoleOrg, PortalAdminRoleOrgInteractive, PortalAdminRoleOrgInteractiveWrapper, PortalAdminRoleOrgWrapper, PortalCandidatesOrg, PortalCandidatesOrgWrapper, PortalCandidatesPersoninorg, PortalCandidatesPersoninorgWrapper, PortalPersonRolemembershipsOrg, PortalPersonRolemembershipsOrgWrapper, PortalRespOrg, PortalRespOrgInteractive, PortalRespOrgInteractiveWrapper, PortalRespOrgWrapper, PortalRolesConfigOrgPrimarymembers, PortalRolesConfigOrgPrimarymembersWrapper, RoleSplitItemType, TypedClient, V2ApiClientMethodFactory, V2Client };
