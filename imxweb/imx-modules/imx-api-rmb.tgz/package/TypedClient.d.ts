import { ApiClient, ApiRequestOptions, DataModel, EntityCollectionData, EntityData, EntitySchema, EntityWriteData, EntityWriteDataColumn, EntityWriteDataSingle, ExtendedEntityWriteData, FilterData, FilterTreeData, FkProviderItem, InteractiveEntityData, InteractiveEntityWriteData, IReadValue, MethodDescriptor, SqlExpression, StaticSchema, TypedEntity, WriteExtTypedEntity } from 'imx-qbm-dbts';
/** Represents the state of an action execution. */
export declare enum ActionState {
    NotExecuted = 0,
    Succeeded = 1,
    RolledBack = 2,
    Failed = 3
}
/** Holds information about a deleted object. */
export interface DeletedObjectInfo {
    /** Gets or sets the object key of the deleted object. */
    DbObjectKey?: string;
    /** Gets or sets the name of the user who deleted the object. */
    DeletedBy?: string;
    /** Gets or sets the display name of the object at the time of its deletion. */
    Display?: string;
    /** Gets or sets the date of deletion. */
    DeletionDate: Date;
    /** Gets or sets detailed information about the deletion operation. */
    ChangeInfo?: IObjectChangeInfo;
}
export interface EntityWriteDataBulk {
    Keys?: string[][];
    Data?: EntityWriteDataColumn[];
}
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface ExtendedEntityWriteDataOfRoleExtendedDataWrite extends EntityWriteData {
    ExtendedData?: RoleExtendedDataWrite;
}
export interface ExtendedInteractiveEntityWriteDataOfRoleExtendedDataWrite extends InteractiveEntityWriteData {
    ExtendedData?: RoleExtendedDataWrite;
}
export interface IObjectChangeInfo {
    Id: string;
    ObjectKey: any;
    ChangeTime: any;
    User: string;
    ChangeType: any;
    ProcessId: string;
    Changes: any;
}
export declare enum RecommendationType {
    Add = 0,
    Remove = 1
}
export interface RestoreActionList {
    ActionId?: string[];
}
export interface RestoreActions {
    Actions?: UiActionData[];
}
export interface RoleExtendedDataWrite {
    NewDynamicRole?: SqlExpression;
    RoleSplit?: RoleSplitActionInput;
}
export interface RoleRecommendationItem {
    Type: RecommendationType;
    Display?: string;
    ObjectTypeDisplay?: string;
    ObjectKey?: string;
    Reason?: string;
}
export interface RoleRecommendationResult {
    Items?: RoleRecommendationItem[];
}
export interface RoleSplitActionInput extends RoleSplitInput {
    SourceRoleObjectKey?: string;
    ActionIds?: string[];
}
export interface RoleSplitInput {
    SplitItems?: RoleSplitInputItem[];
}
export interface RoleSplitInputItem {
    Item?: string;
    Type: RoleSplitItemType;
}
export declare enum RoleSplitItemType {
    Keep = 0,
    Copy = 1,
    Move = 2
}
export interface TeamRoleData {
    Uid?: string;
    Display?: string;
}
export interface UiActionData {
    Id?: string;
    IsActive: boolean;
    CanExecute: boolean;
    Display?: string;
    ObjectDisplay?: string;
}
export interface UiActionResultData {
    Display?: string;
    ObjectDisplay?: string;
    Exceptions?: ExceptionData[];
    State: ActionState;
}
export declare class TypedClient {
    readonly PortalAdminRoleOrg: PortalAdminRoleOrgWrapper;
    readonly PortalAdminRoleOrgInteractive: PortalAdminRoleOrgInteractiveWrapper;
    readonly PortalCandidatesOrg: PortalCandidatesOrgWrapper;
    readonly PortalCandidatesPersoninorg: PortalCandidatesPersoninorgWrapper;
    readonly PortalPersonRolemembershipsOrg: PortalPersonRolemembershipsOrgWrapper;
    readonly PortalRespOrg: PortalRespOrgWrapper;
    readonly PortalRespOrgInteractive: PortalRespOrgInteractiveWrapper;
    readonly PortalRolesConfigOrgPrimarymembers: PortalRolesConfigOrgPrimarymembersWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalAdminRoleOrg extends WriteExtTypedEntity<RoleExtendedDataWrite> {
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly UID_OrgRoot: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly UID_DynamicGroup: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'RiskIndexCalculated' | 'UID_OrgRoot' | 'XObjectKey' | 'UID_DynamicGroup'>;
}
/** @deprecated Use the PortalAdminRoleOrg type. */
export declare class PortalAdminRoleOrgInteractive extends PortalAdminRoleOrg {
}
export declare class PortalCandidatesOrg extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_Org: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_Org'>;
}
/** @deprecated Use the PortalCandidatesOrg type. */
export declare class PortalCandidatesOrgInteractive extends PortalCandidatesOrg {
}
export declare class PortalCandidatesPersoninorg extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_Org: IReadValue<string>;
    readonly UID_Person: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_Org' | 'UID_Person'>;
}
/** @deprecated Use the PortalCandidatesPersoninorg type. */
export declare class PortalCandidatesPersoninorgInteractive extends PortalCandidatesPersoninorg {
}
export declare class PortalPersonRolemembershipsOrg extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly UID_Org: IReadValue<string>;
    readonly RoleFullPath: IReadValue<string>;
    readonly UID_PersonWantsOrg: IReadValue<string>;
    readonly OrderState: IReadValue<string>;
    readonly IsRequestCancellable: IReadValue<boolean>;
    readonly ValidUntil: IReadValue<Date>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'XObjectKey' | 'XOrigin' | 'XDateInserted' | 'UID_Org' | 'RoleFullPath' | 'UID_PersonWantsOrg' | 'OrderState' | 'IsRequestCancellable' | 'ValidUntil'>;
}
/** @deprecated Use the PortalPersonRolemembershipsOrg type. */
export declare class PortalPersonRolemembershipsOrgInteractive extends PortalPersonRolemembershipsOrg {
}
export declare class PortalRespOrg extends WriteExtTypedEntity<RoleExtendedDataWrite> {
    readonly XObjectKey: IReadValue<string>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly UID_DynamicGroup: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'RiskIndexCalculated' | 'UID_DynamicGroup'>;
}
/** @deprecated Use the PortalRespOrg type. */
export declare class PortalRespOrgInteractive extends PortalRespOrg {
}
export declare class PortalRolesConfigOrgPrimarymembers extends TypedEntity {
    readonly DefaultEmailAddress: IReadValue<string>;
    readonly PrimaryMemberSince: IReadValue<Date>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'DefaultEmailAddress' | 'PrimaryMemberSince'>;
}
/** @deprecated Use the PortalRolesConfigOrgPrimarymembers type. */
export declare class PortalRolesConfigOrgPrimarymembersInteractive extends PortalRolesConfigOrgPrimarymembers {
}
export declare class PortalAdminRoleOrgWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalAdminRoleOrg;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_admin_role_org_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleOrg, unknown>>;
    Put(inputParameterName: PortalAdminRoleOrg, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleOrg, unknown>>;
    Post(inputParameterName: PortalAdminRoleOrg, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleOrg, unknown>>;
}
export declare class PortalAdminRoleOrgInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalAdminRoleOrg, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleOrg, unknown>>;
    Get_byid(UID_Org: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleOrg, unknown>>;
    Get(parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAdminRoleOrg, unknown>>;
}
export declare class PortalCandidatesOrgWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_Org_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesOrg, unknown>>;
}
export declare class PortalCandidatesPersoninorgWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_PersonInOrg_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesPersoninorg, unknown>>;
}
export declare class PortalPersonRolemembershipsOrgWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_Person: string, parametersOptional?: portal_person_rolememberships_Org_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonRolemembershipsOrg, unknown>>;
}
export declare class PortalRespOrgWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_resp_org_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespOrg, unknown>>;
}
export declare class PortalRespOrgInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalRespOrg, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespOrg, unknown>>;
    Get_byid(UID_Org: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespOrg, unknown>>;
    Get(parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespOrg, unknown>>;
}
export declare class PortalRolesConfigOrgPrimarymembersWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_Org: string, parametersOptional?: portal_roles_config_Org_primarymembers_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRolesConfigOrgPrimarymembers, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    portal_admin_role_org_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, risk: string, orgroot: string): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_org_put(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_org_post(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_org_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_admin_role_org_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_admin_role_org_interactive_get(): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_org_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_org_interactive_byid_get(UID_Org: string): MethodDescriptor<InteractiveEntityData>;
    portal_candidates_Org_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Org_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_Org_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_PersonInOrg_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_PersonInOrg_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_candidates_PersonInOrg_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_person_rolememberships_Org_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_resp_org_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, orgroot: string): MethodDescriptor<EntityCollectionData>;
    portal_resp_org_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_resp_org_interactive_get(): MethodDescriptor<InteractiveEntityData>;
    portal_resp_org_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_resp_org_interactive_byid_get(UID_Org: string): MethodDescriptor<InteractiveEntityData>;
    portal_resp_Org_restore_get(backto: Date): MethodDescriptor<DeletedObjectInfo[]>;
    portal_resp_Org_restore_byid_get(backto: Date, uid: string): MethodDescriptor<RestoreActions>;
    portal_resp_Org_restore_byid_post(backto: Date, uid: string, inputParameterName: RestoreActionList): MethodDescriptor<UiActionResultData[]>;
    portal_resp_team_teamrole_get(): MethodDescriptor<TeamRoleData>;
    portal_resp_team_teamrole_post(): MethodDescriptor<EntityCollectionData>;
    portal_resp_team_teamrole_recommendations_get(): MethodDescriptor<RoleRecommendationResult>;
    portal_roles_config_membership_Org_get(UID_Org: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Org_post(UID_Org: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Org_delete(UID_Org: string, UID_Person: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Org_UID_Person_candidates_get(UID_Org: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Org_UID_Person_candidates_filtertree_post(UID_Org: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_roles_config_Org_primarymembers_get(UID_Org: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_Org_restore_get(backto: Date): MethodDescriptor<DeletedObjectInfo[]>;
    portal_roles_Org_restore_byid_get(backto: Date, uid: string): MethodDescriptor<RestoreActions>;
    portal_roles_Org_restore_byid_post(backto: Date, uid: string, inputParameterName: RestoreActionList): MethodDescriptor<UiActionResultData[]>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_admin_role_org_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, risk: string, orgroot: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_admin_role_org_put(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_admin_role_org_post(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_admin_role_org_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the admin/role/org endpoint. */
    portal_admin_role_org_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_admin_role_org_interactive_get(requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_admin_role_org_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_admin_role_org_interactive_byid_get(UID_Org: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    /** Returns a list of candidate objects from the table Org. */
    portal_candidates_Org_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/Org endpoint. */
    portal_candidates_Org_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the candidates/Org endpoint. */
    portal_candidates_Org_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table PersonInOrg. */
    portal_candidates_PersonInOrg_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/PersonInOrg endpoint. */
    portal_candidates_PersonInOrg_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the candidates/PersonInOrg endpoint. */
    portal_candidates_PersonInOrg_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_person_rolememberships_Org_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_resp_org_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, orgroot: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/org endpoint. */
    portal_resp_org_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_resp_org_interactive_get(requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_org_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_org_interactive_byid_get(UID_Org: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_Org_restore_get(backto: Date, requestOptions?: ApiRequestOptions): Promise<DeletedObjectInfo[]>;
    portal_resp_Org_restore_byid_get(backto: Date, uid: string, requestOptions?: ApiRequestOptions): Promise<RestoreActions>;
    portal_resp_Org_restore_byid_post(backto: Date, uid: string, inputParameterName: RestoreActionList, requestOptions?: ApiRequestOptions): Promise<UiActionResultData[]>;
    /** Returns information about the existing team role for the current user, if any. */
    portal_resp_team_teamrole_get(requestOptions?: ApiRequestOptions): Promise<TeamRoleData>;
    /** Creates a new team role for the current user. This call will fail if a team role already exists. */
    portal_resp_team_teamrole_post(requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns recommendations for entitlement additions for a team role. */
    portal_resp_team_teamrole_recommendations_get(requestOptions?: ApiRequestOptions): Promise<RoleRecommendationResult>;
    portal_roles_config_membership_Org_get(UID_Org: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_config_membership_Org_post(UID_Org: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_config_membership_Org_delete(UID_Org: string, UID_Person: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    portal_roles_config_membership_Org_UID_Person_candidates_get(UID_Org: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the roles/config/membership/Org/{UID_Org}/UID_Person/candidates endpoint. */
    portal_roles_config_membership_Org_UID_Person_candidates_filtertree_post(UID_Org: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns identities who are primary members of a role. */
    portal_roles_config_Org_primarymembers_get(UID_Org: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_Org_restore_get(backto: Date, requestOptions?: ApiRequestOptions): Promise<DeletedObjectInfo[]>;
    portal_roles_Org_restore_byid_get(backto: Date, uid: string, requestOptions?: ApiRequestOptions): Promise<RestoreActions>;
    portal_roles_Org_restore_byid_post(backto: Date, uid: string, inputParameterName: RestoreActionList, requestOptions?: ApiRequestOptions): Promise<UiActionResultData[]>;
}
export interface portal_admin_role_org_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_ParentOrg) */ ParentKey?: string;
    /** Filter by risk index */ risk?: string;
    /** Role class */ orgroot?: string;
}
export interface portal_admin_role_org_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_candidates_Org_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_ParentOrg) */ ParentKey?: string;
}
export interface portal_candidates_Org_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_candidates_Org_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_candidates_PersonInOrg_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_candidates_PersonInOrg_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_candidates_PersonInOrg_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_person_rolememberships_Org_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_resp_org_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_ParentOrg) */ ParentKey?: string;
    /** Role class */ orgroot?: string;
}
export interface portal_resp_org_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_resp_Org_restore_get_args {
    backto?: Date;
}
export interface portal_resp_Org_restore_byid_get_args {
    backto?: Date;
}
export interface portal_resp_Org_restore_byid_post_args {
    backto?: Date;
}
export interface portal_roles_config_membership_Org_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_roles_config_membership_Org_UID_Person_candidates_get_args {
    /** Filter candidates by assignment flag */ xorigin?: number;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_roles_config_membership_Org_UID_Person_candidates_filtertree_post_args {
    /** Filter candidates by assignment flag */ xorigin?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_roles_config_Org_primarymembers_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_roles_Org_restore_get_args {
    backto?: Date;
}
export interface portal_roles_Org_restore_byid_get_args {
    backto?: Date;
}
export interface portal_roles_Org_restore_byid_post_args {
    backto?: Date;
}
export declare class V2ApiClientMethodFactory {
    portal_admin_role_org_get(options?: portal_admin_role_org_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_org_put(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_org_post(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_admin_role_org_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_admin_role_org_datamodel_get(options?: portal_admin_role_org_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_admin_role_org_interactive_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_org_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_admin_role_org_interactive_byid_get(/** Primary key value UID_Org */ UID_Org: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_candidates_Org_get(options?: portal_candidates_Org_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Org_datamodel_get(options?: portal_candidates_Org_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_candidates_Org_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_Org_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_PersonInOrg_get(options?: portal_candidates_PersonInOrg_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_PersonInOrg_datamodel_get(options?: portal_candidates_PersonInOrg_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_candidates_PersonInOrg_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_PersonInOrg_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_person_rolememberships_Org_get(/** Unique identity identifier */ UID_Person: string, options?: portal_person_rolememberships_Org_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_resp_org_get(options?: portal_resp_org_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_resp_org_datamodel_get(options?: portal_resp_org_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_resp_org_interactive_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_resp_org_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_resp_org_interactive_byid_get(/** Primary key value UID_Org */ UID_Org: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_resp_Org_restore_get(options?: portal_resp_Org_restore_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DeletedObjectInfo[]>;
    portal_resp_Org_restore_byid_get(/** Unique identifier of the role to be restored */ uid: string, options?: portal_resp_Org_restore_byid_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<RestoreActions>;
    portal_resp_Org_restore_byid_post(/** Unique identifier of the role to be restored */ uid: string, inputParameterName: RestoreActionList, options?: portal_resp_Org_restore_byid_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<UiActionResultData[]>;
    portal_resp_team_teamrole_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<TeamRoleData>;
    portal_resp_team_teamrole_post(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_resp_team_teamrole_recommendations_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<RoleRecommendationResult>;
    portal_roles_config_membership_Org_get(/** Unique identifier of the role */ UID_Org: string, options?: portal_roles_config_membership_Org_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Org_post(/** Unique identifier of the role */ UID_Org: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Org_delete(/** Unique identifier of the role */ UID_Org: string, /** Identity */ UID_Person: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Org_UID_Person_candidates_get(/** Unique identifier of the role */ UID_Org: string, options?: portal_roles_config_membership_Org_UID_Person_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_membership_Org_UID_Person_candidates_filtertree_post(/** Unique identifier of the role */ UID_Org: string, inputParameterName: EntityWriteDataSingle, options?: portal_roles_config_membership_Org_UID_Person_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_roles_config_Org_primarymembers_get(/** Primary role identifier */ UID_Org: string, options?: portal_roles_config_Org_primarymembers_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_roles_Org_restore_get(options?: portal_roles_Org_restore_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DeletedObjectInfo[]>;
    portal_roles_Org_restore_byid_get(/** Unique identifier of the role to be restored */ uid: string, options?: portal_roles_Org_restore_byid_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<RestoreActions>;
    portal_roles_Org_restore_byid_post(/** Unique identifier of the role to be restored */ uid: string, inputParameterName: RestoreActionList, options?: portal_roles_Org_restore_byid_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<UiActionResultData[]>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_admin_role_org_get(options?: portal_admin_role_org_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_admin_role_org_put(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_admin_role_org_post(inputParameterName: ExtendedEntityWriteData<RoleExtendedDataWrite>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_admin_role_org_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the admin/role/org endpoint. */
    portal_admin_role_org_datamodel_get(options?: portal_admin_role_org_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_admin_role_org_interactive_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_admin_role_org_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_admin_role_org_interactive_byid_get(/** Primary key value UID_Org */ UID_Org: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    /** Returns a list of candidate objects from the table Org. */
    portal_candidates_Org_get(options?: portal_candidates_Org_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/Org endpoint. */
    portal_candidates_Org_datamodel_get(options?: portal_candidates_Org_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the candidates/Org endpoint. */
    portal_candidates_Org_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_Org_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table PersonInOrg. */
    portal_candidates_PersonInOrg_get(options?: portal_candidates_PersonInOrg_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the candidates/PersonInOrg endpoint. */
    portal_candidates_PersonInOrg_datamodel_get(options?: portal_candidates_PersonInOrg_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the candidates/PersonInOrg endpoint. */
    portal_candidates_PersonInOrg_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_PersonInOrg_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_person_rolememberships_Org_get(/** Unique identity identifier */ UID_Person: string, options?: portal_person_rolememberships_Org_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_resp_org_get(options?: portal_resp_org_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/org endpoint. */
    portal_resp_org_datamodel_get(options?: portal_resp_org_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_resp_org_interactive_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_org_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_org_interactive_byid_get(/** Primary key value UID_Org */ UID_Org: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_Org_restore_get(options?: portal_resp_Org_restore_get_args, requestOptions?: ApiRequestOptions): Promise<DeletedObjectInfo[]>;
    portal_resp_Org_restore_byid_get(/** Unique identifier of the role to be restored */ uid: string, options?: portal_resp_Org_restore_byid_get_args, requestOptions?: ApiRequestOptions): Promise<RestoreActions>;
    portal_resp_Org_restore_byid_post(/** Unique identifier of the role to be restored */ uid: string, inputParameterName: RestoreActionList, options?: portal_resp_Org_restore_byid_post_args, requestOptions?: ApiRequestOptions): Promise<UiActionResultData[]>;
    /** Returns information about the existing team role for the current user, if any. */
    portal_resp_team_teamrole_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<TeamRoleData>;
    /** Creates a new team role for the current user. This call will fail if a team role already exists. */
    portal_resp_team_teamrole_post(options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns recommendations for entitlement additions for a team role. */
    portal_resp_team_teamrole_recommendations_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<RoleRecommendationResult>;
    portal_roles_config_membership_Org_get(/** Unique identifier of the role */ UID_Org: string, options?: portal_roles_config_membership_Org_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_config_membership_Org_post(/** Unique identifier of the role */ UID_Org: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_config_membership_Org_delete(/** Unique identifier of the role */ UID_Org: string, /** Identity */ UID_Person: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    portal_roles_config_membership_Org_UID_Person_candidates_get(/** Unique identifier of the role */ UID_Org: string, options?: portal_roles_config_membership_Org_UID_Person_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the roles/config/membership/Org/{UID_Org}/UID_Person/candidates endpoint. */
    portal_roles_config_membership_Org_UID_Person_candidates_filtertree_post(/** Unique identifier of the role */ UID_Org: string, inputParameterName: EntityWriteDataSingle, options?: portal_roles_config_membership_Org_UID_Person_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns identities who are primary members of a role. */
    portal_roles_config_Org_primarymembers_get(/** Primary role identifier */ UID_Org: string, options?: portal_roles_config_Org_primarymembers_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_roles_Org_restore_get(options?: portal_roles_Org_restore_get_args, requestOptions?: ApiRequestOptions): Promise<DeletedObjectInfo[]>;
    portal_roles_Org_restore_byid_get(/** Unique identifier of the role to be restored */ uid: string, options?: portal_roles_Org_restore_byid_get_args, requestOptions?: ApiRequestOptions): Promise<RestoreActions>;
    portal_roles_Org_restore_byid_post(/** Unique identifier of the role to be restored */ uid: string, inputParameterName: RestoreActionList, options?: portal_roles_Org_restore_byid_post_args, requestOptions?: ApiRequestOptions): Promise<UiActionResultData[]>;
}
