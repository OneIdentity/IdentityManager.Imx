import { ApiClient, DataModel, EntityCollectionData, EntityData, EntitySchema, EntityWriteData, EntityWriteDataColumn, EntityWriteDataSingle, FilterData, FilterTreeData, FkProviderItem, IReadValue, IWriteValue, MethodDescriptor, StaticSchema, TypedEntity } from 'imx-qbm-dbts';
export interface EntityWriteDataBulk {
    Keys?: string[][];
    Data?: EntityWriteDataColumn[];
}
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export declare class TypedClient {
    readonly PortalAaddirectoryroleMemberships: PortalAaddirectoryroleMembershipsWrapper;
    readonly PortalAadgroupMemberships: PortalAadgroupMembershipsWrapper;
    readonly PortalAadsubskuMemberships: PortalAadsubskuMembershipsWrapper;
    readonly PortalShopConfigEntitlementsAaddeniedserviceplan: PortalShopConfigEntitlementsAaddeniedserviceplanWrapper;
    readonly PortalTargetsystemAadgroupDeniedserviceplans: PortalTargetsystemAadgroupDeniedserviceplansWrapper;
    readonly PortalTargetsystemAadgroupSubsku: PortalTargetsystemAadgroupSubskuWrapper;
    readonly PortalTargetsystemAaduserDeniedserviceplans: PortalTargetsystemAaduserDeniedserviceplansWrapper;
    readonly PortalTargetsystemAaduserSubsku: PortalTargetsystemAaduserSubskuWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalAaddirectoryroleMemberships extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly IsPending: IReadValue<boolean>;
    readonly IsPrimary: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'ObjectKeyAssignment' | 'XOrigin' | 'IsPending' | 'IsPrimary' | 'XMarkedForDeletion' | 'XDateInserted' | 'OrderState' | 'ValidUntil' | 'UID_UNSAccount' | 'UID_UNSGroupChild'>;
}
export declare class PortalAadgroupMemberships extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly IsPending: IReadValue<boolean>;
    readonly IsPrimary: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'ObjectKeyAssignment' | 'XOrigin' | 'IsPending' | 'IsPrimary' | 'XMarkedForDeletion' | 'XDateInserted' | 'OrderState' | 'ValidUntil' | 'UID_UNSAccount' | 'UID_UNSGroupChild'>;
}
export declare class PortalAadsubskuMemberships extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly IsPending: IReadValue<boolean>;
    readonly IsPrimary: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'ObjectKeyAssignment' | 'XOrigin' | 'IsPending' | 'IsPrimary' | 'XMarkedForDeletion' | 'XDateInserted' | 'OrderState' | 'ValidUntil' | 'UID_UNSAccount' | 'UID_UNSGroupChild'>;
}
export declare class PortalShopConfigEntitlementsAaddeniedserviceplan extends TypedEntity {
    readonly UID_ITShopOrg: IReadValue<string>;
    readonly UID_AADDeniedServicePlan: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_ITShopOrg' | 'UID_AADDeniedServicePlan'>;
}
export declare class PortalTargetsystemAadgroupDeniedserviceplans extends TypedEntity {
    readonly UID_AADGroup: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly UID_AADDeniedServicePlan: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_AADGroup' | 'XOrigin' | 'UID_AADDeniedServicePlan'>;
}
export declare class PortalTargetsystemAadgroupSubsku extends TypedEntity {
    readonly UID_AADGroup: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly UID_AADSubSku: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_AADGroup' | 'XOrigin' | 'UID_AADSubSku'>;
}
export declare class PortalTargetsystemAaduserDeniedserviceplans extends TypedEntity {
    readonly UID_AADUser: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly UID_AADDeniedServicePlan: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_AADUser' | 'XOrigin' | 'UID_AADDeniedServicePlan'>;
}
export declare class PortalTargetsystemAaduserSubsku extends TypedEntity {
    readonly UID_AADUser: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly ObjectKeyAADSubSku: IWriteValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_AADUser' | 'XOrigin' | 'ObjectKeyAADSubSku'>;
}
export declare class PortalAaddirectoryroleMembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAaddirectoryroleMemberships, unknown>>;
}
export declare class PortalAadgroupMembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAadgroupMemberships, unknown>>;
}
export declare class PortalAadsubskuMembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAadsubskuMemberships, unknown>>;
}
export declare class PortalShopConfigEntitlementsAaddeniedserviceplanWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalShopConfigEntitlementsAaddeniedserviceplan;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ITShopOrg: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsAaddeniedserviceplan, unknown>>;
    Post(UID_ITShopOrg: string, inputParameterName: PortalShopConfigEntitlementsAaddeniedserviceplan): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsAaddeniedserviceplan, unknown>>;
    Delete(UID_ITShopOrg: string, UID_AADDeniedServicePlan: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsAaddeniedserviceplan, unknown>>;
}
export declare class PortalTargetsystemAadgroupDeniedserviceplansWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalTargetsystemAadgroupDeniedserviceplans;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_AADGroup: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroupDeniedserviceplans, unknown>>;
    Put(UID_AADGroup: string, inputParameterName: PortalTargetsystemAadgroupDeniedserviceplans): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroupDeniedserviceplans, unknown>>;
    Post(UID_AADGroup: string, inputParameterName: PortalTargetsystemAadgroupDeniedserviceplans): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroupDeniedserviceplans, unknown>>;
    Delete(UID_AADGroup: string, UID_AADDeniedServicePlan: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroupDeniedserviceplans, unknown>>;
}
export declare class PortalTargetsystemAadgroupSubskuWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalTargetsystemAadgroupSubsku;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_AADGroup: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroupSubsku, unknown>>;
    Put(UID_AADGroup: string, inputParameterName: PortalTargetsystemAadgroupSubsku): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroupSubsku, unknown>>;
    Post(UID_AADGroup: string, inputParameterName: PortalTargetsystemAadgroupSubsku): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroupSubsku, unknown>>;
    Delete(UID_AADGroup: string, UID_AADSubSku: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroupSubsku, unknown>>;
}
export declare class PortalTargetsystemAaduserDeniedserviceplansWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalTargetsystemAaduserDeniedserviceplans;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_AADUser: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaduserDeniedserviceplans, unknown>>;
    Put(UID_AADUser: string, inputParameterName: PortalTargetsystemAaduserDeniedserviceplans): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaduserDeniedserviceplans, unknown>>;
    Post(UID_AADUser: string, inputParameterName: PortalTargetsystemAaduserDeniedserviceplans): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaduserDeniedserviceplans, unknown>>;
    Delete(UID_AADUser: string, UID_AADDeniedServicePlan: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaduserDeniedserviceplans, unknown>>;
}
export declare class PortalTargetsystemAaduserSubskuWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalTargetsystemAaduserSubsku;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_AADUser: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaduserSubsku, unknown>>;
    Put(UID_AADUser: string, inputParameterName: PortalTargetsystemAaduserSubsku): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaduserSubsku, unknown>>;
    Post(UID_AADUser: string, inputParameterName: PortalTargetsystemAaduserSubsku): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaduserSubsku, unknown>>;
    Delete(UID_AADUser: string, UID_AADUserHasSubSku: string): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaduserSubsku, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    portal_AADDirectoryRole_memberships_get(uid: string): MethodDescriptor<EntityCollectionData>;
    portal_AADDirectoryRole_memberships_delete(uid: string, uidaccount: string): MethodDescriptor<void>;
    portal_AADGroup_memberships_get(uid: string): MethodDescriptor<EntityCollectionData>;
    portal_AADGroup_memberships_delete(uid: string, uidaccount: string): MethodDescriptor<void>;
    portal_AADSubSku_memberships_get(uid: string): MethodDescriptor<EntityCollectionData>;
    portal_AADSubSku_memberships_delete(uid: string, uidaccount: string): MethodDescriptor<void>;
    portal_shop_config_entitlements_AADDeniedServicePlan_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_delete(UID_ITShopOrg: string, UID_AADDeniedServicePlan: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_aadgroup_deniedserviceplans_get(UID_AADGroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_put(UID_AADGroup: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_post(UID_AADGroup: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_delete(UID_AADGroup: string, UID_AADDeniedServicePlan: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_bulk_put(UID_AADGroup: string, inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(UID_AADGroup: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_AADGroup: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_AADGroup: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_aadgroup_subsku_get(UID_AADGroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_put(UID_AADGroup: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_post(UID_AADGroup: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_delete(UID_AADGroup: string, UID_AADSubSku: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_bulk_put(UID_AADGroup: string, inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get(UID_AADGroup: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get(UID_AADGroup: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post(UID_AADGroup: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_aadsubsku_licenceoverview_get(UID_AADSubSku: string): MethodDescriptor<void>;
    portal_targetsystem_aaduser_deniedserviceplans_get(UID_AADUser: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_put(UID_AADUser: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_post(UID_AADUser: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_delete(UID_AADUser: string, UID_AADDeniedServicePlan: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_bulk_put(UID_AADUser: string, inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(UID_AADUser: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_AADUser: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_AADUser: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_aaduser_subsku_get(UID_AADUser: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_put(UID_AADUser: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_post(UID_AADUser: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_delete(UID_AADUser: string, UID_AADUserHasSubSku: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_bulk_put(UID_AADUser: string, inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get(UID_AADUser: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get(UID_AADUser: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post(UID_AADUser: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_AADDirectoryRole_memberships_get(uid: string): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_AADDirectoryRole_memberships_delete(uid: string, uidaccount: string): Promise<void>;
    portal_AADGroup_memberships_get(uid: string): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_AADGroup_memberships_delete(uid: string, uidaccount: string): Promise<void>;
    portal_AADSubSku_memberships_get(uid: string): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_AADSubSku_memberships_delete(uid: string, uidaccount: string): Promise<void>;
    portal_shop_config_entitlements_AADDeniedServicePlan_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_delete(UID_ITShopOrg: string, UID_AADDeniedServicePlan: string): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AADDirectoryRole. */
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates endpoint. */
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates endpoint. */
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AADGroup. */
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates endpoint. */
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates endpoint. */
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AADSubSku. */
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates endpoint. */
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates endpoint. */
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    portal_targetsystem_aadgroup_deniedserviceplans_get(UID_AADGroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_put(UID_AADGroup: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_post(UID_AADGroup: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_delete(UID_AADGroup: string, UID_AADDeniedServicePlan: string): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_bulk_put(UID_AADGroup: string, inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(UID_AADGroup: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_AADGroup: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_AADGroup: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    portal_targetsystem_aadgroup_subsku_get(UID_AADGroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_put(UID_AADGroup: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_post(UID_AADGroup: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_delete(UID_AADGroup: string, UID_AADSubSku: string): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_bulk_put(UID_AADGroup: string, inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Returns a list of objects that can be assigned to the property UID_AADSubSku. */
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get(UID_AADGroup: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates endpoint. */
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get(UID_AADGroup: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates endpoint. */
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post(UID_AADGroup: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    portal_targetsystem_aadsubsku_licenceoverview_get(UID_AADSubSku: string): Promise<void>;
    portal_targetsystem_aaduser_deniedserviceplans_get(UID_AADUser: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_put(UID_AADUser: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_post(UID_AADUser: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_delete(UID_AADUser: string, UID_AADDeniedServicePlan: string): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_bulk_put(UID_AADUser: string, inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(UID_AADUser: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_AADUser: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_AADUser: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
    portal_targetsystem_aaduser_subsku_get(UID_AADUser: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_put(UID_AADUser: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_post(UID_AADUser: string, inputParameterName: EntityWriteData): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_delete(UID_AADUser: string, UID_AADUserHasSubSku: string): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_bulk_put(UID_AADUser: string, inputParameterName: EntityWriteDataBulk): Promise<void>;
    /** Returns a list of objects that can be assigned to the property ObjectKeyAADSubSku. */
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get(UID_AADUser: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates endpoint. */
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get(UID_AADUser: string, filter: FilterData[]): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates endpoint. */
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post(UID_AADUser: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): Promise<FilterTreeData>;
}
export declare class V2ApiClientMethodFactory {
    portal_AADDirectoryRole_memberships_get(uid: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_AADDirectoryRole_memberships_delete(uid: string, uidaccount: string, options?: {}): MethodDescriptor<void>;
    portal_AADGroup_memberships_get(uid: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_AADGroup_memberships_delete(uid: string, uidaccount: string, options?: {}): MethodDescriptor<void>;
    portal_AADSubSku_memberships_get(uid: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_AADSubSku_memberships_delete(uid: string, uidaccount: string, options?: {}): MethodDescriptor<void>;
    portal_shop_config_entitlements_AADDeniedServicePlan_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_delete(UID_ITShopOrg: string, UID_AADDeniedServicePlan: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_aadgroup_deniedserviceplans_get(UID_AADGroup: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_put(UID_AADGroup: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_post(UID_AADGroup: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_delete(UID_AADGroup: string, UID_AADDeniedServicePlan: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_bulk_put(UID_AADGroup: string, inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(UID_AADGroup: string, options?: {
        xorigin?: number;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_AADGroup: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_AADGroup: string, inputParameterName: EntityWriteDataSingle, options?: {
        xorigin?: number;
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_aadgroup_subsku_get(UID_AADGroup: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_put(UID_AADGroup: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_post(UID_AADGroup: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_delete(UID_AADGroup: string, UID_AADSubSku: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_bulk_put(UID_AADGroup: string, inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get(UID_AADGroup: string, options?: {
        xorigin?: number;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get(UID_AADGroup: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post(UID_AADGroup: string, inputParameterName: EntityWriteDataSingle, options?: {
        xorigin?: number;
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_aadsubsku_licenceoverview_get(UID_AADSubSku: string, options?: {}): MethodDescriptor<void>;
    portal_targetsystem_aaduser_deniedserviceplans_get(UID_AADUser: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_put(UID_AADUser: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_post(UID_AADUser: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_delete(UID_AADUser: string, UID_AADDeniedServicePlan: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_bulk_put(UID_AADUser: string, inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(UID_AADUser: string, options?: {
        xorigin?: number;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_AADUser: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_AADUser: string, inputParameterName: EntityWriteDataSingle, options?: {
        xorigin?: number;
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_aaduser_subsku_get(UID_AADUser: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_put(UID_AADUser: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_post(UID_AADUser: string, inputParameterName: EntityWriteData, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_delete(UID_AADUser: string, UID_AADUserHasSubSku: string, options?: {}): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_bulk_put(UID_AADUser: string, inputParameterName: EntityWriteDataBulk, options?: {}): MethodDescriptor<void>;
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get(UID_AADUser: string, options?: {
        xorigin?: number;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get(UID_AADUser: string, options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post(UID_AADUser: string, inputParameterName: EntityWriteDataSingle, options?: {
        xorigin?: number;
        filter?: FilterData[];
        parentkey?: string;
    }): MethodDescriptor<FilterTreeData>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_AADDirectoryRole_memberships_get(uid: string, options?: {}): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_AADDirectoryRole_memberships_delete(uid: string, uidaccount: string, options?: {}): Promise<void>;
    portal_AADGroup_memberships_get(uid: string, options?: {}): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_AADGroup_memberships_delete(uid: string, uidaccount: string, options?: {}): Promise<void>;
    portal_AADSubSku_memberships_get(uid: string, options?: {}): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_AADSubSku_memberships_delete(uid: string, uidaccount: string, options?: {}): Promise<void>;
    portal_shop_config_entitlements_AADDeniedServicePlan_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_delete(UID_ITShopOrg: string, UID_AADDeniedServicePlan: string, options?: {}): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AADDirectoryRole. */
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates endpoint. */
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates endpoint. */
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AADGroup. */
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates endpoint. */
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates endpoint. */
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AADSubSku. */
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get(UID_ITShopOrg: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates endpoint. */
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get(UID_ITShopOrg: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates endpoint. */
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post(UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: {
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    portal_targetsystem_aadgroup_deniedserviceplans_get(UID_AADGroup: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_put(UID_AADGroup: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_post(UID_AADGroup: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_delete(UID_AADGroup: string, UID_AADDeniedServicePlan: string, options?: {}): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_bulk_put(UID_AADGroup: string, inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(UID_AADGroup: string, options?: {
        xorigin?: number;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_AADGroup: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_AADGroup: string, inputParameterName: EntityWriteDataSingle, options?: {
        xorigin?: number;
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    portal_targetsystem_aadgroup_subsku_get(UID_AADGroup: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_put(UID_AADGroup: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_post(UID_AADGroup: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_delete(UID_AADGroup: string, UID_AADSubSku: string, options?: {}): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_bulk_put(UID_AADGroup: string, inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Returns a list of objects that can be assigned to the property UID_AADSubSku. */
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get(UID_AADGroup: string, options?: {
        xorigin?: number;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates endpoint. */
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get(UID_AADGroup: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates endpoint. */
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post(UID_AADGroup: string, inputParameterName: EntityWriteDataSingle, options?: {
        xorigin?: number;
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    portal_targetsystem_aadsubsku_licenceoverview_get(UID_AADSubSku: string, options?: {}): Promise<void>;
    portal_targetsystem_aaduser_deniedserviceplans_get(UID_AADUser: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_put(UID_AADUser: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_post(UID_AADUser: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_delete(UID_AADUser: string, UID_AADDeniedServicePlan: string, options?: {}): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_bulk_put(UID_AADUser: string, inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(UID_AADUser: string, options?: {
        xorigin?: number;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_AADUser: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_AADUser: string, inputParameterName: EntityWriteDataSingle, options?: {
        xorigin?: number;
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
    portal_targetsystem_aaduser_subsku_get(UID_AADUser: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_put(UID_AADUser: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_post(UID_AADUser: string, inputParameterName: EntityWriteData, options?: {}): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_delete(UID_AADUser: string, UID_AADUserHasSubSku: string, options?: {}): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_bulk_put(UID_AADUser: string, inputParameterName: EntityWriteDataBulk, options?: {}): Promise<void>;
    /** Returns a list of objects that can be assigned to the property ObjectKeyAADSubSku. */
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get(UID_AADUser: string, options?: {
        xorigin?: number;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates endpoint. */
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get(UID_AADUser: string, options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates endpoint. */
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post(UID_AADUser: string, inputParameterName: EntityWriteDataSingle, options?: {
        xorigin?: number;
        filter?: FilterData[];
        parentkey?: string;
    }): Promise<FilterTreeData>;
}
