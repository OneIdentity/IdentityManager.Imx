(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('imx-qbm-dbts')) :
    typeof define === 'function' && define.amd ? define(['exports', 'imx-qbm-dbts'], factory) :
    (global = global || self, factory(global['imx-api'] = {}, global.imxQbmDbts));
}(this, (function (exports, imxQbmDbts) { 'use strict';

    var __extends = (undefined && undefined.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    };
    var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    };
    var TypedClient = /** @class */ (function () {
        function TypedClient(client, translationProvider) {
            this.PortalAaddirectoryroleMemberships = new PortalAaddirectoryroleMembershipsWrapper(client, translationProvider);
            this.PortalAadgroupMemberships = new PortalAadgroupMembershipsWrapper(client, translationProvider);
            this.PortalAadsubskuMemberships = new PortalAadsubskuMembershipsWrapper(client, translationProvider);
            this.PortalShopConfigEntitlementsAaddeniedserviceplan = new PortalShopConfigEntitlementsAaddeniedserviceplanWrapper(client, translationProvider);
            this.PortalTargetsystemAadgroupDeniedserviceplans = new PortalTargetsystemAadgroupDeniedserviceplansWrapper(client, translationProvider);
            this.PortalTargetsystemAadgroupSubsku = new PortalTargetsystemAadgroupSubskuWrapper(client, translationProvider);
            this.PortalTargetsystemAaduserDeniedserviceplans = new PortalTargetsystemAaduserDeniedserviceplansWrapper(client, translationProvider);
            this.PortalTargetsystemAaduserSubsku = new PortalTargetsystemAaduserSubskuWrapper(client, translationProvider);
        }
        return TypedClient;
    }());
    var PortalAaddirectoryroleMemberships = /** @class */ (function (_super) {
        __extends(PortalAaddirectoryroleMemberships, _super);
        function PortalAaddirectoryroleMemberships() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.ObjectKeyAssignment = _this.GetEntityValue('ObjectKeyAssignment');
            _this.XOrigin = _this.GetEntityValue('XOrigin');
            _this.IsPending = _this.GetEntityValue('IsPending');
            _this.IsPrimary = _this.GetEntityValue('IsPrimary');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.OrderState = _this.GetEntityValue('OrderState');
            _this.ValidUntil = _this.GetEntityValue('ValidUntil');
            _this.UID_UNSAccount = _this.GetEntityValue('UID_UNSAccount');
            _this.UID_UNSGroupChild = _this.GetEntityValue('UID_UNSGroupChild');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        PortalAaddirectoryroleMemberships.GetEntitySchema = function () {
            var columns = {
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ObjectKeyAssignment': {
                    ColumnName: 'ObjectKeyAssignment',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XOrigin': {
                    ColumnName: 'XOrigin',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'IsPending': {
                    ColumnName: 'IsPending',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsPrimary': {
                    ColumnName: 'IsPrimary',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'OrderState': {
                    ColumnName: 'OrderState',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ValidUntil': {
                    ColumnName: 'ValidUntil',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'UID_UNSAccount': {
                    ColumnName: 'UID_UNSAccount',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSGroupChild': {
                    ColumnName: 'UID_UNSGroupChild',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: '', Columns: columns };
        };
        return PortalAaddirectoryroleMemberships;
    }(imxQbmDbts.TypedEntity));
    var PortalAadgroupMemberships = /** @class */ (function (_super) {
        __extends(PortalAadgroupMemberships, _super);
        function PortalAadgroupMemberships() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.ObjectKeyAssignment = _this.GetEntityValue('ObjectKeyAssignment');
            _this.XOrigin = _this.GetEntityValue('XOrigin');
            _this.IsPending = _this.GetEntityValue('IsPending');
            _this.IsPrimary = _this.GetEntityValue('IsPrimary');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.OrderState = _this.GetEntityValue('OrderState');
            _this.ValidUntil = _this.GetEntityValue('ValidUntil');
            _this.UID_UNSAccount = _this.GetEntityValue('UID_UNSAccount');
            _this.UID_UNSGroupChild = _this.GetEntityValue('UID_UNSGroupChild');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        PortalAadgroupMemberships.GetEntitySchema = function () {
            var columns = {
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ObjectKeyAssignment': {
                    ColumnName: 'ObjectKeyAssignment',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XOrigin': {
                    ColumnName: 'XOrigin',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'IsPending': {
                    ColumnName: 'IsPending',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsPrimary': {
                    ColumnName: 'IsPrimary',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'OrderState': {
                    ColumnName: 'OrderState',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ValidUntil': {
                    ColumnName: 'ValidUntil',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'UID_UNSAccount': {
                    ColumnName: 'UID_UNSAccount',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSGroupChild': {
                    ColumnName: 'UID_UNSGroupChild',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: '', Columns: columns };
        };
        return PortalAadgroupMemberships;
    }(imxQbmDbts.TypedEntity));
    var PortalAadsubskuMemberships = /** @class */ (function (_super) {
        __extends(PortalAadsubskuMemberships, _super);
        function PortalAadsubskuMemberships() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.ObjectKeyAssignment = _this.GetEntityValue('ObjectKeyAssignment');
            _this.XOrigin = _this.GetEntityValue('XOrigin');
            _this.IsPending = _this.GetEntityValue('IsPending');
            _this.IsPrimary = _this.GetEntityValue('IsPrimary');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.OrderState = _this.GetEntityValue('OrderState');
            _this.ValidUntil = _this.GetEntityValue('ValidUntil');
            _this.UID_UNSAccount = _this.GetEntityValue('UID_UNSAccount');
            _this.UID_UNSGroupChild = _this.GetEntityValue('UID_UNSGroupChild');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        PortalAadsubskuMemberships.GetEntitySchema = function () {
            var columns = {
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ObjectKeyAssignment': {
                    ColumnName: 'ObjectKeyAssignment',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XOrigin': {
                    ColumnName: 'XOrigin',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'IsPending': {
                    ColumnName: 'IsPending',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsPrimary': {
                    ColumnName: 'IsPrimary',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'OrderState': {
                    ColumnName: 'OrderState',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ValidUntil': {
                    ColumnName: 'ValidUntil',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'UID_UNSAccount': {
                    ColumnName: 'UID_UNSAccount',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSGroupChild': {
                    ColumnName: 'UID_UNSGroupChild',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: '', Columns: columns };
        };
        return PortalAadsubskuMemberships;
    }(imxQbmDbts.TypedEntity));
    var PortalShopConfigEntitlementsAaddeniedserviceplan = /** @class */ (function (_super) {
        __extends(PortalShopConfigEntitlementsAaddeniedserviceplan, _super);
        function PortalShopConfigEntitlementsAaddeniedserviceplan() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_ITShopOrg = _this.GetEntityValue('UID_ITShopOrg');
            _this.UID_AADDeniedServicePlan = _this.GetEntityValue('UID_AADDeniedServicePlan');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        PortalShopConfigEntitlementsAaddeniedserviceplan.GetEntitySchema = function () {
            var columns = {
                'UID_ITShopOrg': {
                    ColumnName: 'UID_ITShopOrg',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_AADDeniedServicePlan': {
                    ColumnName: 'UID_AADDeniedServicePlan',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'ITShopOrgHasDeniedService', Columns: columns };
        };
        return PortalShopConfigEntitlementsAaddeniedserviceplan;
    }(imxQbmDbts.TypedEntity));
    var PortalTargetsystemAadgroupDeniedserviceplans = /** @class */ (function (_super) {
        __extends(PortalTargetsystemAadgroupDeniedserviceplans, _super);
        function PortalTargetsystemAadgroupDeniedserviceplans() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_AADGroup = _this.GetEntityValue('UID_AADGroup');
            _this.XOrigin = _this.GetEntityValue('XOrigin');
            _this.UID_AADDeniedServicePlan = _this.GetEntityValue('UID_AADDeniedServicePlan');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        PortalTargetsystemAadgroupDeniedserviceplans.GetEntitySchema = function () {
            var columns = {
                'UID_AADGroup': {
                    ColumnName: 'UID_AADGroup',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XOrigin': {
                    ColumnName: 'XOrigin',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'UID_AADDeniedServicePlan': {
                    ColumnName: 'UID_AADDeniedServicePlan',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'AADGroupHasDeniedService', Columns: columns };
        };
        return PortalTargetsystemAadgroupDeniedserviceplans;
    }(imxQbmDbts.TypedEntity));
    var PortalTargetsystemAadgroupSubsku = /** @class */ (function (_super) {
        __extends(PortalTargetsystemAadgroupSubsku, _super);
        function PortalTargetsystemAadgroupSubsku() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_AADGroup = _this.GetEntityValue('UID_AADGroup');
            _this.XOrigin = _this.GetEntityValue('XOrigin');
            _this.UID_AADSubSku = _this.GetEntityValue('UID_AADSubSku');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        PortalTargetsystemAadgroupSubsku.GetEntitySchema = function () {
            var columns = {
                'UID_AADGroup': {
                    ColumnName: 'UID_AADGroup',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XOrigin': {
                    ColumnName: 'XOrigin',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'UID_AADSubSku': {
                    ColumnName: 'UID_AADSubSku',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'AADGroupHasSubSku', Columns: columns };
        };
        return PortalTargetsystemAadgroupSubsku;
    }(imxQbmDbts.TypedEntity));
    var PortalTargetsystemAaduserDeniedserviceplans = /** @class */ (function (_super) {
        __extends(PortalTargetsystemAaduserDeniedserviceplans, _super);
        function PortalTargetsystemAaduserDeniedserviceplans() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_AADUser = _this.GetEntityValue('UID_AADUser');
            _this.XOrigin = _this.GetEntityValue('XOrigin');
            _this.UID_AADDeniedServicePlan = _this.GetEntityValue('UID_AADDeniedServicePlan');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        PortalTargetsystemAaduserDeniedserviceplans.GetEntitySchema = function () {
            var columns = {
                'UID_AADUser': {
                    ColumnName: 'UID_AADUser',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XOrigin': {
                    ColumnName: 'XOrigin',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'UID_AADDeniedServicePlan': {
                    ColumnName: 'UID_AADDeniedServicePlan',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'AADUserHasDeniedService', Columns: columns };
        };
        return PortalTargetsystemAaduserDeniedserviceplans;
    }(imxQbmDbts.TypedEntity));
    var PortalTargetsystemAaduserSubsku = /** @class */ (function (_super) {
        __extends(PortalTargetsystemAaduserSubsku, _super);
        function PortalTargetsystemAaduserSubsku() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_AADUser = _this.GetEntityValue('UID_AADUser');
            _this.XOrigin = _this.GetEntityValue('XOrigin');
            _this.ObjectKeyAADSubSku = _this.GetEntityValue('ObjectKeyAADSubSku');
            return _this;
        }
        /** Returns the static compile time schema for this method. */
        PortalTargetsystemAaduserSubsku.GetEntitySchema = function () {
            var columns = {
                'UID_AADUser': {
                    ColumnName: 'UID_AADUser',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XOrigin': {
                    ColumnName: 'XOrigin',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'ObjectKeyAADSubSku': {
                    ColumnName: 'ObjectKeyAADSubSku',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'AADUserHasSubSku', Columns: columns };
        };
        return PortalTargetsystemAaduserSubsku;
    }(imxQbmDbts.TypedEntity));
    var PortalAaddirectoryroleMembershipsWrapper = /** @class */ (function () {
        function PortalAaddirectoryroleMembershipsWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalAaddirectoryroleMembershipsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/AADDirectoryRole/{uid}/memberships');
        };
        PortalAaddirectoryroleMembershipsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/AADDirectoryRole/{uid}/memberships');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalAaddirectoryroleMemberships, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAaddirectoryroleMembershipsWrapper.prototype.Get = function (uid) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_AADDirectoryRole_memberships_get(uid)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAaddirectoryroleMembershipsWrapper;
    }());
    var PortalAadgroupMembershipsWrapper = /** @class */ (function () {
        function PortalAadgroupMembershipsWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalAadgroupMembershipsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/AADGroup/{uid}/memberships');
        };
        PortalAadgroupMembershipsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/AADGroup/{uid}/memberships');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalAadgroupMemberships, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAadgroupMembershipsWrapper.prototype.Get = function (uid) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_AADGroup_memberships_get(uid)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAadgroupMembershipsWrapper;
    }());
    var PortalAadsubskuMembershipsWrapper = /** @class */ (function () {
        function PortalAadsubskuMembershipsWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalAadsubskuMembershipsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/AADSubSku/{uid}/memberships');
        };
        PortalAadsubskuMembershipsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/AADSubSku/{uid}/memberships');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalAadsubskuMemberships, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAadsubskuMembershipsWrapper.prototype.Get = function (uid) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_AADSubSku_memberships_get(uid)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAadsubskuMembershipsWrapper;
    }());
    var PortalShopConfigEntitlementsAaddeniedserviceplanWrapper = /** @class */ (function () {
        function PortalShopConfigEntitlementsAaddeniedserviceplanWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                {
                    return _this.client.portal_shop_config_entitlements_AADDeniedServicePlan_post(entity.GetColumn('UID_ITShopOrg').GetValue(), writeData);
                }
            };
            this.deleteMethod = function (entity) {
                return _this.client.portal_shop_config_entitlements_AADDeniedServicePlan_delete(entity.GetColumn('UID_ITShopOrg').GetValue(), entity.GetColumn('UID_AADDeniedServicePlan').GetValue());
            };
        }
        PortalShopConfigEntitlementsAaddeniedserviceplanWrapper.prototype.createEntity = function (initialData) {
            this.buildBuilderIfNeeded();
            return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, imxQbmDbts.EntityState.Created);
        };
        /** Returns the runtime schema for this method. */
        PortalShopConfigEntitlementsAaddeniedserviceplanWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan');
        };
        PortalShopConfigEntitlementsAaddeniedserviceplanWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalShopConfigEntitlementsAaddeniedserviceplan, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalShopConfigEntitlementsAaddeniedserviceplanWrapper.prototype.Get = function (UID_ITShopOrg, parametersOptional) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_AADDeniedServicePlan_get(UID_ITShopOrg, parametersOptional)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalShopConfigEntitlementsAaddeniedserviceplanWrapper.prototype.Post = function (UID_ITShopOrg, inputParameterName) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_AADDeniedServicePlan_post(UID_ITShopOrg, inputParameterName.EntityWriteData)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalShopConfigEntitlementsAaddeniedserviceplanWrapper.prototype.Delete = function (UID_ITShopOrg, UID_AADDeniedServicePlan) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_AADDeniedServicePlan_delete(UID_ITShopOrg, UID_AADDeniedServicePlan)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalShopConfigEntitlementsAaddeniedserviceplanWrapper;
    }());
    var PortalTargetsystemAadgroupDeniedserviceplansWrapper = /** @class */ (function () {
        function PortalTargetsystemAadgroupDeniedserviceplansWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                if (entity.GetState() == imxQbmDbts.EntityState.Created) {
                    return _this.client.portal_targetsystem_aadgroup_deniedserviceplans_post(entity.GetColumn('UID_AADGroup').GetValue(), writeData);
                }
                return _this.client.portal_targetsystem_aadgroup_deniedserviceplans_put(entity.GetColumn('UID_AADGroup').GetValue(), writeData);
            };
            this.deleteMethod = function (entity) {
                return _this.client.portal_targetsystem_aadgroup_deniedserviceplans_delete(entity.GetColumn('UID_AADGroup').GetValue(), entity.GetColumn('UID_AADDeniedServicePlan').GetValue());
            };
        }
        PortalTargetsystemAadgroupDeniedserviceplansWrapper.prototype.createEntity = function (initialData) {
            this.buildBuilderIfNeeded();
            return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, imxQbmDbts.EntityState.Created);
        };
        /** Returns the runtime schema for this method. */
        PortalTargetsystemAadgroupDeniedserviceplansWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans');
        };
        PortalTargetsystemAadgroupDeniedserviceplansWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemAadgroupDeniedserviceplans, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemAadgroupDeniedserviceplansWrapper.prototype.Get = function (UID_AADGroup, parametersOptional) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_deniedserviceplans_get(UID_AADGroup, parametersOptional)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemAadgroupDeniedserviceplansWrapper.prototype.Put = function (UID_AADGroup, inputParameterName) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_deniedserviceplans_put(UID_AADGroup, inputParameterName.EntityWriteData)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemAadgroupDeniedserviceplansWrapper.prototype.Post = function (UID_AADGroup, inputParameterName) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_deniedserviceplans_post(UID_AADGroup, inputParameterName.EntityWriteData)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemAadgroupDeniedserviceplansWrapper.prototype.Delete = function (UID_AADGroup, UID_AADDeniedServicePlan) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_deniedserviceplans_delete(UID_AADGroup, UID_AADDeniedServicePlan)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemAadgroupDeniedserviceplansWrapper;
    }());
    var PortalTargetsystemAadgroupSubskuWrapper = /** @class */ (function () {
        function PortalTargetsystemAadgroupSubskuWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                if (entity.GetState() == imxQbmDbts.EntityState.Created) {
                    return _this.client.portal_targetsystem_aadgroup_subsku_post(entity.GetColumn('UID_AADGroup').GetValue(), writeData);
                }
                return _this.client.portal_targetsystem_aadgroup_subsku_put(entity.GetColumn('UID_AADGroup').GetValue(), writeData);
            };
            this.deleteMethod = function (entity) {
                return _this.client.portal_targetsystem_aadgroup_subsku_delete(entity.GetColumn('UID_AADGroup').GetValue(), entity.GetColumn('UID_AADSubSku').GetValue());
            };
        }
        PortalTargetsystemAadgroupSubskuWrapper.prototype.createEntity = function (initialData) {
            this.buildBuilderIfNeeded();
            return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, imxQbmDbts.EntityState.Created);
        };
        /** Returns the runtime schema for this method. */
        PortalTargetsystemAadgroupSubskuWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/aadgroup/{UID_AADGroup}/subsku');
        };
        PortalTargetsystemAadgroupSubskuWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/aadgroup/{UID_AADGroup}/subsku');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemAadgroupSubsku, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemAadgroupSubskuWrapper.prototype.Get = function (UID_AADGroup, parametersOptional) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_subsku_get(UID_AADGroup, parametersOptional)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemAadgroupSubskuWrapper.prototype.Put = function (UID_AADGroup, inputParameterName) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_subsku_put(UID_AADGroup, inputParameterName.EntityWriteData)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemAadgroupSubskuWrapper.prototype.Post = function (UID_AADGroup, inputParameterName) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_subsku_post(UID_AADGroup, inputParameterName.EntityWriteData)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemAadgroupSubskuWrapper.prototype.Delete = function (UID_AADGroup, UID_AADSubSku) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_subsku_delete(UID_AADGroup, UID_AADSubSku)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemAadgroupSubskuWrapper;
    }());
    var PortalTargetsystemAaduserDeniedserviceplansWrapper = /** @class */ (function () {
        function PortalTargetsystemAaduserDeniedserviceplansWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                if (entity.GetState() == imxQbmDbts.EntityState.Created) {
                    return _this.client.portal_targetsystem_aaduser_deniedserviceplans_post(entity.GetColumn('UID_AADUser').GetValue(), writeData);
                }
                return _this.client.portal_targetsystem_aaduser_deniedserviceplans_put(entity.GetColumn('UID_AADUser').GetValue(), writeData);
            };
            this.deleteMethod = function (entity) {
                return _this.client.portal_targetsystem_aaduser_deniedserviceplans_delete(entity.GetColumn('UID_AADUser').GetValue(), entity.GetColumn('UID_AADDeniedServicePlan').GetValue());
            };
        }
        PortalTargetsystemAaduserDeniedserviceplansWrapper.prototype.createEntity = function (initialData) {
            this.buildBuilderIfNeeded();
            return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, imxQbmDbts.EntityState.Created);
        };
        /** Returns the runtime schema for this method. */
        PortalTargetsystemAaduserDeniedserviceplansWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans');
        };
        PortalTargetsystemAaduserDeniedserviceplansWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemAaduserDeniedserviceplans, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemAaduserDeniedserviceplansWrapper.prototype.Get = function (UID_AADUser, parametersOptional) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaduser_deniedserviceplans_get(UID_AADUser, parametersOptional)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemAaduserDeniedserviceplansWrapper.prototype.Put = function (UID_AADUser, inputParameterName) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaduser_deniedserviceplans_put(UID_AADUser, inputParameterName.EntityWriteData)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemAaduserDeniedserviceplansWrapper.prototype.Post = function (UID_AADUser, inputParameterName) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaduser_deniedserviceplans_post(UID_AADUser, inputParameterName.EntityWriteData)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemAaduserDeniedserviceplansWrapper.prototype.Delete = function (UID_AADUser, UID_AADDeniedServicePlan) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaduser_deniedserviceplans_delete(UID_AADUser, UID_AADDeniedServicePlan)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemAaduserDeniedserviceplansWrapper;
    }());
    var PortalTargetsystemAaduserSubskuWrapper = /** @class */ (function () {
        function PortalTargetsystemAaduserSubskuWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                if (entity.GetState() == imxQbmDbts.EntityState.Created) {
                    return _this.client.portal_targetsystem_aaduser_subsku_post(entity.GetColumn('UID_AADUser').GetValue(), writeData);
                }
                return _this.client.portal_targetsystem_aaduser_subsku_put(entity.GetColumn('UID_AADUser').GetValue(), writeData);
            };
            this.deleteMethod = function (entity) {
                return _this.client.portal_targetsystem_aaduser_subsku_delete(entity.GetColumn('UID_AADUser').GetValue(), entity.GetColumn('UID_AADUserHasSubSku').GetValue());
            };
        }
        PortalTargetsystemAaduserSubskuWrapper.prototype.createEntity = function (initialData) {
            this.buildBuilderIfNeeded();
            return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, imxQbmDbts.EntityState.Created);
        };
        /** Returns the runtime schema for this method. */
        PortalTargetsystemAaduserSubskuWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/aaduser/{UID_AADUser}/subsku');
        };
        PortalTargetsystemAaduserSubskuWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/aaduser/{UID_AADUser}/subsku');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemAaduserSubsku, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemAaduserSubskuWrapper.prototype.Get = function (UID_AADUser, parametersOptional) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaduser_subsku_get(UID_AADUser, parametersOptional)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemAaduserSubskuWrapper.prototype.Put = function (UID_AADUser, inputParameterName) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaduser_subsku_put(UID_AADUser, inputParameterName.EntityWriteData)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemAaduserSubskuWrapper.prototype.Post = function (UID_AADUser, inputParameterName) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaduser_subsku_post(UID_AADUser, inputParameterName.EntityWriteData)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemAaduserSubskuWrapper.prototype.Delete = function (UID_AADUser, UID_AADUserHasSubSku) {
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaduser_subsku_delete(UID_AADUser, UID_AADUserHasSubSku)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemAaduserSubskuWrapper;
    }());
    /** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
    var ApiClientMethodFactory = /** @class */ (function () {
        function ApiClientMethodFactory() {
        }
        ApiClientMethodFactory.prototype.portal_AADDirectoryRole_memberships_get = function (uid) {
            return {
                path: '/portal/AADDirectoryRole/{uid}/memberships',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_AADDirectoryRole_memberships_delete = function (uid, uidaccount) {
            return {
                path: '/portal/AADDirectoryRole/{uid}/memberships/{uidaccount}',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_AADGroup_memberships_get = function (uid) {
            return {
                path: '/portal/AADGroup/{uid}/memberships',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_AADGroup_memberships_delete = function (uid, uidaccount) {
            return {
                path: '/portal/AADGroup/{uid}/memberships/{uidaccount}',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_AADSubSku_memberships_get = function (uid) {
            return {
                path: '/portal/AADSubSku/{uid}/memberships',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_AADSubSku_memberships_delete = function (uid, uidaccount) {
            return {
                path: '/portal/AADSubSku/{uid}/memberships/{uidaccount}',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_post = function (UID_ITShopOrg, inputParameterName) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_delete = function (UID_ITShopOrg, UID_AADDeniedServicePlan) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/{UID_AADDeniedServicePlan}',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_AADDeniedServicePlan',
                        value: UID_AADDeniedServicePlan,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates/datamodel',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates/datamodel',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates/datamodel',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates/datamodel',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_get = function (UID_AADGroup, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans',
                parameters: [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_put = function (UID_AADGroup, inputParameterName) {
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans',
                parameters: [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_post = function (UID_AADGroup, inputParameterName) {
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans',
                parameters: [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_delete = function (UID_AADGroup, UID_AADDeniedServicePlan) {
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/{UID_AADDeniedServicePlan}',
                parameters: [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_AADDeniedServicePlan',
                        value: UID_AADDeniedServicePlan,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_bulk_put = function (UID_AADGroup, inputParameterName) {
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/bulk',
                parameters: [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get = function (UID_AADGroup, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates',
                parameters: [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'xorigin',
                        value: xorigin,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get = function (UID_AADGroup, filter) {
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates/datamodel',
                parameters: [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post = function (UID_AADGroup, xorigin, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'xorigin',
                        value: xorigin,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_get = function (UID_AADGroup, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku',
                parameters: [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_put = function (UID_AADGroup, inputParameterName) {
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku',
                parameters: [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_post = function (UID_AADGroup, inputParameterName) {
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku',
                parameters: [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_delete = function (UID_AADGroup, UID_AADSubSku) {
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku/{UID_AADSubSku}',
                parameters: [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_AADSubSku',
                        value: UID_AADSubSku,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_bulk_put = function (UID_AADGroup, inputParameterName) {
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku/bulk',
                parameters: [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get = function (UID_AADGroup, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates',
                parameters: [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'xorigin',
                        value: xorigin,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get = function (UID_AADGroup, filter) {
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates/datamodel',
                parameters: [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post = function (UID_AADGroup, xorigin, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'xorigin',
                        value: xorigin,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aadsubsku_licenceoverview_get = function (UID_AADSubSku) {
            return {
                path: '/portal/targetsystem/aadsubsku/{UID_AADSubSku}/licenceoverview',
                parameters: [
                    {
                        name: 'UID_AADSubSku',
                        value: UID_AADSubSku,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_get = function (UID_AADUser, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans',
                parameters: [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_put = function (UID_AADUser, inputParameterName) {
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans',
                parameters: [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_post = function (UID_AADUser, inputParameterName) {
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans',
                parameters: [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_delete = function (UID_AADUser, UID_AADDeniedServicePlan) {
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/{UID_AADDeniedServicePlan}',
                parameters: [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_AADDeniedServicePlan',
                        value: UID_AADDeniedServicePlan,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_bulk_put = function (UID_AADUser, inputParameterName) {
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/bulk',
                parameters: [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get = function (UID_AADUser, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates',
                parameters: [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'xorigin',
                        value: xorigin,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get = function (UID_AADUser, filter) {
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates/datamodel',
                parameters: [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post = function (UID_AADUser, xorigin, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'xorigin',
                        value: xorigin,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_get = function (UID_AADUser, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku',
                parameters: [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_put = function (UID_AADUser, inputParameterName) {
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku',
                parameters: [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_post = function (UID_AADUser, inputParameterName) {
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku',
                parameters: [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_delete = function (UID_AADUser, UID_AADUserHasSubSku) {
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku/{UID_AADUserHasSubSku}',
                parameters: [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_AADUserHasSubSku',
                        value: UID_AADUserHasSubSku,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_bulk_put = function (UID_AADUser, inputParameterName) {
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku/bulk',
                parameters: [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get = function (UID_AADUser, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates',
                parameters: [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'xorigin',
                        value: xorigin,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get = function (UID_AADUser, filter) {
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates/datamodel',
                parameters: [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post = function (UID_AADUser, xorigin, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'xorigin',
                        value: xorigin,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        return ApiClientMethodFactory;
    }());
    /** @deprecated Use the V2Client class for a stable method interface. */
    var Client = /** @class */ (function () {
        function Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        Client.prototype.portal_AADDirectoryRole_memberships_get = function (uid) {
            return this.apiClient.processRequest(this.methodFactory.portal_AADDirectoryRole_memberships_get(uid));
        };
        /** Deletes an account membership. */
        Client.prototype.portal_AADDirectoryRole_memberships_delete = function (uid, uidaccount) {
            return this.apiClient.processRequest(this.methodFactory.portal_AADDirectoryRole_memberships_delete(uid, uidaccount));
        };
        Client.prototype.portal_AADGroup_memberships_get = function (uid) {
            return this.apiClient.processRequest(this.methodFactory.portal_AADGroup_memberships_get(uid));
        };
        /** Deletes an account membership. */
        Client.prototype.portal_AADGroup_memberships_delete = function (uid, uidaccount) {
            return this.apiClient.processRequest(this.methodFactory.portal_AADGroup_memberships_delete(uid, uidaccount));
        };
        Client.prototype.portal_AADSubSku_memberships_get = function (uid) {
            return this.apiClient.processRequest(this.methodFactory.portal_AADSubSku_memberships_get(uid));
        };
        /** Deletes an account membership. */
        Client.prototype.portal_AADSubSku_memberships_delete = function (uid, uidaccount) {
            return this.apiClient.processRequest(this.methodFactory.portal_AADSubSku_memberships_delete(uid, uidaccount));
        };
        Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_post = function (UID_ITShopOrg, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_post(UID_ITShopOrg, inputParameterName));
        };
        Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_delete = function (UID_ITShopOrg, UID_AADDeniedServicePlan) {
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_delete(UID_ITShopOrg, UID_AADDeniedServicePlan));
        };
        /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
        Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_ITShopOrg, filter));
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName));
        };
        /** Returns a list of objects that can be assigned to the property UID_AADDirectoryRole. */
        Client.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get(UID_ITShopOrg, filter));
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName));
        };
        /** Returns a list of objects that can be assigned to the property UID_AADGroup. */
        Client.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get(UID_ITShopOrg, filter));
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName));
        };
        /** Returns a list of objects that can be assigned to the property UID_AADSubSku. */
        Client.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get(UID_ITShopOrg, filter));
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName));
        };
        Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_get = function (UID_AADGroup, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_get(UID_AADGroup, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_put = function (UID_AADGroup, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_put(UID_AADGroup, inputParameterName));
        };
        Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_post = function (UID_AADGroup, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_post(UID_AADGroup, inputParameterName));
        };
        Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_delete = function (UID_AADGroup, UID_AADDeniedServicePlan) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_delete(UID_AADGroup, UID_AADDeniedServicePlan));
        };
        Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_bulk_put = function (UID_AADGroup, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_bulk_put(UID_AADGroup, inputParameterName));
        };
        /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
        Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get = function (UID_AADGroup, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(UID_AADGroup, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        /** Returns data model information about query options for the targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
        Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get = function (UID_AADGroup, filter) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_AADGroup, filter));
        };
        /** Returns filter tree information for the targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
        Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post = function (UID_AADGroup, xorigin, filter, parentkey, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_AADGroup, xorigin, filter, parentkey, inputParameterName));
        };
        Client.prototype.portal_targetsystem_aadgroup_subsku_get = function (UID_AADGroup, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_get(UID_AADGroup, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        Client.prototype.portal_targetsystem_aadgroup_subsku_put = function (UID_AADGroup, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_put(UID_AADGroup, inputParameterName));
        };
        Client.prototype.portal_targetsystem_aadgroup_subsku_post = function (UID_AADGroup, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_post(UID_AADGroup, inputParameterName));
        };
        Client.prototype.portal_targetsystem_aadgroup_subsku_delete = function (UID_AADGroup, UID_AADSubSku) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_delete(UID_AADGroup, UID_AADSubSku));
        };
        Client.prototype.portal_targetsystem_aadgroup_subsku_bulk_put = function (UID_AADGroup, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_bulk_put(UID_AADGroup, inputParameterName));
        };
        /** Returns a list of objects that can be assigned to the property UID_AADSubSku. */
        Client.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get = function (UID_AADGroup, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get(UID_AADGroup, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        /** Returns data model information about query options for the targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates endpoint. */
        Client.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get = function (UID_AADGroup, filter) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get(UID_AADGroup, filter));
        };
        /** Returns filter tree information for the targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates endpoint. */
        Client.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post = function (UID_AADGroup, xorigin, filter, parentkey, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post(UID_AADGroup, xorigin, filter, parentkey, inputParameterName));
        };
        Client.prototype.portal_targetsystem_aadsubsku_licenceoverview_get = function (UID_AADSubSku) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadsubsku_licenceoverview_get(UID_AADSubSku));
        };
        Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_get = function (UID_AADUser, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_get(UID_AADUser, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_put = function (UID_AADUser, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_put(UID_AADUser, inputParameterName));
        };
        Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_post = function (UID_AADUser, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_post(UID_AADUser, inputParameterName));
        };
        Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_delete = function (UID_AADUser, UID_AADDeniedServicePlan) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_delete(UID_AADUser, UID_AADDeniedServicePlan));
        };
        Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_bulk_put = function (UID_AADUser, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_bulk_put(UID_AADUser, inputParameterName));
        };
        /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
        Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get = function (UID_AADUser, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(UID_AADUser, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        /** Returns data model information about query options for the targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
        Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get = function (UID_AADUser, filter) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_AADUser, filter));
        };
        /** Returns filter tree information for the targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
        Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post = function (UID_AADUser, xorigin, filter, parentkey, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_AADUser, xorigin, filter, parentkey, inputParameterName));
        };
        Client.prototype.portal_targetsystem_aaduser_subsku_get = function (UID_AADUser, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_get(UID_AADUser, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        Client.prototype.portal_targetsystem_aaduser_subsku_put = function (UID_AADUser, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_put(UID_AADUser, inputParameterName));
        };
        Client.prototype.portal_targetsystem_aaduser_subsku_post = function (UID_AADUser, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_post(UID_AADUser, inputParameterName));
        };
        Client.prototype.portal_targetsystem_aaduser_subsku_delete = function (UID_AADUser, UID_AADUserHasSubSku) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_delete(UID_AADUser, UID_AADUserHasSubSku));
        };
        Client.prototype.portal_targetsystem_aaduser_subsku_bulk_put = function (UID_AADUser, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_bulk_put(UID_AADUser, inputParameterName));
        };
        /** Returns a list of objects that can be assigned to the property ObjectKeyAADSubSku. */
        Client.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get = function (UID_AADUser, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get(UID_AADUser, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search));
        };
        /** Returns data model information about query options for the targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates endpoint. */
        Client.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get = function (UID_AADUser, filter) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get(UID_AADUser, filter));
        };
        /** Returns filter tree information for the targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates endpoint. */
        Client.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post = function (UID_AADUser, xorigin, filter, parentkey, inputParameterName) {
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post(UID_AADUser, xorigin, filter, parentkey, inputParameterName));
        };
        return Client;
    }());
    var V2ApiClientMethodFactory = /** @class */ (function () {
        function V2ApiClientMethodFactory() {
        }
        V2ApiClientMethodFactory.prototype.portal_AADDirectoryRole_memberships_get = function (uid, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/AADDirectoryRole/{uid}/memberships',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_AADDirectoryRole_memberships_delete = function (uid, uidaccount, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/AADDirectoryRole/{uid}/memberships/{uidaccount}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_AADGroup_memberships_get = function (uid, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/AADGroup/{uid}/memberships',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_AADGroup_memberships_delete = function (uid, uidaccount, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/AADGroup/{uid}/memberships/{uidaccount}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_AADSubSku_memberships_get = function (uid, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/AADSubSku/{uid}/memberships',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_AADSubSku_memberships_delete = function (uid, uidaccount, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/AADSubSku/{uid}/memberships/{uidaccount}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_get = function (UID_ITShopOrg, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_post = function (UID_ITShopOrg, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_delete = function (UID_ITShopOrg, UID_AADDeniedServicePlan, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/{UID_AADDeniedServicePlan}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_AADDeniedServicePlan',
                        value: UID_AADDeniedServicePlan,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get = function (UID_ITShopOrg, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get = function (UID_ITShopOrg, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post = function (UID_ITShopOrg, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get = function (UID_ITShopOrg, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get = function (UID_ITShopOrg, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post = function (UID_ITShopOrg, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get = function (UID_ITShopOrg, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get = function (UID_ITShopOrg, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post = function (UID_ITShopOrg, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get = function (UID_ITShopOrg, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get = function (UID_ITShopOrg, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post = function (UID_ITShopOrg, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_get = function (UID_AADGroup, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_put = function (UID_AADGroup, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_post = function (UID_AADGroup, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_delete = function (UID_AADGroup, UID_AADDeniedServicePlan, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/{UID_AADDeniedServicePlan}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_AADDeniedServicePlan',
                        value: UID_AADDeniedServicePlan,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_bulk_put = function (UID_AADGroup, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/bulk',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get = function (UID_AADGroup, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get = function (UID_AADGroup, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post = function (UID_AADGroup, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_get = function (UID_AADGroup, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_put = function (UID_AADGroup, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_post = function (UID_AADGroup, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_delete = function (UID_AADGroup, UID_AADSubSku, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku/{UID_AADSubSku}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_AADSubSku',
                        value: UID_AADSubSku,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_bulk_put = function (UID_AADGroup, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku/bulk',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get = function (UID_AADGroup, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get = function (UID_AADGroup, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post = function (UID_AADGroup, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADGroup',
                        value: UID_AADGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aadsubsku_licenceoverview_get = function (UID_AADSubSku, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aadsubsku/{UID_AADSubSku}/licenceoverview',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADSubSku',
                        value: UID_AADSubSku,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_get = function (UID_AADUser, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_put = function (UID_AADUser, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_post = function (UID_AADUser, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_delete = function (UID_AADUser, UID_AADDeniedServicePlan, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/{UID_AADDeniedServicePlan}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_AADDeniedServicePlan',
                        value: UID_AADDeniedServicePlan,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_bulk_put = function (UID_AADUser, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/bulk',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get = function (UID_AADUser, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get = function (UID_AADUser, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post = function (UID_AADUser, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_get = function (UID_AADUser, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_put = function (UID_AADUser, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_post = function (UID_AADUser, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_delete = function (UID_AADUser, UID_AADUserHasSubSku, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku/{UID_AADUserHasSubSku}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_AADUserHasSubSku',
                        value: UID_AADUserHasSubSku,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_bulk_put = function (UID_AADUser, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku/bulk',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get = function (UID_AADUser, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get = function (UID_AADUser, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post = function (UID_AADUser, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AADUser',
                        value: UID_AADUser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        return V2ApiClientMethodFactory;
    }());
    var V2Client = /** @class */ (function () {
        function V2Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new V2ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(V2Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        V2Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        V2Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        V2Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        V2Client.prototype.portal_AADDirectoryRole_memberships_get = function (uid, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_AADDirectoryRole_memberships_get(uid, options));
        };
        /** Deletes an account membership. */
        V2Client.prototype.portal_AADDirectoryRole_memberships_delete = function (uid, uidaccount, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_AADDirectoryRole_memberships_delete(uid, uidaccount, options));
        };
        V2Client.prototype.portal_AADGroup_memberships_get = function (uid, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_AADGroup_memberships_get(uid, options));
        };
        /** Deletes an account membership. */
        V2Client.prototype.portal_AADGroup_memberships_delete = function (uid, uidaccount, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_AADGroup_memberships_delete(uid, uidaccount, options));
        };
        V2Client.prototype.portal_AADSubSku_memberships_get = function (uid, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_AADSubSku_memberships_get(uid, options));
        };
        /** Deletes an account membership. */
        V2Client.prototype.portal_AADSubSku_memberships_delete = function (uid, uidaccount, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_AADSubSku_memberships_delete(uid, uidaccount, options));
        };
        V2Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_get = function (UID_ITShopOrg, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_get(UID_ITShopOrg, options));
        };
        V2Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_post = function (UID_ITShopOrg, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_post(UID_ITShopOrg, inputParameterName, options));
        };
        V2Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_delete = function (UID_ITShopOrg, UID_AADDeniedServicePlan, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_delete(UID_ITShopOrg, UID_AADDeniedServicePlan, options));
        };
        /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
        V2Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get = function (UID_ITShopOrg, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get(UID_ITShopOrg, options));
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get = function (UID_ITShopOrg, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_ITShopOrg, options));
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post = function (UID_ITShopOrg, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options));
        };
        /** Returns a list of objects that can be assigned to the property UID_AADDirectoryRole. */
        V2Client.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get = function (UID_ITShopOrg, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get(UID_ITShopOrg, options));
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get = function (UID_ITShopOrg, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get(UID_ITShopOrg, options));
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post = function (UID_ITShopOrg, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options));
        };
        /** Returns a list of objects that can be assigned to the property UID_AADGroup. */
        V2Client.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get = function (UID_ITShopOrg, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get(UID_ITShopOrg, options));
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get = function (UID_ITShopOrg, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get(UID_ITShopOrg, options));
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post = function (UID_ITShopOrg, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options));
        };
        /** Returns a list of objects that can be assigned to the property UID_AADSubSku. */
        V2Client.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get = function (UID_ITShopOrg, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get(UID_ITShopOrg, options));
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get = function (UID_ITShopOrg, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get(UID_ITShopOrg, options));
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post = function (UID_ITShopOrg, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options));
        };
        V2Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_get = function (UID_AADGroup, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_get(UID_AADGroup, options));
        };
        V2Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_put = function (UID_AADGroup, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_put(UID_AADGroup, inputParameterName, options));
        };
        V2Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_post = function (UID_AADGroup, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_post(UID_AADGroup, inputParameterName, options));
        };
        V2Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_delete = function (UID_AADGroup, UID_AADDeniedServicePlan, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_delete(UID_AADGroup, UID_AADDeniedServicePlan, options));
        };
        V2Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_bulk_put = function (UID_AADGroup, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_bulk_put(UID_AADGroup, inputParameterName, options));
        };
        /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
        V2Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get = function (UID_AADGroup, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(UID_AADGroup, options));
        };
        /** Returns data model information about query options for the targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
        V2Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get = function (UID_AADGroup, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_AADGroup, options));
        };
        /** Returns filter tree information for the targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
        V2Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post = function (UID_AADGroup, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_AADGroup, inputParameterName, options));
        };
        V2Client.prototype.portal_targetsystem_aadgroup_subsku_get = function (UID_AADGroup, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_get(UID_AADGroup, options));
        };
        V2Client.prototype.portal_targetsystem_aadgroup_subsku_put = function (UID_AADGroup, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_put(UID_AADGroup, inputParameterName, options));
        };
        V2Client.prototype.portal_targetsystem_aadgroup_subsku_post = function (UID_AADGroup, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_post(UID_AADGroup, inputParameterName, options));
        };
        V2Client.prototype.portal_targetsystem_aadgroup_subsku_delete = function (UID_AADGroup, UID_AADSubSku, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_delete(UID_AADGroup, UID_AADSubSku, options));
        };
        V2Client.prototype.portal_targetsystem_aadgroup_subsku_bulk_put = function (UID_AADGroup, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_bulk_put(UID_AADGroup, inputParameterName, options));
        };
        /** Returns a list of objects that can be assigned to the property UID_AADSubSku. */
        V2Client.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get = function (UID_AADGroup, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get(UID_AADGroup, options));
        };
        /** Returns data model information about query options for the targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates endpoint. */
        V2Client.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get = function (UID_AADGroup, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get(UID_AADGroup, options));
        };
        /** Returns filter tree information for the targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates endpoint. */
        V2Client.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post = function (UID_AADGroup, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post(UID_AADGroup, inputParameterName, options));
        };
        V2Client.prototype.portal_targetsystem_aadsubsku_licenceoverview_get = function (UID_AADSubSku, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadsubsku_licenceoverview_get(UID_AADSubSku, options));
        };
        V2Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_get = function (UID_AADUser, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_get(UID_AADUser, options));
        };
        V2Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_put = function (UID_AADUser, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_put(UID_AADUser, inputParameterName, options));
        };
        V2Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_post = function (UID_AADUser, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_post(UID_AADUser, inputParameterName, options));
        };
        V2Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_delete = function (UID_AADUser, UID_AADDeniedServicePlan, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_delete(UID_AADUser, UID_AADDeniedServicePlan, options));
        };
        V2Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_bulk_put = function (UID_AADUser, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_bulk_put(UID_AADUser, inputParameterName, options));
        };
        /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
        V2Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get = function (UID_AADUser, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(UID_AADUser, options));
        };
        /** Returns data model information about query options for the targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
        V2Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get = function (UID_AADUser, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_AADUser, options));
        };
        /** Returns filter tree information for the targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
        V2Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post = function (UID_AADUser, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_AADUser, inputParameterName, options));
        };
        V2Client.prototype.portal_targetsystem_aaduser_subsku_get = function (UID_AADUser, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_get(UID_AADUser, options));
        };
        V2Client.prototype.portal_targetsystem_aaduser_subsku_put = function (UID_AADUser, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_put(UID_AADUser, inputParameterName, options));
        };
        V2Client.prototype.portal_targetsystem_aaduser_subsku_post = function (UID_AADUser, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_post(UID_AADUser, inputParameterName, options));
        };
        V2Client.prototype.portal_targetsystem_aaduser_subsku_delete = function (UID_AADUser, UID_AADUserHasSubSku, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_delete(UID_AADUser, UID_AADUserHasSubSku, options));
        };
        V2Client.prototype.portal_targetsystem_aaduser_subsku_bulk_put = function (UID_AADUser, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_bulk_put(UID_AADUser, inputParameterName, options));
        };
        /** Returns a list of objects that can be assigned to the property ObjectKeyAADSubSku. */
        V2Client.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get = function (UID_AADUser, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get(UID_AADUser, options));
        };
        /** Returns data model information about query options for the targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates endpoint. */
        V2Client.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get = function (UID_AADUser, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get(UID_AADUser, options));
        };
        /** Returns filter tree information for the targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates endpoint. */
        V2Client.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post = function (UID_AADUser, inputParameterName, options) {
            if (options === void 0) { options = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post(UID_AADUser, inputParameterName, options));
        };
        return V2Client;
    }());

    exports.ApiClientMethodFactory = ApiClientMethodFactory;
    exports.Client = Client;
    exports.PortalAaddirectoryroleMemberships = PortalAaddirectoryroleMemberships;
    exports.PortalAaddirectoryroleMembershipsWrapper = PortalAaddirectoryroleMembershipsWrapper;
    exports.PortalAadgroupMemberships = PortalAadgroupMemberships;
    exports.PortalAadgroupMembershipsWrapper = PortalAadgroupMembershipsWrapper;
    exports.PortalAadsubskuMemberships = PortalAadsubskuMemberships;
    exports.PortalAadsubskuMembershipsWrapper = PortalAadsubskuMembershipsWrapper;
    exports.PortalShopConfigEntitlementsAaddeniedserviceplan = PortalShopConfigEntitlementsAaddeniedserviceplan;
    exports.PortalShopConfigEntitlementsAaddeniedserviceplanWrapper = PortalShopConfigEntitlementsAaddeniedserviceplanWrapper;
    exports.PortalTargetsystemAadgroupDeniedserviceplans = PortalTargetsystemAadgroupDeniedserviceplans;
    exports.PortalTargetsystemAadgroupDeniedserviceplansWrapper = PortalTargetsystemAadgroupDeniedserviceplansWrapper;
    exports.PortalTargetsystemAadgroupSubsku = PortalTargetsystemAadgroupSubsku;
    exports.PortalTargetsystemAadgroupSubskuWrapper = PortalTargetsystemAadgroupSubskuWrapper;
    exports.PortalTargetsystemAaduserDeniedserviceplans = PortalTargetsystemAaduserDeniedserviceplans;
    exports.PortalTargetsystemAaduserDeniedserviceplansWrapper = PortalTargetsystemAaduserDeniedserviceplansWrapper;
    exports.PortalTargetsystemAaduserSubsku = PortalTargetsystemAaduserSubsku;
    exports.PortalTargetsystemAaduserSubskuWrapper = PortalTargetsystemAaduserSubskuWrapper;
    exports.TypedClient = TypedClient;
    exports.V2ApiClientMethodFactory = V2ApiClientMethodFactory;
    exports.V2Client = V2Client;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
