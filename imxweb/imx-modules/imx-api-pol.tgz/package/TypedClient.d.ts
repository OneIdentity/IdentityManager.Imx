import { ApiClient, ApiRequestOptions, DataModel, EntityCollectionData, EntitySchema, FilterData, FkProviderItem, GroupInfo, IReadValue, MethodDescriptor, StaticSchema, TypedEntity } from 'imx-qbm-dbts';
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface PolicyViolationDecisionInput {
    ExceptionValidUntil?: Date;
    Reason?: string;
    UidJustification?: string;
    Decision: boolean;
}
export declare class TypedClient {
    readonly PortalPolicies: PortalPoliciesWrapper;
    readonly PortalPoliciesViolationsApprove: PortalPoliciesViolationsApproveWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalPolicies extends TypedEntity {
    readonly Description: IReadValue<string>;
    readonly Ident_QERPolicy: IReadValue<string>;
    readonly IsExceptionAllowed: IReadValue<boolean>;
    readonly IsInActive: IReadValue<boolean>;
    readonly IsWorkingCopy: IReadValue<boolean>;
    readonly RiskIndex: IReadValue<number>;
    readonly RiskIndexReduced: IReadValue<number>;
    readonly RuleSeverity: IReadValue<number>;
    readonly RuleViolationThreshold: IReadValue<number>;
    readonly SignificancyClass: IReadValue<number>;
    readonly StateInfo: IReadValue<string>;
    readonly TransparencyIndex: IReadValue<number>;
    readonly UID_AERoleAttestator: IReadValue<string>;
    readonly UID_AERoleResponsible: IReadValue<string>;
    readonly UID_AERoleRuler: IReadValue<string>;
    readonly UID_DialogReport: IReadValue<string>;
    readonly UID_DialogTable: IReadValue<string>;
    readonly UID_QERPolicy: IReadValue<string>;
    readonly UID_QERPolicyGroup: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'Description' | 'Ident_QERPolicy' | 'IsExceptionAllowed' | 'IsInActive' | 'IsWorkingCopy' | 'RiskIndex' | 'RiskIndexReduced' | 'RuleSeverity' | 'RuleViolationThreshold' | 'SignificancyClass' | 'StateInfo' | 'TransparencyIndex' | 'UID_AERoleAttestator' | 'UID_AERoleResponsible' | 'UID_AERoleRuler' | 'UID_DialogReport' | 'UID_DialogTable' | 'UID_QERPolicy' | 'UID_QERPolicyGroup'>;
}
export declare class PortalPoliciesViolationsApprove extends TypedEntity {
    readonly XDateInserted: IReadValue<Date>;
    readonly DecisionDate: IReadValue<Date>;
    readonly DecisionReason: IReadValue<string>;
    readonly UID_QERPolicy: IReadValue<string>;
    readonly ObjectKey: IReadValue<string>;
    readonly UID_PersonDecisionMade: IReadValue<string>;
    readonly UID_QERJustification: IReadValue<string>;
    readonly State: IReadValue<string>;
    readonly Description: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'XDateInserted' | 'DecisionDate' | 'DecisionReason' | 'UID_QERPolicy' | 'ObjectKey' | 'UID_PersonDecisionMade' | 'UID_QERJustification' | 'State' | 'Description'>;
}
export declare class PortalPoliciesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPolicies, unknown>>;
}
export declare class PortalPoliciesViolationsApproveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        state?: string;
        uid_qerpolicy?: string;
    }, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPoliciesViolationsApprove, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    portal_policies_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_policies_violations_approve_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, state: string, uid_qerpolicy: string): MethodDescriptor<EntityCollectionData>;
    portal_policies_violations_approve_post(uidviolation: string, inputParameterName: PolicyViolationDecisionInput): MethodDescriptor<void>;
    portal_policies_violations_approve_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_policies_violations_approve_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, state: string, uid_qerpolicy: string): MethodDescriptor<GroupInfo[]>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_policies_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_policies_violations_approve_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, state: string, uid_qerpolicy: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_policies_violations_approve_post(uidviolation: string, inputParameterName: PolicyViolationDecisionInput, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the policies/violations/approve endpoint. */
    portal_policies_violations_approve_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_policies_violations_approve_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, state: string, uid_qerpolicy: string, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
}
export declare class V2ApiClientMethodFactory {
    portal_policies_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_policies_violations_approve_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        state?: string;
        uid_qerpolicy?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_policies_violations_approve_post(uidviolation: string, inputParameterName: PolicyViolationDecisionInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_policies_violations_approve_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_policies_violations_approve_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
        state?: string;
        uid_qerpolicy?: string;
    }, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfo[]>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_policies_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_policies_violations_approve_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        state?: string;
        uid_qerpolicy?: string;
    }, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_policies_violations_approve_post(uidviolation: string, inputParameterName: PolicyViolationDecisionInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the policies/violations/approve endpoint. */
    portal_policies_violations_approve_datamodel_get(options?: {
        filter?: FilterData[];
    }, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_policies_violations_approve_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
        state?: string;
        uid_qerpolicy?: string;
    }, requestOptions?: ApiRequestOptions): Promise<GroupInfo[]>;
}
