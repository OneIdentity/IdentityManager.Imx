(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('imx-qbm-dbts')) :
    typeof define === 'function' && define.amd ? define(['exports', 'imx-qbm-dbts'], factory) :
    (global = global || self, factory(global['imx-api'] = {}, global.imxQbmDbts));
}(this, (function (exports, imxQbmDbts) { 'use strict';

    var __extends = (undefined && undefined.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    };
    var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    };
    var TypedClient = /** @class */ (function () {
        function TypedClient(client, translationProvider) {
            this.PortalCandidatesMitigatingcontrol = new PortalCandidatesMitigatingcontrolWrapper(client, translationProvider);
            this.PortalPolicies = new PortalPoliciesWrapper(client, translationProvider);
            this.PortalPoliciesMitigatingcontrols = new PortalPoliciesMitigatingcontrolsWrapper(client, translationProvider);
            this.PortalPoliciesViolations = new PortalPoliciesViolationsWrapper(client, translationProvider);
            this.PortalPoliciesViolationslist = new PortalPoliciesViolationslistWrapper(client, translationProvider);
        }
        return TypedClient;
    }());
    var PortalCandidatesMitigatingcontrol = /** @class */ (function (_super) {
        __extends(PortalCandidatesMitigatingcontrol, _super);
        function PortalCandidatesMitigatingcontrol() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.UID_MitigatingControl = _this.GetEntityValue('UID_MitigatingControl');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalCandidatesMitigatingcontrol.GetEntitySchema = function () {
            var columns = {
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_MitigatingControl': {
                    ColumnName: 'UID_MitigatingControl',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'MitigatingControl', Columns: columns };
        };
        return PortalCandidatesMitigatingcontrol;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalCandidatesMitigatingcontrol type. */
    var PortalCandidatesMitigatingcontrolInteractive = /** @class */ (function (_super) {
        __extends(PortalCandidatesMitigatingcontrolInteractive, _super);
        function PortalCandidatesMitigatingcontrolInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalCandidatesMitigatingcontrolInteractive;
    }(PortalCandidatesMitigatingcontrol));
    var PortalPolicies = /** @class */ (function (_super) {
        __extends(PortalPolicies, _super);
        function PortalPolicies() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.Description = _this.GetEntityValue('Description');
            _this.Ident_QERPolicy = _this.GetEntityValue('Ident_QERPolicy');
            _this.IsExceptionAllowed = _this.GetEntityValue('IsExceptionAllowed');
            _this.IsInActive = _this.GetEntityValue('IsInActive');
            _this.IsWorkingCopy = _this.GetEntityValue('IsWorkingCopy');
            _this.RiskIndex = _this.GetEntityValue('RiskIndex');
            _this.RiskIndexReduced = _this.GetEntityValue('RiskIndexReduced');
            _this.RuleSeverity = _this.GetEntityValue('RuleSeverity');
            _this.RuleViolationThreshold = _this.GetEntityValue('RuleViolationThreshold');
            _this.SignificancyClass = _this.GetEntityValue('SignificancyClass');
            _this.StateInfo = _this.GetEntityValue('StateInfo');
            _this.TransparencyIndex = _this.GetEntityValue('TransparencyIndex');
            _this.UID_AERoleAttestator = _this.GetEntityValue('UID_AERoleAttestator');
            _this.UID_AERoleResponsible = _this.GetEntityValue('UID_AERoleResponsible');
            _this.UID_AERoleRuler = _this.GetEntityValue('UID_AERoleRuler');
            _this.UID_DialogReport = _this.GetEntityValue('UID_DialogReport');
            _this.UID_DialogTable = _this.GetEntityValue('UID_DialogTable');
            _this.UID_QERPolicy = _this.GetEntityValue('UID_QERPolicy');
            _this.UID_QERPolicyWork = _this.GetEntityValue('UID_QERPolicyWork');
            _this.UID_QERPolicyGroup = _this.GetEntityValue('UID_QERPolicyGroup');
            _this.CountOpen = _this.GetEntityValue('CountOpen');
            _this.CountClosed = _this.GetEntityValue('CountClosed');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalPolicies.GetEntitySchema = function () {
            var columns = {
                'Description': {
                    ColumnName: 'Description',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Ident_QERPolicy': {
                    ColumnName: 'Ident_QERPolicy',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'IsExceptionAllowed': {
                    ColumnName: 'IsExceptionAllowed',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsInActive': {
                    ColumnName: 'IsInActive',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsWorkingCopy': {
                    ColumnName: 'IsWorkingCopy',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'RiskIndex': {
                    ColumnName: 'RiskIndex',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'RiskIndexReduced': {
                    ColumnName: 'RiskIndexReduced',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'RuleSeverity': {
                    ColumnName: 'RuleSeverity',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'RuleViolationThreshold': {
                    ColumnName: 'RuleViolationThreshold',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'SignificancyClass': {
                    ColumnName: 'SignificancyClass',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'StateInfo': {
                    ColumnName: 'StateInfo',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'TransparencyIndex': {
                    ColumnName: 'TransparencyIndex',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'UID_AERoleAttestator': {
                    ColumnName: 'UID_AERoleAttestator',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_AERoleResponsible': {
                    ColumnName: 'UID_AERoleResponsible',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_AERoleRuler': {
                    ColumnName: 'UID_AERoleRuler',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_DialogReport': {
                    ColumnName: 'UID_DialogReport',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_DialogTable': {
                    ColumnName: 'UID_DialogTable',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_QERPolicy': {
                    ColumnName: 'UID_QERPolicy',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_QERPolicyWork': {
                    ColumnName: 'UID_QERPolicyWork',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_QERPolicyGroup': {
                    ColumnName: 'UID_QERPolicyGroup',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'CountOpen': {
                    ColumnName: 'CountOpen',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'CountClosed': {
                    ColumnName: 'CountClosed',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'QERPolicy', Columns: columns };
        };
        return PortalPolicies;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalPolicies type. */
    var PortalPoliciesInteractive = /** @class */ (function (_super) {
        __extends(PortalPoliciesInteractive, _super);
        function PortalPoliciesInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalPoliciesInteractive;
    }(PortalPolicies));
    var PortalPoliciesMitigatingcontrols = /** @class */ (function (_super) {
        __extends(PortalPoliciesMitigatingcontrols, _super);
        function PortalPoliciesMitigatingcontrols() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_QERPolicy = _this.GetEntityValue('UID_QERPolicy');
            _this.UID_MitigatingControl = _this.GetEntityValue('UID_MitigatingControl');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalPoliciesMitigatingcontrols.GetEntitySchema = function () {
            var columns = {
                'UID_QERPolicy': {
                    ColumnName: 'UID_QERPolicy',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_MitigatingControl': {
                    ColumnName: 'UID_MitigatingControl',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'QERPolicyHasMControl', Columns: columns };
        };
        return PortalPoliciesMitigatingcontrols;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalPoliciesMitigatingcontrols type. */
    var PortalPoliciesMitigatingcontrolsInteractive = /** @class */ (function (_super) {
        __extends(PortalPoliciesMitigatingcontrolsInteractive, _super);
        function PortalPoliciesMitigatingcontrolsInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalPoliciesMitigatingcontrolsInteractive;
    }(PortalPoliciesMitigatingcontrols));
    var PortalPoliciesViolations = /** @class */ (function (_super) {
        __extends(PortalPoliciesViolations, _super);
        function PortalPoliciesViolations() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_QERPolicyHasObject = _this.GetEntityValue('UID_QERPolicyHasObject');
            _this.UID_MitigatingControl = _this.GetEntityValue('UID_MitigatingControl');
            _this.ObjectKey = _this.GetEntityValue('ObjectKey');
            _this.UID_QERPolicy = _this.GetEntityValue('UID_QERPolicy');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalPoliciesViolations.GetEntitySchema = function () {
            var columns = {
                'UID_QERPolicyHasObject': {
                    ColumnName: 'UID_QERPolicyHasObject',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_MitigatingControl': {
                    ColumnName: 'UID_MitigatingControl',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'ObjectKey': {
                    ColumnName: 'ObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_QERPolicy': {
                    ColumnName: 'UID_QERPolicy',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'PolicyObjectHasMControl', Columns: columns };
        };
        return PortalPoliciesViolations;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalPoliciesViolations type. */
    var PortalPoliciesViolationsInteractive = /** @class */ (function (_super) {
        __extends(PortalPoliciesViolationsInteractive, _super);
        function PortalPoliciesViolationsInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalPoliciesViolationsInteractive;
    }(PortalPoliciesViolations));
    var PortalPoliciesViolationslist = /** @class */ (function (_super) {
        __extends(PortalPoliciesViolationslist, _super);
        function PortalPoliciesViolationslist() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.DecisionDate = _this.GetEntityValue('DecisionDate');
            _this.DecisionReason = _this.GetEntityValue('DecisionReason');
            _this.UID_QERPolicy = _this.GetEntityValue('UID_QERPolicy');
            _this.ObjectKey = _this.GetEntityValue('ObjectKey');
            _this.UID_PersonDecisionMade = _this.GetEntityValue('UID_PersonDecisionMade');
            _this.UID_QERJustification = _this.GetEntityValue('UID_QERJustification');
            _this.State = _this.GetEntityValue('State');
            _this.Description = _this.GetEntityValue('Description');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalPoliciesViolationslist.GetEntitySchema = function () {
            var columns = {
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'DecisionDate': {
                    ColumnName: 'DecisionDate',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'DecisionReason': {
                    ColumnName: 'DecisionReason',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_QERPolicy': {
                    ColumnName: 'UID_QERPolicy',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ObjectKey': {
                    ColumnName: 'ObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_PersonDecisionMade': {
                    ColumnName: 'UID_PersonDecisionMade',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_QERJustification': {
                    ColumnName: 'UID_QERJustification',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'State': {
                    ColumnName: 'State',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Description': {
                    ColumnName: 'Description',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'QERPolicyHasObject', Columns: columns };
        };
        return PortalPoliciesViolationslist;
    }(imxQbmDbts.ReadExtTypedEntity));
    /** @deprecated Use the PortalPoliciesViolationslist type. */
    var PortalPoliciesViolationslistInteractive = /** @class */ (function (_super) {
        __extends(PortalPoliciesViolationslistInteractive, _super);
        function PortalPoliciesViolationslistInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalPoliciesViolationslistInteractive;
    }(PortalPoliciesViolationslist));
    var PortalCandidatesMitigatingcontrolWrapper = /** @class */ (function () {
        function PortalCandidatesMitigatingcontrolWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalCandidatesMitigatingcontrolWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/candidates/MitigatingControl');
        };
        PortalCandidatesMitigatingcontrolWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/candidates/MitigatingControl');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalCandidatesMitigatingcontrol, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalCandidatesMitigatingcontrolWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_candidates_MitigatingControl_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalCandidatesMitigatingcontrolWrapper;
    }());
    var PortalPoliciesWrapper = /** @class */ (function () {
        function PortalPoliciesWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalPoliciesWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/policies');
        };
        PortalPoliciesWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/policies');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalPolicies, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalPoliciesWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_policies_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalPoliciesWrapper;
    }());
    var PortalPoliciesMitigatingcontrolsWrapper = /** @class */ (function () {
        function PortalPoliciesMitigatingcontrolsWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                {
                    return _this.client.portal_policies_mitigatingcontrols_post(entity.GetColumn('UID_QERPolicy').GetValue(), writeData);
                }
            };
            this.deleteMethod = function (entity) {
                return _this.client.portal_policies_mitigatingcontrols_delete(entity.GetColumn('UID_QERPolicy').GetValue(), entity.GetColumn('UID_MitigatingControl').GetValue());
            };
        }
        PortalPoliciesMitigatingcontrolsWrapper.prototype.createEntity = function (initialData) {
            this.buildBuilderIfNeeded();
            return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, imxQbmDbts.EntityState.Created);
        };
        /** Returns the runtime schema for this method. */
        PortalPoliciesMitigatingcontrolsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/policies/{UID_QERPolicy}/mitigatingcontrols');
        };
        PortalPoliciesMitigatingcontrolsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/policies/{UID_QERPolicy}/mitigatingcontrols');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalPoliciesMitigatingcontrols, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalPoliciesMitigatingcontrolsWrapper.prototype.Get = function (UID_QERPolicy, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_policies_mitigatingcontrols_get(UID_QERPolicy, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalPoliciesMitigatingcontrolsWrapper.prototype.Post = function (UID_QERPolicy, inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_policies_mitigatingcontrols_post(UID_QERPolicy, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalPoliciesMitigatingcontrolsWrapper.prototype.Delete = function (UID_QERPolicy, UID_MitigatingControl, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_policies_mitigatingcontrols_delete(UID_QERPolicy, UID_MitigatingControl, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalPoliciesMitigatingcontrolsWrapper;
    }());
    var PortalPoliciesViolationsWrapper = /** @class */ (function () {
        function PortalPoliciesViolationsWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                {
                    return _this.client.portal_policies_violations_post(entity.GetColumn('UID_QERPolicyHasObject').GetValue(), writeData);
                }
            };
            this.deleteMethod = function (entity) {
                return _this.client.portal_policies_violations_delete(entity.GetColumn('UID_QERPolicyHasObject').GetValue(), entity.GetColumn('UID_MitigatingControl').GetValue());
            };
        }
        PortalPoliciesViolationsWrapper.prototype.createEntity = function (initialData) {
            this.buildBuilderIfNeeded();
            return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, imxQbmDbts.EntityState.Created);
        };
        /** Returns the runtime schema for this method. */
        PortalPoliciesViolationsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/policies/violations/{UID_QERPolicyHasObject}');
        };
        PortalPoliciesViolationsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/policies/violations/{UID_QERPolicyHasObject}');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalPoliciesViolations, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalPoliciesViolationsWrapper.prototype.Get = function (UID_QERPolicyHasObject, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_policies_violations_get(UID_QERPolicyHasObject, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalPoliciesViolationsWrapper.prototype.Post = function (UID_QERPolicyHasObject, inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_policies_violations_post(UID_QERPolicyHasObject, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalPoliciesViolationsWrapper.prototype.Delete = function (UID_QERPolicyHasObject, UID_MitigatingControl, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_policies_violations_delete(UID_QERPolicyHasObject, UID_MitigatingControl, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalPoliciesViolationsWrapper;
    }());
    var PortalPoliciesViolationslistWrapper = /** @class */ (function () {
        function PortalPoliciesViolationslistWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalPoliciesViolationslistWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/policies/violations');
        };
        PortalPoliciesViolationslistWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/policies/violations');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalPoliciesViolationslist, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalPoliciesViolationslistWrapper.prototype.Get_list = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_policies_violations_list_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalPoliciesViolationslistWrapper;
    }());
    /** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
    var ApiClientMethodFactory = /** @class */ (function () {
        function ApiClientMethodFactory() {
        }
        ApiClientMethodFactory.prototype.portal_candidates_MitigatingControl_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/candidates/MitigatingControl',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_candidates_MitigatingControl_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/candidates/MitigatingControl/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_policies_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, active) {
            return {
                path: '/portal/policies',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'active',
                        value: active,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_policies_mitigatingcontrols_get = function (UID_QERPolicy, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/policies/{UID_QERPolicy}/mitigatingcontrols',
                parameters: [
                    {
                        name: 'UID_QERPolicy',
                        value: UID_QERPolicy,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_policies_mitigatingcontrols_post = function (UID_QERPolicy, inputParameterName) {
            return {
                path: '/portal/policies/{UID_QERPolicy}/mitigatingcontrols',
                parameters: [
                    {
                        name: 'UID_QERPolicy',
                        value: UID_QERPolicy,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_policies_mitigatingcontrols_delete = function (UID_QERPolicy, UID_MitigatingControl) {
            return {
                path: '/portal/policies/{UID_QERPolicy}/mitigatingcontrols/{UID_MitigatingControl}',
                parameters: [
                    {
                        name: 'UID_QERPolicy',
                        value: UID_QERPolicy,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_MitigatingControl',
                        value: UID_MitigatingControl,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_policies_report_get = function (uidpolicy) {
            return {
                path: '/portal/policies/{uidpolicy}/report',
                parameters: [
                    {
                        name: 'uidpolicy',
                        value: uidpolicy,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_policies_datamodel_get = function (filter) {
            return {
                path: '/portal/policies/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_policies_group_get = function (by, def, filter, StartIndex, PageSize, withcount, active) {
            return {
                path: '/portal/policies/group',
                parameters: [
                    {
                        name: 'by',
                        value: by,
                        in: 'query'
                    },
                    {
                        name: 'def',
                        value: def,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'withcount',
                        value: withcount,
                        in: 'query'
                    },
                    {
                        name: 'active',
                        value: active,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_policies_violations_list_get = function (approvable, OrderBy, StartIndex, PageSize, filter, withProperties, search, state, uid_qerpolicy) {
            return {
                path: '/portal/policies/violations',
                parameters: [
                    {
                        name: 'approvable',
                        value: approvable,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'state',
                        value: state,
                        in: 'query'
                    },
                    {
                        name: 'uid_qerpolicy',
                        value: uid_qerpolicy,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_policies_violations_get = function (UID_QERPolicyHasObject, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/policies/violations/{UID_QERPolicyHasObject}',
                parameters: [
                    {
                        name: 'UID_QERPolicyHasObject',
                        value: UID_QERPolicyHasObject,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_policies_violations_post = function (UID_QERPolicyHasObject, inputParameterName) {
            return {
                path: '/portal/policies/violations/{UID_QERPolicyHasObject}',
                parameters: [
                    {
                        name: 'UID_QERPolicyHasObject',
                        value: UID_QERPolicyHasObject,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_policies_violations_delete = function (UID_QERPolicyHasObject, UID_MitigatingControl) {
            return {
                path: '/portal/policies/violations/{UID_QERPolicyHasObject}/{UID_MitigatingControl}',
                parameters: [
                    {
                        name: 'UID_QERPolicyHasObject',
                        value: UID_QERPolicyHasObject,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_MitigatingControl',
                        value: UID_MitigatingControl,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_policies_violations_UID_MitigatingControl_candidates_post = function (UID_QERPolicyHasObject, OrderBy, StartIndex, PageSize, filter, withProperties, search, inputParameterName) {
            return {
                path: '/portal/policies/violations/{UID_QERPolicyHasObject}/UID_MitigatingControl/candidates',
                parameters: [
                    {
                        name: 'UID_QERPolicyHasObject',
                        value: UID_QERPolicyHasObject,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_policies_violations_UID_MitigatingControl_candidates_filtertree_post = function (UID_QERPolicyHasObject, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/policies/violations/{UID_QERPolicyHasObject}/UID_MitigatingControl/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_QERPolicyHasObject',
                        value: UID_QERPolicyHasObject,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_policies_violations_approve_post = function (uidviolation, inputParameterName) {
            return {
                path: '/portal/policies/violations/approve/{uidviolation}',
                parameters: [
                    {
                        name: 'uidviolation',
                        value: uidviolation,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_policies_violations_datamodel_get = function (filter) {
            return {
                path: '/portal/policies/violations/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_policies_violations_group_list_get = function (by, def, filter, StartIndex, PageSize, withcount, state, uid_qerpolicy) {
            return {
                path: '/portal/policies/violations/group',
                parameters: [
                    {
                        name: 'by',
                        value: by,
                        in: 'query'
                    },
                    {
                        name: 'def',
                        value: def,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'withcount',
                        value: withcount,
                        in: 'query'
                    },
                    {
                        name: 'state',
                        value: state,
                        in: 'query'
                    },
                    {
                        name: 'uid_qerpolicy',
                        value: uid_qerpolicy,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_policy_config_get = function () {
            return {
                path: '/portal/policy/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        return ApiClientMethodFactory;
    }());
    /** @deprecated Use the V2Client class for a stable method interface. */
    var Client = /** @class */ (function () {
        function Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        /** Returns a list of candidate objects from the table MitigatingControl. */
        Client.prototype.portal_candidates_MitigatingControl_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_MitigatingControl_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns filter tree information for the candidates/MitigatingControl endpoint. */
        Client.prototype.portal_candidates_MitigatingControl_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_MitigatingControl_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        Client.prototype.portal_policies_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, active, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, active), requestOptions);
        };
        Client.prototype.portal_policies_mitigatingcontrols_get = function (UID_QERPolicy, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_mitigatingcontrols_get(UID_QERPolicy, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Assign a mitigating control to the company policy. */
        Client.prototype.portal_policies_mitigatingcontrols_post = function (UID_QERPolicy, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_mitigatingcontrols_post(UID_QERPolicy, inputParameterName), requestOptions);
        };
        /** Removes a mitigating control from the company policy. */
        Client.prototype.portal_policies_mitigatingcontrols_delete = function (UID_QERPolicy, UID_MitigatingControl, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_mitigatingcontrols_delete(UID_QERPolicy, UID_MitigatingControl), requestOptions);
        };
        Client.prototype.portal_policies_report_get = function (uidpolicy, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_report_get(uidpolicy), requestOptions);
        };
        /** Returns data model information about query options for the policies endpoint. */
        Client.prototype.portal_policies_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_policies_group_get = function (by, def, filter, StartIndex, PageSize, withcount, active, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_group_get(by, def, filter, StartIndex, PageSize, withcount, active), requestOptions);
        };
        /** Returns a list of policy violations. */
        Client.prototype.portal_policies_violations_list_get = function (approvable, OrderBy, StartIndex, PageSize, filter, withProperties, search, state, uid_qerpolicy, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_list_get(approvable, OrderBy, StartIndex, PageSize, filter, withProperties, search, state, uid_qerpolicy), requestOptions);
        };
        Client.prototype.portal_policies_violations_get = function (UID_QERPolicyHasObject, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_get(UID_QERPolicyHasObject, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Assign a mitigating control to the policy violation. */
        Client.prototype.portal_policies_violations_post = function (UID_QERPolicyHasObject, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_post(UID_QERPolicyHasObject, inputParameterName), requestOptions);
        };
        /** Removes a mitigating control from the policy violation. */
        Client.prototype.portal_policies_violations_delete = function (UID_QERPolicyHasObject, UID_MitigatingControl, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_delete(UID_QERPolicyHasObject, UID_MitigatingControl), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_MitigatingControl. */
        Client.prototype.portal_policies_violations_UID_MitigatingControl_candidates_post = function (UID_QERPolicyHasObject, OrderBy, StartIndex, PageSize, filter, withProperties, search, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_UID_MitigatingControl_candidates_post(UID_QERPolicyHasObject, OrderBy, StartIndex, PageSize, filter, withProperties, search, inputParameterName), requestOptions);
        };
        /** Returns filter tree information for the policies/violations/{UID_QERPolicyHasObject}/UID_MitigatingControl/candidates endpoint. */
        Client.prototype.portal_policies_violations_UID_MitigatingControl_candidates_filtertree_post = function (UID_QERPolicyHasObject, filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_UID_MitigatingControl_candidates_filtertree_post(UID_QERPolicyHasObject, filter, parentkey, inputParameterName), requestOptions);
        };
        Client.prototype.portal_policies_violations_approve_post = function (uidviolation, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_approve_post(uidviolation, inputParameterName), requestOptions);
        };
        /** Returns data model information about query options for the policies/violations endpoint. */
        Client.prototype.portal_policies_violations_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_datamodel_get(filter), requestOptions);
        };
        /** Returns a list of policy violations. */
        Client.prototype.portal_policies_violations_group_list_get = function (by, def, filter, StartIndex, PageSize, withcount, state, uid_qerpolicy, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_group_list_get(by, def, filter, StartIndex, PageSize, withcount, state, uid_qerpolicy), requestOptions);
        };
        Client.prototype.portal_policy_config_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policy_config_get(), requestOptions);
        };
        return Client;
    }());
    var V2ApiClientMethodFactory = /** @class */ (function () {
        function V2ApiClientMethodFactory() {
        }
        V2ApiClientMethodFactory.prototype.portal_candidates_MitigatingControl_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/MitigatingControl',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_candidates_MitigatingControl_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/MitigatingControl/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_policies_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/policies',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_policies_mitigatingcontrols_get = function (UID_QERPolicy, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/policies/{UID_QERPolicy}/mitigatingcontrols',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_QERPolicy',
                        value: UID_QERPolicy,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_policies_mitigatingcontrols_post = function (UID_QERPolicy, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/policies/{UID_QERPolicy}/mitigatingcontrols',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_QERPolicy',
                        value: UID_QERPolicy,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_policies_mitigatingcontrols_delete = function (UID_QERPolicy, /** Mitigating control */ UID_MitigatingControl, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/policies/{UID_QERPolicy}/mitigatingcontrols/{UID_MitigatingControl}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_QERPolicy',
                        value: UID_QERPolicy,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_MitigatingControl',
                        value: UID_MitigatingControl,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_policies_report_get = function (/** Unique policy identifier */ uidpolicy, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/policies/{uidpolicy}/report',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidpolicy',
                        value: uidpolicy,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_policies_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/policies/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_policies_group_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/policies/group',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_policies_violations_list_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/policies/violations',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_policies_violations_get = function (UID_QERPolicyHasObject, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/policies/violations/{UID_QERPolicyHasObject}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_QERPolicyHasObject',
                        value: UID_QERPolicyHasObject,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_policies_violations_post = function (UID_QERPolicyHasObject, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/policies/violations/{UID_QERPolicyHasObject}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_QERPolicyHasObject',
                        value: UID_QERPolicyHasObject,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_policies_violations_delete = function (UID_QERPolicyHasObject, /** Mitigating control */ UID_MitigatingControl, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/policies/violations/{UID_QERPolicyHasObject}/{UID_MitigatingControl}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_QERPolicyHasObject',
                        value: UID_QERPolicyHasObject,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_MitigatingControl',
                        value: UID_MitigatingControl,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_policies_violations_UID_MitigatingControl_candidates_post = function (UID_QERPolicyHasObject, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/policies/violations/{UID_QERPolicyHasObject}/UID_MitigatingControl/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_QERPolicyHasObject',
                        value: UID_QERPolicyHasObject,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_policies_violations_UID_MitigatingControl_candidates_filtertree_post = function (UID_QERPolicyHasObject, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/policies/violations/{UID_QERPolicyHasObject}/UID_MitigatingControl/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_QERPolicyHasObject',
                        value: UID_QERPolicyHasObject,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_policies_violations_approve_post = function (/** Unique violation identifier */ uidviolation, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/policies/violations/approve/{uidviolation}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidviolation',
                        value: uidviolation,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_policies_violations_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/policies/violations/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_policies_violations_group_list_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/policies/violations/group',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_policy_config_get = function (options, requestOptions) {
            return {
                path: '/portal/policy/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        return V2ApiClientMethodFactory;
    }());
    var V2Client = /** @class */ (function () {
        function V2Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new V2ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(V2Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        V2Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        V2Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        V2Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        /** Returns a list of candidate objects from the table MitigatingControl. */
        V2Client.prototype.portal_candidates_MitigatingControl_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_MitigatingControl_get(options), requestOptions);
        };
        /** Returns filter tree information for the candidates/MitigatingControl endpoint. */
        V2Client.prototype.portal_candidates_MitigatingControl_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_MitigatingControl_filtertree_post(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_policies_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_get(options), requestOptions);
        };
        V2Client.prototype.portal_policies_mitigatingcontrols_get = function (UID_QERPolicy, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_mitigatingcontrols_get(UID_QERPolicy, options), requestOptions);
        };
        /** Assign a mitigating control to the company policy. */
        V2Client.prototype.portal_policies_mitigatingcontrols_post = function (UID_QERPolicy, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_mitigatingcontrols_post(UID_QERPolicy, inputParameterName, options), requestOptions);
        };
        /** Removes a mitigating control from the company policy. */
        V2Client.prototype.portal_policies_mitigatingcontrols_delete = function (UID_QERPolicy, /** Mitigating control */ UID_MitigatingControl, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_mitigatingcontrols_delete(UID_QERPolicy, UID_MitigatingControl, options), requestOptions);
        };
        V2Client.prototype.portal_policies_report_get = function (/** Unique policy identifier */ uidpolicy, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_report_get(uidpolicy, options), requestOptions);
        };
        /** Returns data model information about query options for the policies endpoint. */
        V2Client.prototype.portal_policies_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_policies_group_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_group_get(options), requestOptions);
        };
        /** Returns a list of policy violations. */
        V2Client.prototype.portal_policies_violations_list_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_list_get(options), requestOptions);
        };
        V2Client.prototype.portal_policies_violations_get = function (UID_QERPolicyHasObject, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_get(UID_QERPolicyHasObject, options), requestOptions);
        };
        /** Assign a mitigating control to the policy violation. */
        V2Client.prototype.portal_policies_violations_post = function (UID_QERPolicyHasObject, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_post(UID_QERPolicyHasObject, inputParameterName, options), requestOptions);
        };
        /** Removes a mitigating control from the policy violation. */
        V2Client.prototype.portal_policies_violations_delete = function (UID_QERPolicyHasObject, /** Mitigating control */ UID_MitigatingControl, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_delete(UID_QERPolicyHasObject, UID_MitigatingControl, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_MitigatingControl. */
        V2Client.prototype.portal_policies_violations_UID_MitigatingControl_candidates_post = function (UID_QERPolicyHasObject, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_UID_MitigatingControl_candidates_post(UID_QERPolicyHasObject, inputParameterName, options), requestOptions);
        };
        /** Returns filter tree information for the policies/violations/{UID_QERPolicyHasObject}/UID_MitigatingControl/candidates endpoint. */
        V2Client.prototype.portal_policies_violations_UID_MitigatingControl_candidates_filtertree_post = function (UID_QERPolicyHasObject, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_UID_MitigatingControl_candidates_filtertree_post(UID_QERPolicyHasObject, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_policies_violations_approve_post = function (/** Unique violation identifier */ uidviolation, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_approve_post(uidviolation, inputParameterName, options), requestOptions);
        };
        /** Returns data model information about query options for the policies/violations endpoint. */
        V2Client.prototype.portal_policies_violations_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_datamodel_get(options), requestOptions);
        };
        /** Returns a list of policy violations. */
        V2Client.prototype.portal_policies_violations_group_list_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_group_list_get(options), requestOptions);
        };
        V2Client.prototype.portal_policy_config_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_policy_config_get(options), requestOptions);
        };
        return V2Client;
    }());

    exports.ApiClientMethodFactory = ApiClientMethodFactory;
    exports.Client = Client;
    exports.PortalCandidatesMitigatingcontrol = PortalCandidatesMitigatingcontrol;
    exports.PortalCandidatesMitigatingcontrolInteractive = PortalCandidatesMitigatingcontrolInteractive;
    exports.PortalCandidatesMitigatingcontrolWrapper = PortalCandidatesMitigatingcontrolWrapper;
    exports.PortalPolicies = PortalPolicies;
    exports.PortalPoliciesInteractive = PortalPoliciesInteractive;
    exports.PortalPoliciesMitigatingcontrols = PortalPoliciesMitigatingcontrols;
    exports.PortalPoliciesMitigatingcontrolsInteractive = PortalPoliciesMitigatingcontrolsInteractive;
    exports.PortalPoliciesMitigatingcontrolsWrapper = PortalPoliciesMitigatingcontrolsWrapper;
    exports.PortalPoliciesViolations = PortalPoliciesViolations;
    exports.PortalPoliciesViolationsInteractive = PortalPoliciesViolationsInteractive;
    exports.PortalPoliciesViolationsWrapper = PortalPoliciesViolationsWrapper;
    exports.PortalPoliciesViolationslist = PortalPoliciesViolationslist;
    exports.PortalPoliciesViolationslistInteractive = PortalPoliciesViolationslistInteractive;
    exports.PortalPoliciesViolationslistWrapper = PortalPoliciesViolationslistWrapper;
    exports.PortalPoliciesWrapper = PortalPoliciesWrapper;
    exports.TypedClient = TypedClient;
    exports.V2ApiClientMethodFactory = V2ApiClientMethodFactory;
    exports.V2Client = V2Client;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
