import { ValType, DisplayColumns, TypedEntity, TypedEntityBuilder, TimeZoneInfo, DisplayPattern, FkCandidateBuilder, MethodDefinition } from 'imx-qbm-dbts';

var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var TypedClient = /** @class */ (function () {
    function TypedClient(client, translationProvider) {
        this.PortalPolicies = new PortalPoliciesWrapper(client, translationProvider);
        this.PortalPoliciesViolationsApprove = new PortalPoliciesViolationsApproveWrapper(client, translationProvider);
    }
    return TypedClient;
}());
var PortalPolicies = /** @class */ (function (_super) {
    __extends(PortalPolicies, _super);
    function PortalPolicies() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.Description = _this.GetEntityValue('Description');
        _this.Ident_QERPolicy = _this.GetEntityValue('Ident_QERPolicy');
        _this.IsExceptionAllowed = _this.GetEntityValue('IsExceptionAllowed');
        _this.IsInActive = _this.GetEntityValue('IsInActive');
        _this.IsWorkingCopy = _this.GetEntityValue('IsWorkingCopy');
        _this.RiskIndex = _this.GetEntityValue('RiskIndex');
        _this.RiskIndexReduced = _this.GetEntityValue('RiskIndexReduced');
        _this.RuleSeverity = _this.GetEntityValue('RuleSeverity');
        _this.RuleViolationThreshold = _this.GetEntityValue('RuleViolationThreshold');
        _this.SignificancyClass = _this.GetEntityValue('SignificancyClass');
        _this.StateInfo = _this.GetEntityValue('StateInfo');
        _this.TransparencyIndex = _this.GetEntityValue('TransparencyIndex');
        _this.UID_AERoleAttestator = _this.GetEntityValue('UID_AERoleAttestator');
        _this.UID_AERoleResponsible = _this.GetEntityValue('UID_AERoleResponsible');
        _this.UID_AERoleRuler = _this.GetEntityValue('UID_AERoleRuler');
        _this.UID_DialogReport = _this.GetEntityValue('UID_DialogReport');
        _this.UID_DialogTable = _this.GetEntityValue('UID_DialogTable');
        _this.UID_QERPolicy = _this.GetEntityValue('UID_QERPolicy');
        _this.UID_QERPolicyGroup = _this.GetEntityValue('UID_QERPolicyGroup');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    PortalPolicies.GetEntitySchema = function () {
        var columns = {
            'Description': {
                ColumnName: 'Description',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Ident_QERPolicy': {
                ColumnName: 'Ident_QERPolicy',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'IsExceptionAllowed': {
                ColumnName: 'IsExceptionAllowed',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'IsInActive': {
                ColumnName: 'IsInActive',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'IsWorkingCopy': {
                ColumnName: 'IsWorkingCopy',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'RiskIndex': {
                ColumnName: 'RiskIndex',
                Type: ValType.Double,
                IsReadOnly: true,
            },
            'RiskIndexReduced': {
                ColumnName: 'RiskIndexReduced',
                Type: ValType.Double,
                IsReadOnly: true,
            },
            'RuleSeverity': {
                ColumnName: 'RuleSeverity',
                Type: ValType.Double,
                IsReadOnly: true,
            },
            'RuleViolationThreshold': {
                ColumnName: 'RuleViolationThreshold',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'SignificancyClass': {
                ColumnName: 'SignificancyClass',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'StateInfo': {
                ColumnName: 'StateInfo',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'TransparencyIndex': {
                ColumnName: 'TransparencyIndex',
                Type: ValType.Double,
                IsReadOnly: true,
            },
            'UID_AERoleAttestator': {
                ColumnName: 'UID_AERoleAttestator',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_AERoleResponsible': {
                ColumnName: 'UID_AERoleResponsible',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_AERoleRuler': {
                ColumnName: 'UID_AERoleRuler',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_DialogReport': {
                ColumnName: 'UID_DialogReport',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_DialogTable': {
                ColumnName: 'UID_DialogTable',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_QERPolicy': {
                ColumnName: 'UID_QERPolicy',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_QERPolicyGroup': {
                ColumnName: 'UID_QERPolicyGroup',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'QERPolicy', Columns: columns };
    };
    return PortalPolicies;
}(TypedEntity));
var PortalPoliciesViolationsApprove = /** @class */ (function (_super) {
    __extends(PortalPoliciesViolationsApprove, _super);
    function PortalPoliciesViolationsApprove() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XDateInserted = _this.GetEntityValue('XDateInserted');
        _this.DecisionDate = _this.GetEntityValue('DecisionDate');
        _this.DecisionReason = _this.GetEntityValue('DecisionReason');
        _this.UID_QERPolicy = _this.GetEntityValue('UID_QERPolicy');
        _this.ObjectKey = _this.GetEntityValue('ObjectKey');
        _this.UID_PersonDecisionMade = _this.GetEntityValue('UID_PersonDecisionMade');
        _this.UID_QERJustification = _this.GetEntityValue('UID_QERJustification');
        _this.State = _this.GetEntityValue('State');
        _this.Description = _this.GetEntityValue('Description');
        return _this;
    }
    /** Returns the static compile time schema for this method. */
    PortalPoliciesViolationsApprove.GetEntitySchema = function () {
        var columns = {
            'XDateInserted': {
                ColumnName: 'XDateInserted',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'DecisionDate': {
                ColumnName: 'DecisionDate',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'DecisionReason': {
                ColumnName: 'DecisionReason',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_QERPolicy': {
                ColumnName: 'UID_QERPolicy',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'ObjectKey': {
                ColumnName: 'ObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_PersonDecisionMade': {
                ColumnName: 'UID_PersonDecisionMade',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_QERJustification': {
                ColumnName: 'UID_QERJustification',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'State': {
                ColumnName: 'State',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Description': {
                ColumnName: 'Description',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'QERPolicyHasObject', Columns: columns };
    };
    return PortalPoliciesViolationsApprove;
}(TypedEntity));
var PortalPoliciesWrapper = /** @class */ (function () {
    function PortalPoliciesWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalPoliciesWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/policies');
    };
    PortalPoliciesWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/policies');
            this.builder = new TypedEntityBuilder(PortalPolicies, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalPoliciesWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_policies_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalPoliciesWrapper;
}());
var PortalPoliciesViolationsApproveWrapper = /** @class */ (function () {
    function PortalPoliciesViolationsApproveWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalPoliciesViolationsApproveWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/policies/violations/approve');
    };
    PortalPoliciesViolationsApproveWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/policies/violations/approve');
            this.builder = new TypedEntityBuilder(PortalPoliciesViolationsApprove, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalPoliciesViolationsApproveWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_policies_violations_approve_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalPoliciesViolationsApproveWrapper;
}());
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
var ApiClientMethodFactory = /** @class */ (function () {
    function ApiClientMethodFactory() {
    }
    ApiClientMethodFactory.prototype.portal_policies_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/policies',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_policies_violations_approve_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, state, uid_qerpolicy) {
        return {
            path: '/portal/policies/violations/approve',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'state',
                    value: state,
                    in: 'query'
                },
                {
                    name: 'uid_qerpolicy',
                    value: uid_qerpolicy,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_policies_violations_approve_post = function (uidviolation, inputParameterName) {
        return {
            path: '/portal/policies/violations/approve/{uidviolation}',
            parameters: [
                {
                    name: 'uidviolation',
                    value: uidviolation,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_policies_violations_approve_datamodel_get = function (filter) {
        return {
            path: '/portal/policies/violations/approve/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_policies_violations_approve_group_get = function (by, def, filter, StartIndex, PageSize, withcount, state, uid_qerpolicy) {
        return {
            path: '/portal/policies/violations/approve/group',
            parameters: [
                {
                    name: 'by',
                    value: by,
                    in: 'query'
                },
                {
                    name: 'def',
                    value: def,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'withcount',
                    value: withcount,
                    in: 'query'
                },
                {
                    name: 'state',
                    value: state,
                    in: 'query'
                },
                {
                    name: 'uid_qerpolicy',
                    value: uid_qerpolicy,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    return ApiClientMethodFactory;
}());
/** @deprecated Use the V2Client class for a stable method interface. */
var Client = /** @class */ (function () {
    function Client(apiClient, schemaProvider) {
        this.apiClient = apiClient;
        this.schemaProvider = schemaProvider;
        this.methodFactory = new ApiClientMethodFactory();
        if (!apiClient) {
            throw new Error("The value for the apiClient parameter is undefined.");
        }
    }
    Object.defineProperty(Client.prototype, "schemas", {
        get: function () {
            if (!this.schemaProvider) {
                throw new Error("The schema has not been loaded.");
            }
            return this.schemaProvider.schemas;
        },
        enumerable: false,
        configurable: true
    });
    Client.prototype.loadSchema = function (language) {
        return __awaiter(this, void 0, void 0, function () {
            var headers, dtos, schemas, key, dto, columns;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        headers = {};
                        if (language)
                            headers['Accept-Language'] = language;
                        return [4 /*yield*/, this.apiClient.processRequest({
                                path: '/imx/entityschema',
                                parameters: [],
                                method: 'GET',
                                headers: headers,
                                credentials: 'include',
                                observe: 'response',
                                responseType: 'json'
                            })];
                    case 1:
                        dtos = _a.sent();
                        schemas = {};
                        for (key in dtos) {
                            dto = dtos[key];
                            columns = dto.Properties;
                            columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
                            columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
                            schemas[key] = {
                                TypeName: dto.TypeName,
                                DisplayPattern: new DisplayPattern(dto.DisplayPattern),
                                Display: dto.Display,
                                DisplaySingular: dto.DisplaySingular,
                                FkCandidateRoutes: dto.FkCandidateRoutes,
                                Columns: columns
                            };
                        }
                        this.schemaProvider = { schemas: schemas };
                        return [2 /*return*/];
                }
            });
        });
    };
    Client.prototype.getFkProviderItems = function (methodKey) {
        var _a;
        return new FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
    };
    /** Returns the runtime schema for the named method. */
    Client.prototype.getSchema = function (methodKey) {
        var result = this.schemas[methodKey];
        if (!result)
            throw new Error('Unknown method: ' + methodKey);
        return result;
    };
    Client.prototype.portal_policies_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_policies_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    Client.prototype.portal_policies_violations_approve_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, state, uid_qerpolicy, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_approve_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, state, uid_qerpolicy), requestOptions);
    };
    Client.prototype.portal_policies_violations_approve_post = function (uidviolation, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_approve_post(uidviolation, inputParameterName), requestOptions);
    };
    /** Returns data model information about query options for the policies/violations/approve endpoint. */
    Client.prototype.portal_policies_violations_approve_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_approve_datamodel_get(filter), requestOptions);
    };
    Client.prototype.portal_policies_violations_approve_group_get = function (by, def, filter, StartIndex, PageSize, withcount, state, uid_qerpolicy, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_approve_group_get(by, def, filter, StartIndex, PageSize, withcount, state, uid_qerpolicy), requestOptions);
    };
    return Client;
}());
var V2ApiClientMethodFactory = /** @class */ (function () {
    function V2ApiClientMethodFactory() {
    }
    V2ApiClientMethodFactory.prototype.portal_policies_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/policies',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_policies_violations_approve_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/policies/violations/approve',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_policies_violations_approve_post = function (uidviolation, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/policies/violations/approve/{uidviolation}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uidviolation',
                    value: uidviolation,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_policies_violations_approve_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/policies/violations/approve/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_policies_violations_approve_group_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/policies/violations/approve/group',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    return V2ApiClientMethodFactory;
}());
var V2Client = /** @class */ (function () {
    function V2Client(apiClient, schemaProvider) {
        this.apiClient = apiClient;
        this.schemaProvider = schemaProvider;
        this.methodFactory = new V2ApiClientMethodFactory();
        if (!apiClient) {
            throw new Error("The value for the apiClient parameter is undefined.");
        }
    }
    Object.defineProperty(V2Client.prototype, "schemas", {
        get: function () {
            if (!this.schemaProvider) {
                throw new Error("The schema has not been loaded.");
            }
            return this.schemaProvider.schemas;
        },
        enumerable: false,
        configurable: true
    });
    V2Client.prototype.loadSchema = function (language) {
        return __awaiter(this, void 0, void 0, function () {
            var headers, dtos, schemas, key, dto, columns;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        headers = {};
                        if (language)
                            headers['Accept-Language'] = language;
                        return [4 /*yield*/, this.apiClient.processRequest({
                                path: '/imx/entityschema',
                                parameters: [],
                                method: 'GET',
                                headers: headers,
                                credentials: 'include',
                                observe: 'response',
                                responseType: 'json'
                            })];
                    case 1:
                        dtos = _a.sent();
                        schemas = {};
                        for (key in dtos) {
                            dto = dtos[key];
                            columns = dto.Properties;
                            columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
                            columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
                            schemas[key] = {
                                TypeName: dto.TypeName,
                                DisplayPattern: new DisplayPattern(dto.DisplayPattern),
                                Display: dto.Display,
                                DisplaySingular: dto.DisplaySingular,
                                FkCandidateRoutes: dto.FkCandidateRoutes,
                                Columns: columns
                            };
                        }
                        this.schemaProvider = { schemas: schemas };
                        return [2 /*return*/];
                }
            });
        });
    };
    V2Client.prototype.getFkProviderItems = function (methodKey) {
        var _a;
        return new FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
    };
    /** Returns the runtime schema for the named method. */
    V2Client.prototype.getSchema = function (methodKey) {
        var result = this.schemas[methodKey];
        if (!result)
            throw new Error('Unknown method: ' + methodKey);
        return result;
    };
    V2Client.prototype.portal_policies_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_policies_get(options), requestOptions);
    };
    V2Client.prototype.portal_policies_violations_approve_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_approve_get(options), requestOptions);
    };
    V2Client.prototype.portal_policies_violations_approve_post = function (uidviolation, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_approve_post(uidviolation, inputParameterName, options), requestOptions);
    };
    /** Returns data model information about query options for the policies/violations/approve endpoint. */
    V2Client.prototype.portal_policies_violations_approve_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_approve_datamodel_get(options), requestOptions);
    };
    V2Client.prototype.portal_policies_violations_approve_group_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_policies_violations_approve_group_get(options), requestOptions);
    };
    return V2Client;
}());

export { ApiClientMethodFactory, Client, PortalPolicies, PortalPoliciesViolationsApprove, PortalPoliciesViolationsApproveWrapper, PortalPoliciesWrapper, TypedClient, V2ApiClientMethodFactory, V2Client };
