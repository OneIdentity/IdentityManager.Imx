import { ApiClient, DataModel, EntityCollectionData, EntitySchema, ExtendedEntityCollectionData, FilterData, FkProviderItem, IClientProperty, IReadValue, MethodDescriptor, StaticSchema, TypedEntity } from 'imx-qbm-dbts';
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface ExtendedEntityCollectionDataOfManualChangeOperationData extends EntityCollectionData {
    ExtendedData?: ManualChangeOperationData;
}
export interface ManualChangeOperation {
    Property?: IClientProperty;
    DiffValue?: any;
}
export interface ManualChangeOperationData {
    Operations?: ManualChangeOperation[][];
}
export interface SuccessFlag {
    Success: boolean;
}
export declare class TypedClient {
    readonly OpsupportUciChangedetail: OpsupportUciChangedetailWrapper;
    readonly OpsupportUciChanges: OpsupportUciChangesWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class OpsupportUciChangedetail extends TypedEntity {
    readonly IsProcessed: IReadValue<number>;
    readonly Operation: IReadValue<string>;
    readonly CreationDate: IReadValue<Date>;
    readonly UID_QBMPendingChange: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'IsProcessed' | 'Operation' | 'CreationDate' | 'UID_QBMPendingChange'>;
}
export declare class OpsupportUciChanges extends TypedEntity {
    readonly ObjectKeyElement: IReadValue<string>;
    readonly XDateInserted: IReadValue<Date>;
    readonly IsProcessed: IReadValue<number>;
    readonly Operation: IReadValue<string>;
    readonly UID_UCIRoot: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'ObjectKeyElement' | 'XDateInserted' | 'IsProcessed' | 'Operation' | 'UID_UCIRoot'>;
}
export declare class OpsupportUciChangedetailWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_QBMPendingChange: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportUciChangedetail, ManualChangeOperationData>>;
}
export declare class OpsupportUciChangesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        state?: string;
        root?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<OpsupportUciChanges, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    opsupport_uci_changedetail_get(UID_QBMPendingChange: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<ExtendedEntityCollectionData<ManualChangeOperationData>>;
    opsupport_uci_changes_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, state: string, root: string): MethodDescriptor<EntityCollectionData>;
    opsupport_uci_changes_post(UID_QBMPendingChangeDetail: string, inputParameterName: SuccessFlag): MethodDescriptor<void>;
    opsupport_uci_changes_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    opsupport_uci_changedetail_get(UID_QBMPendingChange: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<ExtendedEntityCollectionData<ManualChangeOperationData>>;
    opsupport_uci_changes_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, state: string, root: string): Promise<EntityCollectionData>;
    opsupport_uci_changes_post(UID_QBMPendingChangeDetail: string, inputParameterName: SuccessFlag): Promise<void>;
    /** Returns data model information about query options for the uci/changes endpoint. */
    opsupport_uci_changes_datamodel_get(filter: FilterData[]): Promise<DataModel>;
}
export declare class V2ApiClientMethodFactory {
    opsupport_uci_changedetail_get(UID_QBMPendingChange: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<ExtendedEntityCollectionData<ManualChangeOperationData>>;
    opsupport_uci_changes_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        state?: string;
        root?: string;
    }): MethodDescriptor<EntityCollectionData>;
    opsupport_uci_changes_post(UID_QBMPendingChangeDetail: string, inputParameterName: SuccessFlag, options?: {}): MethodDescriptor<void>;
    opsupport_uci_changes_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    opsupport_uci_changedetail_get(UID_QBMPendingChange: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<ExtendedEntityCollectionData<ManualChangeOperationData>>;
    opsupport_uci_changes_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        state?: string;
        root?: string;
    }): Promise<EntityCollectionData>;
    opsupport_uci_changes_post(UID_QBMPendingChangeDetail: string, inputParameterName: SuccessFlag, options?: {}): Promise<void>;
    /** Returns data model information about query options for the uci/changes endpoint. */
    opsupport_uci_changes_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
}
