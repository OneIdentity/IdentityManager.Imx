import { ApiClient, DataModel, EntityCollectionData, EntitySchema, FilterData, FkProviderItem, GroupInfo, IReadValue, MethodDescriptor, StaticSchema, TypedEntity } from 'imx-qbm-dbts';
export interface ActionInput extends ResolveInput {
    ActionIds?: string[];
}
export interface ComplianceFeatureConfig {
    /** Returns a flag indicating whether mitigating controls are managed and assigned per rule violation
(true) or per compliance rule (false). */
    MitigatingControlsPerViolation: boolean;
}
export interface ComplianceViolation {
    ViolationType?: string;
    UidShoppingCartItem?: string;
    UidPerson?: string;
    DisplayPerson?: string;
    UidPersonWantsOrg?: string;
    ObjectKeyElement?: string;
    DisplayElement?: string;
    UidComplianceRule?: string;
    DisplayRule?: string;
    UidComplianceSubRule?: string;
    IsNoEffectivePerson: boolean;
    Sources?: ContributingEntitlement[];
    ContributingEntitlements?: ContributingEntitlement[];
}
export interface ContributingEntitlement {
    ObjectKeyEntitlement?: string;
    Display?: string;
    Sources?: ContributingEntitlement[];
}
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface NonComplianceDecisionInput {
    ExceptionValidUntil?: Date;
    Reason?: string;
    UidJustification?: string;
    Decision: boolean;
}
export interface ResolveInput {
    ObjectKeys?: string[];
}
export interface RoleComplianceViolation {
    UID_ComplianceRule?: string;
    RuleName?: string;
    DbObjectKey?: string;
    ObjectDisplay?: string;
    ObjectKeyElement?: string;
}
export interface RoleComplianceViolations {
    Violations?: RoleComplianceViolation[];
}
export interface UiActionData {
    Id?: string;
    IsActive: boolean;
    CanExecute: boolean;
    Display?: string;
    ObjectDisplay?: string;
}
export declare class TypedClient {
    readonly PortalPersonMitigatingcontrols: PortalPersonMitigatingcontrolsWrapper;
    readonly PortalPersonRolemembershipsNoncompliance: PortalPersonRolemembershipsNoncomplianceWrapper;
    readonly PortalRules: PortalRulesWrapper;
    readonly PortalRulesMitigatingcontrols: PortalRulesMitigatingcontrolsWrapper;
    readonly PortalRulesViolations: PortalRulesViolationsWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalPersonMitigatingcontrols extends TypedEntity {
    readonly UID_MitigatingControl: IReadValue<string>;
    readonly IsInActive: IReadValue<boolean>;
    readonly UID_PersonWantsOrg: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_MitigatingControl' | 'IsInActive' | 'UID_PersonWantsOrg'>;
}
export declare class PortalPersonRolemembershipsNoncompliance extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly UID_NonCompliance: IReadValue<string>;
    readonly ExceptionValidUntil: IReadValue<Date>;
    readonly IsDecisionMade: IReadValue<boolean>;
    readonly IsExceptionGranted: IReadValue<boolean>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly RiskIndexReduced: IReadValue<number>;
    readonly DecisionDate: IReadValue<Date>;
    readonly DecisionReason: IReadValue<string>;
    readonly RoleFullPath: IReadValue<string>;
    readonly HasMitigation: IReadValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'XObjectKey' | 'XOrigin' | 'XDateInserted' | 'UID_NonCompliance' | 'ExceptionValidUntil' | 'IsDecisionMade' | 'IsExceptionGranted' | 'RiskIndexCalculated' | 'RiskIndexReduced' | 'DecisionDate' | 'DecisionReason' | 'RoleFullPath' | 'HasMitigation'>;
}
export declare class PortalRules extends TypedEntity {
    readonly RuleSeverity: IReadValue<number>;
    readonly isToGrantEver: IReadValue<boolean>;
    readonly IsExceptionAllowed: IReadValue<boolean>;
    readonly IsInActive: IReadValue<boolean>;
    readonly IsWorkingCopy: IReadValue<boolean>;
    readonly Description: IReadValue<string>;
    readonly RuleNumber: IReadValue<string>;
    readonly RiskIndex: IReadValue<number>;
    readonly RiskIndexReduced: IReadValue<number>;
    readonly CountOpen: IReadValue<number>;
    readonly CountClosed: IReadValue<number>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'RuleSeverity' | 'isToGrantEver' | 'IsExceptionAllowed' | 'IsInActive' | 'IsWorkingCopy' | 'Description' | 'RuleNumber' | 'RiskIndex' | 'RiskIndexReduced' | 'CountOpen' | 'CountClosed'>;
}
export declare class PortalRulesMitigatingcontrols extends TypedEntity {
    readonly UID_MitigatingControl: IReadValue<string>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'UID_MitigatingControl'>;
}
export declare class PortalRulesViolations extends TypedEntity {
    readonly DecisionDate: IReadValue<Date>;
    readonly DecisionReason: IReadValue<string>;
    readonly ExceptionValidUntil: IReadValue<Date>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly RiskIndexReduced: IReadValue<number>;
    readonly UID_NonCompliance: IReadValue<string>;
    readonly UID_Person: IReadValue<string>;
    readonly UID_PersonDecisionMade: IReadValue<string>;
    readonly UID_QERJustification: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly State: IReadValue<string>;
    readonly HasMitigation: IReadValue<boolean>;
    /** Returns the static compile time schema for this method. */
    static GetEntitySchema(): StaticSchema<'DecisionDate' | 'DecisionReason' | 'ExceptionValidUntil' | 'RiskIndexCalculated' | 'RiskIndexReduced' | 'UID_NonCompliance' | 'UID_Person' | 'UID_PersonDecisionMade' | 'UID_QERJustification' | 'XObjectKey' | 'State' | 'HasMitigation'>;
}
export declare class PortalPersonMitigatingcontrolsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_Person: string, UID_NonCompliance: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonMitigatingcontrols, unknown>>;
}
export declare class PortalPersonRolemembershipsNoncomplianceWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_Person: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonRolemembershipsNoncompliance, unknown>>;
}
export declare class PortalRulesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        active?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRules, unknown>>;
}
export declare class PortalRulesMitigatingcontrolsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_NonCompliance: string, parametersOptional?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRulesMitigatingcontrols, unknown>>;
}
export declare class PortalRulesViolationsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: {
        approvable?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        state?: string;
        uid_compliancerule?: string;
    }): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRulesViolations, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    portal_compliance_config_get(): MethodDescriptor<ComplianceFeatureConfig>;
    portal_itshop_requests_compliance_get(uid_personwantsorg: string): MethodDescriptor<ComplianceViolation[]>;
    portal_person_mitigatingcontrols_get(UID_Person: string, UID_NonCompliance: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_person_rolememberships_NonCompliance_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_compliance_get(roleTable: string, rolePk: string): MethodDescriptor<RoleComplianceViolations>;
    portal_rules_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, active: string): MethodDescriptor<EntityCollectionData>;
    portal_rules_mitigatingcontrols_get(UID_NonCompliance: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_rules_report_get(uidrule: string): MethodDescriptor<void>;
    portal_rules_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_rules_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, active: string): MethodDescriptor<GroupInfo[]>;
    portal_rules_violations_get(approvable: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, state: string, uid_compliancerule: string): MethodDescriptor<EntityCollectionData>;
    portal_rules_violations_post(uidperson: string, uidnoncompliance: string, inputParameterName: NonComplianceDecisionInput): MethodDescriptor<void>;
    portal_rules_violations_actions_post(uidperson: string, uidnoncompliance: string, inputParameterName: ResolveInput): MethodDescriptor<UiActionData[]>;
    portal_rules_violations_analyzeloss_post(uidperson: string, uidnoncompliance: string, inputParameterName: ActionInput): MethodDescriptor<ContributingEntitlement[]>;
    portal_rules_violations_entitlements_get(uidperson: string, uidnoncompliance: string): MethodDescriptor<ContributingEntitlement[]>;
    portal_rules_violations_result_post(uidperson: string, uidnoncompliance: string, inputParameterName: ActionInput): MethodDescriptor<void>;
    portal_rules_violations_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_rules_violations_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, state: string, uid_compliancerule: string): MethodDescriptor<GroupInfo[]>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_compliance_config_get(): Promise<ComplianceFeatureConfig>;
    /** Returns the compliance check result for the specified request. */
    portal_itshop_requests_compliance_get(uid_personwantsorg: string): Promise<ComplianceViolation[]>;
    portal_person_mitigatingcontrols_get(UID_Person: string, UID_NonCompliance: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_person_rolememberships_NonCompliance_get(UID_Person: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_roles_config_compliance_get(roleTable: string, rolePk: string): Promise<RoleComplianceViolations>;
    portal_rules_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, active: string): Promise<EntityCollectionData>;
    portal_rules_mitigatingcontrols_get(UID_NonCompliance: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): Promise<EntityCollectionData>;
    portal_rules_report_get(uidrule: string): Promise<void>;
    /** Returns data model information about query options for the rules endpoint. */
    portal_rules_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    portal_rules_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, active: string): Promise<GroupInfo[]>;
    portal_rules_violations_get(approvable: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, state: string, uid_compliancerule: string): Promise<EntityCollectionData>;
    portal_rules_violations_post(uidperson: string, uidnoncompliance: string, inputParameterName: NonComplianceDecisionInput): Promise<void>;
    portal_rules_violations_actions_post(uidperson: string, uidnoncompliance: string, inputParameterName: ResolveInput): Promise<UiActionData[]>;
    portal_rules_violations_analyzeloss_post(uidperson: string, uidnoncompliance: string, inputParameterName: ActionInput): Promise<ContributingEntitlement[]>;
    portal_rules_violations_entitlements_get(uidperson: string, uidnoncompliance: string): Promise<ContributingEntitlement[]>;
    portal_rules_violations_result_post(uidperson: string, uidnoncompliance: string, inputParameterName: ActionInput): Promise<void>;
    /** Returns data model information about query options for the rules/violations endpoint. */
    portal_rules_violations_datamodel_get(filter: FilterData[]): Promise<DataModel>;
    portal_rules_violations_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, state: string, uid_compliancerule: string): Promise<GroupInfo[]>;
}
export declare class V2ApiClientMethodFactory {
    portal_compliance_config_get(options?: {}): MethodDescriptor<ComplianceFeatureConfig>;
    portal_itshop_requests_compliance_get(uid_personwantsorg: string, options?: {}): MethodDescriptor<ComplianceViolation[]>;
    portal_person_mitigatingcontrols_get(UID_Person: string, UID_NonCompliance: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_person_rolememberships_NonCompliance_get(UID_Person: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_roles_config_compliance_get(roleTable: string, rolePk: string, options?: {}): MethodDescriptor<RoleComplianceViolations>;
    portal_rules_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        active?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_rules_mitigatingcontrols_get(UID_NonCompliance: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_rules_report_get(uidrule: string, options?: {}): MethodDescriptor<void>;
    portal_rules_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_rules_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
        active?: string;
    }): MethodDescriptor<GroupInfo[]>;
    portal_rules_violations_get(options?: {
        approvable?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        state?: string;
        uid_compliancerule?: string;
    }): MethodDescriptor<EntityCollectionData>;
    portal_rules_violations_post(uidperson: string, uidnoncompliance: string, inputParameterName: NonComplianceDecisionInput, options?: {}): MethodDescriptor<void>;
    portal_rules_violations_actions_post(uidperson: string, uidnoncompliance: string, inputParameterName: ResolveInput, options?: {}): MethodDescriptor<UiActionData[]>;
    portal_rules_violations_analyzeloss_post(uidperson: string, uidnoncompliance: string, inputParameterName: ActionInput, options?: {}): MethodDescriptor<ContributingEntitlement[]>;
    portal_rules_violations_entitlements_get(uidperson: string, uidnoncompliance: string, options?: {}): MethodDescriptor<ContributingEntitlement[]>;
    portal_rules_violations_result_post(uidperson: string, uidnoncompliance: string, inputParameterName: ActionInput, options?: {}): MethodDescriptor<void>;
    portal_rules_violations_datamodel_get(options?: {
        filter?: FilterData[];
    }): MethodDescriptor<DataModel>;
    portal_rules_violations_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
        state?: string;
        uid_compliancerule?: string;
    }): MethodDescriptor<GroupInfo[]>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_compliance_config_get(options?: {}): Promise<ComplianceFeatureConfig>;
    /** Returns the compliance check result for the specified request. */
    portal_itshop_requests_compliance_get(uid_personwantsorg: string, options?: {}): Promise<ComplianceViolation[]>;
    portal_person_mitigatingcontrols_get(UID_Person: string, UID_NonCompliance: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_person_rolememberships_NonCompliance_get(UID_Person: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_roles_config_compliance_get(roleTable: string, rolePk: string, options?: {}): Promise<RoleComplianceViolations>;
    portal_rules_get(options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        active?: string;
    }): Promise<EntityCollectionData>;
    portal_rules_mitigatingcontrols_get(UID_NonCompliance: string, options?: {
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
    }): Promise<EntityCollectionData>;
    portal_rules_report_get(uidrule: string, options?: {}): Promise<void>;
    /** Returns data model information about query options for the rules endpoint. */
    portal_rules_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    portal_rules_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
        active?: string;
    }): Promise<GroupInfo[]>;
    portal_rules_violations_get(options?: {
        approvable?: boolean;
        OrderBy?: string;
        StartIndex?: number;
        PageSize?: number;
        filter?: FilterData[];
        withProperties?: string;
        search?: string;
        state?: string;
        uid_compliancerule?: string;
    }): Promise<EntityCollectionData>;
    portal_rules_violations_post(uidperson: string, uidnoncompliance: string, inputParameterName: NonComplianceDecisionInput, options?: {}): Promise<void>;
    portal_rules_violations_actions_post(uidperson: string, uidnoncompliance: string, inputParameterName: ResolveInput, options?: {}): Promise<UiActionData[]>;
    portal_rules_violations_analyzeloss_post(uidperson: string, uidnoncompliance: string, inputParameterName: ActionInput, options?: {}): Promise<ContributingEntitlement[]>;
    portal_rules_violations_entitlements_get(uidperson: string, uidnoncompliance: string, options?: {}): Promise<ContributingEntitlement[]>;
    portal_rules_violations_result_post(uidperson: string, uidnoncompliance: string, inputParameterName: ActionInput, options?: {}): Promise<void>;
    /** Returns data model information about query options for the rules/violations endpoint. */
    portal_rules_violations_datamodel_get(options?: {
        filter?: FilterData[];
    }): Promise<DataModel>;
    portal_rules_violations_group_get(options?: {
        by?: string;
        def?: string;
        filter?: FilterData[];
        StartIndex?: number;
        PageSize?: number;
        withcount?: boolean;
        state?: string;
        uid_compliancerule?: string;
    }): Promise<GroupInfo[]>;
}
