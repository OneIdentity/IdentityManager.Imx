import { ValType, DisplayColumns, TypedEntity, TypedEntityBuilder, InteractiveTypedEntityBuilder, TimeZoneInfo, DisplayPattern, FkCandidateBuilder, MethodDefinition } from 'imx-qbm-dbts';

var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var TypedClient = /** @class */ (function () {
    function TypedClient(client, translationProvider) {
        this.PortalCalls = new PortalCallsWrapper(client, translationProvider);
        this.PortalCallsHistory = new PortalCallsHistoryWrapper(client, translationProvider);
        this.PortalCallsInteractive = new PortalCallsInteractiveWrapper(client, translationProvider);
    }
    return TypedClient;
}());
var PortalCalls = /** @class */ (function (_super) {
    __extends(PortalCalls, _super);
    function PortalCalls() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_PersonInTrouble = _this.GetEntityValue('UID_PersonInTrouble');
        _this.CallNumber = _this.GetEntityValue('CallNumber');
        _this.ActionHotline = _this.GetEntityValue('ActionHotline');
        _this.UID_TroubleSeverity = _this.GetEntityValue('UID_TroubleSeverity');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalCalls.GetEntitySchema = function () {
        var columns = {
            'UID_PersonInTrouble': {
                ColumnName: 'UID_PersonInTrouble',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'CallNumber': {
                ColumnName: 'CallNumber',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'ActionHotline': {
                ColumnName: 'ActionHotline',
                Type: ValType.Text,
                IsReadOnly: true,
            },
            'UID_TroubleSeverity': {
                ColumnName: 'UID_TroubleSeverity',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'TroubleTicket', Columns: columns };
    };
    return PortalCalls;
}(TypedEntity));
/** @deprecated Use the PortalCalls type. */
var PortalCallsInteractive = /** @class */ (function (_super) {
    __extends(PortalCallsInteractive, _super);
    function PortalCallsInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalCallsInteractive;
}(PortalCalls));
var PortalCallsHistory = /** @class */ (function (_super) {
    __extends(PortalCallsHistory, _super);
    function PortalCallsHistory() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_TroubleTicket = _this.GetEntityValue('UID_TroubleTicket');
        _this.UID_TroubleCallState = _this.GetEntityValue('UID_TroubleCallState');
        _this.TroubleHistoryDate = _this.GetEntityValue('TroubleHistoryDate');
        _this.ObjectKeyPerson = _this.GetEntityValue('ObjectKeyPerson');
        _this.ObjectKeySupporter = _this.GetEntityValue('ObjectKeySupporter');
        _this.ActionHotline = _this.GetEntityValue('ActionHotline');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalCallsHistory.GetEntitySchema = function () {
        var columns = {
            'UID_TroubleTicket': {
                ColumnName: 'UID_TroubleTicket',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_TroubleCallState': {
                ColumnName: 'UID_TroubleCallState',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'TroubleHistoryDate': {
                ColumnName: 'TroubleHistoryDate',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'ObjectKeyPerson': {
                ColumnName: 'ObjectKeyPerson',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'ObjectKeySupporter': {
                ColumnName: 'ObjectKeySupporter',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'ActionHotline': {
                ColumnName: 'ActionHotline',
                Type: ValType.Text,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'TroubleHistory', Columns: columns };
    };
    return PortalCallsHistory;
}(TypedEntity));
/** @deprecated Use the PortalCallsHistory type. */
var PortalCallsHistoryInteractive = /** @class */ (function (_super) {
    __extends(PortalCallsHistoryInteractive, _super);
    function PortalCallsHistoryInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalCallsHistoryInteractive;
}(PortalCallsHistory));
var PortalCallsWrapper = /** @class */ (function () {
    function PortalCallsWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCallsWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/calls');
    };
    PortalCallsWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/calls');
            this.builder = new TypedEntityBuilder(PortalCalls, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCallsWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_calls_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCallsWrapper;
}());
var PortalCallsHistoryWrapper = /** @class */ (function () {
    function PortalCallsHistoryWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCallsHistoryWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/calls/{UID_TroubleTicket}/history');
    };
    PortalCallsHistoryWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/calls/{UID_TroubleTicket}/history');
            this.builder = new TypedEntityBuilder(PortalCallsHistory, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCallsHistoryWrapper.prototype.Get = function (UID_TroubleTicket, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_calls_history_get(UID_TroubleTicket, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCallsHistoryWrapper;
}());
var PortalCallsInteractiveWrapper = /** @class */ (function () {
    function PortalCallsInteractiveWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_calls_interactive_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalCallsInteractiveWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/calls/interactive');
    };
    PortalCallsInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/calls/interactive');
            this.builder = new InteractiveTypedEntityBuilder(PortalCalls, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCallsInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_calls_interactive_put(inputParameterName.InteractiveEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalCallsInteractiveWrapper.prototype.Get_byid = function (UID_TroubleTicket, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_calls_interactive_byid_get(UID_TroubleTicket, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalCallsInteractiveWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_calls_interactive_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCallsInteractiveWrapper;
}());
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
var ApiClientMethodFactory = /** @class */ (function () {
    function ApiClientMethodFactory() {
    }
    ApiClientMethodFactory.prototype.portal_calls_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, scope, callstate) {
        return {
            path: '/portal/calls',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
                {
                    name: 'scope',
                    value: scope,
                    in: 'query'
                },
                {
                    name: 'callstate',
                    value: callstate,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_calls_attachments_directory_get = function (CallId) {
        return {
            path: '/portal/calls/{CallId}/attachments/directory',
            parameters: [
                {
                    name: 'CallId',
                    value: CallId,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_calls_attachments_directory_bypath_get = function (CallId, path) {
        return {
            path: '/portal/calls/{CallId}/attachments/directory/{path}',
            parameters: [
                {
                    name: 'CallId',
                    value: CallId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'path',
                    value: path,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_calls_attachments_directory_bypath_delete = function (CallId, path) {
        return {
            path: '/portal/calls/{CallId}/attachments/directory/{path}',
            parameters: [
                {
                    name: 'CallId',
                    value: CallId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'path',
                    value: path,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_calls_attachments_directory_bypath_post = function (CallId, path) {
        return {
            path: '/portal/calls/{CallId}/attachments/directory/{path}',
            parameters: [
                {
                    name: 'CallId',
                    value: CallId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'path',
                    value: path,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_calls_attachments_file_get = function (CallId, path) {
        return {
            path: '/portal/calls/{CallId}/attachments/file/{path}',
            parameters: [
                {
                    name: 'CallId',
                    value: CallId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'path',
                    value: path,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_calls_attachments_file_delete = function (CallId, path) {
        return {
            path: '/portal/calls/{CallId}/attachments/file/{path}',
            parameters: [
                {
                    name: 'CallId',
                    value: CallId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'path',
                    value: path,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_calls_attachments_file_post = function (CallId, path, inputParameterName) {
        return {
            path: '/portal/calls/{CallId}/attachments/file/{path}',
            parameters: [
                {
                    name: 'CallId',
                    value: CallId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'path',
                    value: path,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_calls_history_get = function (UID_TroubleTicket, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/calls/{UID_TroubleTicket}/history',
            parameters: [
                {
                    name: 'UID_TroubleTicket',
                    value: UID_TroubleTicket,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_calls_configuration_get = function () {
        return {
            path: '/portal/calls/configuration',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_calls_datamodel_get = function (filter) {
        return {
            path: '/portal/calls/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_calls_interactive_get = function () {
        return {
            path: '/portal/calls/interactive',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_calls_interactive_put = function (inputParameterName) {
        return {
            path: '/portal/calls/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_calls_interactive_byid_get = function (UID_TroubleTicket) {
        return {
            path: '/portal/calls/interactive/{UID_TroubleTicket}',
            parameters: [
                {
                    name: 'UID_TroubleTicket',
                    value: UID_TroubleTicket,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    return ApiClientMethodFactory;
}());
/** @deprecated Use the V2Client class for a stable method interface. */
var Client = /** @class */ (function () {
    function Client(apiClient, schemaProvider) {
        this.apiClient = apiClient;
        this.schemaProvider = schemaProvider;
        this.methodFactory = new ApiClientMethodFactory();
        if (!apiClient) {
            throw new Error("The value for the apiClient parameter is undefined.");
        }
    }
    Object.defineProperty(Client.prototype, "schemas", {
        get: function () {
            if (!this.schemaProvider) {
                throw new Error("The schema has not been loaded.");
            }
            return this.schemaProvider.schemas;
        },
        enumerable: false,
        configurable: true
    });
    Client.prototype.loadSchema = function (language) {
        return __awaiter(this, void 0, void 0, function () {
            var headers, dtos, schemas, key, dto, columns;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        headers = {};
                        if (language)
                            headers['Accept-Language'] = language;
                        return [4 /*yield*/, this.apiClient.processRequest({
                                path: '/imx/entityschema',
                                parameters: [],
                                method: 'GET',
                                headers: headers,
                                credentials: 'include',
                                observe: 'response',
                                responseType: 'json'
                            })];
                    case 1:
                        dtos = _a.sent();
                        schemas = {};
                        for (key in dtos) {
                            dto = dtos[key];
                            columns = dto.Properties;
                            columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
                            columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
                            schemas[key] = {
                                TypeName: dto.TypeName,
                                DisplayPattern: new DisplayPattern(dto.DisplayPattern),
                                Display: dto.Display,
                                DisplaySingular: dto.DisplaySingular,
                                FkCandidateRoutes: dto.FkCandidateRoutes,
                                Columns: columns
                            };
                        }
                        this.schemaProvider = { schemas: schemas };
                        return [2 /*return*/];
                }
            });
        });
    };
    Client.prototype.getFkProviderItems = function (methodKey) {
        var _a;
        return new FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
    };
    /** Returns the runtime schema for the named method. */
    Client.prototype.getSchema = function (methodKey) {
        var result = this.schemas[methodKey];
        if (!result)
            throw new Error('Unknown method: ' + methodKey);
        return result;
    };
    Client.prototype.portal_calls_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, scope, callstate, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, scope, callstate), requestOptions);
    };
    /** Returns a list of all files in the root directory. */
    Client.prototype.portal_calls_attachments_directory_get = function (CallId, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_attachments_directory_get(CallId), requestOptions);
    };
    /** Returns a list of all files in the specified directory. */
    Client.prototype.portal_calls_attachments_directory_bypath_get = function (CallId, path, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_attachments_directory_bypath_get(CallId, path), requestOptions);
    };
    /** Provides access to call attachments */
    Client.prototype.portal_calls_attachments_directory_bypath_delete = function (CallId, path, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_attachments_directory_bypath_delete(CallId, path), requestOptions);
    };
    /** Provides access to call attachments */
    Client.prototype.portal_calls_attachments_directory_bypath_post = function (CallId, path, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_attachments_directory_bypath_post(CallId, path), requestOptions);
    };
    /** Downloads the specified file. */
    Client.prototype.portal_calls_attachments_file_get = function (CallId, path, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_attachments_file_get(CallId, path), requestOptions);
    };
    /** Deletes the specified file. */
    Client.prototype.portal_calls_attachments_file_delete = function (CallId, path, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_attachments_file_delete(CallId, path), requestOptions);
    };
    /** Uploads a new file. */
    Client.prototype.portal_calls_attachments_file_post = function (CallId, path, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_attachments_file_post(CallId, path, inputParameterName), requestOptions);
    };
    Client.prototype.portal_calls_history_get = function (UID_TroubleTicket, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_history_get(UID_TroubleTicket, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    Client.prototype.portal_calls_configuration_get = function (requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_configuration_get(), requestOptions);
    };
    /** Returns data model information about query options for the calls endpoint. */
    Client.prototype.portal_calls_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_datamodel_get(filter), requestOptions);
    };
    Client.prototype.portal_calls_interactive_get = function (requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_interactive_get(), requestOptions);
    };
    Client.prototype.portal_calls_interactive_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_interactive_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_calls_interactive_byid_get = function (UID_TroubleTicket, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_interactive_byid_get(UID_TroubleTicket), requestOptions);
    };
    return Client;
}());
var V2ApiClientMethodFactory = /** @class */ (function () {
    function V2ApiClientMethodFactory() {
    }
    V2ApiClientMethodFactory.prototype.portal_calls_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/calls',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_calls_attachments_directory_get = function (/** Unique call identifier */ CallId, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/calls/{CallId}/attachments/directory',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'CallId',
                    value: CallId,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_calls_attachments_directory_bypath_get = function (/** Unique call identifier */ CallId, /** Path to a directory or a file */ path, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/calls/{CallId}/attachments/directory/{path}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'CallId',
                    value: CallId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'path',
                    value: path,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_calls_attachments_directory_bypath_delete = function (/** Unique call identifier */ CallId, /** Path to a directory or a file */ path, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/calls/{CallId}/attachments/directory/{path}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'CallId',
                    value: CallId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'path',
                    value: path,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_calls_attachments_directory_bypath_post = function (/** Unique call identifier */ CallId, /** Path to a directory or a file */ path, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/calls/{CallId}/attachments/directory/{path}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'CallId',
                    value: CallId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'path',
                    value: path,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_calls_attachments_file_get = function (/** Unique call identifier */ CallId, /** Path of the file */ path, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/calls/{CallId}/attachments/file/{path}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'CallId',
                    value: CallId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'path',
                    value: path,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_calls_attachments_file_delete = function (/** Unique call identifier */ CallId, /** Path of the file */ path, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/calls/{CallId}/attachments/file/{path}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'CallId',
                    value: CallId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'path',
                    value: path,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_calls_attachments_file_post = function (/** Unique call identifier */ CallId, /** Path of the file */ path, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/calls/{CallId}/attachments/file/{path}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'CallId',
                    value: CallId,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'path',
                    value: path,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_calls_history_get = function (UID_TroubleTicket, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/calls/{UID_TroubleTicket}/history',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_TroubleTicket',
                    value: UID_TroubleTicket,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_calls_configuration_get = function (options, requestOptions) {
        return {
            path: '/portal/calls/configuration',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_calls_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/calls/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_calls_interactive_get = function (options, requestOptions) {
        return {
            path: '/portal/calls/interactive',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_calls_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/calls/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_calls_interactive_byid_get = function (/** Primary key value UID_TroubleTicket */ UID_TroubleTicket, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/calls/interactive/{UID_TroubleTicket}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_TroubleTicket',
                    value: UID_TroubleTicket,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    return V2ApiClientMethodFactory;
}());
var V2Client = /** @class */ (function () {
    function V2Client(apiClient, schemaProvider) {
        this.apiClient = apiClient;
        this.schemaProvider = schemaProvider;
        this.methodFactory = new V2ApiClientMethodFactory();
        if (!apiClient) {
            throw new Error("The value for the apiClient parameter is undefined.");
        }
    }
    Object.defineProperty(V2Client.prototype, "schemas", {
        get: function () {
            if (!this.schemaProvider) {
                throw new Error("The schema has not been loaded.");
            }
            return this.schemaProvider.schemas;
        },
        enumerable: false,
        configurable: true
    });
    V2Client.prototype.loadSchema = function (language) {
        return __awaiter(this, void 0, void 0, function () {
            var headers, dtos, schemas, key, dto, columns;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        headers = {};
                        if (language)
                            headers['Accept-Language'] = language;
                        return [4 /*yield*/, this.apiClient.processRequest({
                                path: '/imx/entityschema',
                                parameters: [],
                                method: 'GET',
                                headers: headers,
                                credentials: 'include',
                                observe: 'response',
                                responseType: 'json'
                            })];
                    case 1:
                        dtos = _a.sent();
                        schemas = {};
                        for (key in dtos) {
                            dto = dtos[key];
                            columns = dto.Properties;
                            columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
                            columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
                            schemas[key] = {
                                TypeName: dto.TypeName,
                                DisplayPattern: new DisplayPattern(dto.DisplayPattern),
                                Display: dto.Display,
                                DisplaySingular: dto.DisplaySingular,
                                FkCandidateRoutes: dto.FkCandidateRoutes,
                                Columns: columns
                            };
                        }
                        this.schemaProvider = { schemas: schemas };
                        return [2 /*return*/];
                }
            });
        });
    };
    V2Client.prototype.getFkProviderItems = function (methodKey) {
        var _a;
        return new FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
    };
    /** Returns the runtime schema for the named method. */
    V2Client.prototype.getSchema = function (methodKey) {
        var result = this.schemas[methodKey];
        if (!result)
            throw new Error('Unknown method: ' + methodKey);
        return result;
    };
    V2Client.prototype.portal_calls_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_get(options), requestOptions);
    };
    /** Returns a list of all files in the root directory. */
    V2Client.prototype.portal_calls_attachments_directory_get = function (/** Unique call identifier */ CallId, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_attachments_directory_get(CallId, options), requestOptions);
    };
    /** Returns a list of all files in the specified directory. */
    V2Client.prototype.portal_calls_attachments_directory_bypath_get = function (/** Unique call identifier */ CallId, /** Path to a directory or a file */ path, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_attachments_directory_bypath_get(CallId, path, options), requestOptions);
    };
    /** Provides access to call attachments */
    V2Client.prototype.portal_calls_attachments_directory_bypath_delete = function (/** Unique call identifier */ CallId, /** Path to a directory or a file */ path, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_attachments_directory_bypath_delete(CallId, path, options), requestOptions);
    };
    /** Provides access to call attachments */
    V2Client.prototype.portal_calls_attachments_directory_bypath_post = function (/** Unique call identifier */ CallId, /** Path to a directory or a file */ path, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_attachments_directory_bypath_post(CallId, path, options), requestOptions);
    };
    /** Downloads the specified file. */
    V2Client.prototype.portal_calls_attachments_file_get = function (/** Unique call identifier */ CallId, /** Path of the file */ path, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_attachments_file_get(CallId, path, options), requestOptions);
    };
    /** Deletes the specified file. */
    V2Client.prototype.portal_calls_attachments_file_delete = function (/** Unique call identifier */ CallId, /** Path of the file */ path, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_attachments_file_delete(CallId, path, options), requestOptions);
    };
    /** Uploads a new file. */
    V2Client.prototype.portal_calls_attachments_file_post = function (/** Unique call identifier */ CallId, /** Path of the file */ path, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_attachments_file_post(CallId, path, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_calls_history_get = function (UID_TroubleTicket, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_history_get(UID_TroubleTicket, options), requestOptions);
    };
    V2Client.prototype.portal_calls_configuration_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_configuration_get(options), requestOptions);
    };
    /** Returns data model information about query options for the calls endpoint. */
    V2Client.prototype.portal_calls_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_datamodel_get(options), requestOptions);
    };
    V2Client.prototype.portal_calls_interactive_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_interactive_get(options), requestOptions);
    };
    V2Client.prototype.portal_calls_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_interactive_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_calls_interactive_byid_get = function (/** Primary key value UID_TroubleTicket */ UID_TroubleTicket, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_calls_interactive_byid_get(UID_TroubleTicket, options), requestOptions);
    };
    return V2Client;
}());

export { ApiClientMethodFactory, Client, PortalCalls, PortalCallsHistory, PortalCallsHistoryInteractive, PortalCallsHistoryWrapper, PortalCallsInteractive, PortalCallsInteractiveWrapper, PortalCallsWrapper, TypedClient, V2ApiClientMethodFactory, V2Client };
